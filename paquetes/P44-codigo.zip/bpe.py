#!/usr/bin/env python3
"""P44 · LLM por dentro: tokenizador BPE, atención y generación.

Proyecto completo de la ficha P44. Entrena un tokenizador BPE pequeño **solo con la parte de
entrenamiento** del CSV de reseñas, comprueba que reconstruye el texto, implementa la atención escalada a
mano y verifica que cada fila de pesos suma uno, y mide la perplejidad de un modelo diminuto (unigramas y
bigramas) sobre la parte no vista con dos tamaños de contexto. Genera texto con ese modelo. No usa red.

    python bpe.py             # entrena BPE, atención, perplejidad y generación; guarda resultados/
    python bpe.py --comprobar # solo valida el CSV y muestra el resumen del corpus

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import sys
from collections import Counter
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
COLUMNAS = ["id", "texto", "etiqueta", "longitud_palabras", "canal"]
FIN_PALABRA = "</w>"


def cargar_parametros() -> dict:
    # Paso 1 · Lee la semilla, el tamaño de vocabulario BPE, los contextos y el suavizado
    # Por qué: el vocabulario y los contextos se fijan antes de mirar la perplejidad; si se ajustan
    #          después, la comparación entre contextos está elegida a conveniencia.
    # Salida esperada: "parámetros: BPE 300 símbolos · contextos (1, 2) · semilla 20261109"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o restaura datos-ejemplo/parametros.json.
    ruta = DATOS / "parametros.json"
    parametros = json.loads(ruta.read_text(encoding="utf-8"))
    obligatorias = ("semilla", "test_frac", "vocab_bpe", "dim_embeddings", "contextos", "generacion_tokens", "semilla_generacion", "suavizado")
    faltan = [clave for clave in obligatorias if clave not in parametros]
    if faltan:
        raise RuntimeError(f"faltan claves en {ruta.name}: {', '.join(faltan)}")
    if int(parametros["vocab_bpe"]) < 50:
        raise RuntimeError("«vocab_bpe» es demasiado pequeño para un BPE útil")
    return parametros


def cargar_corpus() -> dict:
    # Paso 2 · Carga y valida el CSV de reseñas (600 filas × 5 columnas, ids únicos)
    # Por qué: el tokenizador aprende del texto; una fila rota o un id repetido contaminaría la partición.
    # Salida esperada: "corpus: 600 filas · 5 columnas · textos unicos 367"
    # Si falla: RuntimeError → falta datos-ejemplo/resenas-texto.csv o cambió de forma.
    ruta = DATOS / "resenas-texto.csv"
    with ruta.open(encoding="utf-8", newline="") as f:
        lector = csv.DictReader(f)
        columnas = lector.fieldnames or []
        filas = [fila for fila in lector if fila]
    if columnas != COLUMNAS or len(filas) != 600:
        raise RuntimeError(f"CSV inesperado: {columnas} y {len(filas)} filas")
    if len({fila["id"] for fila in filas}) != 600:
        raise RuntimeError("hay ids repetidos en el CSV")
    return {"filas": filas, "textos": [fila["texto"] for fila in filas], "etiquetas": [fila["etiqueta"] for fila in filas]}


def partir(corpus: dict, test_frac: float, semilla: int) -> list:
    # Paso 3 · Parte agrupando por texto completo, como en P43, antes de entrenar el tokenizador
    # Por qué: las reseñas repetidas son plantillas; si una copia cae en train y otra en test, la
    #          perplejidad del test está midiendo texto ya visto.
    # Salida esperada: "particion: train 418 filas · test 182 filas · textos compartidos 0"
    # Si falla: RuntimeError → la proporción deja una parte vacía.
    grupos = {}
    for indice, texto in enumerate(corpus["textos"]):
        grupos.setdefault(texto.lower(), []).append(indice)
    claves = sorted(grupos)
    random.Random(semilla).shuffle(claves)
    n_test = round(len(claves) * test_frac)
    if n_test <= 0:
        raise RuntimeError("la partición de test está vacía")
    en_test = set(claves[:n_test])
    return [{"indice": i, "particion": "test" if t.lower() in en_test else "train"} for i, t in enumerate(corpus["textos"])]


def _palabra_a_simbolos(palabra: str) -> list:
    return list(palabra) + [FIN_PALABRA]


def entrenar_bpe(textos: list, vocab_size: int) -> dict:
    # Paso 4 · Entrena el BPE solo con el texto de entrenamiento
    # Por qué: aprender las fusiones con todo el corpus y luego medir perplejidad en el resto es fuga; el
    #          vocabulario tiene que salir del train.
    # Salida esperada: "bpe: 300 símbolos · 152 fusiones · vocabulario único"
    # Si falla: RuntimeError → el texto de entrenamiento no tiene palabras.
    frecuencia = Counter()
    for texto in textos:
        for palabra in texto.split(" "):
            frecuencia[palabra] += 1
    if not frecuencia:
        raise RuntimeError("no hay palabras de entrenamiento")
    palabras = {palabra: _palabra_a_simbolos(palabra) for palabra in frecuencia}
    vocabulario = set(simbolo for simbolos in palabras.values() for simbolo in simbolos)
    fusiones = []
    while len(vocabulario) < vocab_size:
        pares = Counter()
        for palabra, simbolos in palabras.items():
            peso = frecuencia[palabra]
            for izquierda, derecha in zip(simbolos, simbolos[1:]):
                pares[(izquierda, derecha)] += peso
        if not pares:
            break
        # Desempate determinista por el propio par y sin repetir símbolos: un merge cuyo resultado ya está
        # en el vocabulario solo haría crecer la lista de fusiones sin añadir un símbolo nuevo.
        elegido = None
        for (izquierda, derecha), _ in sorted(pares.items(), key=lambda elemento: (-elemento[1], elemento[0])):
            if izquierda + derecha not in vocabulario:
                elegido = (izquierda, derecha)
                break
        if elegido is None:
            break
        izquierda, derecha = elegido
        nuevo = izquierda + derecha
        fusiones.append((izquierda, derecha))
        for palabra, simbolos in palabras.items():
            actualizado = []
            i = 0
            while i < len(simbolos):
                if i + 1 < len(simbolos) and simbolos[i] == izquierda and simbolos[i + 1] == derecha:
                    actualizado.append(nuevo)
                    i += 2
                else:
                    actualizado.append(simbolos[i])
                    i += 1
            palabras[palabra] = actualizado
        vocabulario.add(nuevo)
    # El vocabulario real del BPE es el conjunto que fue creciendo: base (caracteres + cierre) más cada
    # símbolo nuevo de las fusiones. No se deduce del texto final porque un símbolo intermedio puede
    # haberse consumido en una fusión posterior y aun así ser válido al codificar.
    simbolos_finales = sorted(vocabulario)
    return {
        "fusiones": fusiones,
        "vocabulario": simbolos_finales,
        "indice": {simbolo: i for i, simbolo in enumerate(simbolos_finales)},
        "palabras_entrenamiento": palabras,
    }


def codificar_palabra(palabra: str, bpe: dict) -> list:
    simbolos = _palabra_a_simbolos(palabra)
    for izquierda, derecha in bpe["fusiones"]:
        actualizado = []
        i = 0
        while i < len(simbolos):
            if i + 1 < len(simbolos) and simbolos[i] == izquierda and simbolos[i + 1] == derecha:
                actualizado.append(izquierda + derecha)
                i += 2
            else:
                actualizado.append(simbolos[i])
                i += 1
        simbolos = actualizado
    return simbolos


def codificar(texto: str, bpe: dict) -> list:
    tokens = []
    for palabra in texto.split(" "):
        tokens.extend(codificar_palabra(palabra, bpe))
    return tokens


def decodificar(tokens: list) -> str:
    """Reconstruye el texto: cada `</w>` cierra una palabra y las palabras se unen con un espacio."""
    palabras = []
    actual = ""
    for token in tokens:
        if token.endswith(FIN_PALABRA):
            actual += token[: -len(FIN_PALABRA)]
            palabras.append(actual)
            actual = ""
        else:
            actual += token
    if actual:
        palabras.append(actual)
    return " ".join(palabras)


def embeddings_token(token: str, dim: int, semilla: int) -> list:
    resumen = hashlib.sha256(f"{semilla}:{token}".encode("utf-8")).hexdigest()
    vector = [0.0] * dim
    for i in range(dim):
        cubo = int(resumen[i * 2: i * 2 + 2], 16) % dim
        signo = 1.0 if int(resumen[i * 2], 16) % 2 == 0 else -1.0
        vector[cubo] += signo
    norma = math.sqrt(sum(valor * valor for valor in vector)) or 1.0
    return [valor / norma for valor in vector]


def softmax(fila: list) -> list:
    maximo = max(fila)
    exponenciales = [math.exp(valor - maximo) for valor in fila]
    suma = sum(exponenciales)
    return [valor / suma for valor in exponenciales]


def atencion(vectores: list) -> list:
    # Paso 5 · Implementa la atención escalada a mano y comprueba que cada fila suma uno
    # Por qué: si el softmax está mal, los pesos no suman uno; la comprobación numérica es la prueba de
    #          que la atención está implementada y no importada.
    # Salida esperada: "atencion: 8 consultas · suma de pesos 1.000000"
    # Si falla: ValueError → la secuencia está vacía o los vectores tienen dimensiones distintas.
    if not vectores:
        raise ValueError("la secuencia de atención está vacía")
    dim = len(vectores[0])
    if any(len(vector) != dim for vector in vectores):
        raise ValueError("los vectores de la secuencia tienen dimensiones distintas")
    escala = math.sqrt(dim)
    pesos = []
    for consulta in vectores:
        puntuaciones = [sum(consulta[d] * clave[d] for d in range(dim)) / escala for clave in vectores]
        pesos.append(softmax(puntuaciones))
    return pesos


def contar_ngramas(secuencias: list) -> dict:
    unigramas = Counter()
    bigramas = Counter()
    for secuencia in secuencias:
        for token in secuencia:
            unigramas[token] += 1
        for anterior, siguiente in zip(secuencia, secuencia[1:]):
            bigramas[(anterior, siguiente)] += 1
    return {"unigramas": unigramas, "bigramas": bigramas, "total": sum(unigramas.values())}


def perplejidad(secuencias: list, orden: int, modelo: dict, vocabulario: int, suavizado: float) -> float:
    # Paso 6 · Mide la perplejidad sobre texto no visto con dos tamaños de contexto
    # Por qué: la perplejidad del train no dice nada; se mide sobre el test con la misma partición, y el
    #          «orden» (unigrama o bigrama) es el tamaño de contexto que se compara.
    # Salida esperada: "perplejidad: contexto 1 = … · contexto 2 = …"
    # Si falla: ZeroDivisionError → no hay tokens de evaluación o el suavizado es 0.
    log_verosimilitud = 0.0
    total = 0
    for secuencia in secuencias:
        anterior = None
        for token in secuencia:
            if orden == 1 or anterior is None:
                probabilidad = (modelo["unigramas"][token] + suavizado) / (modelo["total"] + suavizado * vocabulario)
            else:
                probabilidad = (modelo["bigramas"][(anterior, token)] + suavizado) / (
                    modelo["unigramas"][anterior] + suavizado * vocabulario
                )
            log_verosimilitud += math.log(probabilidad)
            total += 1
            anterior = token
    if total == 0:
        raise ZeroDivisionError("no hay tokens para evaluar la perplejidad")
    return math.exp(-log_verosimilitud / total)


def generar(modelo: dict, bpe: dict, vocabulario: list, n_tokens: int, semilla: int, suavizado: float) -> list:
    # Paso 7 · Genera texto con el modelo diminuto bigrama, con semilla declarada
    # Por qué: la generación es la prueba de que el modelo predice siguiente token; se muestrea del bigrama
    #          con el mismo suavizado y se declara que un modelo diminuto repite y no «conversa».
    # Salida esperada: una secuencia de tokens y su texto decodificado
    # Si falla: ValueError → el vocabulario está vacío.
    if not vocabulario:
        raise ValueError("el vocabulario está vacío")
    rng = random.Random(semilla)
    terminadas = [token for token in vocabulario if token.endswith(FIN_PALABRA)]
    anterior = terminadas[0] if terminadas else bpe["vocabulario"][0]
    tokens = [anterior]
    for _ in range(n_tokens - 1):
        candidatos = []
        pesos = []
        for token in vocabulario:
            candidatos.append(token)
            pesos.append((modelo["bigramas"][(anterior, token)] + suavizado) / (modelo["unigramas"][anterior] + suavizado * len(vocabulario)))
        total = sum(pesos)
        acumulado = 0.0
        sorteo = rng.random() * total
        elegido = candidatos[-1]
        for token, peso in zip(candidatos, pesos):
            acumulado += peso
            if sorteo <= acumulado:
                elegido = token
                break
        tokens.append(elegido)
        anterior = elegido
    return tokens


def ejecutar(parametros: dict) -> dict:
    """Entrena, verifica y mide; devuelve todo lo que la puerta necesita."""
    corpus = cargar_corpus()
    asignacion = partir(corpus, float(parametros["test_frac"]), int(parametros["semilla"]))
    indices_train = [fila["indice"] for fila in asignacion if fila["particion"] == "train"]
    indices_test = [fila["indice"] for fila in asignacion if fila["particion"] == "test"]
    textos_train = [corpus["textos"][i] for i in indices_train]
    textos_test = [corpus["textos"][i] for i in indices_test]
    textos_unicos_train = sorted({texto for texto in textos_train})
    claves_train = {texto.lower() for texto in textos_train}
    claves_test = {texto.lower() for texto in textos_test}

    bpe = entrenar_bpe(textos_unicos_train, int(parametros["vocab_bpe"]))
    reconstruidos = sum(1 for texto in textos_test if decodificar(codificar(texto, bpe)) == texto)
    tokens_por_palabra = [
        len(codificar_palabra(palabra, bpe)) for texto in textos_unicos_train for palabra in texto.split(" ") if palabra
    ]

    muestra = textos_test[0].split(" ")[:8]
    vectores = [embeddings_token(token, int(parametros["dim_embeddings"]), int(parametros["semilla"])) for token in muestra]
    pesos = atencion(vectores)
    sumas = [sum(fila) for fila in pesos]

    modelo = contar_ngramas([codificar(texto, bpe) for texto in textos_unicos_train])
    secuencias_test = [codificar(texto, bpe) for texto in textos_test]
    vocab = bpe["vocabulario"]
    perplejidades = {
        orden: perplejidad(secuencias_test, int(orden), modelo, len(vocab), float(parametros["suavizado"]))
        for orden in parametros["contextos"]
    }

    tokens_generados = generar(modelo, bpe, vocab, int(parametros["generacion_tokens"]), int(parametros["semilla_generacion"]), float(parametros["suavizado"]))
    texto_generado = decodificar(tokens_generados)

    print(f"corpus: {len(corpus['filas'])} filas · {len(COLUMNAS)} columnas · textos unicos {len({t.lower() for t in corpus['textos']})}")
    print(
        f"particion: train {len(indices_train)} filas · test {len(indices_test)} filas"
        f" · textos compartidos {len(claves_train & claves_test)}"
    )
    print(
        f"bpe: {len(bpe['vocabulario'])} simbolos · {len(bpe['fusiones'])} fusiones"
        f" · test reconstruido {reconstruidos}/{len(textos_test)} textos"
    )
    print(f"bpe: {sum(tokens_por_palabra) / len(tokens_por_palabra):.2f} tokens por palabra (media en train)")
    print(
        f"atencion: {len(pesos)} consultas · suma de pesos min {min(sumas):.12f} max {max(sumas):.12f}"
    )
    print("perplejidad (test): " + " · ".join(f"contexto {orden} = {valor:.3f}" for orden, valor in sorted(perplejidades.items())))
    print(f"generacion (semilla {int(parametros['semilla_generacion'])}): {texto_generado[:120]}")
    return {
        "corpus": corpus,
        "asignacion": asignacion,
        "bpe": bpe,
        "textos_test": textos_test,
        "textos_unicos_train": textos_unicos_train,
        "reconstruidos": reconstruidos,
        "tokens_por_palabra": tokens_por_palabra,
        "pesos": pesos,
        "sumas": sumas,
        "modelo": modelo,
        "perplejidades": perplejidades,
        "tokens_generados": tokens_generados,
        "texto_generado": texto_generado,
        "claves_train": claves_train,
        "claves_test": claves_test,
        "secuencias_test": secuencias_test,
        "dim": int(parametros["dim_embeddings"]),
    }


def guardar(resultados: dict, parametros: dict) -> None:
    # Paso 8 · Guarda el tokenizador, los pesos de atención, la perplejidad y la generación
    # Por qué: el vocabulario y las fusiones son el artefacto del entrenamiento; sin ellos no se puede
    #          comprobar que el BPE salió del train ni reconstruir el texto.
    # Salida esperada: "resultados: tokenizador.json, atencion.csv, perplejidad.csv, generacion.txt"
    # Si falla: PermissionError → resultados/ no es escribible; ejecuta desde codigo/.
    RESULTADOS.mkdir(parents=True, exist_ok=True)
    tokenizador = {
        "vocabulario": resultados["bpe"]["vocabulario"],
        "fusiones": [list(par) for par in resultados["bpe"]["fusiones"]],
        "tokens_por_palabra": sum(resultados["tokens_por_palabra"]) / len(resultados["tokens_por_palabra"]),
        "reconstruidos": resultados["reconstruidos"],
        "textos_test": len(resultados["textos_test"]),
    }
    (RESULTADOS / "tokenizador.json").write_text(json.dumps(tokenizador, ensure_ascii=False, indent=2), encoding="utf-8")
    with (RESULTADOS / "atencion.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["consulta", "suma_pesos", "max_peso", "atendido_en_posicion"])
        for indice, fila in enumerate(resultados["pesos"]):
            maximo = max(fila)
            posicion = fila.index(maximo)
            escritor.writerow([indice, f"{sum(fila):.12f}", f"{maximo:.6f}", posicion])
    with (RESULTADOS / "perplejidad.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["contexto", "perplejidad"])
        for orden, valor in sorted(resultados["perplejidades"].items()):
            escritor.writerow([orden, f"{valor:.6f}"])
    with (RESULTADOS / "generacion.txt").open("w", encoding="utf-8") as f:
        f.write(" ".join(resultados["tokens_generados"]) + "\n\n" + resultados["texto_generado"] + "\n")
    print("resultados: tokenizador.json, atencion.csv, perplejidad.csv, generacion.txt")


def main(argv: list) -> int:
    try:
        parametros = cargar_parametros()
        if "--comprobar" in argv:
            corpus = cargar_corpus()
            print(f"corpus: {len(corpus['filas'])} filas · textos unicos {len({t.lower() for t in corpus['textos']})}")
            return 0
        print("== P44 · LLM por dentro: tokenizador BPE, atencion y generacion ==")
        resultados = ejecutar(parametros)
        guardar(resultados, parametros)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
