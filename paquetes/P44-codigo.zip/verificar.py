#!/usr/bin/env python3
"""Puerta del proyecto P44 (LLM por dentro: BPE, atención y generación).

Comprueba el resultado de verdad, sin escribir en disco y sin red: corpus y partición sin fuga, BPE
entrenado solo con el train y que reconstruye el texto, tokens por palabra medidos, atención con filas que
suman uno, perplejidad sobre el test con dos contextos, generación reproducible, adaptadores simulados de
arXiv y Semantic Scholar y código offline. Termina en RESULTADO: VERDE (código 0) o ROJO (código 1).

Uso:
    python verificar.py

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

sys.dont_write_bytecode = True  # la puerta no escribe nada: ni resultados ni caché de bytecode

import adaptador
import bpe

fallos: list = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P44 · LLM por dentro: BPE, atencion y generacion ==")

    # Paso 1 · Comprueba los parámetros, el corpus y la partición sin fuga
    # Por qué: el tokenizador y la perplejidad se miden sobre una partición fija; si train y test comparten
    #          textos repetidos, la perplejidad del test no sería fuera de muestra.
    # Salida esperada: "OK parámetros", "OK corpus", "OK partición".
    # Si falla: RuntimeError de cargar_parametros → falta datos-ejemplo/parametros.json.
    parametros = bpe.cargar_parametros()
    ok(
        (int(parametros["semilla"]), int(parametros["vocab_bpe"]), tuple(int(c) for c in parametros["contextos"])) == (20261109, 300, (1, 2)),
        f"parámetros: semilla {int(parametros['semilla'])} · BPE {int(parametros['vocab_bpe'])} símbolos · contextos {tuple(int(c) for c in parametros['contextos'])}",
    )
    corpus = bpe.cargar_corpus()
    ok(
        len(corpus["filas"]) == 600 and len(bpe.COLUMNAS) == 5 and len({texto.lower() for texto in corpus["textos"]}) == 367,
        f"corpus: {len(corpus['filas'])} filas · {len(bpe.COLUMNAS)} columnas · {len({texto.lower() for texto in corpus['textos']})} textos únicos",
    )
    resultados = bpe.ejecutar(parametros)
    claves_train = resultados["claves_train"]
    claves_test = resultados["claves_test"]
    ok(
        len(claves_train) + 0 == len({texto.lower() for texto in resultados["corpus"]["textos"] if texto.lower() in claves_train})
        and not (claves_train & claves_test)
        and len(resultados["textos_test"]) > 50,
        f"partición: train y test sin textos compartidos · test {len(resultados['textos_test'])} textos",
    )
    repetida = bpe.partir(corpus, float(parametros["test_frac"]), int(parametros["semilla"]))
    ok(repetida == resultados["asignacion"], "reproducibilidad: la misma semilla devuelve la misma partición")

    # Paso 2 · Comprueba el BPE: entrenado solo con el train y que reconstruye el texto
    # Por qué: un BPE entrenado con el test es la fuga típica de la ficha; se reentrena desde el train y se
    #          comparan las fusiones, y se exige que el texto de prueba vuelva idéntico.
    # Salida esperada: "OK BPE: ... fusiones idénticas al reentrenar con el train" y "OK reconstrucción: 182/182".
    # Si falla: las fusiones no coinciden → el BPE usó texto de test.
    bpe_reentrenado = bpe.entrenar_bpe(resultados["textos_unicos_train"], int(parametros["vocab_bpe"]))
    ok(
        bpe_reentrenado["fusiones"] == resultados["bpe"]["fusiones"] and bpe_reentrenado["vocabulario"] == resultados["bpe"]["vocabulario"],
        f"BPE: reentrenado solo con el train y {len(resultados['bpe']['fusiones'])} fusiones idénticas",
    )
    caracteres = set()
    for texto in resultados["textos_unicos_train"]:
        for palabra in texto.split(" "):
            caracteres.update(palabra)
    ok(
        len(resultados["bpe"]["vocabulario"]) == len(caracteres) + 1 + len(resultados["bpe"]["fusiones"]),
        f"BPE: {len(resultados['bpe']['vocabulario'])} símbolos = {len(caracteres)} caracteres + cierre + {len(resultados['bpe']['fusiones'])} fusiones",
    )
    reconstruidos = sum(1 for texto in resultados["textos_test"] if bpe.decodificar(bpe.codificar(texto, resultados["bpe"])) == texto)
    ok(
        reconstruidos == len(resultados["textos_test"]),
        f"reconstrucción: {reconstruidos}/{len(resultados['textos_test'])} textos de test vuelven idénticos",
    )
    media_tokens = sum(resultados["tokens_por_palabra"]) / len(resultados["tokens_por_palabra"])
    ok(1.0 <= media_tokens <= 2.0, f"tokens por palabra: {media_tokens:.2f} de media medidos en el train")

    # Paso 3 · Comprueba la atención: cada fila de pesos suma uno y no hay pesos negativos
    # Por qué: la atención se implementa a mano; si el softmax está mal, las filas no suman uno y la
    #          comprobación numérica lo caza.
    # Salida esperada: "OK atención: 8 consultas y todas las filas suman 1".
    # Si falla: suma distinta de 1 → softmax mal normalizado o escala mal aplicada.
    pesos = resultados["pesos"]
    ok(
        len(pesos) == 8 and all(len(fila) == 8 for fila in pesos),
        f"atención: matriz {len(pesos)}×{len(pesos[0])} para una secuencia de {len(pesos)} tokens",
    )
    ok(
        all(abs(sum(fila) - 1.0) < 1e-12 and all(valor >= 0.0 for valor in fila) for fila in pesos),
        f"atención: las {len(pesos)} filas suman 1 (tolerancia 1e-12) y no hay pesos negativos",
    )
    otra_vez = bpe.atencion([
        bpe.embeddings_token(token, resultados["dim"], int(parametros["semilla"]))
        for token in resultados["textos_test"][0].split(" ")[:8]
    ])
    ok(otra_vez == pesos, "atención: determinista con la misma secuencia y la misma semilla")

    # Paso 4 · Comprueba la perplejidad sobre el test y la ventaja del contexto mayor
    # Por qué: la perplejidad del train no demuestra nada; se recalcula desde el modelo y las secuencias de
    #          test, y se comprueba que los dos contextos declarados se comparan.
    # Salida esperada: "OK perplejidad: contexto 1 = … · contexto 2 = … (menor)".
    # Si falla: el bigrama no mejora al unigrama → el modelo o las secuencias de evaluación están mal.
    perplejidades = resultados["perplejidades"]
    ok(
        all(valor > 1.0 and valor == valor and valor != float("inf") for valor in perplejidades.values()),
        "perplejidad: " + " · ".join(f"contexto {orden} = {valor:.3f}" for orden, valor in sorted(perplejidades.items())),
    )
    ok(perplejidades[2] < perplejidades[1], f"perplejidad: el contexto 2 ({perplejidades[2]:.3f}) mejora al contexto 1 ({perplejidades[1]:.3f})")
    recalculadas = {
        orden: bpe.perplejidad(resultados["secuencias_test"], int(orden), resultados["modelo"], len(resultados["bpe"]["vocabulario"]), float(parametros["suavizado"]))
        for orden in parametros["contextos"]
    }
    ok(
        all(abs(recalculadas[orden] - perplejidades[orden]) < 1e-9 for orden in recalculadas),
        "perplejidad: recalculada sobre las secuencias de test, no sobre el train",
    )
    ok(
        len(resultados["secuencias_test"]) == len(resultados["textos_test"])
        and all(bpe.decodificar(secuencia) == texto for secuencia, texto in zip(resultados["secuencias_test"], resultados["textos_test"])),
        "perplejidad: las secuencias evaluadas son exactamente los textos de test",
    )

    # Paso 5 · Comprueba la generación: longitud, vocabulario y reproducibilidad
    # Por qué: generar con un modelo diminuto es una demostración, no una promesa; se fija la semilla y el
    #          número de tokens para poder repetir la salida.
    # Salida esperada: "OK generación: 20 tokens del vocabulario y reproducible".
    # Si falla: tokens fuera del vocabulario o generación distinta con la misma semilla.
    tokens = resultados["tokens_generados"]
    ok(
        len(tokens) == int(parametros["generacion_tokens"]) and all(token in resultados["bpe"]["indice"] for token in tokens),
        f"generación: {len(tokens)} tokens del vocabulario (semilla {int(parametros['semilla_generacion'])})",
    )
    repetida_gen = bpe.generar(resultados["modelo"], resultados["bpe"], resultados["bpe"]["vocabulario"], int(parametros["generacion_tokens"]), int(parametros["semilla_generacion"]), float(parametros["suavizado"]))
    ok(repetida_gen == tokens, "generación: la misma semilla reproduce la misma secuencia")

    # Paso 6 · Comprueba los adaptadores simulados de arXiv y Semantic Scholar
    # Por qué: los papers se citan con su licencia; el adaptador no debe inventar registros fuera del
    #          fixture ni guardar claves.
    # Salida esperada: "OK arXiv: 3 papers con metadatos CC0-1.0" y "OK Semantic Scholar: 3 registros de citas".
    # Si falla: ErrorDeFixture → falta fixtures/arxiv.json o fixtures/semantic-scholar.json.
    arxiv = adaptador.AdaptadorArXiv()
    scholar = adaptador.AdaptadorSemanticScholar()
    ids_arxiv = [paper["id"] for paper in arxiv.papers()]
    ok(
        len(ids_arxiv) == 3 and arxiv.datos["licencia_metadatos"] == "CC0-1.0",
        f"arXiv: {len(ids_arxiv)} papers con metadatos CC0-1.0 · {', '.join(ids_arxiv)}",
    )
    ok(
        len(scholar.registros()) == 3 and all(scholar.citas(identificador) > 0 for identificador in ids_arxiv),
        "Semantic Scholar: 3 registros con citas y licencia " + scholar.datos["licencia_datos"],
    )
    try:
        arxiv.paper("0000.00000")
        fallo_esperado = False
    except adaptador.ErrorDeFixture:
        fallo_esperado = True
    ok(fallo_esperado, "adaptadores: un id fuera del fixture lanza ErrorDeFixture (no inventa metadatos)")

    # Paso 7 · Comprueba que el código es offline y no lleva claves
    # Por qué: la entrega se comparte y la puerta se ejecuta sin red; la clave de Semantic Scholar, si se
    #          usara, iría en una variable de entorno.
    # Salida esperada: "el código no hace peticiones de red" y "no contiene claves".
    # Si falla: aparece un http(s) o un patrón de token → quítalo antes de empaquetar.
    fuentes = [bpe.RAIZ / "bpe.py", bpe.RAIZ / "adaptador.py",
               bpe.DATOS / "fixtures" / "arxiv.json", bpe.DATOS / "fixtures" / "semantic-scholar.json"]
    texto = "\n".join(ruta.read_text(encoding="utf-8") for ruta in fuentes)
    ok("http://" not in texto and "https://" not in texto, "el código del proyecto no hace peticiones de red")
    ok(
        not any(patron in texto for patron in ("ghp_", "github_pat_", "Authorization:", "api_key", "x-api-key")),
        "el código del proyecto no contiene claves ni cabeceras de autorización",
    )

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
