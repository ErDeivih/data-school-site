#!/usr/bin/env python3
"""Adaptadores simulados de arXiv y Semantic Scholar (sin red).

El proyecto no descarga papers: lee dos **respuestas capturadas** con la forma de cada API.
`fixtures/arxiv.json` guarda metadatos (id, título, autores, año) y declara la licencia **CC0-1.0** de los
metadatos; `fixtures/semantic-scholar.json` guarda recuentos de citas y la licencia por registro
(**CC-BY-NC-4.0** con atribución). Los recuentos de citas del fixture son ilustrativos, no una consulta
real; los metadatos y los títulos sí son de los papers citados.

Con red, arXiv responde sin clave y Semantic Scholar pide una clave gratuita que va en variable de
entorno; esta entrega no incluye esas llamadas.
"""
from __future__ import annotations

import json
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
FIXTURE_ARXIV = RAIZ / "datos-ejemplo" / "fixtures" / "arxiv.json"
FIXTURE_S2 = RAIZ / "datos-ejemplo" / "fixtures" / "semantic-scholar.json"


class ErrorDeFixture(RuntimeError):
    """El fixture no existe, no tiene la forma declarada o no cubre el id pedido."""


class AdaptadorArXiv:
    """Cliente simulado de arXiv: devuelve los metadatos del fixture y su licencia CC0-1.0."""

    def __init__(self, ruta: Path = FIXTURE_ARXIV):
        # Paso 1 · Carga los metadatos y comprueba la licencia declarada
        # Por qué: el contenido de los e-prints no se redistribuye; lo que se guarda son metadatos CC0 y su
        #          licencia se cita en el README.
        # Salida esperada: "arxiv: 3 papers · metadatos CC0-1.0 · capturado 2026-11-07"
        # Si falla: ErrorDeFixture → falta datos-ejemplo/fixtures/arxiv.json.
        ruta = Path(ruta)
        if not ruta.exists():
            raise ErrorDeFixture(f"no existe el fixture {ruta}")
        datos = json.loads(ruta.read_text(encoding="utf-8"))
        if datos.get("licencia_metadatos") != "CC0-1.0":
            raise ErrorDeFixture("el fixture de arXiv no declara metadatos CC0-1.0")
        if not datos.get("papers"):
            raise ErrorDeFixture("el fixture de arXiv no trae papers")
        self.datos = datos
        self._por_id = {paper["id"]: paper for paper in datos["papers"]}

    def papers(self) -> list:
        return list(self.datos["papers"])

    def paper(self, identificador: str) -> dict:
        if identificador not in self._por_id:
            raise ErrorDeFixture(f"paper fuera del fixture: {identificador}")
        return dict(self._por_id[identificador])


class AdaptadorSemanticScholar:
    """Cliente simulado de Semantic Scholar: citas y licencia por registro."""

    def __init__(self, ruta: Path = FIXTURE_S2):
        # Paso 2 · Carga los recuentos de citas y la licencia de los datos
        # Por qué: Semantic Scholar se usa para contrastar citas, no para descargar el paper; la clave es
        #          personal y aquí no hay ninguna.
        # Salida esperada: "semantic-scholar: 3 registros · licencia CC-BY-NC-4.0 · capturado 2026-11-07"
        # Si falla: ErrorDeFixture → falta datos-ejemplo/fixtures/semantic-scholar.json.
        ruta = Path(ruta)
        if not ruta.exists():
            raise ErrorDeFixture(f"no existe el fixture {ruta}")
        datos = json.loads(ruta.read_text(encoding="utf-8"))
        if not datos.get("licencia_datos"):
            raise ErrorDeFixture("el fixture de Semantic Scholar no declara licencia")
        if not datos.get("papers"):
            raise ErrorDeFixture("el fixture de Semantic Scholar no trae registros")
        self.datos = datos
        self._por_id = {paper["id"]: paper for paper in datos["papers"]}

    def registros(self) -> list:
        return list(self.datos["papers"])

    def citas(self, identificador: str) -> int:
        if identificador not in self._por_id:
            raise ErrorDeFixture(f"registro fuera del fixture: {identificador}")
        return int(self._por_id[identificador]["citas"])


if __name__ == "__main__":
    arxiv = AdaptadorArXiv()
    scholar = AdaptadorSemanticScholar()
    print(f"arxiv: {len(arxiv.papers())} papers · metadatos {arxiv.datos['licencia_metadatos']} · capturado {arxiv.datos['capturado']}")
    print(f"semantic-scholar: {len(scholar.registros())} registros · licencia {scholar.datos['licencia_datos']}")
    for paper in arxiv.papers():
        print(f"  {paper['id']} · {paper['titulo']} ({paper['anio']}) · citas {scholar.citas(paper['id'])}")
