# P44 · LLM por dentro: tokenizador BPE, atención y generación — código ejecutable

Construye las tres piezas de un LLM en pequeño: un **tokenizador BPE** entrenado solo con la parte de
entrenamiento de las 600 reseñas, la **atención escalada implementada a mano** (con comprobación de que
cada fila de pesos suma uno) y un **modelo diminuto de unigramas/bigramas** que genera texto y mide la
**perplejidad sobre la parte no vista** con dos tamaños de contexto. No usa red: los papers se citan con
dos fixtures capturados. Es el código que acompaña a la ficha
`../../fichas-portfolio/p44-llm-por-dentro.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: solo la biblioteca estándar (`csv`, `hashlib`, `math`, `random`,
  `collections`).
- No hace falta red ni clave: no se descarga ningún modelo ni paper.

## Instalación

```powershell
cd proyectos/p44-llm-por-dentro/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` no instala nada: el proyecto es de biblioteca estándar.

## Orden de ejecución

```powershell
python bpe.py --comprobar   # solo valida el CSV y muestra el resumen del corpus
python bpe.py               # entrena BPE, atención, perplejidad y generación; guarda resultados/
python adaptador.py         # comprueba los fixtures de arXiv y Semantic Scholar
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta es **solo stdout** (no escribe en disco) y no usa red. Comprueba **22 cosas**: el corpus
(600 filas × 5 columnas, 367 textos únicos), la partición sin fuga (train y test no comparten ningún
texto), que el BPE se **reentrena solo con el train y da las mismas fusiones**, que el vocabulario cuadra
(300 símbolos = 34 caracteres + cierre + 265 fusiones), que **los 182 textos de test se reconstruyen
idénticos**, los tokens por palabra medidos, la atención (8 × 8, cada fila suma 1 con tolerancia 1e-12,
determinista), la perplejidad recalculada sobre las secuencias de test (bigrama mejor que unigrama), la
generación reproducible, los adaptadores de arXiv/Semantic Scholar y que el código no hace red ni lleva
claves. Termina en `RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). La salida real es la de
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt), con **22 comprobaciones** en verde:

- **Partición:** train 418 filas · test 182 filas · **textos compartidos 0**.
- **BPE:** 300 símbolos · 265 fusiones · **182/182 textos de test reconstruidos** · 1,23 tokens por
  palabra de media en train (el corpus tiene 107 palabras limpias: el vocabulario se agota antes de
  pedir más símbolos y el límite se declara).
- **Atención:** 8 consultas, matriz 8 × 8 y todas las filas suman 1,000000000000.
- **Perplejidad (test):** contexto de 1 token (unigrama) **124,184** · contexto de 2 tokens (bigrama)
  **5,915**; el bigrama mejora porque las plantillas repiten secuencias.
- **Generación (semilla 11):** `, lvió el tiempo. envestáimer brorraempo. algqni aquí. y unmete.` — un
  modelo diminuto produce palabras mal formadas y repeticiones; el cuaderno lo dice en vez de maquillarlo.

## Datos y procedencia

- `datos-ejemplo/resenas-texto.csv`: **600 filas × 5 columnas** (`id`, `texto`, `etiqueta`,
  `longitud_palabras`, `canal`). Sintético, semilla 20261109 y **CC0-1.0**. Copia literal del catálogo del
  portal (`aprender/web/datos/datasets/resenas-texto.csv`), no presente en `datasets/csv/`; sha256
  `30f40f0d7ea897cf2ec849ada0e383d8391685113ed92ffab5a6dd1935ee990c`.
- `datos-ejemplo/parametros.json`: semilla 20261109, 30 % de test, 300 símbolos de vocabulario BPE, 32
  dimensiones para los embeddings de atención, contextos (1, 2), 20 tokens de generación con semilla 11 y
  suavizado 0,1.
- `datos-ejemplo/fixtures/arxiv.json`: **3 papers** (Sennrich et al. 2016 para BPE, Vaswani et al. 2017
  para atención, Bengio et al. 2003 para el modelo de lenguaje) con metadatos congelados y la licencia
  **CC0-1.0** de los metadatos de arXiv; los e-prints no se copian.
- `datos-ejemplo/fixtures/semantic-scholar.json`: **3 registros** con recuentos de citas **simulados**
  (declarado en el propio fixture) y la licencia **CC-BY-NC-4.0** con atribución; no es una consulta real.
- `resultados/`: `tokenizador.json`, `atencion.csv`, `perplejidad.csv` y `generacion.txt`, regenerados con
  `python bpe.py`.

## Qué es real y qué es simulado

- **Real:** el CSV del catálogo (sha256 comprobado), el BPE, la atención y la perplejidad los calcula el
  código; los papers citados existen y la licencia de los metadatos de arXiv (CC0-1.0) es la declarada.
- **Simulado:** la respuesta de arXiv y de Semantic Scholar (fixtures). Los recuentos de citas del fixture
  son ilustrativos; con red y clave gratuita se consultarían de verdad, pero esta entrega no hace la
  llamada ni guarda ninguna clave.
- **Límite:** la perplejidad de este modelo **no es comparable** con la de un LLM real; es una medida
  interna para comparar dos contextos sobre el mismo corpus.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · CSV y partición agrupada | Partir por texto para no filtrar plantillas al test | `Fuga de datos` |
| 2 · Entrenar el BPE | Fusiones de pares, vocabulario y tokens por palabra | `Tokenización` |
| 3 · Reconstruir el texto | Un vocabulario mal cerrado pierde caracteres | `Tokenización` |
| 4 · Atención escalada | Consulta, clave, valor y softmax por filas | `Atención` |
| 5 · Comprobar las sumas | Si los pesos no suman uno, el softmax está mal | `Transformers` |
| 6 · Perplejidad con contexto | Entropía, log-verosimilitud y tamaño de contexto | `Entropía e información` |
| 7 · Generar texto | Un modelo diminuto repite y deforma; se declara | `Transformers` |
| 8 · Fixtures de las APIs | Metadatos con licencia, sin claves ni red | `APIs y peticiones HTTP` |

## Estructura

```text
codigo/
├── bpe.py                  # corpus, partición, BPE, atención, perplejidad y generación
├── adaptador.py            # clientes simulados de arXiv y Semantic Scholar (fixtures)
├── datos-ejemplo/          # resenas-texto.csv (CC0-1.0), parametros.json y fixtures/
├── verificar.py            # la puerta del proyecto (solo stdout, sin red)
└── resultados/             # ejemplo-salida.txt y los artefactos generados
```

## Fallos típicos

- **BPE entrenado con todo el corpus:** entrenar las fusiones con el test y medir perplejidad allí es fuga;
  la puerta reentrena solo con el train y compara las fusiones.
- **Vocabulario que no reconstruye:** si el vocabulario se cierra mal, el texto de prueba pierde
  caracteres; la puerta exige que los 182 textos vuelvan idénticos.
- **Atención importada:** aquí se implementa; si las filas no suman 1, el softmax o la escala están mal.
- **Perplejidad del train:** una perplejidad baja en entrenamiento no dice nada; se mide sobre las
  secuencias de test, con la misma partición que el tokenizador.
- **Comparar con un LLM:** la perplejidad de un modelo de 107 palabras no es comparable; el README lo
  declara como medida interna.
- **Contexto sin justificar:** los dos contextos se fijan en `parametros.json` antes de medir y se
  comparan; no se añade un tercero después de ver el resultado.
- **Leer la generación como si fuera un LLM:** el texto generado tiene palabras mal formadas; es la
  consecuencia de muestrear tokens de un modelo diminuto y se declara.
- **Clave de Semantic Scholar:** si se usara el modo real, iría en una variable de entorno; el fixture y el
  código no contienen ninguna clave.
