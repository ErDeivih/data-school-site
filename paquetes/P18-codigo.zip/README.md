# P18 · Predecir la clasificación sin mirar la carrera

Paquete descargable de **Data School** para el proyecto P18. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita el repositorio, ni conexión, ni dependencias.

La pregunta del proyecto: con lo que se sabe **antes** de la salida (los tres sectores de la
clasificación, el compuesto y la temperatura), ¿se puede estimar el puesto final de la carrera? Y,
sobre todo: ¿cómo se mide sin engañarse? El código construye una regresión ridge desde cero y publica
el resultado honesto: **el modelo no bate al orden de la parrilla**. El valor no está en el modelo,
está en las tres decisiones que enseña: qué columnas son fuga, cómo se parte por carrera y cómo se
mide el orden.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: `requirements.txt` solo lo dice. Todo va con la biblioteca
  estándar de Python, sin pandas ni scikit-learn, para que se vea la cuenta por dentro.
- Windows, Linux o macOS. No hace falta red.

## Instalación

```bash
python -m pip install -r requirements.txt
```

No instala nada: el fichero existe para que el comando funcione igual que en el resto de paquetes.

## Ejecutar

```bash
python clasificacion.py
python verificar.py
```

`clasificacion.py` lee el CSV, audita las columnas, mide la línea base, parte por carrera, entrena,
evalúa, repite con una partición aleatoria para enseñar el artefacto de la métrica y demuestra la
fuga. `verificar.py` comprueba el resultado de verdad y sale 0 si todo cuadra.

Desde la carpeta del paquete (los datos se buscan en `datos-ejemplo/`):

```bash
cd P18-codigo
python clasificacion.py --csv datos-ejemplo/f1-clasificacion.csv
```

## Salida esperada

```text
datos: 400 filas × 12 columnas · 20 carreras × 20 pilotos
columnas posteriores a la carrera: posicion_final, puntos · fuga: 2 columnas
posición final → puntos: 20 puestos · 11 valores de puntos
línea base (parrilla): MAE 1.012 · Spearman 0.9763
partición por carrera: train 320 (r01–r16) · test 80 (r17–r20)
modelo honesto: MAE 1.4148 · Spearman 0.9689
la parrilla en el test: MAE 1.0625 · Spearman 0.9756 → el modelo NO bate la línea base
orden dentro de cada carrera: modelo MAE 1.1375 · Spearman 0.9770 · parrilla MAE 1.0625 · Spearman 0.9796
partición aleatoria: 300/100 · carreras compartidas 20/20 · MAE 1.4311 · Spearman 0.9562
el artefacto: re-ordenar fragmentos de 5 pilotos da MAE 6.0800 (métrica rota, mismo modelo)
fuga demostrada: con posicion_final el MAE cae a 0.0161 y el Spearman sube a 1.0000 (80/80)
límite: 20 carreras sintéticas; el modelo no bate a la parrilla y no predice coches nuevos.
```

## Datos

- `datos-ejemplo/f1-clasificacion.csv`: **400 filas × 12 columnas**. 20 carreras (`r01`–`r20`) ×
  20 pilotos; 5 equipos; compuesto `blando` (206 filas) y `medio` (194); temperatura de 24,0 a
  32,0 °C. La clave `(carrera, piloto)` es única; la posición de clasificación es una permutación
  1..20 en cada carrera.
- **Sintético, determinista y CC0-1.0**: es una copia literal del CSV `f1-clasificacion` del catálogo
  del portal, generado con semilla fija `20261103`. No son datos reales de ningún equipo ni carrera.
- `sha256` del fichero: `2cd5b45e02b14ad12bae786880bf4a175cfc8d2a2ea13d286e28384779054a93`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.
- La fuente real equivalente, si algún día se quiere repetir con datos de verdad, sería **OpenF1**
  (uso educativo y no comercial; declara no reclamar la propiedad de los datos de F1) o **Jolpica F1**
  (datos bajo CC BY-NC-SA 4.0). Este paquete **no** las consulta ni redistribuye sus datos.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida columnas y la clave (carrera, piloto) | grano y clave de una tabla |
| 2 · Auditar | separa columnas de antes y de después de la carrera | fuga de datos |
| 3 · Spearman | correlación de orden con empates | métricas de orden |
| 4 · Línea base | ordena por la parrilla sin entrenar | línea base |
| 5 · Partir por carrera | 16 carreras entrenan, 4 prueban | partición por grupo |
| 6 · Partir al azar | una de cada cuatro filas al test | por qué barajar mezcla unidades |
| 7 · Estandarizar y ajustar | media y desviación solo de train; ridge desde cero | regresión y fuga del escalador |
| 8 · Puntuar | puesto esperado continuo | predicción frente a decisión |
| 9 · Evaluar | MAE y Spearman fuera de muestra | métricas de regresión |
| 10 · Re-ordenar por carrera | ordena dentro de cada carrera | unidad de análisis |
| 11 · Demostrar la fuga | mete `posicion_final` como variable | fuga de datos, demostrada |
| 12 · Publicar | cifras y límite en la misma salida | comunicación honesta |

## Las tres trampas que el código deja a la vista

1. **Fuga de datos.** `posicion_final` y `puntos` se conocen **después** de la carrera. Si entran como
   variables, el error baja a 0,0161 puestos y el Spearman sube a 1,0: no es un modelo, es copiar la
   respuesta. El código lo demuestra a propósito y el verificador exige que el modelo honesto no las use.
2. **Partición por carrera.** Los 20 pilotos de una carrera comparten pista y sesión. Si se barajan
   filas, las mismas 20 carreras aparecen en train y en test; además el test queda partido en trozos de
   5 pilotos y la métrica de orden se rompe: el mismo modelo pasa de 1,2 a 6,08 puestos de MAE solo
   porque el test ya no contiene carreras completas.
3. **Métrica de orden.** La clasificación es un orden; no basta el error medio. Se publican MAE y
   Spearman, y se compara siempre contra la parrilla: aquí la parrilla gana (1,06 frente a 1,41), y se
   escribe tal cual.

## Fallos típicos

- **`ModuleNotFoundError: clasificacion`**: ejecuta desde la carpeta del paquete, no desde su padre.
- **`FileNotFoundError`**: el comando se ha lanzado desde otra carpeta; `--csv` apunta a
  `datos-ejemplo/f1-clasificacion.csv` y la ruta es relativa al directorio actual.
- **`columnas inesperadas`**: el CSV no es el del catálogo o se ha abierto con otro separador.
- **Error perfecto (0,01 puestos)**: has dejado `posicion_final` o `puntos` entre las variables; es fuga.
- **MAE de 6 puestos al re-ordenar**: estás re-ordenando fragmentos de carrera; la partición no es por
  carrera y la métrica no mide lo que crees.
- **Spearman distinto en cada ejecución**: no debería; el código es determinista y no usa aleatoriedad.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar; si tu terminal
  no lo admite, redirige la salida a un fichero.

## Estructura

```text
P18-codigo/
├── clasificacion.py            # pasos 1–12: grano, fuga, partición, modelo y métricas
├── verificar.py                # la puerta del proyecto: 42 comprobaciones, sin red, sin escribir
├── requirements.txt            # sin dependencias
├── datos-ejemplo/
│   └── f1-clasificacion.csv    # 400 × 12 · sintético, CC0-1.0
└── resultados/
    └── ejemplo-salida.txt      # la salida real de una ejecución
```

## Límite

Son 20 carreras sintéticas generadas con una regla conocida: el puesto final es el de clasificación más
un ruido entero. Por eso el modelo lineal no puede batir a la parrilla y el resultado se publica como
es. El paquete enseña el método (fuga, partición, orden, línea base), **no** un modelo de F1: no
demuestra nada sobre coches, circuitos ni temporadas reales, y no sirve para apostar.
