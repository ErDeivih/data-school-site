"""P18 · Predecir la clasificación sin mirar la carrera.

Construye una regresión ridge desde cero (sin scikit-learn) para estimar el puesto final de una
carrera usando solo lo que se sabe antes de la salida: los tres sectores de la clasificación, el
compuesto y la temperatura. El proyecto enseña las tres decisiones que más modelos de datos
arruinan: qué columnas son fuga, cómo se parte por carrera y cómo se mide el orden.

Sin dependencias externas: solo la biblioteca estándar. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = (
    "carrera", "piloto", "equipo", "posicion_quali", "vuelta_quali_s",
    "sector1_s", "sector2_s", "sector3_s", "compuesto", "temperatura_c",
    "posicion_final", "puntos",
)
# Variables que existen ANTES de la carrera: se pueden usar para predecir.
CARACTERISTICAS = ("sector1_s", "sector2_s", "sector3_s", "compuesto", "temperatura_c")
# Columnas que solo existen DESPUÉS de la carrera: usarlas es fuga, no predicción.
POST_CARRERA = ("posicion_final", "puntos")
CARRERAS_TEST = 4
CADA = 4
RIDGE = 1.0


def _valor(fila: dict, columna: str) -> float:
    """Convierte una celda a número; el compuesto se codifica como 1 (blando) o 0 (medio)."""
    texto = fila[columna]
    try:
        return float(texto)
    except ValueError:
        return 1.0 if texto == "blando" else 0.0


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el grano: una fila por carrera y piloto.
    # Por qué: si hay filas repetidas o una carrera con 19 pilotos, la partición por carrera miente.
    # Salida esperada: 400 filas × 12 columnas, 20 carreras de 20 pilotos.
    # Si falla: «columnas inesperadas» o «la clave (carrera, piloto) no es única».
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 400:
        raise ValueError(f"se esperaban 400 filas, hay {len(filas)}")
    if len({(f["carrera"], f["piloto"]) for f in filas}) != len(filas):
        raise ValueError("la clave (carrera, piloto) no es única")
    if {f["compuesto"] for f in filas} - {"blando", "medio"}:
        raise ValueError("compuesto solo puede ser blando o medio")
    return filas


def auditar(filas: list[dict]) -> dict:
    # Paso 2 · Clasificar las columnas en «antes» y «después» de la carrera.
    # Por qué: posicion_final y puntos no existen cuando predices la carrera; mirarlos es hacer trampa.
    # Salida esperada: 2 columnas posteriores y el mapa posición final → puntos (20 puestos, 11 valores).
    # Si falla: el CSV no es el del catálogo o se ha colado una columna nueva sin clasificar.
    puntos_por_posicion = {}
    for fila in filas:
        posicion = int(fila["posicion_final"])
        puntos = int(fila["puntos"])
        if posicion in puntos_por_posicion and puntos_por_posicion[posicion] != puntos:
            raise ValueError("puntos no es función de la posición final")
        puntos_por_posicion[posicion] = puntos
    return {
        "post_carrera": sorted(POST_CARRERA),
        "puntos_por_posicion": puntos_por_posicion,
        "valores_de_puntos": sorted(set(puntos_por_posicion.values())),
    }


def spearman(xs: list[float], ys: list[float]) -> float:
    # Paso 3 · Correlación de orden de Spearman, con empates resueltos por el rango medio.
    # Por qué: en una carrera lo que importa es el orden, no el número de segundos; y hay empates.
    # Salida esperada: un número entre -1 y 1; 1 si los dos órdenes coinciden.
    # Si falla: una de las dos listas es constante (varianza 0) y el coeficiente no está definido.

    def rangos(valores: list[float]) -> list[float]:
        orden = sorted(range(len(valores)), key=lambda i: valores[i])
        salida = [0.0] * len(valores)
        i = 0
        while i < len(orden):
            j = i
            while j + 1 < len(orden) and valores[orden[j + 1]] == valores[orden[i]]:
                j += 1
            medio = (i + j) / 2 + 1
            for k in range(i, j + 1):
                salida[orden[k]] = medio
            i = j + 1
        return salida

    rx, ry = rangos(xs), rangos(ys)
    n = len(rx)
    mx, my = sum(rx) / n, sum(ry) / n
    vx = sum((a - mx) ** 2 for a in rx)
    vy = sum((b - my) ** 2 for b in ry)
    if vx == 0 or vy == 0:
        return 0.0
    return sum((a - mx) * (b - my) for a, b in zip(rx, ry)) / math.sqrt(vx * vy)


def _metricas(prediccion: list[float], real: list[float]) -> dict:
    """Error absoluto medio y Spearman de un par de listas."""
    mae = sum(abs(p - r) for p, r in zip(prediccion, real)) / len(real)
    return {"mae": mae, "spearman": spearman(prediccion, real), "n": len(real)}


def linea_base(filas: list[dict]) -> dict:
    # Paso 4 · Línea base: ordenar por la parrilla y no entrenar nada.
    # Por qué: un modelo que no bate «el orden de la clasificación» no ha aprendido nada útil.
    # Salida esperada: 1,012 puestos de error de media y Spearman 0,9763 sobre las 400 filas.
    # Si falla: se está comparando contra otra cosa o las columnas de posición están invertidas.
    prediccion = [float(f["posicion_quali"]) for f in filas]
    real = [float(f["posicion_final"]) for f in filas]
    return _metricas(prediccion, real)


def partir_por_carrera(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    # Paso 5 · Partir por CARRERA: las 16 primeras entrenan y las 4 últimas prueban.
    # Por qué: los 20 pilotos de una carrera comparten pista y sesión; barajar filas mezcla carreras.
    # Salida esperada: 320 filas de train (r01–r16) y 80 de test (r17–r20), 0 carreras compartidas.
    # Si falla: la lista de carreras no está ordenada o el corte no cuadra con 20 pilotos por carrera.
    carreras = sorted({f["carrera"] for f in filas})
    train_carreras = set(carreras[:-CARRERAS_TEST])
    test_carreras = set(carreras[-CARRERAS_TEST:])
    train = [f for f in filas if f["carrera"] in train_carreras]
    test = [f for f in filas if f["carrera"] in test_carreras]
    if len(train) != 320 or len(test) != 80:
        raise ValueError("la partición por carrera no da 320/80")
    return train, test


def partir_al_azar(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    # Paso 6 · La partición equivocada: una de cada cuatro filas al test.
    # Por qué: se implementa para poder comparar; así se ve que las 20 carreras acaban en los dos lados.
    # Salida esperada: 300 filas de train y 100 de test, con las 20 carreras compartidas.
    # Si falla: no hay error de ejecución; el error es conceptual y lo enseña la comparación.
    train = [f for i, f in enumerate(filas) if i % CADA != 0]
    test = [f for i, f in enumerate(filas) if i % CADA == 0]
    return train, test


def ajustar(entrenamiento: list[dict], columnas: tuple[str, ...]) -> dict:
    # Paso 7 · Estandarizar con train y ajustar una regresión ridge desde cero.
    # Por qué: la media y la desviación se calculan SOLO con train; usar el test es fuga de datos.
    # Salida esperada: media y desviación por variable y 6 pesos (intercepto + 5 variables).
    # Si falla: una variable tiene desviación 0 o el sistema de ecuaciones queda sin solución.
    valores = [[_valor(f, c) for c in columnas] for f in entrenamiento]
    columnas_datos = list(zip(*valores))
    medias = [sum(c) / len(c) for c in columnas_datos]
    desv = [math.sqrt(sum((v - m) ** 2 for v in c) / len(c)) or 1.0
            for c, m in zip(columnas_datos, medias)]
    diseno = [[1.0] + [(_valor(f, c) - m) / d for c, m, d in zip(columnas, medias, desv)]
              for f in entrenamiento]
    objetivo = [float(f["posicion_final"]) for f in entrenamiento]
    n = len(diseno[0])
    # Ecuaciones normales (XᵀX + λI)β = Xᵀy; λ pequeño estabiliza la colinealidad de los sectores.
    a = [[sum(x[i] * x[j] for x in diseno) + (RIDGE if i == j and i > 0 else 0.0) for j in range(n)]
         for i in range(n)]
    b = [sum(x[i] * y for x, y in zip(diseno, objetivo)) for i in range(n)]
    beta = _resolver(a, b)
    return {"medias": medias, "desv": desv, "beta": beta, "columnas": tuple(columnas)}


def _resolver(a: list[list[float]], b: list[float]) -> list[float]:
    """Gauss con pivote parcial: resuelve un sistema pequeño sin numpy."""
    n = len(b)
    for col in range(n):
        pivote = max(range(col, n), key=lambda r: abs(a[r][col]))
        a[col], a[pivote] = a[pivote], a[col]
        b[col], b[pivote] = b[pivote], b[col]
        for fila in range(col + 1, n):
            factor = a[fila][col] / a[col][col]
            for c in range(col, n):
                a[fila][c] -= factor * a[col][c]
            b[fila] -= factor * b[col]
    beta = [0.0] * n
    for fila in range(n - 1, -1, -1):
        beta[fila] = (b[fila] - sum(a[fila][c] * beta[c] for c in range(fila + 1, n))) / a[fila][fila]
    return beta


def puntuar(fila: dict, modelo: dict) -> float:
    # Paso 8 · Puntuar una fila: el puesto esperado, sin recortar todavía.
    # Por qué: el modelo devuelve un número continuo; recortarlo a 1..20 es una decisión aparte.
    # Salida esperada: un número en torno a 1–20 (puede salirse por los extremos).
    # Si falla: el modelo no tiene los mismos pesos que variables.
    return modelo["beta"][0] + sum(
        peso * (_valor(fila, columna) - media) / desv
        for peso, columna, media, desv in zip(modelo["beta"][1:], modelo["columnas"],
                                              modelo["medias"], modelo["desv"]))


def predecir(filas: list[dict], modelo: dict) -> list[float]:
    """Puesto esperado recortado al rango real de la parrilla (1..20)."""
    return [min(20.0, max(1.0, puntuar(f, modelo))) for f in filas]


def evaluar(filas: list[dict], modelo: dict) -> dict:
    # Paso 9 · Medir fuera de muestra: error de puesto y correlación de orden.
    # Por qué: dos modelos pueden tener el mismo error y ordenar distinto; hacen falta las dos métricas.
    # Salida esperada: sobre r17–r20, MAE 1,4148 y Spearman 0,9689.
    # Si falla: el test comparte carreras con el train (no es una prueba fuera de muestra).
    real = [float(f["posicion_final"]) for f in filas]
    return _metricas(predecir(filas, modelo), real)


def evaluar_por_carrera(filas: list[dict], modelo: dict) -> dict:
    # Paso 10 · Re-ordenar DENTRO de cada carrera y comparar contra la parrilla.
    # Por qué: la clasificación es un orden por carrera; mezclar filas de carreras distintas no la mide.
    # Salida esperada (4 carreras completas): modelo 1,1375 puestos y parrilla 1,0625.
    # Si falla: el test tiene fragmentos de carrera (partición aleatoria) y el MAE se dispara: es el artefacto.
    por_carrera = defaultdict(list)
    for fila in filas:
        por_carrera[fila["carrera"]].append(fila)
    maes, correlaciones, parrilla_maes, parrilla_correlaciones = [], [], [], []
    orden_por_carrera = {}
    for carrera in sorted(por_carrera):
        grupo = por_carrera[carrera]
        if len(grupo) < 2:
            continue
        orden = sorted(grupo, key=lambda f: puntuar(f, modelo))
        posiciones = [float(i) for i in range(1, len(orden) + 1)]
        reales = [float(f["posicion_final"]) for f in orden]
        metrica = _metricas(posiciones, reales)
        maes.append(metrica["mae"])
        correlaciones.append(metrica["spearman"])
        parrilla = sorted(grupo, key=lambda f: int(f["posicion_quali"]))
        metrica_parrilla = _metricas(posiciones, [float(f["posicion_final"]) for f in parrilla])
        parrilla_maes.append(metrica_parrilla["mae"])
        parrilla_correlaciones.append(metrica_parrilla["spearman"])
        orden_por_carrera[carrera] = {
            "modelo": [f["piloto"] for f in orden],
            "parrilla": [f["piloto"] for f in parrilla],
        }
    return {
        "carreras": sorted(orden_por_carrera),
        "mae_medio": sum(maes) / len(maes),
        "spearman_medio": sum(correlaciones) / len(correlaciones),
        "parrilla_mae": sum(parrilla_maes) / len(parrilla_maes),
        "parrilla_spearman_medio": sum(parrilla_correlaciones) / len(parrilla_correlaciones),
    }


def fuga(train: list[dict], test: list[dict]) -> dict:
    # Paso 11 · Demostrar la fuga: meter posicion_final como variable.
    # Por qué: si el modelo acierta el puesto casi exacto, no ha aprendido nada: ha leído la respuesta.
    # Salida esperada: MAE 0,0161 y Spearman 1,0; las 80 filas quedan a menos de 0,05 puestos.
    # Si falla: la columna no se ha pasado al modelo o hay filas de test repetidas en train.
    modelo = ajustar(train, ("posicion_final",))
    prediccion = [puntuar(f, modelo) for f in test]
    real = [float(f["posicion_final"]) for f in test]
    metrica = _metricas(prediccion, real)
    metrica["aciertos_005"] = sum(1 for p, r in zip(prediccion, real) if abs(p - r) < 0.05)
    metrica["beta"] = modelo["beta"]
    return metrica


def main() -> int:
    # Paso 12 · Publicar el resultado y, sobre todo, el límite.
    # Por qué: el número incómodo (el modelo no bate a la parrilla) se publica igual que el resto.
    # Salida esperada: las cifras del README y el aviso de que son 20 carreras sintéticas.
    # Si falla: revisa --csv; el código se ejecuta desde la carpeta del paquete.
    parser = argparse.ArgumentParser(description="Predecir la clasificación sin mirar la carrera (P18)")
    parser.add_argument("--csv", default="datos-ejemplo/f1-clasificacion.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    carreras = sorted({f["carrera"] for f in filas})
    auditoria = auditar(filas)
    base = linea_base(filas)
    train, test = partir_por_carrera(filas)
    modelo = ajustar(train, CARACTERISTICAS)
    evaluacion = evaluar(test, modelo)
    base_test = linea_base(test)
    por_carrera = evaluar_por_carrera(test, modelo)
    train_azar, test_azar = partir_al_azar(filas)
    modelo_azar = ajustar(train_azar, CARACTERISTICAS)
    evaluacion_azar = evaluar(test_azar, modelo_azar)
    fragmentos = evaluar_por_carrera(test_azar, modelo_azar)
    trampa = fuga(train, test)

    print(f"datos: {len(filas)} filas × {len(COLUMNAS)} columnas · {len(carreras)} carreras × 20 pilotos")
    print(f"columnas posteriores a la carrera: {', '.join(auditoria['post_carrera'])} · fuga: {len(auditoria['post_carrera'])} columnas")
    print(f"posición final → puntos: {len(auditoria['puntos_por_posicion'])} puestos · {len(auditoria['valores_de_puntos'])} valores de puntos")
    print(f"línea base (parrilla): MAE {base['mae']:.3f} · Spearman {base['spearman']:.4f}")
    print(f"partición por carrera: train {len(train)} ({carreras[0]}–{carreras[15]}) · test {len(test)} ({carreras[16]}–{carreras[-1]})")
    print(f"modelo honesto: MAE {evaluacion['mae']:.4f} · Spearman {evaluacion['spearman']:.4f}")
    print(f"la parrilla en el test: MAE {base_test['mae']:.4f} · Spearman {base_test['spearman']:.4f} → el modelo NO bate la línea base")
    print(f"orden dentro de cada carrera: modelo MAE {por_carrera['mae_medio']:.4f} · Spearman {por_carrera['spearman_medio']:.4f} · "
          f"parrilla MAE {por_carrera['parrilla_mae']:.4f} · Spearman {por_carrera['parrilla_spearman_medio']:.4f}")
    print(f"partición aleatoria: {len(train_azar)}/{len(test_azar)} · carreras compartidas 20/20 · "
          f"MAE {evaluacion_azar['mae']:.4f} · Spearman {evaluacion_azar['spearman']:.4f}")
    print(f"el artefacto: re-ordenar fragmentos de 5 pilotos da MAE {fragmentos['mae_medio']:.4f} (métrica rota, mismo modelo)")
    print(f"fuga demostrada: con posicion_final el MAE cae a {trampa['mae']:.4f} y el Spearman sube a {trampa['spearman']:.4f} "
          f"({trampa['aciertos_005']}/{len(test)})")
    print("límite: 20 carreras sintéticas; el modelo no bate a la parrilla y no predice coches nuevos.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
