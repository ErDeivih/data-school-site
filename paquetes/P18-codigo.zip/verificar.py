#!/usr/bin/env python3
"""Puerta del proyecto P18 (predecir la clasificación sin mirar la carrera).

Comprueba de verdad el resultado: grano, auditoría de columnas posteriores a la carrera,
línea base, partición por carrera, modelo fuera de muestra, el artefacto de la partición
aleatoria y la fuga demostrada. No usa red y no escribe en disco.

VERDE (código 0) solo si todo pasa; ROJO (código 1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import clasificacion

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "f1-clasificacion.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f} ± {tolerancia})")


def main() -> int:
    # Paso 1 · Grano del CSV: 400 filas, una por carrera y piloto.
    filas = clasificacion.leer(CSV)
    ok(len(filas) == 400, "el CSV tiene 400 filas")
    ok(len(filas[0]) == 12, "el CSV tiene 12 columnas")
    carreras = sorted({f["carrera"] for f in filas})
    ok(len(carreras) == 20, "hay 20 carreras")
    por_carrera = {c: [f for f in filas if f["carrera"] == c] for c in carreras}
    ok(all(len(por_carrera[c]) == 20 for c in carreras), "cada carrera tiene 20 pilotos")
    ok(len({(f["carrera"], f["piloto"]) for f in filas}) == 400, "la clave (carrera, piloto) es única")
    ok(all(sorted(int(f["posicion_quali"]) for f in por_carrera[c]) == list(range(1, 21)) for c in carreras),
       "la posición de clasificación es una permutación 1..20 en cada carrera")
    ok(all(len({int(f["posicion_final"]) for f in por_carrera[c]}) < 20 for c in carreras),
       "la posición final NO es una permutación: hay puestos repetidos en 20/20 carreras")

    # Paso 2 · Auditar los valores del CSV: compuestos, temperatura y sectores.
    ok({f["compuesto"] for f in filas} == {"blando", "medio"}, "compuesto solo tiene blando y medio")
    ok(sum(1 for f in filas if f["compuesto"] == "blando") == 206, "hay 206 vueltas con blando")
    ok(min(float(f["temperatura_c"]) for f in filas) == 24.0 and max(float(f["temperatura_c"]) for f in filas) == 32.0,
       "la temperatura va de 24,0 a 32,0 °C")
    error_sectores = max(abs(float(f["vuelta_quali_s"]) - float(f["sector1_s"]) - float(f["sector2_s"]) - float(f["sector3_s"]))
                         for f in filas)
    ok(error_sectores <= 0.0011, "los tres sectores reconstruyen la vuelta con error ≤ 0,001 s")

    # Paso 3 · Auditoría de fuga: las columnas posteriores a la carrera no son variables.
    auditoria = clasificacion.auditar(filas)
    ok(auditoria["post_carrera"] == ["posicion_final", "puntos"], "la auditoría marca posicion_final y puntos como posteriores")
    ok(len(auditoria["puntos_por_posicion"]) == 20, "la tabla posición final → puntos tiene 20 entradas")
    ok(len(set(auditoria["puntos_por_posicion"].values())) == 11, "solo hay 11 valores de puntos distintos")

    # Paso 4 · Línea base: el orden de la parrilla, sin entrenar nada.
    base = clasificacion.linea_base(filas)
    cerca(base["mae"], 1.012, 0.002, "la parrilla falla 1,012 puestos de media")
    cerca(base["spearman"], 0.9763, 0.0005, "la parrilla ordena con Spearman 0,9763")

    # Paso 5 · Partición por carrera: 16 carreras para entrenar y 4 para probar.
    train, test = clasificacion.partir_por_carrera(filas)
    ok(len(train) == 320 and len(test) == 80, "la partición por carrera deja 320 de train y 80 de test")
    ok(not ({f["carrera"] for f in train} & {f["carrera"] for f in test}), "train y test no comparten ninguna carrera")
    ok({f["carrera"] for f in test} == {"r17", "r18", "r19", "r20"}, "el test son las carreras r17–r20")

    # Paso 6 · Modelo honesto: pesos, predicción y error fuera de muestra.
    modelo = clasificacion.ajustar(train, clasificacion.CARACTERISTICAS)
    pesos = modelo["beta"]
    ok(len(pesos) == 6, "el modelo aprende 6 pesos (intercepto + 5 variables)")
    ok([round(p, 4) for p in pesos] == [10.5125, 2.1303, 1.6343, 1.844, 0.1293, -0.0483],
       "los pesos son los esperados")
    ok(pesos[1] > 0 and pesos[2] > 0 and pesos[3] > 0, "más tiempo en cualquier sector empeora el puesto esperado")
    evaluacion = clasificacion.evaluar(test, modelo)
    cerca(evaluacion["mae"], 1.4148, 0.001, "el modelo falla 1,4148 puestos de media en el test")
    cerca(evaluacion["spearman"], 0.9689, 0.0005, "el modelo ordena con Spearman 0,9689")

    # Paso 7 · La comparación honesta: la parrilla gana al modelo.
    base_test = clasificacion.linea_base(test)
    ok(base_test["mae"] < evaluacion["mae"], "la línea base de la parrilla bate al modelo en el test")
    ok(base_test["spearman"] > evaluacion["spearman"], "la parrilla ordena mejor que el modelo en el test")
    cerca(base_test["mae"], 1.0625, 0.001, "la parrilla falla 1,0625 puestos en el test")

    # Paso 8 · Orden dentro de cada carrera completa del test.
    por_carrera_test = clasificacion.evaluar_por_carrera(test, modelo)
    cerca(por_carrera_test["mae_medio"], 1.1375, 0.001, "re-ordenando cada carrera, el modelo falla 1,1375 puestos")
    cerca(por_carrera_test["spearman_medio"], 0.9770, 0.0005, "re-ordenando cada carrera, Spearman 0,9770")
    ok(len(por_carrera_test["carreras"]) == 4, "se evalúan las 4 carreras completas del test")
    cerca(por_carrera_test["parrilla_mae"], 1.0625, 0.001, "la parrilla falla 1,0625 puestos por carrera")

    # Paso 9 · La partición aleatoria rompe la métrica de orden.
    train_azar, test_azar = clasificacion.partir_al_azar(filas)
    ok(len(train_azar) == 300 and len(test_azar) == 100, "la partición aleatoria deja 300 y 100 filas")
    ok(len({f["carrera"] for f in train_azar} & {f["carrera"] for f in test_azar}) == 20,
       "la partición aleatoria comparte las 20 carreras entre train y test")
    modelo_azar = clasificacion.ajustar(train_azar, clasificacion.CARACTERISTICAS)
    evaluacion_azar = clasificacion.evaluar(test_azar, modelo_azar)
    cerca(evaluacion_azar["mae"], 1.4311, 0.001, "con partición aleatoria el MAE es 1,4311")
    cerca(evaluacion_azar["spearman"], 0.9562, 0.0005, "con partición aleatoria el Spearman es 0,9562")
    fragmentos = clasificacion.evaluar_por_carrera(test_azar, modelo_azar)
    ok(fragmentos["mae_medio"] > 5.0, "re-ordenar fragmentos de 5 pilotos da un MAE > 5: la métrica no mide al modelo")

    # Paso 10 · La fuga demostrada: meter posicion_final hunde el error a cero.
    fuga = clasificacion.fuga(train, test)
    ok(fuga["mae"] < 0.05, "con posicion_final como variable el MAE baja de 0,05")
    cerca(fuga["spearman"], 1.0, 0.0001, "con posicion_final el Spearman es 1,0")
    ok(fuga["aciertos_005"] == 80, "las 80 filas del test quedan a menos de 0,05 puestos")

    # Paso 11 · Las variables del modelo honesto no incluyen columnas posteriores.
    ok("posicion_final" not in clasificacion.CARACTERISTICAS and "puntos" not in clasificacion.CARACTERISTICAS,
       "el modelo honesto no usa posicion_final ni puntos")
    codigo = (AQUI / "clasificacion.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
