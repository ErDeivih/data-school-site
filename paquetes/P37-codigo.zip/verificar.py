#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Puerta del proyecto P37: comprueba de verdad el pipeline y la ausencia de fuga.

Es offline y no lanza procesos hijos: importa `pipeline.py`, ejecuta su `main()`, recalcula la
tabla de pliegues desde el holdout y reconstruye la partición con la misma semilla para
comprobar que el escalador se ajustó solo con el entrenamiento.

Uso:
    python verificar.py

Termina con `RESULTADO: VERDE` (exit 0) si todas las comprobaciones pasan.
"""

from __future__ import annotations

import contextlib
import csv
import io
import json
import shutil
import statistics
import sys
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

import pipeline

BASE = Path(__file__).resolve().parent
DATOS = BASE / "datos-ejemplo" / "clientes-churn.csv"
RESULTADOS = BASE / "resultados"
TMP = RESULTADOS / "verificacion"

# La salida se fuerza a UTF-8: la puerta lanza este script con stdout redirigido y la consola de
# Windows en cp1252 no puede escribir «·», «—» ni «≤».
for _flujo in (sys.stdout, sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8")

comprobaciones = 0
fallos: list[str] = []

METRICAS = ("accuracy", "precision", "recall", "f1", "roc_auc")


def check(condicion: bool, mensaje: str) -> bool:
    """Una comprobación, una línea. Si falla, se anota y el resultado final será ROJO."""
    global comprobaciones
    comprobaciones += 1
    if condicion:
        print(f"OK   · {mensaje}")
    else:
        print(f"FALLA· {mensaje}")
        fallos.append(mensaje)
    return condicion


def ejecutar_pipeline(resultados: Path) -> tuple[int, str]:
    """Ejecuta pipeline.main() en el mismo proceso; devuelve código de salida y salida impresa."""
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        codigo = pipeline.main(["--datos", str(DATOS), "--resultados", str(resultados)])
    return codigo, buffer.getvalue()


def leer_csv(ruta: Path) -> tuple[list[str], list[dict]]:
    with ruta.open(encoding="utf-8", newline="") as fichero:
        lector = csv.DictReader(fichero)
        return list(lector.fieldnames or []), list(lector)


# Paso 1 · Comprueba el crudo y las columnas del modelo
# Por qué: si la tabla no es la del proyecto, las métricas no se pueden interpretar.
# Salida esperada: 200 filas, 5 columnas, id único, 94 bajas y sin nulos.
# Si falla: FileNotFoundError → el CSV no está en datos-ejemplo/; revisa la ruta.
campos, filas = leer_csv(DATOS)
check(campos == pipeline.COLUMNAS_ESPERADAS, "el CSV tiene las 5 columnas esperadas en orden")
check(len(filas) == 200, f"el CSV tiene 200 filas (tiene {len(filas)})")
check(len({f['id_cliente'] for f in filas}) == 200, "los 200 ids de cliente son únicos")
check(sum(int(f["baja"]) for f in filas) == 94, "el CSV tiene 94 bajas de 200 (47 %)")
check(all(f[c].strip() != "" for f in filas for c in campos), "el CSV no tiene celdas vacías")
check(all(1 <= int(f["antiguedad_meses"]) <= 48 for f in filas), "antigüedad entre 1 y 48 meses")
check(all(4 <= int(f["uso_mensual"]) <= 42 for f in filas), "uso mensual entre 4 y 42 sesiones")
check(all(0 <= int(f["reclamaciones"]) <= 3 for f in filas), "reclamaciones entre 0 y 3")

# Paso 2 · Ejecuta el pipeline real del proyecto
# Por qué: la puerta lanza el mismo comando que el README, no una función de conveniencia.
# Salida esperada: exit 0 y los cuatro ficheros de resultados.
# Si falla: exit 2 → el CSV no se pudo leer; exit 1 → una métrica inesperada rompió el flujo.
try:
    codigo, salida = ejecutar_pipeline(RESULTADOS)
    check(codigo == 0, f"pipeline.py sale con 0; salió {codigo}")
    check("140 train" in salida and "60 test" in salida,
          "la partición es 140 entrenamiento / 60 prueba")
    for nombre in ("metricas-por-pliegue.csv", "holdout.json", "predicciones.csv", "umbral.csv"):
        check((RESULTADOS / nombre).is_file(), f"se ha escrito resultados/{nombre}")

    # Paso 3 · Recalcula la validación cruzada desde la tabla, no se la cree
    # Por qué: una tabla de métricas se puede fabricar; media y desviación se recalculan.
    # Salida esperada: 5 pliegues + media + desviación; la media y la desviación cuadran.
    # Si falla: la fila media no coincide → se calculó con otro conjunto de pliegues.
    campos_pliegues, pliegues = leer_csv(RESULTADOS / "metricas-por-pliegue.csv")
    check(campos_pliegues == ["pliegue", *METRICAS],
          "la tabla de pliegues trae pliegue, accuracy, precision, recall, f1 y roc_auc")
    check(len(pliegues) == 7, "la tabla tiene 5 pliegues, una media y una desviación")
    cinco = pliegues[:5]
    media = pliegues[5]
    desviacion = pliegues[6]
    check(media["pliegue"] == "media" and desviacion["pliegue"] == "desviacion",
          "las dos últimas filas son media y desviación")
    for metrica in METRICAS:
        valores = [float(fila[metrica]) for fila in cinco]
        check(abs(float(media[metrica]) - statistics.mean(valores)) < 1e-6,
              f"la media de {metrica} está bien calculada")
        check(abs(float(desviacion[metrica]) - statistics.pstdev(valores)) < 1e-6,
              f"la desviación de {metrica} está bien calculada")
    check(all(0.5 <= float(fila["roc_auc"]) <= 1.0 for fila in cinco),
          "los 5 pliegues tienen ROC-AUC por encima del azar (≥ 0,5)")

    # Paso 4 · Holdout, matriz de confusión y línea base en la misma lectura
    # Por qué: con 47 % de bajas, la exactitud sola no dice nada; se compara con el 53 % base.
    # Salida esperada: 60 predicciones, exactitud > línea base, AUC > 0,5 y recall > 0.
    # Si falla: exactitud = 1,0 → fuga; o confusión que no suma 60 → se evaluó con otra fila.
    holdout = json.loads((RESULTADOS / "holdout.json").read_text(encoding="utf-8"))
    check(holdout["n_train"] == 140 and holdout["n_test"] == 60,
          "el holdout usa 140 para entrenar y 60 para medir")
    confusion = holdout["matriz_confusion"]
    check(confusion["tn"] + confusion["fp"] + confusion["fn"] + confusion["tp"] == 60,
          "la matriz de confusión del holdout suma las 60 filas de prueba")
    check(abs(holdout["linea_base_exactitud"] - 106 / 200) < 0.02,
          "la línea base de clase mayoritaria ronda el 53 % (106/200 sin baja)")
    check(holdout["exactitud"] > holdout["linea_base_exactitud"],
          "el modelo supera la exactitud de la línea base")
    check(holdout["roc_auc"] > 0.5 and holdout["recall"] > 0.0,
          "el holdout tiene AUC por encima del azar y detecta alguna baja")

    # Paso 5 · La prueba de fuga: el escalador se ajustó solo con el entrenamiento
    # Por qué: si se ajusta con todo el dataset, la media del test entra en el train.
    # Salida esperada: escalador_igual_train = true, distinto de la media completa, ids fuera.
    # Si falla: escalador_igual_train = false → se escaló antes del split (fuga clásica).
    datos = pd.read_csv(DATOS)
    X = datos[pipeline.COLUMNAS]
    y = datos[pipeline.ETIQUETA]
    X_train, X_test, _, _ = train_test_split(
        X, y, test_size=pipeline.TAMANO_PRUEBA, stratify=y, random_state=pipeline.SEED)
    media_train = [round(float(v), 6) for v in X_train.mean().to_list()]
    media_completa = [round(float(v), 6) for v in X.mean().to_list()]
    sin_fuga = holdout["sin_fuga"]
    check(sin_fuga["predictores"] == pipeline.COLUMNAS,
          "los predictores son antigüedad, uso y reclamaciones (el id queda fuera)")
    check(sin_fuga["pasos"] == ["imputar", "escalar", "modelo"],
          "el pipeline tiene imputación, escalado y modelo en el mismo objeto")
    check(sin_fuga["escalador_media"] == media_train,
          "la media del escalador coincide con la del entrenamiento reconstruido")
    check(sin_fuga["escalador_media"] != media_completa,
          "la media del escalador no es la del dataset completo (no vio el test)")
    check(sin_fuga["escalador_igual_train"] is True and
          sin_fuga["escalador_distinto_completa"] is True,
          "el informe declara las dos comprobaciones de la prueba sin fuga")

    # Paso 6 · Predicciones y umbrales coherentes con el holdout
    # Por qué: la probabilidad guardada tiene que reproducir la predicción y el barrido.
    # Salida esperada: 60 predicciones con id, probabilidad en [0,1] y predicción binaria.
    # Si falla: la predicción no coincide con el corte en 0,5 → se guardó otra cosa.
    campos_pred, predicciones = leer_csv(RESULTADOS / "predicciones.csv")
    check(campos_pred == ["id_cliente", "probabilidad", "prediccion", "baja"],
          "predicciones.csv tiene id, probabilidad, predicción y etiqueta")
    check(len(predicciones) == 60, "hay 60 predicciones, una por fila del holdout")
    check(all(0.0 <= float(f["probabilidad"]) <= 1.0 for f in predicciones),
          "todas las probabilidades están entre 0 y 1")
    check(all((float(f["probabilidad"]) >= 0.5) == (f["prediccion"] == "1")
              for f in predicciones),
          "todas las predicciones son el corte en 0,5 de su probabilidad")
    ids_test = [datos.loc[i, pipeline.IDENTIFICADOR] for i in X_test.index]
    check([f["id_cliente"] for f in predicciones] == ids_test,
          "las predicciones corresponden a los ids del holdout reconstruido")

    campos_umbral, umbrales = leer_csv(RESULTADOS / "umbral.csv")
    check(campos_umbral == ["umbral", "precision", "recall", "f1", "fp", "fn"],
          "umbral.csv trae precisión, recall, f1, fp y fn")
    check(len(umbrales) >= 3, "el barrido tiene al menos tres umbrales")
    recalls = [float(fila["recall"]) for fila in umbrales]
    check(all(a >= b for a, b in zip(recalls, recalls[1:])),
          "el recall no sube al subir el umbral (barrido coherente)")

    # Paso 7 · Reproducibilidad: misma semilla, mismos ficheros byte a byte
    # Por qué: una tabla que cambia entre ejecuciones no se puede defender en un informe.
    # Salida esperada: los cuatro ficheros de la segunda pasada son idénticos a los primeros.
    # Si falla: cambian las métricas → falta random_state, cambió la versión o el orden de filas.
    TMP.mkdir(parents=True, exist_ok=True)
    codigo_dos, _ = ejecutar_pipeline(TMP)
    check(codigo_dos == 0, "la segunda ejecución del pipeline sale con 0")
    for nombre in ("metricas-por-pliegue.csv", "holdout.json", "predicciones.csv", "umbral.csv"):
        check((RESULTADOS / nombre).read_bytes() == (TMP / nombre).read_bytes(),
              f"la segunda ejecución deja {nombre} idéntico (semilla fija)")
finally:
    if TMP.exists():
        shutil.rmtree(TMP)

# Cierre
print()
if fallos:
    print(f"RESULTADO: ROJO — {len(fallos)} de {comprobaciones} comprobaciones sin cumplir")
    sys.exit(1)
print(f"RESULTADO: VERDE — {comprobaciones} comprobaciones pasan")
sys.exit(0)
