#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pipeline de scikit-learn que no se autoengaña sobre `clientes-churn`.

Tres predictores (`antiguedad_meses`, `uso_mensual`, `reclamaciones`), una etiqueta (`baja`) y
un `Pipeline` con imputación, escalado y regresión logística. La validación es cruzada y
estratificada con semilla fija; el holdout se mide una sola vez y la línea base de clase
mayoritaria se presenta al lado. Se demuestra que el escalador y el imputador se ajustan solo
con el entrenamiento, no con todo el dataset.

Uso:
    python pipeline.py
    python pipeline.py --datos datos-ejemplo/clientes-churn.csv --resultados resultados

Escribe:
    resultados/metricas-por-pliegue.csv   métricas de los 5 pliegues + media y desviación
    resultados/holdout.json               métricas fuera de muestra, línea base y prueba sin fuga
    resultados/predicciones.csv           id, probabilidad y predicción del holdout
    resultados/umbral.csv                 barrido de umbrales con fp/fn
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path

import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import StratifiedKFold, cross_validate, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

BASE = Path(__file__).resolve().parent
SEED = 20261002
COLUMNAS = ["antiguedad_meses", "uso_mensual", "reclamaciones"]
ETIQUETA = "baja"
IDENTIFICADOR = "id_cliente"
COLUMNAS_ESPERADAS = [IDENTIFICADOR, *COLUMNAS, ETIQUETA]
PLIEGUES = 5
TAMANO_PRUEBA = 0.30
METRICAS = ("accuracy", "precision", "recall", "f1", "roc_auc")

# La salida se fuerza a UTF-8: la puerta lanza este script con stdout redirigido y la consola de
# Windows en cp1252 no puede escribir «·», «—» ni «≤».
for _flujo in (sys.stdout, sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8")


def resolver(ruta: str) -> Path:
    destino = Path(ruta)
    return destino if destino.is_absolute() else BASE / destino


# Paso 1 · Carga el CSV y fija las columnas que entran al modelo
# Por qué: el id es un cuasi-identificador secuencial, no un predictor; la etiqueta no se toca.
# Salida esperada: "datos: 200 filas × 5 columnas · predictores: 3".
# Si falla: ValueError con las columnas que faltan → el CSV no es el del proyecto.
def cargar(ruta: Path) -> pd.DataFrame:
    datos = pd.read_csv(ruta)
    faltan = [c for c in COLUMNAS_ESPERADAS if c not in datos.columns]
    if faltan:
        raise ValueError(f"faltan columnas en el CSV: {faltan}")
    print(f"datos: {len(datos)} filas × {len(datos.columns)} columnas · "
          f"predictores: {len(COLUMNAS)} · etiqueta: {ETIQUETA}")
    return datos[COLUMNAS_ESPERADAS].copy()


# Paso 2 · Construye el pipeline completo, no pasos sueltos
# Por qué: imputar y escalar dentro del Pipeline hace que cada pliegue ajuste con su train.
# Salida esperada: un objeto con tres pasos: imputar, escalar y modelo.
# Si falla: StandardScaler con `mean_` raro → se ajustó fuera del pipeline, con todo el dataset.
def construir_pipeline() -> Pipeline:
    return Pipeline([
        ("imputar", SimpleImputer(strategy="median")),
        ("escalar", StandardScaler()),
        ("modelo", LogisticRegression(max_iter=1000, random_state=SEED)),
    ])


# Paso 3 · Valida con pliegues estratificados y semilla fija
# Por qué: cada fila se predice una vez fuera de su pliegue; el desbalanceo no se falsea.
# Salida esperada: 5 pliegues con ROC-AUC > 0,5 y una fila de media y otra de desviación.
# Si falla: todos los valores a 1,0 → el pipeline se ajustó con el pliegue de prueba (fuga).
def evaluar_cv(datos: pd.DataFrame) -> pd.DataFrame:
    X, y = datos[COLUMNAS], datos[ETIQUETA]
    pliegues = StratifiedKFold(n_splits=PLIEGUES, shuffle=True, random_state=SEED)
    resultado = cross_validate(construir_pipeline(), X, y, cv=pliegues,
                               scoring=list(METRICAS), n_jobs=1, return_train_score=False)
    filas = []
    for indice in range(PLIEGUES):
        filas.append({
            "pliegue": f"pliegue {indice + 1}",
            **{metrica: round(resultado[f"test_{metrica}"][indice], 6) for metrica in METRICAS},
        })
    for estadistico, funcion in (("media", statistics.mean), ("desviacion", statistics.pstdev)):
        filas.append({
            "pliegue": estadistico,
            **{metrica: round(funcion(resultado[f"test_{metrica}"]), 6) for metrica in METRICAS},
        })
    return pd.DataFrame(filas)


# Paso 4 · Entrena el holdout y demuestra que el escalador no vio el test
# Por qué: si el escalador se ajusta con todo el dataset, la media del test se cuela en el train.
# Salida esperada: media del escalador = media del train y distinta de la media completa.
# Si falla: escalador_igual_train = false → el escalado se hizo antes del split.
def entrenar_holdout(datos: pd.DataFrame) -> tuple[dict, pd.DataFrame, list[float], list[int]]:
    X, y = datos[COLUMNAS], datos[ETIQUETA]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TAMANO_PRUEBA, stratify=y, random_state=SEED)
    pipeline = construir_pipeline()
    pipeline.fit(X_train, y_train)
    probabilidades = pipeline.predict_proba(X_test)[:, 1]
    predicciones = (probabilidades >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, predicciones).ravel()

    base = DummyClassifier(strategy="most_frequent")
    base.fit(X_train, y_train)
    exactitud_base = accuracy_score(y_test, base.predict(X_test))

    escalador = pipeline.named_steps["escalar"]
    media_escalador = [round(float(v), 6) for v in escalador.mean_]
    media_train = [round(float(v), 6) for v in X_train.mean().to_list()]
    media_completa = [round(float(v), 6) for v in X.mean().to_list()]
    imputador = pipeline.named_steps["imputar"]

    metricas = {
        "n_train": len(X_train),
        "n_test": len(X_test),
        "semilla": SEED,
        "exactitud": round(float(accuracy_score(y_test, predicciones)), 6),
        "precision": round(float(precision_score(y_test, predicciones, zero_division=0)), 6),
        "recall": round(float(recall_score(y_test, predicciones, zero_division=0)), 6),
        "f1": round(float(f1_score(y_test, predicciones, zero_division=0)), 6),
        "roc_auc": round(float(roc_auc_score(y_test, probabilidades)), 6),
        "matriz_confusion": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        "linea_base_exactitud": round(float(exactitud_base), 6),
        "sin_fuga": {
            "predictores": COLUMNAS,
            "pasos": list(pipeline.named_steps),
            "escalador_media": media_escalador,
            "train_media": media_train,
            "completa_media": media_completa,
            "escalador_igual_train": media_escalador == media_train,
            "escalador_distinto_completa": media_escalador != media_completa,
            "imputador_medianas": [round(float(v), 6) for v in imputador.statistics_],
        },
    }
    tabla_predicciones = pd.DataFrame({
        "id_cliente": X_test.index.map(lambda i: datos.loc[i, IDENTIFICADOR]),
        "probabilidad": [round(float(p), 6) for p in probabilidades],
        "prediccion": predicciones,
        "baja": y_test.to_numpy(),
    })
    return metricas, tabla_predicciones, probabilidades.tolist(), y_test.to_list()


# Paso 5 · Barre umbrales y deja la decisión explícita
# Por qué: el 0,5 no es automático; la tabla permite ver el coste de cada corte (P30/P38).
# Salida esperada: 9 umbrales de 0,10 a 0,90 con precisión, recall, f1, fp y fn.
# Si falla: recall no baja al subir el umbral → el barrido no está recalculando predicciones.
def barrer_umbrales(probabilidades: list[float], y_test: list[int]) -> pd.DataFrame:
    filas = []
    for paso in range(1, 10):
        umbral = round(paso / 10, 2)
        predicciones = [1 if p >= umbral else 0 for p in probabilidades]
        tn, fp, fn, tp = confusion_matrix(y_test, predicciones, labels=[0, 1]).ravel()
        filas.append({
            "umbral": umbral,
            "precision": round(float(precision_score(y_test, predicciones, zero_division=0)), 6),
            "recall": round(float(recall_score(y_test, predicciones, zero_division=0)), 6),
            "f1": round(float(f1_score(y_test, predicciones, zero_division=0)), 6),
            "fp": int(fp),
            "fn": int(fn),
        })
    return pd.DataFrame(filas)


# Paso 6 · Escribe las tablas y comprueba la reproducibilidad con la semilla
# Por qué: dos ejecuciones con la misma semilla deben dejar la misma tabla, no «parecida».
# Salida esperada: cuatro ficheros en resultados/ y exit 0.
# Si falla: las métricas cambian entre ejecuciones → falta random_state o cambió la versión.
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Pipeline sin fuga sobre clientes-churn.")
    parser.add_argument("--datos", default="datos-ejemplo/clientes-churn.csv")
    parser.add_argument("--resultados", default="resultados")
    args = parser.parse_args(argv)

    datos = cargar(resolver(args.datos))
    salida = resolver(args.resultados)
    salida.mkdir(parents=True, exist_ok=True)

    print(f"== Pipeline sin fuga · semilla {SEED} ==")
    tabla_pliegues = evaluar_cv(datos)
    tabla_pliegues.to_csv(salida / "metricas-por-pliegue.csv", index=False)

    holdout, predicciones, probabilidades, y_test = entrenar_holdout(datos)
    (salida / "holdout.json").write_text(
        json.dumps(holdout, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    predicciones.to_csv(salida / "predicciones.csv", index=False)
    barrer_umbrales(probabilidades, y_test).to_csv(salida / "umbral.csv", index=False)

    media = tabla_pliegues[tabla_pliegues["pliegue"] == "media"].iloc[0]
    print(f"pliegues: {PLIEGUES} · ROC-AUC media: {media['roc_auc']:.3f} · "
          f"recall media: {media['recall']:.3f}")
    print(f"holdout: exactitud {holdout['exactitud']:.3f} · AUC {holdout['roc_auc']:.3f} · "
          f"línea base {holdout['linea_base_exactitud']:.3f}")
    print(f"sin fuga: escalador ajustado solo con train = {holdout['sin_fuga']['escalador_igual_train']}")
    print(f"RESULTADO: {holdout['n_train']} train · {holdout['n_test']} test · "
          f"{len(predicciones)} predicciones")
    return 0


if __name__ == "__main__":
    sys.exit(main())
