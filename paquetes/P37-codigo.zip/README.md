﻿# P37 · scikit-learn: un pipeline que no se autoengaña — código

Pipeline reproducible sobre `clientes-churn`: imputación, escalado y regresión logística dentro
del **mismo objeto**, validación cruzada estratificada con semilla fija, métricas fuera de
muestra frente a la línea base de clase mayoritaria y una comprobación explícita de que el
escalador **no vio el test**. El barrido de umbrales deja la decisión de corte a la vista.

Acompaña a la ficha `p37-scikit-learn-sin-autoengano.md`.
No hay red ni claves: el CSV de ejemplo es una copia local.

## Requisitos

- Python **3.10 o superior**.
- `pandas` y `scikit-learn`. Probado con **pandas 3.0.6** y **scikit-learn 1.9.1**.
- No se descarga nada en tiempo de ejecución.

## Instalación

```powershell
cd proyectos\p37-scikit-learn-sin-autoengano\codigo
python -m pip install -r requirements.txt
```

## Ejecución

```powershell
python pipeline.py
```

Salida esperada en esta máquina (tus cifras pueden variar con otras versiones):

```text
datos: 200 filas × 5 columnas · predictores: 3 · etiqueta: baja
== Pipeline sin fuga · semilla 20261002 ==
pliegues: 5 · ROC-AUC media: 0.770 · recall media: 0.626
holdout: exactitud 0.600 · AUC 0.739 · línea base 0.533
sin fuga: escalador ajustado solo con train = True
RESULTADO: 140 train · 60 test · 60 predicciones
```

Escribe en `resultados/`:

| Fichero | Contenido |
| --- | --- |
| `metricas-por-pliegue.csv` | 5 pliegues + media y desviación de exactitud, precisión, recall, F1 y ROC-AUC |
| `holdout.json` | métricas fuera de muestra, matriz de confusión, línea base y prueba sin fuga |
| `predicciones.csv` | id, probabilidad, predicción y etiqueta de las 60 filas de prueba |
| `umbral.csv` | 9 umbrales (0,10–0,90) con precisión, recall, F1, FP y FN |

## Verificación

```powershell
python verificar.py
```

La puerta comprueba el CSV, ejecuta el pipeline, recalcula media y desviación de cada métrica,
reconstruye la partición con la misma semilla para verificar la prueba sin fuga, revisa
predicciones y umbrales, y repite la ejecución para exigir ficheros idénticos byte a byte.
Termina con `RESULTADO: VERDE` y exit 0.

## Datos de ejemplo

`datos-ejemplo/clientes-churn.csv` es una **copia local** del CSV del catálogo
`datasets/csv/clientes-churn.csv`: **200 filas** y
**5 columnas**, sintético, determinista, CC0-1.0. Checksum del original:
`sha256:5290b89e3ecf746e378b01af2e73bb9e39a4297541e5ccbedae19bfc97a9839c` (verificado contra
`datasets/datasets.json`). Contiene 94 bajas de 200 (47 %), así que **no es un problema
desbalanceado**: la línea base de clase mayoritaria acierta el 53 %.

No hay API: el catálogo declara `api: []`. La fuente real es el propio CSV del catálogo, sin
descargas ni servicios externos.

## Fuente real y licencias

- **Dato:** `clientes-churn`, sintético, CC0-1.0. Procedencia y generador en
  `datasets/FICHAS.md` y en el portal (`datos/generar-datasets.mjs`).
- **pandas** — BSD-3-Clause. **scikit-learn** — BSD-3-Clause.
- **Python** — PSF-2.0.
- Sin claves ni secretos en el repositorio.

## Mapa paso → lección

| Paso del código | Qué hace | Lección del temario |
| --- | --- | --- |
| Paso 1 · Cargar | lee el CSV y fija los tres predictores | Pandas: fundamentos |
| Paso 2 · Pipeline | une imputación, escalado y modelo en un objeto | Pipelines de machine learning |
| Paso 3 · Validar | 5 pliegues estratificados con semilla fija | Validación cruzada |
| Paso 4 · Medir | holdout, matriz de confusión y línea base | Métricas de clasificación |
| Paso 5 · Sin fuga | el escalador se ajusta solo con el train | Fuga de datos |
| Paso 6 · Escalar | escala dentro del pipeline, no antes del split | Escalado y transformación |
| Paso 7 · Umbral | barrido de cortes y reproducibilidad | Selección de hiperparámetros |

## Estructura

```text
codigo/
├── pipeline.py           # carga, Pipeline, CV, holdout, prueba sin fuga y umbrales
├── verificar.py          # puerta offline: 0 solo si todo pasa
├── requirements.txt      # pandas y scikit-learn con versiones mínimas
├── datos-ejemplo/        # copia del CSV del catálogo (200 × 5)
└── resultados/           # métricas, holdout, predicciones, umbrales y ejemplo-salida.txt
```

## Límites

Doscientos clientes y tres predictores dan para aprender el método, no para prometer un modelo.
Las relaciones entre reclamaciones, uso y baja las impone el generador; no hay fecha de baja ni
datos demográficos. Las versiones de pandas y scikit-learn están fijadas en `requirements.txt`
porque cambian el orden de los empates y, con él, las últimas cifras decimales.
