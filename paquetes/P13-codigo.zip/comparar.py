"""P13 · ¿Le costó la carrera la parada?

Compara el ritmo de un piloto antes y después de la parada en boxes y separa tres cosas que se
mezclan si se mira solo la media: el efecto de la parada, el del neumático nuevo y el del
combustible que ya no lleva. Sin dependencias externas: solo la biblioteca estándar. Sin red.

La pregunta del proyecto no es «¿va más rápido después?», sino «¿cuánto de esa diferencia puede
ser simple ruido?». Por eso el código publica la diferencia bruta, una comparación controlada por
carrera, piloto y compuesto, un ajuste por edad del neumático y vuelta, y una prueba de
permutación que dice si la diferencia observada es distinguible del azar.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = (
    "carrera", "piloto", "vuelta", "compuesto", "edad_neumatico",
    "sector1_s", "sector2_s", "sector3_s", "tiempo_vuelta_s", "parada",
)
# Columnas que describen el coche y la vuelta; el tiempo es la respuesta.
NUMERICAS = ("vuelta", "edad_neumatico", "sector1_s", "sector2_s", "sector3_s", "tiempo_vuelta_s")
ITERACIONES = 2000
SEMILLA = 20261103


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el grano: una fila por carrera, piloto y vuelta.
    # Por qué: si una vuelta se repite o falta una carrera, la comparación antes/después miente.
    # Salida esperada: 180 filas × 10 columnas, 3 carreras × 2 pilotos × 30 vueltas.
    # Si falla: «columnas inesperadas» o «la clave (carrera, piloto, vuelta) no es única».
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 180:
        raise ValueError(f"se esperaban 180 filas, hay {len(filas)}")
    if len({(f["carrera"], f["piloto"], f["vuelta"]) for f in filas}) != len(filas):
        raise ValueError("la clave (carrera, piloto, vuelta) no es única")
    for fila in filas:
        for columna in NUMERICAS:
            float(fila[columna])
    if {f["parada"] for f in filas} - {"0", "1"}:
        raise ValueError("parada solo puede ser 0 o 1")
    return filas


def fases(filas: list[dict]) -> list[dict]:
    # Paso 2 · Marcar cada vuelta como «antes» o «después» de la parada, y quitar la vuelta de boxes.
    # Por qué: la vuelta de la parada dura ~22 s más; contarla como ritmo arruina la media.
    # Salida esperada: 174 vueltas comparables y 6 vueltas de parada excluidas (una por piloto y carrera).
    # Si falla: falta la marca parada=1 o hay dos paradas en la misma carrera.
    salida = []
    excluidas = 0
    for (carrera, piloto), grupo in _agrupar(filas).items():
        paradas = [f for f in grupo if f["parada"] == "1"]
        if len(paradas) != 1:
            raise ValueError(f"{carrera}/{piloto}: se esperaba 1 parada, hay {len(paradas)}")
        vuelta_parada = int(paradas[0]["vuelta"])
        for fila in grupo:
            if fila["parada"] == "1":
                excluidas += 1
                continue
            copia = dict(fila)
            copia["fase"] = "antes" if int(fila["vuelta"]) < vuelta_parada else "despues"
            salida.append(copia)
    if len(salida) != 174 or excluidas != 6:
        raise ValueError(f"se esperaban 174 vueltas comparables y 6 excluidas; hay {len(salida)} y {excluidas}")
    return salida


def _agrupar(filas: list[dict]) -> dict:
    grupos = defaultdict(list)
    for fila in filas:
        grupos[(fila["carrera"], fila["piloto"])].append(fila)
    return dict(grupos)


def media(valores: list[float]) -> float:
    return sum(valores) / len(valores)


def diferencia_bruta(filas: list[dict]) -> dict:
    # Paso 3 · La comparación que haría cualquiera: media de después menos media de antes.
    # Por qué: sirve de punto de partida, pero mezcla compuesto, desgaste y combustible.
    # Salida esperada: una diferencia negativa (después parece más rápido) con muchos grados de libertad.
    pre = [float(f["tiempo_vuelta_s"]) for f in filas if f["fase"] == "antes"]
    post = [float(f["tiempo_vuelta_s"]) for f in filas if f["fase"] == "despues"]
    return {"antes": media(pre), "despues": media(post), "diferencia": media(post) - media(pre),
            "n_antes": len(pre), "n_despues": len(post)}


def diferencia_controlada(filas: list[dict]) -> dict:
    # Paso 4 · Comparar dentro de cada carrera y piloto (bloques), ponderando por vueltas.
    # Por qué: el compuesto cambia justo en la parada (medio → duro), así que compuesto y fase están
    # confundidos: no se pueden separar. Lo que sí se puede es comparar cada piloto consigo mismo y
    # controlar después la edad del neumático y el combustible con el ajuste del paso 5.
    # Salida esperada: una diferencia menor que la bruta pero aún negativa.
    # Si falla: un bloque se queda sin vueltas antes o después de la parada.
    estratos = defaultdict(lambda: {"antes": [], "despues": []})
    for fila in filas:
        clave = (fila["carrera"], fila["piloto"])
        estratos[clave][fila["fase"]].append(float(fila["tiempo_vuelta_s"]))
    detalle = []
    peso_total = 0.0
    acumulado = 0.0
    for clave, fases_ in sorted(estratos.items()):
        if not fases_["antes"] or not fases_["despues"]:
            continue
        diferencia = media(fases_["despues"]) - media(fases_["antes"])
        peso = min(len(fases_["antes"]), len(fases_["despues"]))
        detalle.append({"carrera": clave[0], "piloto": clave[1],
                        "antes": media(fases_["antes"]), "despues": media(fases_["despues"]),
                        "diferencia": diferencia, "peso": peso})
        acumulado += diferencia * peso
        peso_total += peso
    if not peso_total:
        raise ValueError("no hay estratos comparables")
    return {"diferencia": acumulado / peso_total, "estratos": detalle, "peso_total": peso_total}


def _resolver(a: list[list[float]], b: list[float]) -> list[float]:
    """Gauss con pivote parcial para sistemas pequeños, sin numpy."""
    n = len(b)
    for col in range(n):
        pivote = max(range(col, n), key=lambda r: abs(a[r][col]))
        a[col], a[pivote] = a[pivote], a[col]
        b[col], b[pivote] = b[pivote], b[col]
        for fila in range(col + 1, n):
            factor = a[fila][col] / a[col][col]
            for c in range(col, n):
                a[fila][c] -= factor * a[col][c]
            b[fila] -= factor * b[col]
    x = [0.0] * n
    for fila in range(n - 1, -1, -1):
        suma = b[fila] - sum(a[fila][c] * x[c] for c in range(fila + 1, n))
        x[fila] = suma / a[fila][fila]
    return x


def ajustar(filas: list[dict]) -> dict:
    # Paso 5 · Ajustar el tiempo de vuelta con fase, edad del neumático, vuelta (combustible) y
    # circuito. Por qué: después de la parada el neumático es nuevo (-edad) y queda menos combustible
    # (-vuelta); si no se controlan, la fase «después» se lleva el mérito de las dos cosas.
    # Salida esperada: «después» cerca de 0, edad positiva (~0,055 s/vuelta) y vuelta negativa
    # (~-0,03 s/vuelta). Si falla: una columna es constante y el sistema queda singular.
    filas_ordenadas = sorted(filas, key=lambda f: (f["carrera"], f["piloto"], int(f["vuelta"])))
    # Monza y Suzuka como variables ficticias: cada circuito tiene un ritmo base distinto y, sin
    # controlarlo, ese nivel se cuela en el resto de coeficientes.
    diseno = [[1.0, 1.0 if f["fase"] == "despues" else 0.0,
               float(f["edad_neumatico"]), float(f["vuelta"]),
               1.0 if f["carrera"] == "monza" else 0.0,
               1.0 if f["carrera"] == "suzuka" else 0.0] for f in filas_ordenadas]
    objetivo = [float(f["tiempo_vuelta_s"]) for f in filas_ordenadas]
    n = len(diseno[0])
    a = [[sum(x[i] * x[j] for x in diseno) for j in range(n)] for i in range(n)]
    b = [sum(x[i] * y for x, y in zip(diseno, objetivo)) for i in range(n)]
    beta = _resolver(a, b)
    residuos = [y - sum(xi * bi for xi, bi in zip(x, beta)) for x, y in zip(diseno, objetivo)]
    sigma = math.sqrt(sum(r * r for r in residuos) / (len(residuos) - n))
    return {"beta": beta, "sigma": sigma, "n": len(residuos)}


def _generador(semilla: int):
    """LCG pequeño y determinista: la misma semilla da la misma prueba de permutación."""
    estado = semilla & 0xFFFFFFFF

    def siguiente() -> float:
        nonlocal estado
        estado = (1664525 * estado + 1013904223) & 0xFFFFFFFF
        return estado / 2 ** 32

    return siguiente


def _estadistico(filas: list[dict]) -> float:
    return diferencia_controlada(filas)["diferencia"]


def permutacion(filas: list[dict], iteraciones: int = ITERACIONES, semilla: int = SEMILLA) -> dict:
    # Paso 6 · Prueba de permutación: barajar «antes/después» dentro de cada piloto y carrera.
    # Por qué: con 174 vueltas, una diferencia de décimas puede ser ruido; la prueba dice cuántas
    # veces el azar produce una diferencia tan grande como la observada.
    # Salida esperada: p-valor alto (la parada no explica el ritmo más allá del neumático).
    # Si falla: los estratos no conservan sus tamaños o la semilla no es fija.
    azar = _generador(semilla)
    observado = _estadistico(filas)
    grupos = _agrupar(filas)
    etiquetas = {clave: [f["fase"] for f in grupo] for clave, grupo in grupos.items()}
    extremos = 0
    for _ in range(iteraciones):
        barajadas = []
        for clave, grupo in grupos.items():
            copia = [dict(f) for f in grupo]
            fases_ = list(etiquetas[clave])
            for i in range(len(fases_) - 1, 0, -1):
                j = int(azar() * (i + 1))
                fases_[i], fases_[j] = fases_[j], fases_[i]
            for fila, fase in zip(copia, fases_):
                fila["fase"] = fase
            barajadas.extend(copia)
        if abs(_estadistico(barajadas)) >= abs(observado):
            extremos += 1
    return {"observado": observado, "p_valor": (extremos + 1) / (iteraciones + 1),
            "iteraciones": iteraciones}


def main() -> int:
    parser = argparse.ArgumentParser(description="P13 · ¿Le costó la carrera la parada?")
    parser.add_argument("--csv", default="datos-ejemplo/telemetria-f1.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    comparables = fases(filas)
    bruta = diferencia_bruta(comparables)
    controlada = diferencia_controlada(comparables)
    ajuste = ajustar(comparables)
    prueba = permutacion(comparables)

    print(f"datos: {len(filas)} vueltas × {len(COLUMNAS)} columnas · "
          f"{len(_agrupar(filas))} pares carrera/piloto")
    print(f"vueltas comparables: {len(comparables)} · paradas excluidas: {len(filas) - len(comparables)}")
    print(f"media antes: {bruta['antes']:.3f} s · media después: {bruta['despues']:.3f} s")
    print(f"diferencia bruta (después − antes): {bruta['diferencia']:+.3f} s "
          f"({bruta['n_antes']} vs {bruta['n_despues']} vueltas)")
    print(f"diferencia controlada por carrera y piloto: {controlada['diferencia']:+.3f} s "
          f"({len(controlada['estratos'])} estratos)")
    print(f"ajuste: después {ajuste['beta'][1]:+.3f} s · edad {ajuste['beta'][2]:+.3f} s/vuelta · "
          f"vuelta {ajuste['beta'][3]:+.3f} s/vuelta · sigma {ajuste['sigma']:.3f} s")
    print(f"permutación ({prueba['iteraciones']} barajados): p = {prueba['p_valor']:.3f}")
    print("lectura: la diferencia bruta no es ruido (p pequeño), pero tampoco es la parada: el ajuste "
          f"deja un efecto de {ajuste['beta'][1]:+.3f} s cuando se descuentan neumático, combustible y circuito.")
    print("límite: 3 carreras y 2 pilotos sintéticos; no dice nada del rendimiento real de un equipo.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
