#!/usr/bin/env python3
"""Puerta del proyecto P13 (¿le costó la carrera la parada?).

Comprueba de verdad el resultado: grano, vueltas de parada excluidas, comparación bruta,
comparación controlada por carrera y piloto, ajuste con circuito y neumático, prueba de
permutación determinista y que el código no usa red ni claves.

VERDE (código 0) solo si todo pasa; ROJO (código 1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import comparar

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "telemetria-f1.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f} ± {tolerancia})")


def main() -> int:
    # Paso 1 · Grano del CSV: una fila por carrera, piloto y vuelta.
    filas = comparar.leer(CSV)
    ok(len(filas) == 180, "el CSV tiene 180 vueltas")
    ok(len(filas[0]) == 10, "el CSV tiene 10 columnas")
    carreras = sorted({f["carrera"] for f in filas})
    ok(carreras == ["bahrein", "monza", "suzuka"], "hay 3 carreras: bahrein, monza y suzuka")
    pares = comparar._agrupar(filas)
    ok(len(pares) == 6, "hay 6 pares carrera/piloto")
    ok(all(len(g) == 30 for g in pares.values()), "cada par tiene 30 vueltas")
    ok(len({(f["carrera"], f["piloto"], f["vuelta"]) for f in filas}) == 180,
       "la clave (carrera, piloto, vuelta) es única")
    ok(all(sum(1 for f in g if f["parada"] == "1") == 1 for g in pares.values()),
       "cada par tiene exactamente una parada")

    # Paso 2 · Fases y exclusión de la vuelta de boxes.
    comparables = comparar.fases(filas)
    ok(len(comparables) == 174, "quedan 174 vueltas comparables")
    ok(len(filas) - len(comparables) == 6, "se excluyen 6 vueltas de parada")
    ok(all(f["fase"] in ("antes", "despues") for f in comparables), "todas las vueltas llevan fase")
    ok(all(f["parada"] == "0" for f in comparables), "la vuelta de boxes no entra en la comparación")
    ok(len({f["fase"] for f in comparables}) == 2, "están las dos fases")

    # Paso 3 · Diferencia bruta (la que haría cualquiera).
    bruta = comparar.diferencia_bruta(comparables)
    ok(bruta["n_antes"] == 114 and bruta["n_despues"] == 60, "reparto de 114 vueltas antes y 60 después")
    cerca(bruta["antes"], 89.5183, 0.002, "media antes de la parada")
    cerca(bruta["despues"], 88.5815, 0.002, "media después de la parada")
    cerca(bruta["diferencia"], -0.9368, 0.002, "la diferencia bruta es de -0,9368 s")
    ok(bruta["diferencia"] < 0, "después de la parada el tiempo medio baja (parece más rápido)")

    # Paso 4 · Comparación controlada por carrera y piloto.
    controlada = comparar.diferencia_controlada(comparables)
    ok(len(controlada["estratos"]) == 6, "la comparación controlada usa 6 estratos")
    cerca(controlada["diferencia"], -0.9282, 0.002, "la diferencia controlada es de -0,9282 s")
    ok(controlada["diferencia"] > bruta["diferencia"] - 0.05,
       "controlar por piloto y carrera apenas cambia la diferencia: el sesgo no es de nivel")
    ok(controlada["peso_total"] == 60, "la ponderación usa las 60 vueltas de después")

    # Paso 5 · Ajuste con circuito, neumático y vuelta.
    ajuste = comparar.ajustar(comparables)
    beta = ajuste["beta"]
    ok(len(beta) == 6, "el ajuste estima 6 coeficientes")
    cerca(beta[1], -0.8308, 0.01, "el coeficiente de «después» es -0,8308 s")
    cerca(beta[2], 0.0243, 0.002, "cada vuelta de neumático añade 0,0243 s")
    cerca(beta[4], -8.2845, 0.01, "monza es 8,2845 s más rápida que bahrein")
    cerca(ajuste["sigma"], 0.1972, 0.005, "el error típico del ajuste es 0,1972 s")
    ok(abs(beta[1]) < abs(bruta["diferencia"]), "el ajuste reduce la diferencia bruta")

    # Paso 6 · Prueba de permutación: determinista y contundente.
    prueba = comparar.permutacion(comparables)
    ok(prueba["iteraciones"] == 2000, "la prueba hace 2000 barajados")
    cerca(prueba["observado"], controlada["diferencia"], 0.0001, "el estadístico observado es la diferencia controlada")
    cerca(prueba["p_valor"], 0.0005, 0.0002, "el p-valor es 0,0005")
    ok(prueba["p_valor"] < 0.01, "la diferencia no se explica por azar")
    repetida = comparar.permutacion(comparables)
    ok(repetida == prueba, "la prueba es determinista: misma semilla, mismo resultado")

    # Paso 7 · El código no usa red ni claves.
    codigo = (AQUI / "comparar.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
