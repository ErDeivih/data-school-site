# P13 · ¿Le costó la carrera la parada?

Paquete descargable de **Data School** para el proyecto P13. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita el repositorio, ni conexión, ni dependencias.

La pregunta del proyecto no es «¿va más rápido después?» (la media lo dice: **-0,937 s**), sino
**cuánto de esa diferencia es la parada y cuánto es el neumático nuevo y el combustible que ya no
lleva**. El código quita la vuelta de boxes, compara cada piloto consigo mismo, ajusta por circuito,
edad del neumático y vuelta, y hace una prueba de permutación para separar efecto de ruido. La
respuesta honesta es incómoda: la diferencia **no es ruido** (p = 0,0005), pero **tampoco es la
parada**: con 3 carreras y 2 pilotos, neumático y combustible van pegados a la fase y no se pueden
separar del todo; lo que sí se puede es dejar de atribuirle a la parada lo que no demuestra.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: `requirements.txt` solo lo dice. Todo va con la biblioteca
  estándar de Python, sin pandas ni statsmodels, para que se vea la cuenta por dentro.
- Windows, Linux o macOS. No hace falta red.

## Instalación

```bash
python -m pip install -r requirements.txt
```

No instala nada: el fichero existe para que el comando funcione igual que en el resto de paquetes.

## Ejecutar

```bash
python comparar.py
python verificar.py
```

`comparar.py` lee el CSV, comprueba el grano, marca las vueltas de antes y de después de la parada,
calcula la diferencia bruta, la controlada por carrera y piloto, el ajuste con circuito/neumático/
combustible y la prueba de permutación. `verificar.py` comprueba el resultado y sale 0 si todo cuadra.

Desde la carpeta del paquete (los datos se buscan en `datos-ejemplo/`):

```bash
cd P13-codigo
python comparar.py --csv datos-ejemplo/telemetria-f1.csv
```

## Salida esperada

```text
datos: 180 vueltas × 10 columnas · 6 pares carrera/piloto
vueltas comparables: 174 · paradas excluidas: 6
media antes: 89.518 s · media después: 88.582 s
diferencia bruta (después − antes): -0.937 s (114 vs 60 vueltas)
diferencia controlada por carrera y piloto: -0.928 s (6 estratos)
ajuste: después -0.831 s · edad +0.024 s/vuelta · vuelta +0.000 s/vuelta · sigma 0.197 s
permutación (2000 barajados): p = 0.000
lectura: la diferencia bruta no es ruido (p pequeño), pero tampoco es la parada: el ajuste deja un
efecto de -0.831 s cuando se descuentan neumático, combustible y circuito.
límite: 3 carreras y 2 pilotos sintéticos; no dice nada del rendimiento real de un equipo.
```

La salida completa de una ejecución está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/telemetria-f1.csv`: **180 filas × 10 columnas**. 3 carreras (`bahrein`, `monza`,
  `suzuka`) × 2 pilotos (`A`, `B`) × 30 vueltas. Compuesto `medio` antes de la parada y `duro`
  después; una parada por piloto y carrera; edad del neumático, tres sectores, tiempo de vuelta y
  marca de parada. Clave `(carrera, piloto, vuelta)` única.
- **Sintético, determinista y CC0-1.0**: es una copia literal del dataset `telemetria-f1` del
  catálogo del portal (semilla fija `20261101`). No son datos reales de ningún equipo ni circuito.
- `sha256` del fichero: `c232e767dc95184fddeb329f6a7c4c72ccb13423a2961bea717cd464150c2c3b`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida columnas y clave `(carrera, piloto, vuelta)` | grano y clave de una tabla |
| 2 · Fases | marca antes/después y excluye la vuelta de boxes | por qué un valor atípico contamina la media |
| 3 · Diferencia bruta | media de después menos media de antes | la comparación que haría cualquiera |
| 4 · Controlada | compara cada piloto consigo mismo, ponderando por vueltas | bloques y confusión |
| 5 · Ajuste | circuito, edad del neumático y vuelta | variables de control y colinealidad |
| 6 · Permutación | baraja la fase dentro de cada piloto y carrera | contraste de aleatorización, sin fórmulas mágicas |

## Las tres trampas que el código deja a la vista

1. **La vuelta de boxes no es ritmo.** Dura ~22 s más; si entra en la media, la diferencia se dispara.
   El código la excluye y lo dice en la salida (6 vueltas).
2. **Compuesto y fase están confundidos.** El neumático cambia justo en la parada: no se puede
   comparar «medio contra duro» y llamarlo efecto de la parada. Por eso el paso 4 compara cada piloto
   consigo mismo, y el paso 5 controla la edad del neumático en lugar de fingir que el compuesto es
   una variable independiente.
3. **Una diferencia grande no es una causa.** La diferencia bruta es real (-0,937 s) y no es ruido
   (p = 0,0005), pero al descontar neumático, combustible y circuito queda en -0,831 s y sigue sin
   poder separarse de esos factores con este diseño. Publicar «la parada costó 0,9 s» sería falso.

## Fallos típicos

- **`ModuleNotFoundError: comparar`**: ejecuta desde la carpeta del paquete, no desde su padre.
- **`FileNotFoundError`**: el comando se ha lanzado desde otra carpeta; `--csv` es relativo al
  directorio actual.
- **`columnas inesperadas`**: el CSV no es el del catálogo o se ha abierto con otro separador.
- **`se esperaban 1 parada`**: falta la marca `parada=1` en alguna carrera o hay dos paradas.
- **p-valor distinto en cada ejecución**: no debería; la semilla es fija y la prueba es determinista.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P13-codigo/
├── comparar.py                # pasos 1–6: grano, fases, comparación y contraste
├── verificar.py               # la puerta del proyecto: 34 comprobaciones, sin red, sin escribir
├── requirements.txt           # sin dependencias
├── datos-ejemplo/
│   └── telemetria-f1.csv      # 180 × 10 · sintético, CC0-1.0
└── resultados/
    └── ejemplo-salida.txt     # la salida real de una ejecución
```

## Límite

Son 3 carreras y 2 pilotos sintéticos generados con una regla conocida: el tiempo de vuelta es una
base por circuito más degradación, combustible, parada y ruido. Por eso las cifras salen tan limpias
y el paquete enseña el método (grano, atípicos, bloques, controles, contraste), **no** un estudio
sobre F1: no demuestra nada sobre coches, circuitos ni temporadas reales, y no sirve para apostar.
