﻿#!/usr/bin/env python3
"""Puerta del proyecto P22 (interés, inflación y riesgo).

Comprueba esquema, grano, cifras de retorno y volatilidad, retorno real, caída máxima y ausencia de red.
Sin escribir en disco. Termina en RESULTADO: VERDE (0) o ROJO (1).
"""
from __future__ import annotations

from pathlib import Path
# La consola de Windows puede estar en cp1252: se fuerza UTF-8 para los signos y acentos.
import sys as _sys
for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

import finanzas

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "cartera-acciones.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    serie = finanzas.leer(CSV)
    ok(len(serie) == 6, "hay 6 activos (índice y cinco acciones)")
    ok(all(len(v) == 60 for v in serie.values()), "cada activo tiene 60 retornos mensuales")
    ok(sum(len(v) for v in serie.values()) == 360, "el CSV suma 360 filas")

    indice = serie["indice"]
    ok(round(finanzas.acumulado(indice), 5) == -0.06478, "el índice acumula −6,478 %")
    ok(round(finanzas.anualizado(indice), 5) == -0.01331, "el índice anualiza −1,331 %")
    ok(round(finanzas.volatilidad(indice), 5) == 0.06663, "la volatilidad anual del índice es 6,663 %")
    ok(round(finanzas.caida_maxima(indice), 5) == -0.14244, "la caída máxima del índice es −14,244 %")

    a = serie["accion-a"]
    ok(round(finanzas.acumulado(a), 5) == -0.39195, "acción-a acumula −39,195 %")
    ok(round(finanzas.anualizado(a), 5) == -0.09471, "acción-a anualiza −9,471 %")
    ok(round(finanzas.volatilidad(a), 5) == 0.09985, "la volatilidad de acción-a es 9,985 %")
    ok(finanzas.volatilidad(a) > finanzas.volatilidad(indice), "acción-a es más volátil que el índice")
    ok(round(finanzas.retorno_real(finanzas.anualizado(a), 0.025), 5) == -0.11679, "acción-a pierde −11,679 % real con inflación del 2,5 %")
    ok(finanzas.retorno_real(0.0, 0.0) == 0.0, "sin inflación, el retorno real es el nominal")
    ok(float(finanzas.retorno_real(0.0, 0.025)) < 0, "con inflación, un 0 % nominal pierde poder de compra")

    # Cada activo tiene su propia volatilidad: si todas salieran iguales, se estaría leyendo mal.
    volatilidades = {a: round(finanzas.volatilidad(v), 4) for a, v in serie.items()}
    ok(len(set(volatilidades.values())) >= 4, "las volatilidades distinguen a los activos")
    ok(min(volatilidades, key=volatilidades.get) == "indice", "el índice es el activo menos volátil")

    codigo = (AQUI / "finanzas.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
