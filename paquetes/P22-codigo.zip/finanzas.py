"""P22 · Finanzas desde cero: interés, inflación y riesgo.

Convierte una serie de retornos mensuales en las tres cifras que se piden en cualquier conversación de
inversión: retorno acumulado, retorno anualizado y volatilidad. Añade el retorno real (descontando una
inflación declarada) y la caída máxima del índice. Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import math
import statistics
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("mes", "activo", "retorno")
ACTIVOS = ("indice", "accion-a", "accion-b", "accion-c", "accion-d", "accion-e")
MESES = 60


def leer(ruta: Path) -> dict[str, list[float]]:
    # Paso 1 · Leer y comprobar el grano: un retorno mensual por activo.
    # Por qué: mezclar activos o meses duplicados invalida cualquier media.
    # Salida esperada: 360 filas, 6 activos y 60 retornos por activo.
    # Si falla: «columnas inesperadas» o «meses repetidos».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    serie = defaultdict(list)
    for fila in filas:
        serie[fila["activo"]].append(float(fila["retorno"]))
    if set(serie) != set(ACTIVOS):
        raise ValueError(f"activos inesperados: {sorted(serie)}")
    for activo, valores in serie.items():
        if len(valores) != MESES:
            raise ValueError(f"{activo} tiene {len(valores)} meses, no {MESES}")
    return dict(serie)


def acumulado(retornos: list[float]) -> float:
    # Paso 2 · Encadenar los retornos: (1+r1)(1+r2)… - 1.
    # Por qué: sumar retornos simples miente cuando hay meses negativos grandes.
    # Salida esperada: el índice acumula −6,48 % en 60 meses.
    # Si falla: hay un retorno fuera de rango o una fila sin leer.
    producto = 1.0
    for r in retornos:
        producto *= 1 + r
    return producto - 1


def anualizado(retornos: list[float]) -> float:
    # Paso 3 · Pasar el acumulado a tasa anual compuesta.
    # Por qué: 60 meses no se comparan con un año sin anualizar.
    # Salida esperada: el índice anualiza −1,33 %.
    # Si falla: el número de meses no es 60.
    return (1 + acumulado(retornos)) ** (12 / len(retornos)) - 1


def volatilidad(retornos: list[float]) -> float:
    # Paso 4 · Medir el riesgo como desviación típica anualizada.
    # Por qué: el retorno sin su volatilidad no dice si el viaje fue tranquilo.
    # Salida esperada: el índice 6,66 % y acción-a 9,99 %.
    # Si falla: hay menos de dos retornos.
    return statistics.stdev(retornos) * math.sqrt(12)


def retorno_real(nominal: float, inflacion: float) -> float:
    # Paso 5 · Descontar la inflación: (1+nominal)/(1+inflación)-1.
    # Por qué: un 0 % nominal con 2,5 % de inflación es perder poder de compra.
    # Salida esperada: acción-a −11,68 % real con inflación del 2,5 %.
    # Si falla: la inflación es ≤ −1 (no tiene sentido).
    if inflacion <= -1:
        raise ValueError("la inflación debe ser mayor que -100 %")
    return (1 + nominal) / (1 + inflacion) - 1


def caida_maxima(retornos: list[float]) -> float:
    # Paso 6 · Calcular la peor caída desde un máximo de la serie encadenada.
    # Por qué: el drawdown es lo que de verdad sufre quien invierte, no la media.
    # Salida esperada: el índice cae un −14,24 % desde su máximo.
    # Si falla: la serie está vacía.
    valor, serie, pico, peor = 1.0, [1.0], 1.0, 0.0
    for r in retornos:
        valor *= 1 + r
        serie.append(valor)
        pico = max(pico, valor)
        peor = min(peor, valor / pico - 1)
    return peor


def main() -> int:
    # Paso 7 · Publicar las cifras con el supuesto de inflación a la vista.
    # Por qué: sin declarar la inflación, el retorno real es una cifra inventada.
    # Salida esperada: tabla con acumulado, anualizado, volatilidad, real y caída máxima.
    # Si falla: revisa la ruta del CSV o el valor de --inflacion.
    parser = argparse.ArgumentParser(description="Interés, inflación y riesgo (P22)")
    parser.add_argument("--csv", default="datos-ejemplo/cartera-acciones.csv")
    parser.add_argument("--inflacion", type=float, default=0.025)
    args = parser.parse_args()
    serie = leer(Path(args.csv))
    print(f"activos: {len(serie)} · meses por activo: {MESES} · inflación supuesta: {args.inflacion:.1%}")
    print("activo  acumulado  anualizado  volatilidad  real")
    for activo in ACTIVOS:
        r = serie[activo]
        print(f"{activo:<8} {acumulado(r):>9.2%} {anualizado(r):>11.2%} {volatilidad(r):>12.2%} {retorno_real(anualizado(r), args.inflacion):>7.2%}")
    print(f"caída máxima del índice: {caida_maxima(serie['indice']):.2%}")
    print("límite: retornos mensuales sintéticos; no es una recomendación ni una serie real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
