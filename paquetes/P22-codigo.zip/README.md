# P22 · Finanzas desde cero: interés, inflación y riesgo

Paquete descargable de **Data School** para el proyecto P22. Incluye la serie de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python finanzas.py
python finanzas.py --inflacion 0.03
python verificar.py
```

`finanzas.py` imprime por activo el retorno acumulado, el anualizado, la volatilidad y el retorno real;
termina con la caída máxima del índice. La inflación es un supuesto declarado (`--inflacion`, 2,5 % por
defecto). `verificar.py` sale 0 si todas las cifras cuadran.

## Datos

- `datos-ejemplo/cartera-acciones.csv`: **360 filas × 3 columnas** (60 retornos mensuales de enero de
  2021 a diciembre de 2025 para el índice y cinco acciones). Sintético y **CC0-1.0**; es el
  `cartera-acciones` del catálogo de Data School.

## Salida esperada

```text
activos: 6 · meses por activo: 60 · inflación supuesta: 2.5%
activo  acumulado  anualizado  volatilidad  real
indice      -6.48%      -1.33%        6.66%  -3.74%
accion-a   -39.20%      -9.47%        9.98% -11.68%
...
caída máxima del índice: -14.24%
límite: retornos mensuales sintéticos; no es una recomendación ni una serie real.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Leer y comprobar el grano | `leer` valida columnas, activos y 60 meses | medidas de centralidad |
| 2 · Encadenar retornos | `acumulado` multiplica (1+r) en vez de sumar | logaritmos y escalas logarítmicas |
| 3 · Anualizar | `anualizado` lleva 60 meses a tasa anual | medidas de centralidad |
| 4 · Medir el riesgo | `volatilidad` anualiza la desviación típica | varianza y desviación |
| 5 · Descontar inflación | `retorno_real` calcula (1+nominal)/(1+inflación)-1 | medidas de centralidad |
| 6 · Caída máxima | `caida_maxima` busca el peor momento desde un máximo | varianza y desviación |

## Fallos típicos

- **`activos inesperados`**: falta el índice o se ha añadido una acción fuera del contrato.
- **`X tiene N meses, no 60`**: la serie está recortada; el anualizado no sería comparable.
- **Retorno real igual al nominal**: se ha pasado `--inflacion 0` o no se ha aplicado el descuento.
- **Sumar retornos en vez de encadenarlos**: con meses negativos grandes, la cifra se aleja de la real.

## Límite

Los retornos son sintéticos y cubren cinco años. Sirven para aprender las tres cifras y el supuesto de
inflación, no para valorar una cartera real.
