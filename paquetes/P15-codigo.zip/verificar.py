#!/usr/bin/env python3
"""Puerta del proyecto P15 (¿batir al índice o asumir más riesgo?).

Comprueba grano, beta, alpha, intervalos, p-valores, corrección por pruebas múltiples y que el
código no usa red ni claves. VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import analizar

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "cartera-acciones.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = analizar.leer(CSV)
    ok(len(filas) == 360, "el CSV tiene 360 filas")
    ok(len({f["mes"] for f in filas}) == 60, "hay 60 meses")
    ok({f["activo"] for f in filas} == {"indice", *analizar.ACCIONES}, "están el índice y las 5 acciones")
    ok(all(sum(1 for f in filas if f["activo"] == a) == 60 for a in analizar.ACCIONES),
       "cada acción tiene los 60 meses")

    mercado, acciones = analizar.series(filas)
    ok(len(mercado) == 60 and len(acciones) == 5, "series alineadas: 60 meses × 5 acciones")
    cerca(sum(mercado) / len(mercado), -0.0009, 0.0002, "el índice rinde -0,09 % de media al mes")

    resultado = analizar.analizar(mercado, acciones)
    betas = {a: resultado[a]["beta"] for a in analizar.ACCIONES}
    alfas = {a: resultado[a]["alpha_anual"] for a in analizar.ACCIONES}
    cerca(betas["accion-a"], 0.246, 0.003, "beta de la acción a")
    cerca(betas["accion-b"], -0.141, 0.003, "beta de la acción b")
    cerca(betas["accion-c"], 0.127, 0.003, "beta de la acción c")
    cerca(betas["accion-d"], -0.267, 0.003, "beta de la acción d")
    cerca(betas["accion-e"], 0.116, 0.003, "beta de la acción e")
    cerca(alfas["accion-a"], -0.0914, 0.002, "alpha anual de la acción a")
    cerca(alfas["accion-b"], -0.1017, 0.002, "alpha anual de la acción b")
    cerca(alfas["accion-c"], 0.0042, 0.002, "alpha anual de la acción c")
    cerca(alfas["accion-d"], 0.0498, 0.002, "alpha anual de la acción d")
    cerca(alfas["accion-e"], 0.1126, 0.002, "alpha anual de la acción e")
    cerca(resultado["accion-a"]["p_alpha"], 0.0398, 0.001, "p-valor del alpha de a")
    cerca(resultado["accion-b"]["p_alpha"], 0.0464, 0.001, "p-valor del alpha de b")
    cerca(resultado["accion-c"]["p_alpha"], 0.9579, 0.001, "p-valor del alpha de c")
    cerca(resultado["accion-d"]["p_alpha"], 0.5014, 0.001, "p-valor del alpha de d")
    cerca(resultado["accion-e"]["p_alpha"], 0.2411, 0.001, "p-valor del alpha de e")
    ok(all(resultado[a]["r2"] < 0.1 for a in analizar.ACCIONES),
       "el mercado explica menos del 10 % del retorno de estas acciones (R² bajo)")
    ok(resultado["accion-c"]["alpha_anual_bajo"] < 0 < resultado["accion-c"]["alpha_anual_alto"],
       "en la acción c el intervalo del alpha cruza 0")
    ok(resultado["accion-d"]["alpha_anual_bajo"] < 0 < resultado["accion-d"]["alpha_anual_alto"],
       "en la acción d el intervalo del alpha cruza 0")
    ok(resultado["accion-e"]["alpha_anual_bajo"] < 0 < resultado["accion-e"]["alpha_anual_alto"],
       "en la acción e el intervalo del alpha cruza 0")

    correccion = analizar.pruebas_multiples(resultado)
    ok(correccion["familia"] == 5, "la familia de alphas tiene 5 pruebas")
    ok(correccion["sin_corregir"] == 2, "sin corregir hay 2 alphas con p < 0,05")
    ok(correccion["bonferroni"] == 0, "con Bonferroni no sobrevive ninguno (umbral 0,01)")
    ok(correccion["holm"] == 0, "con Holm tampoco sobrevive ninguno")
    cerca(correccion["umbral_bonferroni"], 0.01, 0.0001, "umbral de Bonferroni 0,05/5")
    cerca(correccion["probabilidad_alguna_por_azar"], 0.2262, 0.001, "probabilidad de falso positivo familiar")

    codigo = (AQUI / "analizar.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
