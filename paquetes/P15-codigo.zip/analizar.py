"""P15 · ¿Batir al índice o asumir más riesgo?

Separa el retorno de una acción que se explica por el mercado (beta) del que no (alpha) y decide
si el alpha estimado puede ser suerte. Después corrige por haber probado CINCO acciones a la vez:
con 5 pruebas, alguna sale «significativa» por azar más a menudo de lo que parece.

Sin dependencias externas: solo la biblioteca estándar. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("mes", "activo", "retorno")
MERCADO = "indice"
ACCIONES = ("accion-a", "accion-b", "accion-c", "accion-d", "accion-e")
MESES = 60


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el grano: una fila por mes y activo.
    # Por qué: si un activo tiene menos meses que otro, los betas no son comparables.
    # Salida esperada: 360 filas, 60 meses y 6 activos (el índice + 5 acciones).
    # Si falla: «columnas inesperadas» o «cada activo debe tener los 60 meses».
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 360:
        raise ValueError(f"se esperaban 360 filas, hay {len(filas)}")
    meses = sorted({f["mes"] for f in filas})
    if len(meses) != MESES:
        raise ValueError(f"se esperaban {MESES} meses, hay {len(meses)}")
    por_activo = defaultdict(int)
    for fila in filas:
        por_activo[fila["activo"]] += 1
        float(fila["retorno"])
    if set(por_activo) != {MERCADO, *ACCIONES}:
        raise ValueError(f"activos inesperados: {sorted(por_activo)}")
    if any(n != MESES for n in por_activo.values()):
        raise ValueError("cada activo debe tener los 60 meses")
    return filas


def series(filas: list[dict]) -> tuple[list[float], dict[str, list[float]]]:
    # Paso 2 · Pivotar a series alineadas: la misma fecha en la misma posición para todos.
    # Por qué: si se alinean por orden de aparición, un mes perdido desplaza el resto y el beta
    # sale de otra serie. Aquí se comprueba que las fechas coinciden.
    por_mes: dict[str, dict[str, float]] = defaultdict(dict)
    for fila in filas:
        por_mes[fila["mes"]][fila["activo"]] = float(fila["retorno"])
    mercado = [por_mes[m][MERCADO] for m in sorted(por_mes)]
    acciones = {a: [por_mes[m][a] for m in sorted(por_mes)] for a in ACCIONES}
    return mercado, acciones


def _resolver(a: list[list[float]], b: list[float]) -> list[float]:
    """Gauss con pivote parcial: 2×2 y 3×3 sin numpy."""
    n = len(b)
    for col in range(n):
        pivote = max(range(col, n), key=lambda r: abs(a[r][col]))
        a[col], a[pivote] = a[pivote], a[col]
        b[col], b[pivote] = b[pivote], b[col]
        for fila in range(col + 1, n):
            factor = a[fila][col] / a[col][col]
            for c in range(col, n):
                a[fila][c] -= factor * a[col][c]
            b[fila] -= factor * b[col]
    x = [0.0] * n
    for fila in range(n - 1, -1, -1):
        x[fila] = (b[fila] - sum(a[fila][c] * x[c] for c in range(fila + 1, n))) / a[fila][fila]
    return x


def regresion(y: list[float], x: list[float]) -> dict:
    # Paso 3 · Regresión del modelo de mercado: r_i = alpha + beta · r_m + error.
    # Por qué: el beta mide cuánto se mueve la acción con el mercado; el alpha, lo que sobra.
    # Salida esperada: beta de cada acción y alpha mensual, con su error típico y su intervalo.
    # Si falla: el mercado no tiene varianza (beta indefinido) o faltan observaciones.
    n = len(y)
    media_x = sum(x) / n
    media_y = sum(y) / n
    sxx = sum((xi - media_x) ** 2 for xi in x)
    if not sxx:
        raise ValueError("el mercado no tiene varianza")
    sxy = sum((xi - media_x) * (yi - media_y) for xi, yi in zip(x, y))
    beta = sxy / sxx
    alpha = media_y - beta * media_x
    residuos = [yi - alpha - beta * xi for xi, yi in zip(x, y)]
    sigma2 = sum(r * r for r in residuos) / (n - 2)
    ee_alpha = math.sqrt(sigma2 * (1 / n + media_x ** 2 / sxx))
    ee_beta = math.sqrt(sigma2 / sxx)
    t_alpha = alpha / ee_alpha if ee_alpha else 0.0
    t_beta = beta / ee_beta if ee_beta else 0.0
    sst = sum((yi - media_y) ** 2 for yi in y)
    r2 = 1 - sum(r * r for r in residuos) / sst if sst else 0.0
    return {"alpha": alpha, "beta": beta, "ee_alpha": ee_alpha, "ee_beta": ee_beta,
            "t_alpha": t_alpha, "t_beta": t_beta, "r2": r2, "residuos": residuos}


def p_valor_dos_colas(t: float) -> float:
    # Paso 4 · p-valor aproximado del t con la normal tipificada.
    # Por qué: con 58 grados de libertad, la normal es suficientemente buena y evita tablas.
    # Si falla: un t enorme devuelve 0.0, que es el límite correcto.
    return math.erfc(abs(t) / math.sqrt(2))


def intervalo(valor: float, error: float, z: float = 1.96) -> tuple[float, float]:
    # Paso 5 · Intervalo de confianza al 95 % (aproximación normal).
    # Por qué: un alpha sin intervalo invita a leer una cifra puntual como si fuera cierta.
    return valor - z * error, valor + z * error


def analizar(mercado: list[float], acciones: dict[str, list[float]]) -> dict:
    # Paso 6 · Ajustar cada acción y juntar los p-valores.
    # Por qué: el resultado que se publica no es «el que salió significativo», sino la tabla entera.
    # Salida esperada: 5 regresiones con beta, alpha, intervalo y p-valor; alpha anualizado ×12.
    resultado = {}
    for nombre, serie in acciones.items():
        ajuste = regresion(serie, mercado)
        p = p_valor_dos_colas(ajuste["t_alpha"])
        bajo, alto = intervalo(ajuste["alpha"], ajuste["ee_alpha"])
        resultado[nombre] = {
            **ajuste,
            "p_alpha": p,
            "alpha_anual": ajuste["alpha"] * 12,
            "alpha_anual_bajo": bajo * 12,
            "alpha_anual_alto": alto * 12,
        }
    return resultado


def pruebas_multiples(resultado: dict, alfa: float = 0.05) -> dict:
    # Paso 7 · Corregir por haber probado 5 acciones: Bonferroni y Holm.
    # Por qué: con 5 pruebas al 5 %, la probabilidad de que alguna salga «significativa» por azar
    # es 1 - 0,95^5 = 22,6 %. El umbral por prueba baja a 0,05/5 = 0,01.
    # Salida esperada: cuántas pasan sin corregir y cuántas pasan con cada corrección.
    ordenados = sorted(resultado.items(), key=lambda par: par[1]["p_alpha"])
    umbral = alfa / len(ordenados)
    sin_corregir = sum(1 for v in resultado.values() if v["p_alpha"] < alfa)
    bonferroni = sum(1 for v in resultado.values() if v["p_alpha"] < umbral)
    holm = 0
    for i, (_, v) in enumerate(ordenados):
        if v["p_alpha"] < alfa / (len(ordenados) - i):
            holm += 1
        else:
            break
    return {"sin_corregir": sin_corregir, "bonferroni": bonferroni, "holm": holm,
            "umbral_bonferroni": umbral, "familia": len(ordenados),
            "probabilidad_alguna_por_azar": 1 - (1 - alfa) ** len(ordenados)}


def main() -> int:
    parser = argparse.ArgumentParser(description="P15 · alpha, beta y pruebas múltiples")
    parser.add_argument("--csv", default="datos-ejemplo/cartera-acciones.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    mercado, acciones = series(filas)
    resultado = analizar(mercado, acciones)
    correccion = pruebas_multiples(resultado)

    print(f"datos: {len(filas)} filas · {len(mercado)} meses × {len(acciones)} acciones · "
          f"índice con media {sum(mercado) / len(mercado):+.4f} por mes")
    print("acción       beta    alpha/mes   alpha/año  IC95% anual          p-valor   R²")
    for nombre, r in resultado.items():
        print(f"{nombre:12} {r['beta']:6.3f}   {r['alpha']:+.5f}   {r['alpha_anual']:+.4f}   "
              f"[{r['alpha_anual_bajo']:+.4f}, {r['alpha_anual_alto']:+.4f}]   "
              f"{r['p_alpha']:.4f}   {r['r2']:.3f}")
    print(f"pruebas: {correccion['familia']} alpha · sin corregir {correccion['sin_corregir']} "
          f"· Bonferroni {correccion['bonferroni']} (umbral {correccion['umbral_bonferroni']:.3f}) "
          f"· Holm {correccion['holm']}")
    print(f"con 5 pruebas al 5 %, alguna sale «significativa» por azar el "
          f"{correccion['probabilidad_alguna_por_azar'] * 100:.1f} % de las veces")
    print("lectura: el alpha de una sola acción se lee con su intervalo; si el intervalo cruza 0, "
          "no hay evidencia de batir al índice, solo de asumir el beta.")
    print("límite: 5 acciones sintéticas y 60 meses; no es una recomendación de inversión.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
