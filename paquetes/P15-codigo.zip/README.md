# P15 · ¿Batir al índice o asumir más riesgo?

Paquete descargable de **Data School** para el proyecto P15. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita el repositorio, ni conexión, ni dependencias.

La pregunta del proyecto es separar dos cosas que el retorno mezcla: lo que se explica por el
mercado (**beta**) y lo que sobra (**alpha**). Y, sobre todo, decidir si ese alpha puede ser suerte:
con cinco acciones probadas a la vez, ver dos «significativas» al 5 % no es un hallazgo, es lo que
se espera el **22,6 %** de las veces. El código lo demuestra y después corrige por Bonferroni y Holm.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: `requirements.txt` solo lo dice. Todo va con la biblioteca
  estándar de Python, sin pandas ni statsmodels, para que se vea la cuenta por dentro.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python analizar.py
python verificar.py
```

Desde la carpeta del paquete (los datos se buscan en `datos-ejemplo/`):

```bash
cd P15-codigo
python analizar.py --csv datos-ejemplo/cartera-acciones.csv
```

## Salida esperada

```text
datos: 360 filas · 60 meses × 5 acciones · índice con media -0.0009 por mes
acción       beta    alpha/mes   alpha/año  IC95% anual          p-valor   R²
accion-a      0.246   -0.00762   -0.0914   [-0.1786, -0.0042]   0.0398   0.027
accion-b     -0.141   -0.00847   -0.1017   [-0.2018, -0.0016]   0.0464   0.007
accion-c      0.127   +0.00035   +0.0042   [-0.1526, +0.1610]   0.9579   0.002
accion-d     -0.267   +0.00415   +0.0498   [-0.0954, +0.1950]   0.5014   0.012
accion-e      0.116   +0.00938   +0.1126   [-0.0757, +0.3009]   0.2411   0.001
pruebas: 5 alpha · sin corregir 2 · Bonferroni 0 (umbral 0.010) · Holm 0
con 5 pruebas al 5 %, alguna sale «significativa» por azar el 22.6 % de las veces
lectura: el alpha de una sola acción se lee con su intervalo; si el intervalo cruza 0, no hay
evidencia de batir al índice, solo de asumir el beta.
límite: 5 acciones sintéticas y 60 meses; no es una recomendación de inversión.
```

La salida completa está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/cartera-acciones.csv`: **360 filas × 3 columnas** (`mes`, `activo`, `retorno`).
  60 meses × 6 activos: el índice de mercado y cinco acciones (`accion-a`…`accion-e`). Retornos
  mensuales en tanto por uno.
- **Sintético, determinista y CC0-1.0**: es una copia literal del dataset `cartera-acciones` del
  catálogo del portal. No son datos reales de ninguna acción ni índice.
- `sha256` del fichero: `62ccc9a7355a27559024f7e4b725792d2be58a379fad4b4740a8a6fd25eacd51`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida grano, 60 meses y 6 activos | grano y alineación de series |
| 2 · Pivotar | alinea cada mes con el mismo índice | por qué un mes desplazado cambia el beta |
| 3 · Modelo de mercado | OLS `r_i = alpha + beta·r_m + e` | beta, alpha, error típico y R² |
| 4 · p-valor | normal tipificada con 58 grados de libertad | contraste de significación |
| 5 · Intervalo | alpha ± 1,96 · error | leer el alpha como intervalo, no como cifra |
| 6 · Familia | 5 alphas a la vez, anualizados ×12 | comparación honesta entre acciones |
| 7 · Corrección | Bonferroni y Holm | data snooping y pruebas múltiples |

## Las tres trampas que el código deja a la vista

1. **Un beta bajo no es un alpha.** Las acciones a y d tienen beta 0,246 y −0,267: se mueven poco
   con el mercado. Eso no las hace buenas; solo dice que su retorno no viene del índice.
2. **El alpha sin intervalo engaña.** La acción e tiene el alpha anual más alto (+0,1126) y su
   intervalo va de −0,0757 a +0,3009: cruza 0. No hay evidencia de batir al índice.
3. **Cinco pruebas no son una prueba.** Dos alphas salen con p < 0,05, pero con Bonferroni
   (0,05/5 = 0,01) no sobrevive ninguno. El 22,6 % de las veces alguna sale por azar.

## Fallos típicos

- **`ModuleNotFoundError: analizar`**: ejecuta desde la carpeta del paquete, no desde su padre.
- **`FileNotFoundError`**: el comando se ha lanzado desde otra carpeta; `--csv` es relativo.
- **`columnas inesperadas`**: el CSV no es el del catálogo o se ha abierto con otro separador.
- **`cada activo debe tener los 60 meses`**: falta un mes o una fila duplicada.
- **p-valores distintos en cada ejecución**: no debería; no hay aleatoriedad.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P15-codigo/
├── analizar.py                # pasos 1–7: modelo de mercado, intervalos y correcciones
├── verificar.py               # la puerta del proyecto: 33 comprobaciones
├── requirements.txt           # sin dependencias
├── datos-ejemplo/
│   └── cartera-acciones.csv   # 360 × 3 · sintético, CC0-1.0
└── resultados/
    └── ejemplo-salida.txt     # la salida real de una ejecución
```

## Límite

Son 60 meses sintéticos de cinco acciones: el mercado explica menos del 3 % de su retorno y los
alphas son ruido con estructura. El paquete enseña el **método** (modelo de mercado, intervalos,
familia de pruebas y correcciones), no un análisis de inversión: no describe ninguna acción real,
no sirve para elegir cartera y no es asesoramiento financiero.
