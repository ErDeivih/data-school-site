#!/usr/bin/env python3
"""Puerta del proyecto P63 (ventana de undercut con pérdida en boxes y degradación).

Comprueba el resultado de verdad, sin escribir nada y sin red: el CSV es el del catálogo (sha256) y
tiene una parada por grupo, los sectores reconstruyen la vuelta, la pérdida en boxes sale de la serie
(22,40–22,68 s), la degradación se estima por compuesto con sus unidades y su n, la ventana de
undercut se expresa en vueltas y el estudio de coste dice que la parada no se paga dentro de la
carrera con la degradación medida.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import undercut as p

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P63 · ventana de undercut: boxes y degradación ==")

    # Paso 1 · Comprueba el dato de ejemplo y la estructura de grupos
    # Por qué: la pérdida en boxes se calcula restando la vuelta de parada; si el fichero no es el del
    #          catálogo, la resta no es comparable con la ficha.
    # Salida esperada: "datos: 180 filas × 10 columnas · 6 grupos de 30 vueltas · sha256 c232e767…"
    # Si falla: FileNotFoundError → falta datos-ejemplo/telemetria-f1.csv (el ZIP lo trae).
    df = p.cargar()
    ok(len(df) == 180 and df.shape[1] == 10, f"CSV: {len(df)} filas × {df.shape[1]} columnas")
    ok(p.sha256(p.DATOS) == "c232e767dc95184fddeb329f6a7c4c72ccb13423a2961bea717cd464150c2c3b",
       "el sha256 del CSV de ejemplo es el de la copia del catálogo")

    # Paso 2 · Comprueba una sola parada por grupo y los sectores
    # Por qué: los sectores son un desglose del mismo dato; si no suman el tiempo de vuelta, cualquier
    #          reparto de la pérdida por sector sería falso.
    # Salida esperada: "estructura: 1 parada por grupo · sectores suman con error máximo 0.0010 s"
    # Si falla: error de sectores > 0,01 s → el CSV tiene una vuelta corrupta.
    estructura = p.comprobar_estructura(df)
    ok(estructura["diferencia_max_s"] <= 0.01,
       f"sectores: error máximo {estructura['diferencia_max_s']:.4f} s")
    paradas = df[df["parada"] == 1].groupby(["carrera", "piloto"]).size()
    ok((paradas == 1).all(), "una parada por carrera y piloto")
    vueltas = sorted(df[df["parada"] == 1]["vuelta"].tolist())
    ok(vueltas == [18, 18, 18, 22, 22, 22], f"vueltas de parada: {vueltas}")

    # Paso 3 · Comprueba que la pérdida en boxes sale de la serie
    # Por qué: el criterio de la ficha pide que salga de las vueltas de parada del CSV; se recalcula
    #          desde el tiempo de la vuelta de parada y la mediana de las verdes del tramo.
    # Salida esperada: "pérdida en boxes: 22.40–22.68 s en 6 grupos · mediana 22.59 s"
    # Si falla: pérdidas fuera de 20-25 s → la marca de parada o el tramo están mal filtrados.
    boxes = p.perdida_en_boxes(df)
    ok(len(boxes) == 6, f"pérdidas calculadas: {len(boxes)} grupos")
    ok(boxes["perdida_s"].between(20.0, 25.0).all(),
       f"pérdida en boxes entre {boxes['perdida_s'].min():.2f} y {boxes['perdida_s'].max():.2f} s")
    ok(bool((abs(boxes["perdida_s"] - (boxes["tiempo_parada_s"] - boxes["mediana_verde_s"])) < 1e-9).all()),
       "la pérdida publicada es tiempo de parada menos mediana del tramo")
    boxes2 = p.perdida_en_boxes(df)
    ok(boxes.equals(boxes2), "la pérdida es determinista")

    # Paso 4 · Comprueba la degradación por compuesto, con su unidad y su n
    # Por qué: el criterio pide una degradación por compuesto con unidad; además compuesto y tramo van
    #          confundidos en este CSV y el README tiene que decirlo.
    # Salida esperada: "degradación: duro 0.0278 s/vuelta (n=60) · medio 0.0237 s/vuelta (n=114)"
    # Si falla: pendiente negativa o fuera de rango → revisa edad_neumatico y el filtro de verdes.
    degradacion = p.estimar_degradacion(df)
    principales = degradacion[~degradacion["compuesto"].str.contains("·")].set_index("compuesto")
    ok(set(principales.index) == {"medio", "duro"}, f"compuestos: {sorted(principales.index)}")
    ok(principales["pendiente_s_vuelta"].between(0.015, 0.04).all(),
       f"pendientes: {principales['pendiente_s_vuelta'].to_dict()}")
    ok(int(principales.loc["medio", "n_vueltas"]) == 114 and
       int(principales.loc["duro", "n_vueltas"]) == 60,
       f"n de verdes: medio {int(principales.loc['medio', 'n_vueltas'])} · "
       f"duro {int(principales.loc['duro', 'n_vueltas'])}")

    # Paso 5 · Comprueba la ventana en vueltas y el estudio de coste
    # Por qué: la ventana es el entregable; se comprueba que está en vueltas, que baja al envejecer el
    #          rival y que el coste de parar no se paga dentro de una carrera de 30 vueltas.
    # Salida esperada: "ventana: 3–5 vueltas para edades 10–18 con diferencia inicial 1.0 s"
    # Si falla: ventana de cientos de vueltas → la degradación estimada es demasiado pequeña.
    ventana = p.calcular_ventana(boxes, degradacion)
    ok(ventana["ventana_vueltas"].between(2, 6).all(),
       f"ventana en vueltas: {int(ventana['ventana_vueltas'].min())}–"
       f"{int(ventana['ventana_vueltas'].max())}")
    ok(ventana["coste_vueltas"].min() > 30,
       f"la parada se paga en {int(ventana['coste_vueltas'].min())} vueltas como mínimo (más de 30)")
    for compuesto, grupo in ventana.groupby("compuesto"):
        ordenado = grupo.sort_values("edad_rival")
        ok(bool((ordenado["ventana_vueltas"].diff().dropna() <= 0).all()),
           f"la ventana no sube con la edad del rival ({compuesto})")

    # Paso 6 · Comprueba que el contraste está documentado y que no hay red ni secretos
    # Por qué: OpenF1 y Jolpica se citan con licencia y límite; la puerta se ejecuta sin red.
    # Salida esperada: "contraste documentado y código offline"
    # Si falla: falta la mención a las dos fuentes o aparece una llamada de red.
    texto = (p.RAIZ / "undercut.py").read_text(encoding="utf-8")
    ok("OpenF1" in texto and "Jolpica F1" in texto and "CC0-1.0" in texto,
       "el código cita OpenF1, Jolpica F1 y la licencia del CSV")
    ok(not any(x in texto for x in ("import requests", "import urllib", "import socket",
                                    "urlopen(", "requests.get")),
       "el código no hace peticiones de red")
    ok(not any(x in texto for x in ("ghp_", "github_pat_", "Authorization:")),
       "el código no contiene claves ni cabeceras de autorización")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
