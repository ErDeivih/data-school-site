#!/usr/bin/env python3
"""P63 · Ventana de undercut: pérdida en boxes y degradación.

Código ejecutable del proyecto P63 (ruta ciencia). Convierte una serie de vueltas en los dos
parámetros de la estrategia —lo que cuesta una parada y lo que se degrada un neumático— y calcula
la ventana de undercut en vueltas con un modelo declarado y un supuesto explícito. El contraste
real con OpenF1 y Jolpica F1 se documenta, no se descarga.

Uso:
    python undercut.py            # pipeline completo; escribe las tablas en resultados/
    python undercut.py limpiar    # borra las tablas generadas y deja el proyecto como descargado

Datos: datos-ejemplo/telemetria-f1.csv (180 filas × 10 columnas, CC0-1.0; procedencia en el README).
Sin red: solo numpy y pandas.
"""
from __future__ import annotations

import argparse
import hashlib
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo" / "telemetria-f1.csv"
RESULTADOS = RAIZ / "resultados"

DELTA_T = 1.0        # supuesto declarado: el rival rueda 1,0 s por delante al empezar el undercut
EDADES = list(range(10, 19))
COLUMNAS = ["carrera", "piloto", "vuelta", "compuesto", "edad_neumatico", "sector1_s",
            "sector2_s", "sector3_s", "tiempo_vuelta_s", "parada"]
GENERADOS = ["boxes.csv", "degradacion.csv", "ventana.csv", "contraste-openf1.md"]


def exigir(condicion: bool, mensaje: str) -> None:
    """Aborta con un mensaje legible; el pipeline devuelve 1 y no deja resultados a medias."""
    if not condicion:
        raise RuntimeError(mensaje)


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def cargar() -> pd.DataFrame:
    # Paso 1 · Carga el CSV y comprueba recuentos, claves y la marca de parada
    # Por qué: la pérdida en boxes se calcula restando la vuelta de parada; si hay dos paradas por
    #          piloto o falta una vuelta, la resta cambia de significado sin avisar.
    # Salida esperada: "datos: 180 filas × 10 columnas · 6 grupos de 30 vueltas · 1 parada por grupo"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o recupera el CSV de datos-ejemplo/.
    exigir(DATOS.exists(), f"no existe el dato de ejemplo: {DATOS}")
    df = pd.read_csv(DATOS)
    exigir(list(df.columns) == COLUMNAS, f"columnas inesperadas: {list(df.columns)}")
    exigir(len(df) == 180, f"se esperaban 180 filas y hay {len(df)}")
    exigir(df.duplicated(["carrera", "piloto", "vuelta"]).sum() == 0,
           "la clave (carrera, piloto, vuelta) no es única")
    exigir(int(df.isna().sum().sum()) == 0, "el CSV trae valores nulos")
    grupos = df.groupby(["carrera", "piloto"]).size()
    exigir(len(grupos) == 6 and grupos.nunique() == 1, f"grupos inesperados: {len(grupos)}")
    print(f"datos: {len(df)} filas × {df.shape[1]} columnas · {len(grupos)} grupos de "
          f"{int(grupos.iloc[0])} vueltas · sha256 {sha256(DATOS)[:8]}…")
    return df


def comprobar_estructura(df: pd.DataFrame) -> dict:
    # Paso 2 · Comprueba una parada por grupo y que los sectores reconstruyen la vuelta
    # Por qué: los sectores son un desglose del mismo dato; si no suman el tiempo de vuelta, el CSV
    #          está mezclado y cualquier reparto de pérdida por sector sería falso.
    # Salida esperada: "estructura: 1 parada por grupo · sectores suman con error máximo 0.0010 s"
    # Si falla: error de sectores > 0,01 s → el CSV no es el del catálogo o hay una vuelta corrupta.
    paradas = df[df["parada"] == 1].groupby(["carrera", "piloto"]).size()
    exigir((paradas == 1).all(), f"paradas por grupo inesperadas: {dict(paradas)}")
    diferencia = (df["sector1_s"] + df["sector2_s"] + df["sector3_s"] - df["tiempo_vuelta_s"]).abs()
    exigir(float(diferencia.max()) <= 0.01, f"los sectores no suman la vuelta: {diferencia.max():.4f} s")
    vueltas_parada = df[df["parada"] == 1][["carrera", "piloto", "vuelta"]]
    print(f"estructura: 1 parada por grupo · sectores suman con error máximo "
          f"{diferencia.max():.4f} s · vueltas de parada {sorted(vueltas_parada['vuelta'].tolist())}")
    return {"diferencia_max_s": float(diferencia.max())}


def perdida_en_boxes(df: pd.DataFrame) -> pd.DataFrame:
    # Paso 3 · Calcula la pérdida en boxes contra la mediana de las vueltas verdes del tramo
    # Por qué: la vuelta de parada incluye la entrada a boxes; restarla a la mediana del mismo tramo
    #          aísla el coste de parar sin que la degradación del neumático contamine la cifra.
    # Salida esperada: "pérdida en boxes: 22.40–22.68 s en 6 grupos · mediana 22.53 s"
    # Si falla: pérdidas negativas o de minutos → la marca parada o la vuelta están mal alineadas.
    filas = []
    for (carrera, piloto), grupo in df.groupby(["carrera", "piloto"]):
        parada = grupo[grupo["parada"] == 1].iloc[0]
        verdes = grupo[(grupo["parada"] == 0) & (grupo["vuelta"] < parada["vuelta"])]
        exigir(len(verdes) >= 10, f"pocas vueltas verdes antes de la parada en {carrera}/{piloto}")
        mediana = float(verdes["tiempo_vuelta_s"].median())
        filas.append({"carrera": carrera, "piloto": piloto, "vuelta_parada": int(parada["vuelta"]),
                      "tiempo_parada_s": round(float(parada["tiempo_vuelta_s"]), 3),
                      "mediana_verde_s": round(mediana, 3), "n_verdes": len(verdes),
                      "perdida_s": round(float(parada["tiempo_vuelta_s"]) - mediana, 3)})
    boxes = pd.DataFrame(filas)
    print(f"pérdida en boxes: {boxes['perdida_s'].min():.2f}–{boxes['perdida_s'].max():.2f} s en "
          f"{len(boxes)} grupos · mediana {boxes['perdida_s'].median():.2f} s")
    return boxes


def estimar_degradacion(df: pd.DataFrame) -> pd.DataFrame:
    # Paso 4 · Ajusta la degradación por compuesto con las vueltas verdes
    # Por qué: se estima una pendiente (s/vuelta) por compuesto; el CSV tiene el medio en el primer
    #          tramo y el duro en el segundo, así que compuesto y combustible van confundidos y se
    #          declara en el README.
    # Salida esperada: "degradación: medio 0.0237 s/vuelta (n=114) · duro 0.0278 s/vuelta (n=60)"
    # Si falla: pendiente negativa o sin sentido → revisa edad_neumatico y las vueltas filtradas.
    verdes = df[df["parada"] == 0]
    filas = []
    for compuesto, grupo in verdes.groupby("compuesto"):
        pendiente = float(np.polyfit(grupo["edad_neumatico"], grupo["tiempo_vuelta_s"], 1)[0])
        filas.append({"compuesto": compuesto, "pendiente_s_vuelta": round(pendiente, 4),
                      "n_vueltas": len(grupo),
                      "edad_min": int(grupo["edad_neumatico"].min()),
                      "edad_max": int(grupo["edad_neumatico"].max())})
    for carrera in sorted(verdes["carrera"].unique()):
        for compuesto in sorted(verdes["compuesto"].unique()):
            grupo = verdes[(verdes["carrera"] == carrera) & (verdes["compuesto"] == compuesto)]
            filas.append({"compuesto": f"{compuesto}·{carrera}",
                          "pendiente_s_vuelta": round(float(np.polyfit(
                              grupo["edad_neumatico"], grupo["tiempo_vuelta_s"], 1)[0]), 4),
                          "n_vueltas": len(grupo),
                          "edad_min": int(grupo["edad_neumatico"].min()),
                          "edad_max": int(grupo["edad_neumatico"].max())})
    degradacion = pd.DataFrame(filas)
    por_compuesto = degradacion[~degradacion["compuesto"].str.contains("·")]
    resumen = " · ".join(f"{fila.compuesto} {fila.pendiente_s_vuelta:.4f} s/vuelta (n={fila.n_vueltas})"
                         for fila in por_compuesto.itertuples())
    print(f"degradación: {resumen}")
    por_carrera = degradacion[degradacion["compuesto"].str.contains("·")]
    print(f"degradación por carrera y compuesto: "
          f"{por_carrera['pendiente_s_vuelta'].min():.4f}–{por_carrera['pendiente_s_vuelta'].max():.4f} s/vuelta")
    return degradacion


def calcular_ventana(boxes: pd.DataFrame, degradacion: pd.DataFrame) -> pd.DataFrame:
    # Paso 5 · Calcula la ventana de undercut en vueltas
    # Por qué: la ventana sale de igualar la diferencia en pista con lo que se gana por vuelta; sin
    #          escribir el supuesto (1,0 s de diferencia inicial) el número no significa nada.
    # Salida esperada: "ventana: 2–5 vueltas para edades 10–18 · coste L/g = 56–107 vueltas (más de 30)"
    # Si falla: ventana de cientos de vueltas → la degradación estimada es demasiado pequeña.
    perdida = float(boxes["perdida_s"].median())
    pendientes = dict(degradacion[~degradacion["compuesto"].str.contains("·")]
                      [["compuesto", "pendiente_s_vuelta"]].itertuples(index=False))
    filas = []
    for compuesto, pendiente in pendientes.items():
        for edad in EDADES:
            ganancia = pendiente * (edad - 1)
            filas.append({"compuesto": compuesto, "edad_rival": edad,
                          "ganancia_s_vuelta": round(ganancia, 4),
                          "ventana_vueltas": math.ceil(DELTA_T / ganancia),
                          "coste_vueltas": math.ceil(perdida / ganancia)})
    ventana = pd.DataFrame(filas)
    menor, mayor = int(ventana["ventana_vueltas"].min()), int(ventana["ventana_vueltas"].max())
    coste_min = int(ventana["coste_vueltas"].min())
    print(f"ventana: {menor}–{mayor} vueltas para edades {EDADES[0]}–{EDADES[-1]} con diferencia "
          f"inicial {DELTA_T:.1f} s (supuesto)")
    print(f"coste: la parada se paga en {coste_min}–{int(ventana['coste_vueltas'].max())} vueltas "
          f"con degradación; más que las 30 de la carrera")
    return ventana


def documentar_contraste() -> None:
    # Paso 6 · Documenta el contraste real con OpenF1 y Jolpica F1, sin descargar nada
    # Por qué: el CSV es sintético; la comparación con paradas reales se cita con licencia y límite,
    #          y la consulta queda escrita para que el lector la ejecute.
    # Salida esperada: "contraste: OpenF1 y Jolpica F1 documentados — sin descargar"
    # Si falla: PermissionError → la carpeta resultados/ no se puede escribir.
    RESULTADOS.mkdir(exist_ok=True)
    texto = (
        "# Contraste con OpenF1 y Jolpica F1 (documentado, no ejecutado)\n\n"
        "- OpenF1: <https://api.openf1.org/v1/>. Sin clave. Uso educativo, aprendizaje personal,\n"
        "  investigación y afición no comercial; OpenF1 declara no reclamar la propiedad de los datos\n"
        "  de F1. Consulta prevista: `/v1/pit` (paradas) y `/v1/laps` (vueltas) de una carrera.\n"
        "- Jolpica F1: <https://api.jolpi.ca/ergast/f1/>. Sin clave. Datos bajo CC BY-NC-SA 4.0\n"
        "  (uso no comercial, atribución y compartir igual); código del proyecto Apache-2.0.\n"
        "  Consulta prevista: resultado de carrera y paradas por piloto.\n"
        "- Qué se compara: que la pérdida en boxes esté en el orden de 20-25 s y que las paradas\n"
        "  reales caigan en la ventana calculada.\n"
        "- Qué no: el CSV es sintético, con una parada por piloto y sin tráfico; el contraste es\n"
        "  orientativo y no invalida ni confirma la ventana vuelta a vuelta.\n"
    )
    (RESULTADOS / "contraste-openf1.md").write_text(texto, encoding="utf-8")
    print("contraste: OpenF1 y Jolpica F1 documentados — sin descargar")


def escribir(boxes: pd.DataFrame, degradacion: pd.DataFrame, ventana: pd.DataFrame) -> None:
    # Paso 7 · Escribe las tablas de parámetros y de ventana
    # Por qué: cada cifra del README sale de estos CSV; sin escribirlas el informe no se reproduce.
    # Salida esperada: "resultados: boxes.csv, degradacion.csv, ventana.csv, contraste-openf1.md"
    # Si falla: PermissionError → revisa permisos de resultados/.
    RESULTADOS.mkdir(exist_ok=True)
    boxes.to_csv(RESULTADOS / "boxes.csv", index=False)
    degradacion.to_csv(RESULTADOS / "degradacion.csv", index=False)
    ventana.to_csv(RESULTADOS / "ventana.csv", index=False)
    print("resultados: boxes.csv, degradacion.csv, ventana.csv, contraste-openf1.md")


def limpiar() -> None:
    # Paso 8 · Borra las tablas generadas
    # Por qué: el ZIP no lleva derivados; se regeneran con `python undercut.py`.
    # Salida esperada: "limpiar: resultados/ generados borrados"
    # Si falla: PermissionError → cierra el programa que tenga abierto un CSV de resultados/.
    for nombre in GENERADOS:
        (RESULTADOS / nombre).unlink(missing_ok=True)
    print("limpiar: resultados/ generados borrados")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Ventana de undercut con pérdida en boxes (P63)")
    parser.add_argument("accion", nargs="?", default="todo", choices=["todo", "limpiar"])
    args = parser.parse_args(argv)
    if args.accion == "limpiar":
        limpiar()
        return 0
    try:
        df = cargar()
        comprobar_estructura(df)
        boxes = perdida_en_boxes(df)
        degradacion = estimar_degradacion(df)
        ventana = calcular_ventana(boxes, degradacion)
        documentar_contraste()
        escribir(boxes, degradacion, ventana)
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con resultados a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
