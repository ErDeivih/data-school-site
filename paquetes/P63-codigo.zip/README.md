# P63 · Ventana de undercut: pérdida en boxes y degradación — código ejecutable

El proyecto completo sobre el CSV sintético de 180 vueltas: calcula la **pérdida en boxes** restando
la vuelta de parada a la mediana de las verdes del tramo, estima la **degradación por vuelta de cada
compuesto** con una regresión lineal sobre las vueltas verdes, y convierte los dos parámetros en la
**ventana de undercut en vueltas** con un modelo declarado. El contraste real con OpenF1 y Jolpica F1
se documenta, no se descarga. Es el código que acompaña a la ficha
`../../fichas-ideas/p63-ventana-de-undercut.md`.

El resultado que enseña el proyecto: la pérdida en boxes está entre **22,40 y 22,68 s** (mediana
22,59 s), la degradación es de **0,0237 s/vuelta** en el medio y **0,0278 s/vuelta** en el duro, y con
una diferencia inicial supuesta de 1,0 s la ventana es de **3–5 vueltas**. El estudio de coste dice lo
incómodo: pagar la parada solo con degradación exige **48–106 vueltas**, más que las 30 de la carrera;
se publica tal cual en vez de esconderlo.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **numpy** y **pandas** (probados con 2.5.2 y 3.0.6). Se instalan en un comando.
- Windows, Linux o macOS. No hace falta red: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p63-ventana-de-undercut/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide `numpy` y `pandas`. Licencias: numpy BSD-3-Clause; pandas BSD-3-Clause.

## Orden de ejecución

```powershell
python undercut.py          # carga, estructura, pérdida, degradación, ventana y tablas
python undercut.py limpiar  # borra las tablas generadas y deja la carpeta como se descargó
```

La salida esperada de una ejecución es esta:

```text
datos: 180 filas × 10 columnas · 6 grupos de 30 vueltas · sha256 c232e767…
estructura: 1 parada por grupo · sectores suman con error máximo 0.0010 s · vueltas de parada [18, 18, 18, 22, 22, 22]
pérdida en boxes: 22.40–22.68 s en 6 grupos · mediana 22.59 s
degradación: duro 0.0278 s/vuelta (n=60) · medio 0.0237 s/vuelta (n=114)
degradación por carrera y compuesto: 0.0159–0.0345 s/vuelta
ventana: 3–5 vueltas para edades 10–18 con diferencia inicial 1.0 s (supuesto)
coste: la parada se paga en 48–106 vueltas con degradación; más que las 30 de la carrera
contraste: OpenF1 y Jolpica F1 documentados — sin descargar
resultados: boxes.csv, degradacion.csv, ventana.csv, contraste-openf1.md
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula pérdida, degradación y ventana; comprueba que los sectores reconstruyen la vuelta,
que hay una parada por grupo, que la pérdida publicada es tiempo de parada menos mediana del tramo,
que la ventana baja al envejecer el rival y que el coste de parar supera las 30 vueltas de la carrera.
No usa red y no escribe nada. Termina en `RESULTADO: VERDE` (código 0) con **19 comprobaciones**; la
salida real está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- [`datos-ejemplo/telemetria-f1.csv`](datos-ejemplo/telemetria-f1.csv): **180 filas × 10 columnas**
  (`carrera`, `piloto`, `vuelta`, `compuesto`, `edad_neumatico`, `sector1_s`, `sector2_s`,
  `sector3_s`, `tiempo_vuelta_s`, `parada`). 3 carreras × 2 pilotos × 30 vueltas; una parada por
  piloto: A en la vuelta 18 y B en la 22.
- sha256 del fichero:
  `c232e767dc95184fddeb329f6a7c4c72ccb13423a2961bea717cd464150c2c3b`. Es copia literal de
  `datasets/csv/telemetria-f1.csv` del repositorio (manifiesto `datasets/datasets.json`), sintético,
  semilla fija y licencia **CC0-1.0**.

Basta con ese CSV: el proyecto se ejecuta sin descargar nada. Para usar datos propios, se copian en
`datos-ejemplo/` con las mismas columnas o se edita la constante `DATOS` de `undercut.py`.

## Fuente real y licencia

- **OpenF1** (<https://api.openf1.org/v1/>): sin clave. Uso educativo, aprendizaje personal,
  investigación y afición no comercial; OpenF1 declara no reclamar la propiedad de los datos de F1.
- **Jolpica F1** (<https://api.jolpi.ca/ergast/f1/>): sin clave. Datos bajo CC BY-NC-SA 4.0 (uso no
  comercial, atribución y compartir igual); el código del proyecto es Apache-2.0.
- El contraste es orientativo: el CSV tiene una parada por piloto y nada de tráfico; OpenF1 no valida
  la ventana vuelta a vuelta. `resultados/contraste-openf1.md` deja escritas las consultas y el límite.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y validar | Claves, grupos y recuentos de un panel largo | Pandas: fundamentos |
| 2 · Estructura y sectores | Sectores como desglose, no como predictores | Pandas: agrupaciones y joins |
| 3 · Pérdida en boxes | Aislar el coste de la parada de la degradación | Series temporales en pandas |
| 4 · Degradación por compuesto | Una pendiente en s/vuelta y su n | Regresión lineal |
| 5 · Ventana de undercut | Igualar pérdida y ganancia con un supuesto escrito | Optimización con restricciones |
| 6 · Estudio de coste | Cuándo una parada no se paga con degradación | Frecuencia y agregación temporal |
| 7 · Contraste real | Citar dos APIs con licencia sin fingir la descarga | APIs y peticiones HTTP |

## Estructura

```text
codigo/
├── undercut.py           # pipeline: carga, estructura, boxes, degradación, ventana, tablas
├── verificar.py          # la puerta del proyecto (19 comprobaciones, sin red, sin escribir)
├── requirements.txt      # numpy, pandas
├── datos-ejemplo/
│   └── telemetria-f1.csv # 180 × 10 · CC0-1.0
└── resultados/
    └── ejemplo-salida.txt
```

Las tablas que escribe `python undercut.py` (`boxes.csv`, `degradacion.csv`, `ventana.csv`,
`contraste-openf1.md`) no viajan en el ZIP: se regeneran.

## Fallos típicos

- **`ModuleNotFoundError: pandas`**: instala con `python -m pip install -r requirements.txt` con el
  mismo intérprete que lanza el pipeline.
- **Pérdida en boxes de 100 s**: has restado la vuelta de parada a la mediana de todo el stint, o has
  incluido la propia vuelta de parada entre las verdes; el filtro es `parada == 0` y `vuelta < parada`.
- **Degradación confundida con el combustible**: el medio siempre es el primer tramo y el duro el
  segundo; la pendiente por compuesto es una estimación y el README declara el confusor.
- **Ventana sin supuesto**: dar un número de vueltas sin la diferencia inicial declarada convierte la
  cuenta en una frase; `DELTA_T` es un supuesto, no un dato del CSV.
- **Presentar OpenF1 o Jolpica como si fueran estas vueltas**: el contraste es cualitativo y con otra
  resolución; no valida la ventana.
