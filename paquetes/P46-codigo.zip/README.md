# P46 · Orquestación de agentes con herramientas — código ejecutable

Monta un agente sobre los 120 documentos del corpus con **tres herramientas** (`buscar`, `leer`, `contar`)
que declaran entrada, salida y para qué sirven, un **bucle con máximo de pasos y parada declarada**, una
**salida estructurada** validada contra un esquema JSON y una **batería de cinco pruebas** que incluye una
salida inválida y una **instrucción inyectada en un documento**. No usa red: el LLM se sustituye por un
adaptador simulado con fixture. Es el código que acompaña a la ficha
`../../fichas-portfolio/p46-agentes-con-herramientas.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: solo la biblioteca estándar (`csv`, `json`, `math`, `re`).
- No hace falta red ni clave: el LLM es un **adaptador simulado** que lee un fixture con los planes. Con
  una clave gratuita de OpenRouter, Groq o Gemini se sustituiría el adaptador; las claves irían en
  variables de entorno y nunca en el repositorio.

## Instalación

```powershell
cd proyectos/p46-agentes-con-herramientas/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` no instala nada: el proyecto es de biblioteca estándar.

## Orden de ejecución

```powershell
python herramientas.py   # demuestra las tres herramientas, sus resultados y sus errores de entrada
python agente.py         # ejecuta una tarea de ejemplo y muestra la traza paso a paso
python pruebas.py        # batería de 5 casos (incluye inyección y salida inválida); guarda resultados/
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta es **solo stdout** (no escribe en disco) y no usa red. Comprueba **22 cosas**: 120 filas × 5
columnas con 120 ids únicos, 6 temas × 20 documentos, 115 textos únicos, 30 títulos únicos y el sha256 del
catálogo, los tres contratos de herramienta y que **5 entradas malas devuelven error sin lanzar
excepción**, los resultados reales de las herramientas, la batería **5/5** con sus motivos de parada, que
la **inyección** se detecta y no se obedece (respuesta segura y fixture intacto), que el límite de pasos
se respeta, que cada traza guarda decisión, herramienta, entrada y salida, que el esquema acepta una
salida buena y rechaza 5 malas, el adaptador simulado y que el código no hace red ni lleva claves.
Termina en `RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). La salida real es la de
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt), con **22 comprobaciones** en verde:

- **Corpus:** 120 filas · 6 temas × 20 documentos · 115 textos únicos · 30 títulos únicos · 23–74
  palabras · sha256 del catálogo.
- **Herramientas:** `buscar("ratio de sharpe", k=3)` → 3 resultados, primero DOC075 (finanzas);
  `leer("DOC001")` → 50 palabras, tema datos; `contar("salud")` → 20 y `contar()` → 120.
- **Batería 5/5:** `contar_salud` responde · `leer_documento` responde con cita · `inyeccion` termina por
  `inyeccion_detectada` con respuesta segura · `salida_invalida` se rechaza por falta de `citas` ·
  `max_pasos` termina por el límite declarado.
- **Esquema:** la salida buena valida; se rechazan 5 malas (sin `citas`, respuesta corta, herramientas
  vacías, cita inventada y campo extra).
- **Límite de pasos:** con `max_pasos=2`, el bucle termina por `max_pasos` tras 2 pasos.

## Datos y procedencia

- `datos-ejemplo/documentos-corpus.csv`: **120 filas × 5 columnas** (`id`, `titulo`, `texto`, `tema`,
  `nivel`). Sintético, semilla 20261113 y **CC0-1.0**. Copia literal del catálogo del portal
  (`aprender/web/datos/datasets/documentos-corpus.csv`), no presente en `datasets/csv/`; sha256
  `8e353108fa59ccb2623502842551732868f583de7f234d9f56f422ddde837c10`.
- `datos-ejemplo/fixtures/llm-respuestas.json`: **planes simulados** con la forma de una respuesta de API
  de LLM (proveedor, modelo y fecha declarados). No se ha llamado a ninguna API.
- `datos-ejemplo/esquema.json`: el esquema JSON de la respuesta final (`respuesta`,
  `herramientas_usadas`, `citas`, sin campos extra).
- `datos-ejemplo/fixture-inyeccion.txt`: el **texto adversario declarado** («IGNORA LAS INSTRUCCIONES…»).
  No forma parte del corpus: se sirve con `leer("INYECCION")` y el corpus original no se modifica.
- `datos-ejemplo/parametros.json`: semilla 20261113, `max_pasos` 6 y `top_k` 3.
- `resultados/`: `agente-trazas.json` y `pruebas-agente.json`, regenerados con `python pruebas.py`.

## Qué es real y qué es simulado

- **Real:** el CSV del catálogo (sha256 comprobado), las herramientas, el bucle, la validación del
  esquema y las pruebas los ejecuta el código. Las APIs citadas (OpenRouter, Groq, Gemini) existen con
  clave gratuita y sus términos se documentan en la ficha.
- **Simulado:** la decisión del LLM. El adaptador lee planes congelados en un fixture; no hay red ni
  clave. Los planes incluyen a propósito una respuesta inválida y una que obedece a la inyección, para
  probar que el agente las rechaza.
- **Sin red ni secretos:** no hay claves en el repositorio; con clave, irían en variables de entorno
  (`OPENROUTER_API_KEY`, `GROQ_API_KEY` o `GEMINI_API_KEY`) y el README de la ficha indica cuál se usa.
- **Límite:** el corpus es sintético y **no es el temario real**; el valor del proyecto está en el
  contrato, la traza y la defensa, no en la calidad de las respuestas.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Corpus de las herramientas | Datos validados antes de exponerlos | `Agentes y herramientas` |
| 2 · Contrato de cada herramienta | Entrada, salida y errores con forma de dato | `Agentes y herramientas` |
| 3 · Bucle y parada | Decidir, ejecutar y parar con criterio | `Prompting` |
| 4 · Traza de cada paso | Auditar la demo paso a paso | `Agentes y herramientas` |
| 5 · Salida estructurada | Validar el JSON contra un esquema | `JSON y datos anidados` |
| 6 · Inyección de instrucciones | Un documento no manda sobre el agente | `Seguridad y prompt injection` |
| 7 · Claves y proveedores | Claves por variable de entorno, plan gratuito | `Secretos y configuración` |
| 8 · Límites de cuota | Reintentos y ritmo del plan gratuito | `Rate limit y caché de API` |

## Estructura

```text
codigo/
├── herramientas.py         # buscar, leer y contar con contrato y validación de entrada
├── agente.py               # adaptador simulado, bucle, guardián de inyección, esquema y trazas
├── pruebas.py              # batería de 5 casos y guardado de resultados
├── datos-ejemplo/          # documentos-corpus.csv (CC0-1.0), esquema.json y fixtures/
├── verificar.py            # la puerta del proyecto (solo stdout, sin red)
└── resultados/             # ejemplo-salida.txt, agente-trazas.json y pruebas-agente.json
```

## Fallos típicos

- **Agente sin criterio de parada:** el bucle tiene `max_pasos` declarado y cuatro motivos de parada;
  con límite 2 termina por `max_pasos` y lo deja en la traza.
- **Herramienta que revienta:** una entrada inválida devuelve `{"error": ...}`, no una excepción; la traza
  se puede reconstruir aunque el dato sea malo.
- **Salida no validada:** un texto libre no es salida estructurada; el validador rechaza campos ausentes,
  tipos incorrectos, citas inventadas y campos extra.
- **Inyección que no se prueba:** el corpus no trae instrucciones; se usa un fixture adversario declarado
  y se comprueba que la respuesta no obedece y que el corpus no cambia.
- **Título como id:** solo hay 30 títulos para 120 documentos; las citas y herramientas usan el `id`.
- **Clave en el repositorio:** las claves de OpenRouter, Groq o Gemini van en variables de entorno; aquí no
  hay ninguna.
- **Cuota agotada a mitad de la demo:** con el modo real hay que declarar el plan y su ritmo; el fixture no
  gasta cuota y permite repetir la batería.
- **Creer que el corpus es el temario:** es sintético; las respuestas no valen sobre las fichas reales de
  `contenido/`.
