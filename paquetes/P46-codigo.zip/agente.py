#!/usr/bin/env python3
"""Agente con herramientas (P46): bucle, parada declarada, salida estructurada y defensa de inyección.

El agente recibe una tarea, pide el plan al **adaptador simulado** del LLM (fixture, sin red), ejecuta
herramientas locales (`buscar`, `leer`, `contar`), deja **traza** de cada paso y valida la respuesta final
contra `datos-ejemplo/esquema.json`. Si un documento leído contiene instrucciones dirigidas al modelo, el
guardián las detecta y **no las obedece**: la respuesta final se sustituye por una segura y queda marcada
en la traza. El bucle tiene un máximo de pasos y una parada declarada.

    python agente.py     # ejecuta una tarea de ejemplo y muestra la traza
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import herramientas

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
FIXTURE_LLM = DATOS / "fixtures" / "llm-respuestas.json"
ESQUEMA = DATOS / "esquema.json"
# Patrones de instrucción dirigida al modelo dentro de un texto no confiable.
PATRONES_INYECCION = (
    "ignora las instrucciones",
    "ignore previous",
    "responde solo",
    "pwned",
    "olvida las instrucciones",
    "system:",
    "system prompt",
)


class ErrorDeFixture(RuntimeError):
    """El fixture o el esquema no existen o no tienen la forma declarada."""


def cargar_parametros() -> dict:
    # Paso 1 · Lee el máximo de pasos y el top_k de las herramientas
    # Por qué: el bucle de un agente necesita un límite declarado; sin él, un plan malo puede repetir
    #          herramientas sin terminar.
    # Salida esperada: "parámetros: max_pasos 6 · top_k 3 · semilla 20261113"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o restaura datos-ejemplo/parametros.json.
    ruta = DATOS / "parametros.json"
    parametros = json.loads(ruta.read_text(encoding="utf-8"))
    for clave in ("semilla", "max_pasos", "top_k"):
        if clave not in parametros:
            raise RuntimeError(f"falta «{clave}» en datos-ejemplo/parametros.json")
    if int(parametros["max_pasos"]) < 1:
        raise RuntimeError("«max_pasos» tiene que ser al menos 1")
    return parametros


def cargar_esquema() -> dict:
    """Esquema JSON declarado para la salida del agente (subconjunto de JSON Schema)."""
    if not ESQUEMA.exists():
        raise ErrorDeFixture(f"no existe {ESQUEMA}")
    return json.loads(ESQUEMA.read_text(encoding="utf-8"))


class AdaptadorLLM:
    """Cliente simulado del LLM: devuelve planes congelados en un fixture, sin red ni clave."""

    def __init__(self, ruta: Path = FIXTURE_LLM):
        # Paso 2 · Carga el fixture de planes y sus metadatos (proveedor, modelo, fecha)
        # Por qué: con clave se llamaría a OpenRouter, Groq o Gemini; sin red se entrega el adaptador
        #          simulado, y el repo no depende de tener clave para funcionar.
        # Salida esperada: "adaptador: simulado (fixture) · plan-local-de-ejemplo · 5 tareas"
        # Si falla: ErrorDeFixture → falta datos-ejemplo/fixtures/llm-respuestas.json.
        ruta = Path(ruta)
        if not ruta.exists():
            raise ErrorDeFixture(f"no existe el fixture {ruta}")
        datos = json.loads(ruta.read_text(encoding="utf-8"))
        if not datos.get("planes"):
            raise ErrorDeFixture("el fixture no trae planes")
        self.datos = datos
        self._planes = datos["planes"]

    def tareas(self) -> list:
        return sorted(self._planes)

    def plan(self, tarea: str) -> dict:
        if tarea not in self._planes:
            raise ErrorDeFixture(f"tarea fuera del fixture: {tarea}")
        return self._planes[tarea]


def detectar_instrucciones(texto: str) -> bool:
    """Busca instrucciones dirigidas al modelo en un texto no confiable (documento, salida de herramienta)."""
    minusculas = str(texto).lower()
    return any(patron in minusculas for patron in PATRONES_INYECCION)


def validar_salida(salida: dict, esquema: dict, ids_validos: set) -> dict:
    # Paso 3 · Valida la salida contra el esquema declarado y las citas contra el corpus
    # Por qué: un texto libre no es una salida estructurada; el programa que consume la respuesta necesita
    #          los campos y las citas con la forma fijada.
    # Salida esperada: {"valida": True/False, "errores": [...]}
    # Si falla: un campo ausente, de tipo distinto o una cita inventada produce un error de lista.
    errores = []
    if not isinstance(salida, dict):
        return {"valida": False, "errores": ["la salida no es un objeto JSON"]}
    for campo in esquema.get("required", []):
        if campo not in salida:
            errores.append(f"falta el campo obligatorio «{campo}»")
    if esquema.get("additionalProperties") is False:
        permitidas = set(esquema.get("properties", {}))
        for campo in salida:
            if campo not in permitidas:
                errores.append(f"campo no permitido «{campo}»")
    propiedades = esquema.get("properties", {})
    if "respuesta" in salida:
        if not isinstance(salida["respuesta"], str):
            errores.append("«respuesta» no es texto")
        elif len(salida["respuesta"]) < int(propiedades.get("respuesta", {}).get("minLength", 0)):
            errores.append("«respuesta» es más corta que el mínimo declarado")
    if "herramientas_usadas" in salida:
        usadas = salida["herramientas_usadas"]
        minimo = int(propiedades.get("herramientas_usadas", {}).get("minItems", 0))
        if not isinstance(usadas, list) or not all(isinstance(x, str) for x in usadas):
            errores.append("«herramientas_usadas» no es una lista de textos")
        elif len(usadas) < minimo:
            errores.append("«herramientas_usadas» está vacía")
        else:
            for nombre in usadas:
                if nombre not in herramientas.CONTRATOS:
                    errores.append(f"herramienta declarada y no definida: «{nombre}»")
    if "citas" in salida:
        citas = salida["citas"]
        if not isinstance(citas, list) or not all(isinstance(x, str) for x in citas):
            errores.append("«citas» no es una lista de textos")
        else:
            for cita in citas:
                if cita not in ids_validos:
                    errores.append(f"cita que no está en el corpus: «{cita}»")
    return {"valida": not errores, "errores": errores}


def ejecutar(tarea: str, adaptador: AdaptadorLLM = None, corpus: dict = None, modelo: dict = None,
             max_pasos: int = None) -> dict:
    # Paso 4 · Bucle del agente: decidir, ejecutar herramienta, dejar traza y parar con criterio
    # Por qué: un agente no es un chatbot que a veces llama a una función; el bucle tiene parada declarada
    #          (responder, salida inválida, inyección o máximo de pasos) y cada decisión queda registrada.
    # Salida esperada: "decision responder · 2 pasos · salida valida" o "motivo max_pasos"
    # Si falla: ErrorDeFixture → la tarea no está en el fixture; el plan no se inventa.
    parametros = cargar_parametros()
    esquema = cargar_esquema()
    adaptador = adaptador or AdaptadorLLM()
    corpus = corpus or herramientas.cargar_corpus()
    modelo = modelo or herramientas._modelo(corpus)  # noqa: SLF001  (modelo interno compartido del proyecto)
    limite = int(parametros["max_pasos"] if max_pasos is None else max_pasos)
    ids_validos = set(corpus["por_id"]) | {"INYECCION"}

    plan = adaptador.plan(tarea)
    trazas = []
    usadas = []
    inyeccion_detectada = False
    salida_final = None
    motivo_parada = None
    valida_final = False

    for decision in plan["pasos"]:
        if len(trazas) >= limite:
            motivo_parada = "max_pasos"
            break
        if decision.get("accion") == "herramienta":
            nombre = decision.get("herramienta")
            entrada = decision.get("entrada") or {}
            resultado = herramientas.ejecutar(nombre, entrada, corpus, modelo)
            texto_salida = json.dumps(resultado, ensure_ascii=False)
            instrucciones = detectar_instrucciones(texto_salida)
            inyeccion_detectada = inyeccion_detectada or instrucciones
            if nombre in herramientas.CONTRATOS:
                usadas.append(nombre)
            trazas.append({
                "paso": len(trazas) + 1,
                "decision": "herramienta",
                "herramienta": nombre,
                "entrada": entrada,
                "salida": resultado,
                "inyeccion_en_salida": instrucciones,
            })
            continue
        # Decisión de responder: primero el guardián, después el esquema.
        propuesta = decision.get("salida") or {}
        if inyeccion_detectada and detectar_instrucciones(propuesta.get("respuesta", "")):
            salida_final = {
                "respuesta": "El documento leído contiene instrucciones dirigidas al modelo; se ignoran y no se obedecen. La respuesta se limita al contenido del corpus.",
                "herramientas_usadas": usadas or ["leer"],
                "citas": [cita for cita in propuesta.get("citas", []) if cita in ids_validos],
            }
            motivo_parada = "inyeccion_detectada"
            valida_final = validar_salida(salida_final, esquema, ids_validos)["valida"]
            trazas.append({
                "paso": len(trazas) + 1,
                "decision": "respuesta_rechazada",
                "motivo": "instrucciones_en_documento_no_confiable",
                "propuesta_rechazada": propuesta,
                "salida": salida_final,
            })
        else:
            validacion = validar_salida(propuesta, esquema, ids_validos)
            salida_final = propuesta if validacion["valida"] else None
            valida_final = validacion["valida"]
            motivo_parada = "responder" if validacion["valida"] else "salida_invalida"
            trazas.append({
                "paso": len(trazas) + 1,
                "decision": "responder",
                "valida": validacion["valida"],
                "errores": validacion["errores"],
                "salida": propuesta,
            })
        break
    else:
        motivo_parada = "max_pasos" if len(trazas) >= limite else "fin_del_plan"

    return {
        "tarea": tarea,
        "pregunta": plan.get("pregunta"),
        "proveedor": adaptador.datos.get("proveedor"),
        "modelo": adaptador.datos.get("modelo"),
        "motivo_parada": motivo_parada,
        "inyeccion_detectada": inyeccion_detectada,
        "salida": salida_final,
        "salida_valida": bool(valida_final),
        "herramientas_usadas": usadas,
        "trazas": trazas,
        "max_pasos": limite,
    }


def main() -> int:
    try:
        resultado = ejecutar("tarea_leer_doc")
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    print("== P46 · agente con herramientas (demo) ==")
    print(f"tarea: {resultado['tarea']} · {resultado['pregunta']}")
    print(f"motivo de parada: {resultado['motivo_parada']} · {len(resultado['trazas'])} pasos · salida valida: {resultado['salida_valida']}")
    for traza in resultado["trazas"]:
        if traza["decision"] == "herramienta":
            print(f"  paso {traza['paso']}: {traza['herramienta']}({traza['entrada']})")
        else:
            print(f"  paso {traza['paso']}: {traza['decision']}")
    if resultado["salida"]:
        print("respuesta: " + resultado["salida"]["respuesta"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
