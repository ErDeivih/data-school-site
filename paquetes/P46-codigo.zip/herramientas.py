#!/usr/bin/env python3
"""Herramientas del agente (P46): buscar, leer y contar, con contrato declarado.

Las tres herramientas se implementan en local sobre `datos-ejemplo/documentos-corpus.csv`, validan su
entrada y **devuelven JSON**: nunca lanzan una excepción por un dato del usuario, devuelven `{"error": ...}`.
`leer` acepta además el id `INYECCION`, que sirve el **fixture adversario declarado**
`datos-ejemplo/fixture-inyeccion.txt` (no forma parte del corpus y no lo modifica).

    python herramientas.py    # demuestra las tres herramientas y sus errores de entrada
"""
from __future__ import annotations

import csv
import json
import math
import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
COLUMNAS = ["id", "titulo", "texto", "tema", "nivel"]
TEMAS = ("datos", "energia", "f1", "finanzas", "futbol", "salud")
PUNTUACION = str.maketrans("", "", ".,;:!?«»\"'()[]{}¿¡")
PALABRAS_VACIAS = frozenset(
    "de la el los las un una unos unas y o e que en con por para al del se su sus es son esta este estos estas "
    "como mas pero sin sobre entre cuando donde muy ya hay ser esta estan fue han ha ni tan".split()
)

CONTRATOS = {
    "buscar": {
        "entrada": {"consulta": "texto no vacío", "k": "entero entre 1 y 20 (por defecto 3)"},
        "salida": {"consulta": "texto", "resultados": "[{documento, tema, titulo, fragmento, similitud}]"},
        "para_que": "recuperar los k fragmentos más parecidos a una consulta, con su documento y su tema",
    },
    "leer": {
        "entrada": {"id": "id de documento del corpus, o «INYECCION» para el fixture adversario"},
        "salida": {"documento": "id", "titulo": "texto", "tema": "texto", "nivel": "texto", "texto": "texto completo"},
        "para_que": "leer un documento entero por su id para citarlo",
    },
    "contar": {
        "entrada": {"tema": "uno de los seis temas, u omitido para el total"},
        "salida": {"tema": "texto o «todos»", "cuenta": "entero", "por_tema": "{tema: cuenta}"},
        "para_que": "contar documentos por tema o el total del corpus",
    },
}


def cargar_corpus() -> dict:
    # Paso 1 · Carga y valida el corpus con el que trabajan las tres herramientas
    # Por qué: las herramientas citan ids y temas; si el corpus no tiene la forma declarada, la traza del
    #          agente apuntaría a documentos que no existen.
    # Salida esperada: "corpus: 120 documentos · 6 temas · 115 textos unicos"
    # Si falla: RuntimeError → falta datos-ejemplo/documentos-corpus.csv o cambió de forma.
    ruta = DATOS / "documentos-corpus.csv"
    with ruta.open(encoding="utf-8", newline="") as f:
        lector = csv.DictReader(f)
        columnas = lector.fieldnames or []
        filas = [fila for fila in lector if fila]
    if columnas != COLUMNAS or len(filas) != 120:
        raise RuntimeError(f"CSV inesperado: {columnas} y {len(filas)} filas")
    if len({fila["id"] for fila in filas}) != 120:
        raise RuntimeError("hay ids repetidos en el CSV")
    return {"filas": filas, "por_id": {fila["id"]: fila for fila in filas},
            "textos_unicos": len({fila["texto"] for fila in filas})}


def limpiar(texto: str) -> str:
    return re.sub(r"\s+", " ", texto.lower().translate(PUNTUACION)).strip()


def caracteristicas(texto: str) -> list:
    palabras = [palabra for palabra in limpiar(texto).split() if palabra not in PALABRAS_VACIAS and len(palabra) > 1]
    return palabras + [f"{a}_{b}" for a, b in zip(palabras, palabras[1:])]


def _modelo(corpus: dict) -> dict:
    frecuencia_documental = {}
    for fila in corpus["filas"]:
        for caracteristica in set(caracteristicas(fila["texto"])):
            frecuencia_documental[caracteristica] = frecuencia_documental.get(caracteristica, 0) + 1
    total = len(corpus["filas"])
    return {"idf": {c: math.log((1.0 + total) / (1.0 + v)) + 1.0 for c, v in frecuencia_documental.items()}}


def _vector(texto: str, modelo: dict) -> dict:
    cuenta = {}
    for caracteristica in caracteristicas(texto):
        if caracteristica in modelo["idf"]:
            cuenta[caracteristica] = cuenta.get(caracteristica, 0) + 1
    return {c: (1.0 + math.log(n)) * modelo["idf"][c] for c, n in cuenta.items()}


def _coseno(a: dict, b: dict) -> float:
    comunes = set(a) & set(b)
    producto = sum(a[c] * b[c] for c in comunes)
    norma_a = math.sqrt(sum(v * v for v in a.values())) or 1.0
    norma_b = math.sqrt(sum(v * v for v in b.values())) or 1.0
    return producto / (norma_a * norma_b)


def buscar(consulta: str, k: int, corpus: dict, modelo: dict) -> dict:
    # Paso 2 · buscar: recupera los k fragmentos más parecidos y devuelve documento, tema y similitud
    # Por qué: una herramienta devuelve datos, no prosa; el agente necesita el id para poder citar.
    # Salida esperada: "buscar('ratio de sharpe', k=3) -> 3 resultados, el primero DOC061"
    # Si falla: el contrato de entrada devuelve {"error": ...}; nunca se lanza una excepción.
    vector = _vector(consulta, modelo)
    puntuados = []
    for fila in corpus["filas"]:
        puntuados.append({
            "documento": fila["id"],
            "tema": fila["tema"],
            "titulo": fila["titulo"],
            "fragmento": fila["texto"],
            "similitud": round(_coseno(vector, _vector(fila["texto"], modelo)), 6),
        })
    puntuados.sort(key=lambda fila: (-fila["similitud"], fila["documento"]))
    return {"consulta": consulta, "resultados": puntuados[:k]}


def leer(identificador: str, corpus: dict) -> dict:
    # Paso 3 · leer: devuelve el documento completo por id (o el fixture adversario declarado)
    # Por qué: la traza del agente debe poder reconstruirse; la lectura devuelve también el tema y el
    #          nivel, no solo el texto.
    # Salida esperada: "leer('DOC001') -> titulo 'Un pipeline idempotente', tema datos"
    # Si falla: id desconocido → {"error": "documento no encontrado: ..."}.
    if identificador == "INYECCION":
        ruta = DATOS / "fixture-inyeccion.txt"
        if not ruta.exists():
            return {"error": "falta el fixture adversario declarado"}
        return {"documento": "INYECCION", "titulo": "Fixture adversario declarado", "tema": "fixture",
                "nivel": "no aplica", "texto": ruta.read_text(encoding="utf-8").strip()}
    fila = corpus["por_id"].get(identificador)
    if fila is None:
        return {"error": f"documento no encontrado: {identificador}"}
    return {"documento": fila["id"], "titulo": fila["titulo"], "tema": fila["tema"],
            "nivel": fila["nivel"], "texto": fila["texto"]}


def contar(corpus: dict, tema: str = None) -> dict:
    # Paso 4 · contar: número de documentos por tema o total del corpus
    # Por qué: es la herramienta trivial del ejercicio; el valor está en el contrato y en que devuelve JSON.
    # Salida esperada: "contar('salud') -> 20 · contar() -> 120"
    # Si falla: tema desconocido → {"error": "tema desconocido: ..."}.
    por_tema = {t: sum(1 for fila in corpus["filas"] if fila["tema"] == t) for t in TEMAS}
    if tema is None:
        return {"tema": "todos", "cuenta": sum(por_tema.values()), "por_tema": por_tema}
    if tema not in por_tema:
        return {"error": f"tema desconocido: {tema}"}
    return {"tema": tema, "cuenta": por_tema[tema], "por_tema": por_tema}


def ejecutar(nombre: str, entrada: dict, corpus: dict = None, modelo: dict = None) -> dict:
    # Despachador con la validación del contrato de cada herramienta: devuelve siempre un dict.
    if nombre not in CONTRATOS:
        return {"error": f"herramienta desconocida: {nombre}"}
    if not isinstance(entrada, dict):
        return {"error": "la entrada de la herramienta tiene que ser un objeto JSON"}
    corpus = corpus or cargar_corpus()
    modelo = modelo or _modelo(corpus)
    if nombre == "buscar":
        consulta = entrada.get("consulta")
        k = entrada.get("k", 3)
        if not isinstance(consulta, str) or not consulta.strip():
            return {"error": "consulta vacía"}
        if not isinstance(k, int) or k < 1 or k > 20:
            return {"error": "k tiene que ser un entero entre 1 y 20"}
        return buscar(consulta, k, corpus, modelo)
    if nombre == "leer":
        identificador = entrada.get("id")
        if not isinstance(identificador, str) or not identificador.strip():
            return {"error": "falta el id del documento"}
        return leer(identificador, corpus)
    tema = entrada.get("tema")
    if tema is not None and not isinstance(tema, str):
        return {"error": "el tema tiene que ser texto"}
    return contar(corpus, tema)


def main() -> int:
    try:
        corpus = cargar_corpus()
        modelo = _modelo(corpus)
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    print(f"corpus: {len(corpus['filas'])} documentos · 6 temas · {corpus['textos_unicos']} textos unicos")
    print("herramientas: " + ", ".join(CONTRATOS))
    ejemplo = ejecutar("buscar", {"consulta": "ratio de sharpe", "k": 3}, corpus, modelo)
    print(f"buscar('ratio de sharpe', k=3): {len(ejemplo['resultados'])} resultados · primero {ejemplo['resultados'][0]['documento']}")
    leido = ejecutar("leer", {"id": "DOC001"}, corpus, modelo)
    print(f"leer('DOC001'): {leido['titulo']!r} · tema {leido['tema']}")
    print(f"contar('salud'): {ejecutar('contar', {'tema': 'salud'}, corpus, modelo)['cuenta']}")
    print(f"contar(): {ejecutar('contar', {}, corpus, modelo)['cuenta']}")
    print(f"error de entrada: {ejecutar('leer', {'id': 'DOC999'}, corpus, modelo)}")
    print(f"error de contrato: {ejecutar('buscar', {'consulta': 'x', 'k': 0}, corpus, modelo)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
