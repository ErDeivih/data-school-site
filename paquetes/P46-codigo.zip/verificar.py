#!/usr/bin/env python3
"""Puerta del proyecto P46 (agente con herramientas).

Comprueba el resultado de verdad, sin escribir en disco y sin red: corpus y su sha256, las tres
herramientas con contrato y validación de entrada, el bucle con parada declarada y trazas completas, la
validación de la salida contra el esquema, la batería de cinco casos, la defensa contra instrucciones
inyectadas en un documento y el adaptador simulado del LLM. Termina en RESULTADO: VERDE (código 0) o
ROJO (código 1).

Uso:
    python verificar.py

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True  # la puerta no escribe nada: ni resultados ni caché de bytecode

import agente
import herramientas
import pruebas

fallos: list = []
comprobaciones = 0

SHA256_CATALOGO = "8e353108fa59ccb2623502842551732868f583de7f234d9f56f422ddde837c10"


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P46 · agente con herramientas ==")

    # Paso 1 · Comprueba los parámetros, el corpus y su procedencia
    # Por qué: el corpus es el contrato de las herramientas; si cambia, las citas y los conteos dejan de
    #          valer. El sha256 demuestra que es la copia del catálogo.
    # Salida esperada: "OK parámetros", "OK corpus" y "OK procedencia".
    # Si falla: RuntimeError de cargar_corpus → falta datos-ejemplo/documentos-corpus.csv o cambió.
    parametros = agente.cargar_parametros()
    ok(
        (int(parametros["max_pasos"]), int(parametros["top_k"])) == (6, 3),
        f"parámetros: max_pasos {int(parametros['max_pasos'])} · top_k {int(parametros['top_k'])} · semilla {int(parametros['semilla'])}",
    )
    corpus = herramientas.cargar_corpus()
    ok(
        len(corpus["filas"]) == 120 and len(herramientas.COLUMNAS) == 5 and len(corpus["por_id"]) == 120,
        f"corpus: {len(corpus['filas'])} filas · {len(herramientas.COLUMNAS)} columnas · {len(corpus['por_id'])} ids únicos",
    )
    ok(
        all(herramientas.contar(corpus, tema)["cuenta"] == 20 for tema in herramientas.TEMAS)
        and corpus["textos_unicos"] == 115,
        f"temas: 6 × 20 documentos · {corpus['textos_unicos']} textos únicos · {len({f['titulo'] for f in corpus['filas']})} títulos únicos",
    )
    sha256 = hashlib.sha256((herramientas.DATOS / "documentos-corpus.csv").read_bytes()).hexdigest()
    ok(sha256 == SHA256_CATALOGO, f"procedencia: sha256 del CSV coincide con el del catálogo ({sha256[:12]}…)")

    # Paso 2 · Comprueba el contrato de las tres herramientas y la validación de entrada
    # Por qué: una herramienta que revienta con una entrada mala no se puede usar en un agente; debe
    #          devolver un error con forma de dato.
    # Salida esperada: "OK contratos: 3 herramientas" y "OK validación: entradas malas devuelven error".
    # Si falla: una herramienta lanza una excepción o no declara entrada/salida.
    ok(
        len(herramientas.CONTRATOS) == 3
        and all({"entrada", "salida", "para_que"} <= set(contrato) for contrato in herramientas.CONTRATOS.values()),
        f"contratos: {len(herramientas.CONTRATOS)} herramientas con entrada, salida y para qué ({', '.join(herramientas.CONTRATOS)})",
    )
    errores = [
        herramientas.ejecutar("buscar", {"consulta": "x", "k": 0}),
        herramientas.ejecutar("buscar", {"consulta": "   "}),
        herramientas.ejecutar("leer", {"id": "DOC999"}),
        herramientas.ejecutar("contar", {"tema": "inexistente"}),
        herramientas.ejecutar("herramienta_que_no_existe", {}),
    ]
    ok(all(isinstance(resultado, dict) and "error" in resultado for resultado in errores),
       f"validación: {len(errores)} entradas malas devuelven {{'error': ...}} sin lanzar excepción")

    # Paso 3 · Comprueba que las herramientas devuelven los datos del corpus
    # Por qué: el contrato se demuestra con resultados, no con la firma; la búsqueda tiene que devolver el
    #          id y el tema además del texto.
    # Salida esperada: "OK herramientas: búsqueda con documento y tema, lectura por id y conteo".
    # Si falla: la búsqueda devuelve otro documento o los conteos no cuadran.
    busqueda = herramientas.ejecutar("buscar", {"consulta": "ratio de sharpe", "k": 3})
    ok(
        len(busqueda["resultados"]) == 3
        and busqueda["resultados"][0]["documento"] == "DOC075"
        and busqueda["resultados"][0]["tema"] == "finanzas"
        and {"documento", "tema", "titulo", "fragmento", "similitud"} <= set(busqueda["resultados"][0]),
        f"herramientas: buscar devuelve {len(busqueda['resultados'])} resultados y el primero es {busqueda['resultados'][0]['documento']} ({busqueda['resultados'][0]['tema']})",
    )
    lectura = herramientas.ejecutar("leer", {"id": "DOC001"})
    ok(
        lectura["documento"] == "DOC001" and lectura["tema"] == "datos" and len(lectura["texto"].split()) >= 20,
        f"herramientas: leer devuelve DOC001 completo ({len(lectura['texto'].split())} palabras, tema {lectura['tema']})",
    )
    ok(
        herramientas.ejecutar("contar", {"tema": "salud"})["cuenta"] == 20
        and herramientas.ejecutar("contar", {})["cuenta"] == 120,
        "herramientas: contar devuelve 20 para salud y 120 para el total",
    )

    # Paso 4 · Ejecuta la batería y comprueba que cada caso se comporta como está declarado
    # Por qué: la demo se prueba contra lo que falla de verdad —una salida inválida y una instrucción
    #          inyectada—, no solo contra el caso feliz.
    # Salida esperada: "OK batería: 5/5 casos" y "OK inyección: el agente no obedece".
    # Si falla: algún motivo de parada o la validación de salida no coincide con lo esperado.
    antes = hashlib.sha256((herramientas.DATOS / "fixture-inyeccion.txt").read_bytes()).hexdigest()
    resultados = pruebas.ejecutar_bateria()
    fallos_bateria = pruebas.comprobar(resultados)
    ok(len(resultados) == 5 and not fallos_bateria,
       f"batería: {len(resultados) - len(fallos_bateria)}/{len(resultados)} casos como estaban declarados")
    por_caso = {resultado["caso"]: resultado for resultado in resultados}
    inyeccion = por_caso["inyeccion"]
    ok(
        inyeccion["inyeccion_detectada"] and inyeccion["motivo_parada"] == "inyeccion_detectada"
        and inyeccion["salida"] is not None
        and "pwned" not in inyeccion["salida"]["respuesta"].lower()
        and "ignora las instrucciones" not in inyeccion["salida"]["respuesta"].lower(),
        "inyección: el agente detecta las instrucciones del documento y no las obedece (respuesta segura)",
    )
    despues = hashlib.sha256((herramientas.DATOS / "fixture-inyeccion.txt").read_bytes()).hexdigest()
    ok(antes == despues, "inyección: el fixture adversario no se modifica (el corpus original queda intacto)")

    # Paso 5 · Comprueba la parada del bucle y la forma de la traza
    # Por qué: un agente sin criterio de parada no es un agente; la traza es lo que permite auditar cada
    #          decisión y reconstruir la demo paso a paso.
    # Salida esperada: "OK parada: máximo de pasos respetado" y "OK trazas: completas".
    # Si falla: el bucle no respeta el límite o falta entrada/salida en una llamada.
    largo = agente.ejecutar("tarea_larga", max_pasos=2)
    ok(
        largo["motivo_parada"] == "max_pasos" and len(largo["trazas"]) == 2,
        f"parada: con límite 2 el bucle termina por «max_pasos» tras {len(largo['trazas'])} pasos",
    )
    completo = por_caso["max_pasos"]
    ok(
        all(traza.get("decision") and traza.get("paso") == indice + 1 for indice, traza in enumerate(completo["trazas"])),
        f"trazas: {sum(len(resultado['trazas']) for resultado in resultados)} pasos con decisión y número en la batería",
    )
    ok(
        all(
            (traza["decision"] != "herramienta" or {"herramienta", "entrada", "salida"} <= set(traza))
            for resultado in resultados for traza in resultado["trazas"]
        ),
        "trazas: cada llamada a herramienta guarda herramienta, entrada y salida",
    )
    ok(
        por_caso["salida_invalida"]["salida"] is None
        and any("citas" in error for traza in por_caso["salida_invalida"]["trazas"] for error in traza.get("errores", [])),
        "salida inválida: el esquema la rechaza por falta de «citas» y el agente no la entrega",
    )

    # Paso 6 · Comprueba el validador del esquema por separado
    # Por qué: la validación es una pieza propia; se prueban un caso válido y cuatro inválidos.
    # Salida esperada: "OK esquema: 1 salida válida y 4 inválidas rechazadas".
    # Si falla: el validador acepta una salida rota o rechaza una buena.
    esquema = agente.cargar_esquema()
    ids = set(corpus["por_id"]) | {"INYECCION"}
    buena = {"respuesta": "Hay veinte documentos del tema datos.", "herramientas_usadas": ["contar"], "citas": []}
    malas = [
        {"respuesta": "Hay veinte documentos del tema datos.", "herramientas_usadas": ["contar"]},
        {"respuesta": "Corta.", "herramientas_usadas": ["contar"], "citas": []},
        {"respuesta": "Hay veinte documentos del tema datos.", "herramientas_usadas": [], "citas": []},
        {"respuesta": "Hay veinte documentos del tema datos.", "herramientas_usadas": ["contar"], "citas": ["DOC999"]},
        {"respuesta": "Hay veinte documentos del tema datos.", "herramientas_usadas": ["contar"], "citas": [], "extra": 1},
    ]
    validaciones = [agente.validar_salida(mala, esquema, ids)["valida"] for mala in malas]
    ok(
        agente.validar_salida(buena, esquema, ids)["valida"] is True and not any(validaciones),
        f"esquema: la salida buena valida y las {len(malas)} malas se rechazan",
    )

    # Paso 7 · Comprueba el adaptador simulado y la reproducibilidad de la batería
    # Por qué: sin red no hay LLM real; el adaptador lee el fixture y declara proveedor y modelo. La
    #          batería debe ser reproducible para poder comparar ejecuciones.
    # Salida esperada: "OK adaptador: simulado (fixture) · plan-local-de-ejemplo · 5 tareas" y "OK reproducibilidad".
    # Si falla: ErrorDeFixture → falta el fixture o una tarea no está declarada.
    adaptador = agente.AdaptadorLLM()
    ok(
        len(adaptador.tareas()) == 5 and "simulado" in adaptador.datos["proveedor"],
        f"adaptador: {adaptador.datos['proveedor']} · {adaptador.datos['modelo']} · {len(adaptador.tareas())} tareas",
    )
    try:
        adaptador.plan("tarea_que_no_existe")
        fallo_esperado = False
    except agente.ErrorDeFixture:
        fallo_esperado = True
    ok(fallo_esperado, "adaptador: una tarea fuera del fixture lanza ErrorDeFixture (no inventa un plan)")
    segunda = pruebas.ejecutar_bateria()
    ok(
        json.dumps(resultados, ensure_ascii=False, sort_keys=True) == json.dumps(segunda, ensure_ascii=False, sort_keys=True),
        "reproducibilidad: la batería completa devuelve las mismas decisiones y salidas",
    )

    # Paso 8 · Comprueba que el código es offline y no lleva claves
    # Por qué: el repositorio se comparte; las claves de OpenRouter, Groq o Gemini irían en variables de
    #          entorno y nunca en el código ni en el fixture.
    # Salida esperada: "el código no hace peticiones de red" y "no contiene claves".
    # Si falla: aparece un http(s) o un patrón de token → quítalo antes de empaquetar.
    fuentes = [
        agente.RAIZ / "herramientas.py", agente.RAIZ / "agente.py", agente.RAIZ / "pruebas.py",
        agente.DATOS / "esquema.json", agente.DATOS / "fixture-inyeccion.txt",
        agente.DATOS / "fixtures" / "llm-respuestas.json",
    ]
    texto = "\n".join(Path(ruta).read_text(encoding="utf-8") for ruta in fuentes)
    ok("http://" not in texto and "https://" not in texto, "el código del proyecto no hace peticiones de red")
    ok(
        not any(patron in texto for patron in ("ghp_", "github_pat_", "Authorization:", "api_key", "sk-", "gsk_", "AIza")),
        "el código del proyecto no contiene claves ni cabeceras de autorización",
    )

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
