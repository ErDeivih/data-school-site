#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Limpieza con contrato de calidad sobre `transacciones-fraude`.

Carga un CSV, comprueba la cabecera, aplica el contrato de `contrato.py`, escribe las filas
válidas, manda las que no cumplen a una cuarentena con su regla y su valor, y cuadra el
recuento: válidas + rechazadas = filas de entrada. Reejecutar sobrescribe, no duplica.

Uso:
    python limpiar.py
    python limpiar.py --entrada datos-ejemplo/transacciones-fraude-sucio.csv \
        --validas data/sucio-validas.csv --cuarentena data/sucio-cuarentena.csv

Código de salida: 0 si no hay rechazos; 1 si alguna fila va a cuarentena; 2 si el fichero no
se puede leer o la cabecera no es la del contrato.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

from contrato import COLUMNAS, documento_contrato, validar_cabecera, validar_fila

BASE = Path(__file__).resolve().parent
CAMPOS_CUARENTENA = ("linea", "id", "regla", "columna", "valor", "motivo")
CAMPOS_RECUENTOS = ("fichero", "entrada", "validas", "rechazadas", "suma_cuadra")

# La salida se fuerza a UTF-8: la puerta lanza este script con la salida redirigida y la consola
# de Windows en cp1252 no puede escribir «·», «—» ni «≤».
for _flujo in (sys.stdout, sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8")


def resolver(ruta: str) -> Path:
    """Convierte una ruta relativa al script en absoluta; así funciona desde cualquier carpeta."""
    destino = Path(ruta)
    return destino if destino.is_absolute() else BASE / destino


# Paso 1 · Carga el CSV y comprueba la cabecera antes de mirar una sola fila
# Por qué: si la cabecera no es la del contrato, limpiar filas daría una tabla con otro esquema.
# Salida esperada: "entrada: 300 filas · cabecera OK".
# Si falla: SystemExit 2 con la cabecera recibida y la esperada → revisa el fichero y su separador.
def cargar(ruta: Path) -> list[tuple[int, dict]]:
    with ruta.open(encoding="utf-8", newline="") as fichero:
        lector = csv.DictReader(fichero)
        campos = lector.fieldnames or []
        problemas = validar_cabecera(campos)
        if problemas:
            raise ValueError("; ".join(problemas))
        # La línea 1 es la cabecera: la primera fila de datos es la 2.
        return [(numero, fila) for numero, fila in enumerate(lector, start=2)]


# Paso 2 · Aplica el contrato y separa válidas de rechazadas
# Por qué: rechazar conserva la evidencia; corregir un importe negativo a cero la borraría.
# Salida esperada: "válidas: 300 · rechazadas: 0" con la muestra limpia.
# Si falla: todas las filas van a cuarentena → el contrato y la cabecera no hablan del mismo esquema.
def aplicar_contrato(filas: list[tuple[int, dict]]) -> tuple[list[dict], list[dict]]:
    validas: list[dict] = []
    cuarentena: list[dict] = []
    ids_vistos: set[str] = set()
    for linea, fila in filas:
        rechazos = validar_fila(fila, ids_vistos)
        if not rechazos:
            validas.append(fila)
            continue
        rechazo = rechazos[0]
        cuarentena.append({
            "linea": linea,
            "id": (fila.get("id") or "").strip(),
            **rechazo,
        })
    return validas, cuarentena


# Paso 3 · Escribe la tabla válida y la cuarentena con su regla, columna y valor
# Por qué: una cuarentena sin motivo no permite arreglar la fuente; se guarda el valor rechazado.
# Salida esperada: data/transacciones-validas.csv con 300 filas y cuarentena vacía.
# Si falla: cuarentena con 300 filas → el contrato rechaza todo; mira `regla` y `columna`.
def escribir_salidas(entrada: Path, validas: list[dict], cuarentena: list[dict],
                     ruta_validas: Path, ruta_cuarentena: Path) -> None:
    ruta_validas.parent.mkdir(parents=True, exist_ok=True)
    with ruta_validas.open("w", encoding="utf-8", newline="") as fichero:
        escritor = csv.DictWriter(fichero, fieldnames=COLUMNAS)
        escritor.writeheader()
        escritor.writerows(validas)

    ruta_cuarentena.parent.mkdir(parents=True, exist_ok=True)
    with ruta_cuarentena.open("w", encoding="utf-8", newline="") as fichero:
        escritor = csv.DictWriter(fichero, fieldnames=CAMPOS_CUARENTENA)
        escritor.writeheader()
        escritor.writerows(cuarentena)


# Paso 4 · Cuadra el recuento: válidas + rechazadas = entrada
# Por qué: la igualdad es la prueba de que no se ha perdido ninguna fila por el camino.
# Salida esperada: "entrada=12 · válidas=8 · rechazadas=4 · suma_cuadra=si".
# Si falla: suma_cuadra=no → se contaron ids únicos en vez de filas, o se filtró sin contar.
def cuadrar(entrada: Path, filas_entrada: int, validas: list[dict], cuarentena: list[dict],
            ruta_recuentos: Path) -> dict:
    recuento = {
        "fichero": entrada.name,
        "entrada": filas_entrada,
        "validas": len(validas),
        "rechazadas": len(cuarentena),
        "suma_cuadra": "si" if filas_entrada == len(validas) + len(cuarentena) else "no",
    }
    ruta_recuentos.parent.mkdir(parents=True, exist_ok=True)
    with ruta_recuentos.open("w", encoding="utf-8", newline="") as fichero:
        escritor = csv.DictWriter(fichero, fieldnames=CAMPOS_RECUENTOS)
        escritor.writeheader()
        escritor.writerow(recuento)
    return recuento


# Paso 5 · Documenta el contrato junto al resultado y decide el código de salida
# Por qué: el contrato es una pieza auditable; se guarda con las reglas y sus motivos.
# Salida esperada: resultados/contrato.json con 9 columnas y exit 0 sobre la muestra limpia.
# Si falla: exit 1 → hay rechazos (es lo correcto con el fixture sucio); exit 2 → fichero o cabecera.
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Limpia transacciones con un contrato de calidad.")
    parser.add_argument("--entrada", default="datos-ejemplo/transacciones-fraude-muestra.csv")
    parser.add_argument("--validas", default="data/transacciones-validas.csv")
    parser.add_argument("--cuarentena", default="data/cuarentena.csv")
    parser.add_argument("--recuentos", default="resultados/recuentos.csv")
    parser.add_argument("--contrato", default="resultados/contrato.json")
    args = parser.parse_args(argv)

    entrada = resolver(args.entrada)
    try:
        filas = cargar(entrada)
    except (OSError, ValueError) as error:
        print(f"ERROR: no se puede limpiar {entrada.name}: {error}", file=sys.stderr)
        return 2

    validas, cuarentena = aplicar_contrato(filas)
    escribir_salidas(entrada, validas, cuarentena, resolver(args.validas), resolver(args.cuarentena))
    recuento = cuadrar(entrada, len(filas), validas, cuarentena, resolver(args.recuentos))

    ruta_contrato = resolver(args.contrato)
    ruta_contrato.parent.mkdir(parents=True, exist_ok=True)
    ruta_contrato.write_text(json.dumps(documento_contrato(), ensure_ascii=False, indent=2) + "\n",
                             encoding="utf-8")

    print(f"== Limpieza con contrato · {entrada.name} ==")
    print(f"entrada: {recuento['entrada']} filas · válidas: {recuento['validas']} · "
          f"rechazadas: {recuento['rechazadas']} · suma_cuadra: {recuento['suma_cuadra']}")
    for rechazo in cuarentena:
        print(f"  línea {rechazo['linea']}: {rechazo['regla']} en {rechazo['columna']} "
              f"(valor {rechazo['valor']!r})")
    print(f"Contrato: {ruta_contrato.relative_to(BASE) if ruta_contrato.is_relative_to(BASE) else ruta_contrato}")
    return 1 if cuarentena else 0


if __name__ == "__main__":
    sys.exit(main())
