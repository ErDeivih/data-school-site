#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Contrato de calidad de `transacciones-fraude`, declarado columna a columna.

Un contrato no se deduce de los datos: se escribe con el tipo, la obligatoriedad, el rango o la
enumeración de cada columna y el motivo de la regla. El mínimo y el máximo observados no son el
contrato; si lo fueran, cualquier valor futuro pasaría.

Se usa desde `limpiar.py` y se documenta en `resultados/contrato.json`.
"""

from __future__ import annotations

import re

# Las nueve columnas y su orden. Un fichero con otra cabecera no se limpia: se rechaza el fichero.
COLUMNAS = (
    "id",
    "importe_eur",
    "hora",
    "canal",
    "pais",
    "dispositivo",
    "intentos_24h",
    "antiguedad_dias",
    "fraude",
)

# Reglas declaradas. Los límites son decisiones de negocio, no el mínimo y el máximo del fichero.
REGLAS = (
    {
        "columna": "id",
        "tipo": "texto",
        "obligatorio": True,
        "patron": r"^T\d{5}$",
        "motivo": "el id identifica la transacción y sigue el formato T + 5 dígitos",
    },
    {
        "columna": "importe_eur",
        "tipo": "decimal",
        "obligatorio": True,
        "min_exclusivo": 0.0,
        "max": 900.0,
        "motivo": "un pago no puede ser negativo ni superar los 900 € del dominio del generador",
    },
    {
        "columna": "hora",
        "tipo": "entero",
        "obligatorio": True,
        "min": 0,
        "max": 23,
        "motivo": "la hora es la del día, de 0 a 23",
    },
    {
        "columna": "canal",
        "tipo": "texto",
        "obligatorio": True,
        "enum": ["web", "app", "tienda"],
        "motivo": "solo existen tres canales de pago en el catálogo",
    },
    {
        "columna": "pais",
        "tipo": "texto",
        "obligatorio": True,
        "enum": ["ES", "FR", "PT", "MA"],
        "motivo": "el generador solo emite cuatro países",
    },
    {
        "columna": "dispositivo",
        "tipo": "texto",
        "obligatorio": True,
        "enum": ["movil", "escritorio"],
        "motivo": "solo se registran dos tipos de dispositivo",
    },
    {
        "columna": "intentos_24h",
        "tipo": "entero",
        "obligatorio": True,
        "min": 1,
        "max": 8,
        "motivo": "el dominio declara entre 1 y 8 intentos en 24 h",
    },
    {
        "columna": "antiguedad_dias",
        "tipo": "entero",
        "obligatorio": True,
        "min": 1,
        "max": 1180,
        "motivo": "una cuenta no puede tener antigüedad negativa ni superar el máximo del dominio",
    },
    {
        "columna": "fraude",
        "tipo": "entero",
        "obligatorio": True,
        "enum": [0, 1],
        "motivo": "la etiqueta es binaria: 0 no fraude, 1 fraude",
    },
)

# Regla cruzada: el id no se repite. La segunda aparición va a cuarentena, no se sobrescribe.
REGLA_ID_UNICA = {
    "regla": "id_repetido",
    "columna": "id",
    "motivo": "el id es la clave de la transacción y no puede repetirse",
}

PATRON_ENTERO = re.compile(r"^-?\d+$")


def validar_cabecera(campos: list[str] | tuple[str, ...]) -> list[str]:
    """Devuelve los errores de cabecera; lista vacía significa que el fichero se puede limpiar."""
    if tuple(campos) != COLUMNAS:
        return [f"cabecera {tuple(campos)} distinta de la esperada {COLUMNAS}"]
    return []


def _rechazo(regla: str, columna: str, valor: str, motivo: str) -> dict:
    return {"regla": regla, "columna": columna, "valor": valor, "motivo": motivo}


def validar_fila(fila: dict, ids_vistos: set[str]) -> list[dict]:
    """Aplica las reglas de columna y la de id único. Devuelve los rechazos; vacío = fila válida."""
    rechazos: list[dict] = []
    for regla in REGLAS:
        columna = regla["columna"]
        valor = (fila.get(columna) or "").strip()
        if regla.get("obligatorio") and not valor:
            rechazos.append(_rechazo("obligatorio", columna, "", regla["motivo"]))
            continue
        if regla["tipo"] == "texto":
            if regla.get("patron") and not re.fullmatch(regla["patron"], valor):
                rechazos.append(_rechazo("formato", columna, valor, regla["motivo"]))
            if regla.get("enum") and valor not in regla["enum"]:
                rechazos.append(_rechazo(f"{columna}_no_permitido", columna, valor, regla["motivo"]))
        elif regla["tipo"] == "entero":
            if not PATRON_ENTERO.fullmatch(valor):
                rechazos.append(_rechazo("tipo", columna, valor, regla["motivo"]))
                continue
            numero = int(valor)
            if "min" in regla and numero < regla["min"]:
                rechazos.append(_rechazo(f"{columna}_fuera_de_rango", columna, valor, regla["motivo"]))
            if "max" in regla and numero > regla["max"]:
                rechazos.append(_rechazo(f"{columna}_fuera_de_rango", columna, valor, regla["motivo"]))
        elif regla["tipo"] == "decimal":
            try:
                numero = float(valor)
            except ValueError:
                rechazos.append(_rechazo("tipo", columna, valor, regla["motivo"]))
                continue
            if "min_exclusivo" in regla and numero <= regla["min_exclusivo"]:
                rechazos.append(_rechazo(f"{columna}_fuera_de_rango", columna, valor, regla["motivo"]))
            if "max" in regla and numero > regla["max"]:
                rechazos.append(_rechazo(f"{columna}_fuera_de_rango", columna, valor, regla["motivo"]))
        if rechazos:
            break  # el primer motivo basta para mandar la fila a cuarentena

    if not rechazos:
        identificador = (fila.get("id") or "").strip()
        if identificador in ids_vistos:
            rechazos.append(_rechazo(REGLA_ID_UNICA["regla"], REGLA_ID_UNICA["columna"],
                                     identificador, REGLA_ID_UNICA["motivo"]))
        else:
            ids_vistos.add(identificador)
    return rechazos


def documento_contrato() -> dict:
    """Versión serializable del contrato para el README y para `resultados/contrato.json`."""
    return {
        "dataset": "transacciones-fraude (muestra de práctica)",
        "columnas": list(COLUMNAS),
        "reglas": [dict(regla) for regla in REGLAS],
        "regla_cruzada": dict(REGLA_ID_UNICA),
        "nota": "los límites son reglas declaradas, no el mínimo y el máximo observados",
    }
