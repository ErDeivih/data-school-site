﻿# P41 · Limpieza a escala con contrato de calidad — código

Limpieza de `transacciones-fraude` con un **contrato declarado columna a columna**: cada regla
lleva tipo, obligatoriedad, rango o enumeración y motivo. Las filas que no cumplen no se
corrigen: van a una **cuarentena** con su regla, su columna y el valor original. Al final se
comprueba que **válidas + rechazadas = filas de entrada**, también en la segunda ejecución.

Acompaña a la ficha `p41-limpieza-con-contrato.md`. Es
offline: no hay red, ni API, ni dependencias externas.

## Requisitos

- Python **3.10 o superior**.
- Solo biblioteca estándar: `argparse`, `csv`, `json`, `pathlib`, `re`, `sys`, `shutil`.
- No hace falta instalar nada para ejecutarlo.

## Instalación

```powershell
cd proyectos\p41-limpieza-con-contrato\codigo
python -m pip install -r requirements.txt
```

`requirements.txt` no instala nada: el proyecto es stdlib pura. Se deja el comando porque el
contrato de la casa lo pide y para que el lector no busque dependencias ocultas.

## Ejecución

```powershell
# 1. Sobre la muestra limpia: 300 válidas, 0 rechazadas, exit 0
python limpiar.py

# 2. Sobre el fixture sucio declarado: 8 válidas, 4 rechazadas, exit 1
python limpiar.py --entrada datos-ejemplo/transacciones-fraude-sucio.csv `
  --validas data/sucio-validas.csv --cuarentena data/sucio-cuarentena.csv `
  --recuentos resultados/sucio-recuentos.csv
```

Salida esperada del primer comando:

```text
== Limpieza con contrato · transacciones-fraude-muestra.csv ==
entrada: 300 filas · válidas: 300 · rechazadas: 0 · suma_cuadra: si
Contrato: resultados\contrato.json
```

El código de salida es **0 si no hay rechazos**, **1 si hay filas en cuarentena** y **2 si el
fichero no se puede leer o la cabecera no es la del contrato**.

## Verificación

```powershell
python verificar.py
```

La puerta comprueba el crudo, revisa que el contrato sea declarado y no inferido, limpia la
muestra, comprueba la idempotencia y repite con el fixture sucio los cuatro rechazos y los
recuentos. Termina con `RESULTADO: VERDE` y exit 0.

## Datos de ejemplo

| Fichero | Contenido |
| --- | --- |
| `datos-ejemplo/transacciones-fraude-muestra.csv` | **300 filas** y **9 columnas**, copiadas de las 3000 del CSV del portal para que el ejemplo sea pequeño y ejecutable |
| `datos-ejemplo/transacciones-fraude-sucio.csv` | **12 filas**: 8 válidas y 4 defectos declarados (importe −25,00, hora 25, canal `fax`, id `T00003` repetido) |
| `datos-ejemplo/LEEME.md` | procedencia, checksums y lista de defectos |

La muestra es sintética, CC0-1.0 y de semilla fija. Procede de
`aprender/web/datos/datasets/transacciones-fraude.csv` (3000 filas × 9 columnas, checksum
`sha256:830cd8b8…b2a7`, consultado el 2026-11-06). Ese CSV **no está copiado en
`datasets/csv/`**: por eso el ejemplo viaja con su muestra y su procedencia anotada. El CSV
original no se ensucia: el fixture sucio es un fichero aparte.

## Fuente real y licencia

- **Fuente:** `F:\Proyectos\ProyectoServidor\aprender\web\datos\datasets\transacciones-fraude.csv`
  (portal en solo lectura), definido por `datos/generar-datasets.mjs` con semilla fija.
- **Licencia:** **CC0-1.0**. Sintético: no hay pagos ni clientes reales.
- **Sin API:** el catálogo declara `api: []`; no hay una API gratuita verificable de fraude y el
  proyecto no la finge.

## Mapa paso → lección

| Paso del código | Qué hace | Lección del temario |
| --- | --- | --- |
| Paso 1 · Cargar | comprueba la cabecera antes de leer filas | Ficheros y encoding |
| Paso 2 · Contrato | declara tipo, rango o enumeración y motivo por columna | Contratos de datos |
| Paso 3 · Rechazar | manda a cuarentena en vez de corregir | Registros rechazados y cuarentena |
| Paso 4 · Cuarentena | guarda regla, columna, valor e id | Calidad de datos |
| Paso 5 · Cuadrar | válidas + rechazadas = entrada | Reconciliación y pruebas |
| Paso 6 · CLI e idempotencia | reejecutar no duplica; códigos de salida | Scripts ejecutables y argumentos |

## Estructura

```text
codigo/
├── contrato.py           # las 9 reglas con su motivo y la regla de id único
├── limpiar.py            # carga, aplica, escribe válidas/cuarentena y cuadra
├── verificar.py          # puerta offline: 0 solo si todo pasa
├── requirements.txt      # stdlib, sin dependencias
├── datos-ejemplo/        # muestra limpia, fixture sucio y procedencia
├── data/                 # transacciones-validas.csv y cuarentena.csv
└── resultados/           # contrato.json, recuentos.csv y ejemplo-salida.txt
```

## Límites

La muestra de 300 filas se usa para que el ejemplo sea descargable y rápido; el contrato es el
mismo que se aplica a las 3000 filas del proyecto. Los rangos son **reglas de negocio
declaradas**, no el mínimo y el máximo observados: si se copiaran del fichero, cualquier valor
futuro pasaría. La cuarentena guarda el primer motivo de rechazo por fila; una fila con varios
defectos se revisa entera a mano.
