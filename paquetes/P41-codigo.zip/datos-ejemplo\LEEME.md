# Datos de ejemplo (P41)

## Muestra limpia

- **Fichero:** `transacciones-fraude-muestra.csv`
- **Tamaño:** 300 filas × 9 columnas (las primeras 300 del CSV del portal).
- **SHA-256:** `e7fba8a2c9372aec08db36108d9db51fd943373c791b2f1e80de36a394edb240`
- **Procedencia:** `F:\Proyectos\ProyectoServidor\aprender\web\datos\datasets\transacciones-fraude.csv`
  (3000 filas × 9 columnas, CC0-1.0, sintético con semilla fija), copiado el 2026-11-06.
  Checksum del fichero completo de origen:
  `sha256:830cd8b8e2abf8479702530665490dbe2821dc674403471c3b35c25ee838b2a7`.
- **Contenido:** 9 fraudes de 300 (3 %); es la misma distribución que el fichero completo
  (69 de 3000, 2,3 %), solo que con menos filas.

## Fixture sucio declarado

- **Fichero:** `transacciones-fraude-sucio.csv`
- **Tamaño:** 12 filas: las 8 primeras de la muestra (válidas) y 4 defectos inyectados **a
  propósito** para demostrar que el contrato rechaza:
  1. `T00009` con `importe_eur = -25.00` (importe negativo).
  2. `T00010` con `hora = 25` (fuera de 0–23).
  3. `T00011` con `canal = fax` (canal que no existe).
  4. `T00003` repetido (mismo id que la fila 3; la segunda aparición va a cuarentena).
- **Resultado esperado:** 8 válidas y 4 rechazadas; válidas + rechazadas = 12.

El CSV original **no se ensucia**: este fixture es un fichero aparte y se usa solo en la prueba.
