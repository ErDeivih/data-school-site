#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Puerta del proyecto P41: comprueba de verdad el contrato y la cuarentena.

Es offline y no lanza procesos hijos: importa `limpiar.py`, ejecuta su `main()` sobre la muestra
limpia y sobre el fixture sucio declarado, y revisa los ficheros que deja. Comprueba los
recuentos, las reglas aplicadas, la idempotencia y que el contrato declara límites de negocio
en vez de copiarlos del mínimo y el máximo observados.

Uso:
    python verificar.py

Termina con `RESULTADO: VERDE` (exit 0) si todas las comprobaciones pasan.
"""

from __future__ import annotations

import contextlib
import csv
import io
import json
import shutil
import sys
from pathlib import Path

import contrato
import limpiar

BASE = Path(__file__).resolve().parent
MUESTRA = BASE / "datos-ejemplo" / "transacciones-fraude-muestra.csv"
SUCIO = BASE / "datos-ejemplo" / "transacciones-fraude-sucio.csv"
TMP = BASE / "resultados" / "verificacion"

# La salida se fuerza a UTF-8: la puerta lanza este script con stdout redirigido y la consola de
# Windows en cp1252 no puede escribir «·», «—» ni «≤».
for _flujo in (sys.stdout, sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8")

comprobaciones = 0
fallos: list[str] = []


def check(condicion: bool, mensaje: str) -> bool:
    """Una comprobación, una línea. Si falla, se anota y el resultado final será ROJO."""
    global comprobaciones
    comprobaciones += 1
    if condicion:
        print(f"OK   · {mensaje}")
    else:
        print(f"FALLA· {mensaje}")
        fallos.append(mensaje)
    return condicion


def ejecutar_limpieza(entrada: Path, carpeta: Path) -> tuple[int, str]:
    """Ejecuta limpiar.main() en el mismo proceso; devuelve código de salida y salida impresa."""
    carpeta.mkdir(parents=True, exist_ok=True)
    argumentos = [
        "--entrada", str(entrada),
        "--validas", str(carpeta / "validas.csv"),
        "--cuarentena", str(carpeta / "cuarentena.csv"),
        "--recuentos", str(carpeta / "recuentos.csv"),
        "--contrato", str(carpeta / "contrato.json"),
    ]
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        codigo = limpiar.main(argumentos)
    return codigo, buffer.getvalue()


def leer_csv(ruta: Path) -> tuple[list[str], list[dict]]:
    with ruta.open(encoding="utf-8", newline="") as fichero:
        lector = csv.DictReader(fichero)
        return list(lector.fieldnames or []), list(lector)


# Paso 1 · Comprueba el crudo antes de limpiarlo
# Por qué: si el fichero de ejemplo no es el que dice ser, el contrato se está probando con otro dato.
# Salida esperada: 300 filas, 9 columnas, id único, rangos del contrato y 9 fraudes.
# Si falla: FileNotFoundError → la muestra no está en datos-ejemplo/; revisa la ruta.
campos, filas = leer_csv(MUESTRA)
check(campos == list(contrato.COLUMNAS), "la muestra tiene las 9 columnas del contrato en orden")
check(len(filas) == 300, f"la muestra tiene 300 filas (tiene {len(filas)})")
check(len({f['id'] for f in filas}) == 300, "los 300 ids de la muestra son únicos")
check(all(f["id"].startswith("T") and len(f["id"]) == 6 for f in filas),
      "todos los ids de la muestra siguen el formato T + 5 dígitos")
check(sum(int(f["fraude"]) for f in filas) == 9, "la muestra conserva 9 fraudes de las 300 filas")
check(all(f"{campo}".strip() != "" for f in filas for campo in f), "la muestra no tiene celdas vacías")

# Paso 2 · Revisa el contrato declarado, no inferido de los datos
# Por qué: un contrato con el mínimo y el máximo observados deja pasar cualquier valor futuro.
# Salida esperada: 9 reglas con motivo; importe con máximo 900 €, distinto del máximo observado.
# Si falla: falta motivo o límite → el contrato no es auditable; mira `contrato.REGLAS`.
documento = contrato.documento_contrato()
check(len(documento["columnas"]) == 9 and len(documento["reglas"]) == 9,
      "el contrato documenta las 9 columnas con una regla cada una")
check(all(regla.get("motivo") for regla in documento["reglas"]),
      "cada regla del contrato lleva su motivo escrito")
regla_importe = next(r for r in documento["reglas"] if r["columna"] == "importe_eur")
check(regla_importe["max"] == 900.0, "el máximo de importe es una regla declarada (900 €)")
check(max(float(f["importe_eur"]) for f in filas) <= 900.0,
      "la muestra respeta el máximo declarado de importe")
check(regla_importe["max"] != max(float(f["importe_eur"]) for f in filas),
      "el máximo del contrato no es el máximo observado en la muestra")
fila_prueba = {"id": "T00999", "importe_eur": "950.00", "hora": "12", "canal": "web",
               "pais": "ES", "dispositivo": "movil", "intentos_24h": "1",
               "antiguedad_dias": "10", "fraude": "0"}
check(bool(contrato.validar_fila(fila_prueba, set())), "un importe de 950 € se rechaza por la regla")
fila_prueba["importe_eur"] = "899.95"
check(contrato.validar_fila(fila_prueba, set()) == [], "899,95 € (máximo medido) se acepta")

# Paso 3 · Limpia la muestra limpia: todo válido y recuento que cuadra
# Por qué: el contrato no puede rechazar lo que sí cumple; si lo hace, la regla está mal.
# Salida esperada: exit 0, 300 válidas, 0 rechazadas y suma_cuadra = si.
# Si falla: rechazadas > 0 → el contrato y los datos de ejemplo no encajan.
TMP.mkdir(parents=True, exist_ok=True)
try:
    codigo_limpio, salida_limpio = ejecutar_limpieza(MUESTRA, TMP / "limpio")
    check(codigo_limpio == 0, f"la muestra limpia sale con 0; salió {codigo_limpio}")
    check("válidas: 300" in salida_limpio and "rechazadas: 0" in salida_limpio,
          "la limpieza de la muestra anuncia 300 válidas y 0 rechazadas")
    campos_validas, validas = leer_csv(TMP / "limpio" / "validas.csv")
    _, cuarentena = leer_csv(TMP / "limpio" / "cuarentena.csv")
    _, recuentos = leer_csv(TMP / "limpio" / "recuentos.csv")
    check(campos_validas == list(contrato.COLUMNAS), "las válidas conservan las 9 columnas originales")
    check(len(validas) == 300 and len(cuarentena) == 0, "la muestra deja 300 válidas y 0 rechazadas")
    check(recuentos == [{"fichero": MUESTRA.name, "entrada": "300", "validas": "300",
                         "rechazadas": "0", "suma_cuadra": "si"}],
          "el recuento de la muestra cuadra (300 = 300 + 0)")

    # Paso 4 · Idempotencia: la segunda ejecución no duplica ni cambia la tabla
    # Por qué: si se escribe con append, la segunda pasada duplica filas y el recuento se desborda.
    # Salida esperada: los tres ficheros son idénticos byte a byte a los de la primera pasada.
    # Si falla: las válidas crecen → el código abre el CSV en modo append.
    ejecutar_limpieza(MUESTRA, TMP / "limpio2")
    for nombre in ("validas.csv", "cuarentena.csv", "recuentos.csv"):
        check((TMP / "limpio" / nombre).read_bytes() == (TMP / "limpio2" / nombre).read_bytes(),
              f"la segunda ejecución deja {nombre} idéntico (idempotente)")

    # Paso 5 · Fixture sucio: cuatro defectos a cuarentena y ninguna fila perdida
    # Por qué: sobre un CSV limpio el contrato no demuestra nada; rechaza cuando debe rechazar.
    # Salida esperada: exit 1, 8 válidas, 4 rechazadas y suma_cuadra = si (12 = 8 + 4).
    # Si falla: rechazadas != 4 → el fixture o la regla cambiaron; mira la columna `regla`.
    codigo_sucio, salida_sucio = ejecutar_limpieza(SUCIO, TMP / "sucio")
    check(codigo_sucio == 1, f"el fixture sucio sale con 1; salió {codigo_sucio}")
    check("válidas: 8" in salida_sucio and "rechazadas: 4" in salida_sucio,
          "el fixture sucio deja 8 válidas y 4 rechazadas")
    _, validas_sucio = leer_csv(TMP / "sucio" / "validas.csv")
    _, cuarentena_sucio = leer_csv(TMP / "sucio" / "cuarentena.csv")
    _, recuentos_sucio = leer_csv(TMP / "sucio" / "recuentos.csv")
    check(len(validas_sucio) == 8, "la tabla válida del fixture tiene 8 filas")
    check(len(cuarentena_sucio) == 4, "la cuarentena del fixture tiene 4 filas")
    check(recuentos_sucio == [{"fichero": SUCIO.name, "entrada": "12", "validas": "8",
                               "rechazadas": "4", "suma_cuadra": "si"}],
          "el recuento del fixture cuadra (12 = 8 + 4)")
    check({fila["regla"] for fila in cuarentena_sucio} ==
          {"importe_eur_fuera_de_rango", "hora_fuera_de_rango",
           "canal_no_permitido", "id_repetido"},
          "la cuarentena registra las cuatro reglas: importe, hora, canal e id repetido")

    # Paso 6 · La cuarentena conserva la evidencia y lo válido no se toca
    # Por qué: corregir el valor a ciegas borra la prueba de lo que llegó; el rechazo debe ser auditable.
    # Salida esperada: -25.00, 25, fax y T00003 en cuarentena; las 8 válidas idénticas a la muestra.
    # Si falla: un valor aparece «corregido» en válidas → el contrato está mutando filas.
    por_regla = {fila["regla"]: fila for fila in cuarentena_sucio}
    check(por_regla["importe_eur_fuera_de_rango"]["valor"] == "-25.00",
          "la cuarentena guarda el importe negativo -25.00 tal cual")
    check(por_regla["hora_fuera_de_rango"]["valor"] == "25",
          "la cuarentena guarda la hora 25 tal cual")
    check(por_regla["canal_no_permitido"]["valor"] == "fax",
          "la cuarentena guarda el canal fax tal cual")
    check(por_regla["id_repetido"]["valor"] == "T00003",
          "la cuarentena guarda el id repetido T00003")
    check(all(fila["motivo"] for fila in cuarentena_sucio),
          "cada rechazo lleva su motivo escrito")
    check(validas_sucio == filas[:8], "las 8 filas válidas del fixture son las originales sin mutar")
    check(len({f["id"] for f in validas_sucio}) == len(validas_sucio),
          "la tabla válida no contiene ids repetidos")
    check(all(f["id"] not in {"T00009", "T00010", "T00011"} for f in validas_sucio),
          "las filas con defectos no están en la tabla válida")
finally:
    if TMP.exists():
        shutil.rmtree(TMP)

# Cierre
print()
if fallos:
    print(f"RESULTADO: ROJO — {len(fallos)} de {comprobaciones} comprobaciones sin cumplir")
    sys.exit(1)
print(f"RESULTADO: VERDE — {comprobaciones} comprobaciones pasan")
sys.exit(0)
