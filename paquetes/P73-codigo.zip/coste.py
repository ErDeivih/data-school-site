"""P73 · Fraude: cuánto cuesta bloquear de más.

Convierte 3.000 transacciones en una decisión de negocio: qué fraude se evita con una regla, cuánto
cuesta cada falsa alarma y qué umbral deja mejor balance. Sin librerías.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("id", "importe_eur", "hora", "canal", "pais", "dispositivo",
            "intentos_24h", "antiguedad_dias", "fraude")
MARGEN_PERDIDO = 0.30  # margen que se pierde al bloquear una compra legítima


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: importe positivo, fraude 0/1 e intentos no negativos.
    # Por qué: una transacción sin importe no se puede costear; una etiqueta rara rompe el cálculo.
    # Salida esperada: 3000 transacciones con sus campos numéricos.
    # Si falla: «columnas inesperadas», importe no positivo o fraude fuera de 0/1.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 3000:
        raise ValueError(f"se esperaban 3000 filas, hay {len(filas)}")
    for fila in filas:
        if float(fila["importe_eur"]) <= 0:
            raise ValueError("importe no positivo")
        if fila["fraude"] not in ("0", "1"):
            raise ValueError("fraude debe ser 0 o 1")
        if int(fila["intentos_24h"]) < 0:
            raise ValueError("intentos negativos")
    return filas


def base(filas: list[dict]) -> dict:
    # Paso 2 · Tasa de fraude y dinero en juego, sin regla todavía.
    # Por qué: sin línea base no se sabe si la regla mejora algo o solo bloquea.
    # Salida esperada: fraude, importe total, importe fraudulento.
    total = sum(float(f["importe_eur"]) for f in filas)
    fraude = [f for f in filas if f["fraude"] == "1"]
    importe_fraude = sum(float(f["importe_eur"]) for f in fraude)
    return {"n": len(filas), "n_fraude": len(fraude), "tasa": len(fraude) / len(filas),
            "importe_total": total, "importe_fraude": importe_fraude,
            "ticket_medio": total / len(filas)}


def regla(filas: list[dict], umbral: int) -> dict:
    # Paso 3 · Regla: bloquear si intentos_24h ≥ umbral.
    # Por qué: es una regla que un negocio puede explicar; el coste del falso positivo se mide.
    # Salida esperada: TP/FP/FN, fraude evitado, coste de bloquear y neto.
    tp = fp = fn = tn = 0
    evitado = coste_fp = 0.0
    for fila in filas:
        bloquea = int(fila["intentos_24h"]) >= umbral
        es_fraude = fila["fraude"] == "1"
        importe = float(fila["importe_eur"])
        if bloquea and es_fraude:
            tp += 1
            evitado += importe
        elif bloquea and not es_fraude:
            fp += 1
            coste_fp += importe * MARGEN_PERDIDO
        elif not bloquea and es_fraude:
            fn += 1
        else:
            tn += 1
    return {"umbral": umbral, "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "evitado": evitado, "coste_fp": coste_fp, "neto": evitado - coste_fp,
            "precision": tp / (tp + fp) if tp + fp else 0.0,
            "recall": tp / (tp + fn) if tp + fn else 0.0}


def main() -> int:
    parser = argparse.ArgumentParser(description="P73 · coste del falso positivo en fraude")
    parser.add_argument("--csv", default="datos-ejemplo/transacciones-fraude.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    b = base(filas)
    print(f"datos: {b['n']} transacciones · {b['n_fraude']} fraudes ({b['tasa'] * 100:.2f} %) · "
          f"importe {b['importe_total']:.2f} € · ticket medio {b['ticket_medio']:.2f} €")
    print(f"fraude: {b['importe_fraude']:.2f} € en juego")
    print("regla: bloquear si intentos_24h ≥ umbral · margen perdido por falso positivo 30 %")
    filas_regla = [regla(filas, u) for u in (2, 3, 4, 5, 6)]
    for r in filas_regla:
        print(f"  umbral {r['umbral']}: TP {r['tp']:2} · FP {r['fp']:3} · FN {r['fn']:2} · "
              f"evitado {r['evitado']:8.2f} € · coste FP {r['coste_fp']:8.2f} € · neto {r['neto']:+8.2f} € · "
              f"precisión {r['precision'] * 100:5.1f} % · recall {r['recall'] * 100:5.1f} %")
    mejor = max(filas_regla, key=lambda r: r["neto"])
    print(f"mejor umbral por neto: {mejor['umbral']} · neto {mejor['neto']:+.2f} €")
    if mejor["neto"] < 0:
        print("lectura: con este margen, ninguna regla compensa: el fraude evitado no cubre el margen perdido.")
    else:
        print("lectura: bajar el umbral evita más fraude, pero cada falso positivo cuesta margen; el neto lo dice.")
    print("límite: 3000 transacciones sintéticas y un margen supuesto del 30 %; no hay coste de revisión manual.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
