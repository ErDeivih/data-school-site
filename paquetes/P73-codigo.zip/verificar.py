#!/usr/bin/env python3
"""Puerta del proyecto P73 (fraude: cuánto cuesta bloquear de más).

Comprueba datos, línea base, regla, coste del falso positivo y ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import coste

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "transacciones-fraude.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.2f} ≈ {esperado:.2f})")


def main() -> int:
    filas = coste.leer(CSV)
    ok(len(filas) == 3000, "el CSV tiene 3000 transacciones")
    ok(sum(1 for f in filas if f["fraude"] == "1") == 69, "hay 69 fraudes")
    b = coste.base(filas)
    cerca(b["tasa"], 0.023, 0.001, "tasa de fraude")
    cerca(b["importe_total"], 920810.59, 0.02, "importe total")
    cerca(b["importe_fraude"], 43974.56, 0.02, "importe fraudulento")
    cerca(b["ticket_medio"], 306.94, 0.02, "ticket medio")

    r6 = coste.regla(filas, 6)
    ok(r6["tp"] == 36 and r6["fp"] == 394 and r6["fn"] == 33 and r6["tn"] == 2537, "matriz de confusión con umbral 6")
    cerca(r6["evitado"], 21954.18, 0.05, "fraude evitado con umbral 6")
    cerca(r6["coste_fp"], 33917.44, 0.05, "coste del falso positivo con umbral 6")
    cerca(r6["neto"], -11963.26, 0.05, "neto con umbral 6")
    cerca(r6["precision"], 0.084, 0.002, "precisión con umbral 6")
    cerca(r6["recall"], 0.522, 0.002, "recall con umbral 6")

    r2 = coste.regla(filas, 2)
    ok(r2["tp"] > r6["tp"], "bajar el umbral evita más fraude")
    ok(r2["coste_fp"] > r6["coste_fp"], "bajar el umbral cuesta más falsos positivos")
    ok(all(coste.regla(filas, u)["neto"] < 0 for u in (2, 3, 4, 5, 6)),
       "con este margen, ninguna regla compensa")

    codigo = (AQUI / "coste.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
