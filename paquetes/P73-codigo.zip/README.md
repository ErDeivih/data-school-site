# P73 · Fraude: cuánto cuesta bloquear de más

Paquete descargable de **Data School** para el proyecto P73. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es de negocio: **¿compensa bloquear transacciones sospechosas?** El código
prueba una regla simple (`intentos_24h ≥ umbral`), mide fraude evitado y margen perdido por falsos
positivos. Resultado incómodo: con un margen del 30 %, **ninguna regla compensa**; la mejor (umbral 6)
evita 21.954,18 € pero cuesta 33.917,44 € en falsos positivos: neto **−11.963,26 €**.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python coste.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P73-codigo
python coste.py --csv datos-ejemplo/transacciones-fraude.csv
```

## Salida esperada

```text
datos: 3000 transacciones · 69 fraudes (2.30 %) · importe 920810.59 € · ticket medio 306.94 €
fraude: 43974.56 € en juego
regla: bloquear si intentos_24h ≥ umbral · margen perdido por falso positivo 30 %
  umbral 2: TP 57 · FP 1449 · FN 12 · evitado 35492.90 € · coste FP 128094.17 € · neto -92601.27 € · precisión 3.8 % · recall 82.6 %
  …
  umbral 6: TP 36 · FP 394 · FN 33 · evitado 21954.18 € · coste FP 33917.44 € · neto -11963.26 € · precisión 8.4 % · recall 52.2 %
mejor umbral por neto: 6 · neto -11963.26 €
lectura: con este margen, ninguna regla compensa: el fraude evitado no cubre el margen perdido.
límite: 3000 transacciones sintéticas y un margen supuesto del 30 %; no hay coste de revisión manual.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/transacciones-fraude.csv`: **3000 filas × 9 columnas** (`id`, importe, hora, canal,
  país, dispositivo, intentos en 24 h, antigüedad y etiqueta `fraude` 0/1); 69 fraudes.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `transacciones-fraude` del catálogo.
- `sha256`: `830cd8b8e2abf8479702530665490dbe2821dc674403471c3b35c25ee838b2a7`.

## Qué enseña

| Paso | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida importe, etiqueta e intentos | sin etiqueta no hay coste |
| 2 · Línea base | tasa de fraude e importe en juego | cuánto se pierde sin regla |
| 3 · Regla | matriz TP/FP/FN/TN por umbral | una regla se puede explicar |
| 4 · Coste | fraude evitado − margen perdido | el falso positivo tiene precio |
| 5 · Decisión | el umbral que maximiza el neto | decidir con dinero, no con precisión |

## Las trampas que deja a la vista

1. **Precisión alta no es rentabilidad.** El umbral 6 tiene precisión 8,4 %; bloquear 36 fraudes
   implica 394 compras legítimas bloqueadas y un coste mayor que el fraude evitado.
2. **El umbral se elige con el neto, no con el recall.** Bajar a 2 evita más fraude (35.492,90 €)
   pero cuesta 128.094,17 € en margen: el peor neto de la tabla.
3. **El resultado negativo también es un resultado.** Con este margen, la regla no compensa; la
   decisión honesta es no bloquear con esta regla y buscar otra señal o revisión manual.

## Fallos típicos

- **`ModuleNotFoundError: coste`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`**: el CSV no es el del catálogo.
- **`fraude debe ser 0 o 1`**: etiquetas mezcladas o texto.
- **`importe no positivo`**: una transacción a cero rompe el coste.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P73-codigo/
├── coste.py                   # línea base, regla, coste del falso positivo
├── verificar.py               # 17 comprobaciones
├── requirements.txt
├── datos-ejemplo/transacciones-fraude.csv
└── resultados/ejemplo-salida.txt
```

## Límite

3000 transacciones sintéticas y un margen supuesto del 30 %; no hay coste de revisión manual,
recuperación de compras bloqueadas ni modelo de riesgo. El paquete enseña a **costear una regla**, no
a detectar fraude real.
