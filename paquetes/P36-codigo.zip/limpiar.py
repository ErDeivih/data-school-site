#!/usr/bin/env python3
"""P36 · Pandas: limpiar y agregar sin perder filas.

Carga `datos-ejemplo/ventas-mensuales.csv` (180 días, 3 tiendas), declara el grano, comprueba los tipos y
agrega por tienda y por mes sin borrar ninguna fila. El CSV no tiene nulos: la política se documenta y el
tratamiento de nulos se demuestra con la copia declarada `datos-ejemplo/ventas-sucias.csv`.

Uso:
    python limpiar.py              # ejecuta el proyecto y escribe data/ y resultados/
    python limpiar.py --fixture    # además procesa la copia sucia y deja la cuarentena
"""
from __future__ import annotations

import argparse
import calendar
import shutil
import sys
import warnings
from pathlib import Path

import pandas as pd

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
DATA = RAIZ / "data"
RESULTADOS = RAIZ / "resultados"

COLUMNAS = ["fecha", "tienda", "unidades", "ingresos"]
CLAVE = "fecha"
TIPOS = {"fecha": "datetime64[ns]", "tienda": "string", "unidades": "Int64", "ingresos": "float64"}


def cargar(ruta: Path | None = None) -> pd.DataFrame:
    # Paso 1 · Carga el CSV como texto, sin dejar que pandas adivine los tipos
    # Por qué: para poder auditar las conversiones hay que leer el original tal cual; si pandas convierte
    #          solo, una fecha mala se vuelve NaT sin que quede rastro de la fila que falló.
    # Salida esperada: "cargar: 180 filas × 4 columnas, todas como texto"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o revisa datos-ejemplo/ventas-mensuales.csv.
    ruta = RAIZ / ruta if ruta else DATOS / "ventas-mensuales.csv"
    bruto = pd.read_csv(ruta, dtype="string")
    bruto.columns = [str(columna).strip() for columna in bruto.columns]
    print(f"cargar: {len(bruto)} filas × {len(bruto.columns)} columnas, todas como texto")
    return bruto


def limpiar(bruto: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    # Paso 2 · Convierte tipos y separa las filas que no se pueden usar, contándolas
    # Por qué: la política del proyecto es no borrar filas sin decirlo. Primero se marca el motivo de
    #          cada rechazo (nulo, tipo mal, clave nula) y después se separa; la tabla limpia conserva el
    #          recuento de todo lo que entró.
    # Salida esperada: "limpiar: 9 entrada · 3 válidas · 6 rechazadas (duplicado 1, fecha_invalida 1…)"
    # Si falla: si válidas + rechazadas ≠ entrada, alguna rama del filtro se está saltando filas.
    trabajo = pd.DataFrame(
        {
            "fecha_dt": pd.to_datetime(bruto["fecha"], format="%Y-%m-%d", errors="coerce"),
            "tienda": bruto["tienda"],
            "unidades_num": pd.to_numeric(bruto["unidades"], errors="coerce").astype("Int64"),
            "ingresos_num": pd.to_numeric(bruto["ingresos"], errors="coerce").astype("float64"),
        }
    )

    motivos: list[str] = []
    for _, fila in trabajo.iterrows():
        razones = []
        if pd.isna(fila["fecha_dt"]):
            razones.append("fecha_invalida")
        if pd.isna(fila["tienda"]):
            razones.append("tienda_nula")
        if pd.isna(fila["unidades_num"]):
            razones.append("unidades_nulas_o_no_numericas")
        if pd.isna(fila["ingresos_num"]):
            razones.append("ingresos_nulos_o_no_numericos")
        motivos.append(";".join(razones))

    trabajo["motivo"] = motivos
    rechazadas = trabajo[trabajo["motivo"] != ""].copy()
    validas = trabajo[trabajo["motivo"] == ""].copy()

    duplicadas = validas.duplicated(subset=["fecha_dt"], keep="first")
    if duplicadas.any():
        copia_dup = validas[duplicadas].copy()
        copia_dup["motivo"] = "duplicado"
        rechazadas = pd.concat([rechazadas, copia_dup], ignore_index=True)
        validas = validas[~duplicadas].copy()

    limpio = pd.DataFrame(
        {
            "fecha": validas["fecha_dt"].dt.normalize(),
            "tienda": validas["tienda"].astype("string"),
            "unidades": validas["unidades_num"].astype("Int64"),
            "ingresos": validas["ingresos_num"].astype("float64"),
        }
    ).reset_index(drop=True)

    informe = {
        "filas_entrada": int(len(bruto)),
        "filas_validas": int(len(limpio)),
        "filas_rechazadas": int(len(rechazadas)),
        "nulos_entrada": {columna: int(bruto[columna].isna().sum()) for columna in COLUMNAS},
        "duplicados": int(duplicadas.sum()),
        "motivos": rechazadas["motivo"].value_counts().to_dict() if len(rechazadas) else {},
    }
    resumen_motivos = ", ".join(f"{k} {v}" for k, v in sorted(informe["motivos"].items()))
    print(
        f"limpiar: {informe['filas_entrada']} entrada · {informe['filas_validas']} válidas · "
        f"{informe['filas_rechazadas']} rechazadas" + (f" ({resumen_motivos})" if resumen_motivos else "")
    )
    return limpio, rechazadas, informe


def validar_grano(limpio: pd.DataFrame) -> dict:
    # Paso 3 · Declara y comprueba el grano: una fila por día de una tienda
    # Por qué: sin grano, una agregación puede sumar dos veces la misma fecha o comparar tiendas que no
    #          coinciden en el tiempo. La clave `fecha` es única en este CSV porque la tienda rota.
    # Salida esperada: "grano: 180 días únicos · 3 tiendas · 60 filas por tienda"
    # Si falla: si la clave no es única, hay filas duplicadas que no se han ido a cuarentena.
    por_tienda = limpio.groupby("tienda").size().to_dict()
    informe = {
        "filas": int(len(limpio)),
        "clave_unica": bool(limpio[CLAVE].is_unique),
        "dias_unicos": int(limpio[CLAVE].nunique()),
        "tiendas": sorted(por_tienda),
        "filas_por_tienda": {k: int(v) for k, v in por_tienda.items()},
    }
    exigir(informe["clave_unica"], "la clave fecha no es única")
    exigir(informe["dias_unicos"] == 180, f"días únicos {informe['dias_unicos']}, se esperaban 180")
    exigir(informe["tiendas"] == ["centro", "norte", "sur"], f"tiendas inesperadas: {informe['tiendas']}")
    print(
        f"grano: {informe['dias_unicos']} días únicos · {len(informe['tiendas'])} tiendas · "
        f"{informe['filas_por_tienda']} filas por tienda"
    )
    return informe


def agregar_por_tienda(limpio: pd.DataFrame) -> pd.DataFrame:
    # Paso 4 · Agrega por tienda y calcula el precio medio ponderado
    # Por qué: la media de ingresos/unidades no es suma(ingresos)/suma(unidades); solo la segunda es el
    #          precio medio de la tienda. Y el recuento de días tiene que cuadrar con el grano.
    # Salida esperada: "agregar: 3 tiendas · 14295 unidades · 192292.08 EUR"
    # Si falla: si el total no cuadra, se ha filtrado una tienda o se ha agrupado por una columna sucia.
    tabla = (
        limpio.groupby("tienda", as_index=False)
        .agg(dias=("fecha", "count"), unidades=("unidades", "sum"), ingresos=("ingresos", "sum"))
        .sort_values("tienda")
        .reset_index(drop=True)
    )
    tabla["precio_medio_ponderado"] = (tabla["ingresos"] / tabla["unidades"]).round(4)
    print(
        f"agregar: {len(tabla)} tiendas · {int(tabla['unidades'].sum())} unidades · "
        f"{float(tabla['ingresos'].sum()):.2f} EUR"
    )
    return tabla


def agregar_por_mes(limpio: pd.DataFrame) -> pd.DataFrame:
    # Paso 5 · Agrega por mes y marca el mes incompleto
    # Por qué: el dataset se llama «mensuales» pero es diario; junio llega al día 29, así que su total no
    #          se compara con un mes completo. El aviso va en la tabla, no en un comentario suelto.
    # Salida esperada: "meses: 6 · junio con 29 días (incompleto)"
    # Si falla: si salen 7 meses, la serie no empieza el 2026-01-01 o la fecha se leyó mal.
    tabla = (
        limpio.assign(mes=limpio["fecha"].dt.to_period("M").astype(str))
        .groupby("mes", as_index=False)
        .agg(dias=("fecha", "count"), unidades=("unidades", "sum"), ingresos=("ingresos", "sum"))
    )
    tabla["dias_esperados"] = [
        calendar.monthrange(int(mes[:4]), int(mes[5:7]))[1] for mes in tabla["mes"]
    ]
    tabla["incompleto"] = tabla["dias"] < tabla["dias_esperados"]
    junio = tabla[tabla["mes"] == "2026-06"]
    dias_junio = int(junio["dias"].iloc[0]) if len(junio) else 0
    print(f"meses: {len(tabla)} · junio con {dias_junio} días (incompleto)")
    return tabla


def prueba_vista_y_copia(limpio: pd.DataFrame) -> dict:
    # Paso 6 · Demuestra vista frente a copia con dos asignaciones
    # Por qué: `df[condicion]["columna"] = ...` es asignación encadenada y no toca el DataFrame; creer
    #          que se limpió cuando no se limpió es el error silencioso más caro de pandas.
    # Salida esperada: "vista: original sin cambios · copia: solo cambia la copia"
    # Si falla: si el original cambia, se está asignando sobre una vista real; usa `.loc` o `.copy()`.
    original = limpio.copy()
    vista = limpio[limpio["tienda"] == "sur"]
    try:
        vista["ingresos"] = 0.0  # modifica la vista, nunca el original
    except Exception:
        pass
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            limpio[limpio["tienda"] == "sur"]["ingresos"] = 0.0  # encadenada: no debe aplicar
    except Exception:
        pass
    original_intacto = bool(limpio["ingresos"].equals(original["ingresos"]))
    copia = limpio.copy()
    copia.loc[copia["tienda"] == "sur", "ingresos"] = 0.0
    copia_solo_en_copia = bool((copia["ingresos"] != original["ingresos"]).any()) and bool(
        limpio["ingresos"].equals(original["ingresos"])
    )
    exigir(original_intacto, "la asignación encadenada modificó el DataFrame original")
    exigir(copia_solo_en_copia, "la copia no modificó solo la copia")
    print("vista: original sin cambios · copia: solo cambia la copia")
    return {"original_intacto": original_intacto, "copia_solo_en_copia": copia_solo_en_copia}


def exigir(condicion: bool, mensaje: str) -> None:
    if not condicion:
        raise RuntimeError(mensaje)


def escribir_salidas(limpio: pd.DataFrame, por_tienda: pd.DataFrame, por_mes: pd.DataFrame) -> None:
    # Paso 7 · Escribe las tablas y los recuentos que se citan en la ficha
    # Por qué: la entrega no es un notebook con prints; las tablas quedan en CSV para poder compararlas
    #          entre ejecuciones sin abrir el código.
    # Salida esperada: "escrito: data/ventas-limpio.csv, resultados/por-tienda.csv y por-mes.csv"
    # Si falla: PermissionError → algún CSV está abierto en Excel; ciérralo y repite.
    DATA.mkdir(exist_ok=True)
    RESULTADOS.mkdir(exist_ok=True)
    limpio.to_csv(DATA / "ventas-limpio.csv", index=False)
    por_tienda.to_csv(RESULTADOS / "por-tienda.csv", index=False)
    por_mes.to_csv(RESULTADOS / "por-mes.csv", index=False)


def procesar_fixture_sucio() -> dict:
    # Paso 8 · Procesa la copia declarada con nulos, duplicados y tipos malos
    # Por qué: el CSV original está limpio y no demuestra la política de nulos. La copia sucia sí, y su
    #          cuarentena queda con el motivo de cada rechazo.
    # Salida esperada: "fixture: 9 entrada · 3 válidas · 6 rechazadas"
    # Si falla: si válidas + rechazadas ≠ 9, el filtro de duplicados se está aplicando antes de tiempo.
    bruto = cargar(DATOS / "ventas-sucias.csv")
    _, rechazadas, informe = limpiar(bruto)
    DATA.mkdir(exist_ok=True)
    file_fixture = DATA / "ventas-fixture-nulo.csv"
    shutil.copyfile(DATOS / "ventas-sucias.csv", file_fixture)
    rechazadas.to_csv(DATA / "cuarentena.csv", index=False)
    return informe


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Limpieza y agregación de ventas con pandas (P36)")
    parser.add_argument("--fixture", action="store_true", help="procesa también la copia sucia declarada")
    args = parser.parse_args(argv)

    print("== P36 · pandas sin perder filas ==")
    try:
        bruto = cargar()
        limpio, _, informe = limpiar(bruto)
        exigir(informe["filas_validas"] == 180, f"el CSV limpio debería dejar 180 filas y dejó {informe['filas_validas']}")
        validar_grano(limpio)
        por_tienda = agregar_por_tienda(limpio)
        por_mes = agregar_por_mes(limpio)
        prueba_vista_y_copia(limpio)
        escribir_salidas(limpio, por_tienda, por_mes)
        print("escrito: data/ventas-limpio.csv, resultados/por-tienda.csv y por-mes.csv")
        if args.fixture:
            procesar_fixture_sucio()
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con tablas a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
