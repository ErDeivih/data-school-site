# P36 · Pandas: limpiar y agregar sin perder filas — código ejecutable

Carga el CSV de ventas, declara el grano, convierte los tipos, documenta la política de nulos y agrega por
tienda y por mes **sin perder ninguna fila**. El CSV no tiene nulos: el tratamiento se demuestra con una
copia sucia declarada y su cuarentena. Es el código que acompaña a la ficha
`../../fichas-portfolio/p36-pandas-sin-perder-filas.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas 3.0.6** (probado; cualquier versión `>=2.0` sirve). Sin red y sin servicios externos.
- La salida de tipos usa `datetime64[us]` en pandas 3; en pandas 2 verás `datetime64[ns]`. El código no
  depende de la unidad.

## Instalación

```powershell
cd proyectos/p36-pandas-sin-perder-filas/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` solo pide `pandas` (licencia BSD-3-Clause); el resto es la biblioteca estándar.

## Orden de ejecución

```powershell
python limpiar.py             # CSV limpio: carga, grano, tipos, agregados y comprobaciones
python limpiar.py --fixture   # además procesa la copia sucia y escribe la cuarentena
python verificar.py           # la puerta: 23 comprobaciones, exit 0/1
```

`limpiar.py` escribe `data/ventas-limpio.csv`, `data/cuarentena.csv` (con `--fixture`),
`resultados/por-tienda.csv` y `resultados/por-mes.csv`. `verificar.py` reconstruye las tablas desde cero y
comprueba los recuentos y los totales.

## Cómo se verifica

```powershell
python verificar.py
```

Comprueba: 180 filas y 0 nulos en el origen; tipos `datetime64`, `Int64` y `float64`; grano de 3 tiendas ×
60 días; totales 14.295 unidades y 192.292,08 €; centro con 4.892 unidades y 65.279,56 €; junio con 29
días e incompleto mientras febrero (28) está completo; el caso de vista frente a copia; el fixture sucio
con 9 filas → 3 válidas y 6 rechazadas con motivo; el sha256 del CSV original intacto; y la repetición
idempotente. Termina en `RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). La salida real está
en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/ventas-mensuales.csv`: **180 filas × 4 columnas** (`fecha`, `tienda`, `unidades`,
  `ingresos`). Una fila es un día de una tienda; 3 tiendas en rotación; 2026-01-01 a 2026-06-29, con
  junio incompleto (29 días). Copia literal de `datasets/csv/`, sintética y
  CC0-1.0.
- `datos-ejemplo/ventas-sucias.csv`: **9 filas** con los defectos declarados que el CSV original no
  tiene: dos unidades nulas o no numéricas, un ingreso nulo, una fecha imposible (`2026-02-30`), una
  tienda nula y un duplicado. No es un dataset del catálogo: es un fixture para probar la política de
  nulos y duplicados.

## Fuente real y licencia

- **No hay API**: el proyecto es local por diseño y la ficha declara `api: []`.
- Los dos CSV son sintéticos, deterministas y **CC0-1.0**. El limpio es copia de `datasets/csv/`; el sucio
  lo genera este proyecto y está declarado como fixture.
- pandas: licencia **BSD-3-Clause** (`pandas` en `requirements.txt`).

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar como texto | Leer sin que la librería adivine los tipos | `Pandas: fundamentos` |
| 2 · Limpiar contando | Tipos, nulos y rechazos sin perder filas | `Calidad de datos` |
| 3 · Grano y clave | Qué es una fila y por qué la clave es única | `Fechas y horas` |
| 4 · Agregar por tienda | `groupby` y precio medio ponderado | `Pandas: agrupaciones y joins` |
| 5 · Agregar por mes | Periodos y el mes que llega incompleto | `Series temporales en pandas` |
| 6 · Vista frente a copia | Asignación encadenada que no aplica | `Vistas y copias` |
| 7 · Fixture y cuarentena | Declarar el defecto y registrar el rechazo | `Contratos de datos` |
| 8 · Verificador | Recuentos que cuadran como contrato | `Calidad y SLAs` |

## Estructura

```text
codigo/
├── limpiar.py              # carga, limpieza, grano, agregados y prueba vista/copia
├── datos-ejemplo/          # CSV limpio (CC0-1.0) y CSV sucio declarado
├── verificar.py            # la puerta del proyecto (offline)
└── resultados/             # ejemplo-salida.txt, por-tienda.csv, por-mes.csv, comprobaciones.csv
```

## Fallos típicos

- **`ModuleNotFoundError: pandas`**: instala con el mismo Python que ejecuta el script,
  `python -m pip install -r requirements.txt`.
- **`FileNotFoundError`**: se ejecuta desde otra carpeta; `limpiar.py` resuelve las rutas desde su propio
  directorio, así que comprueba que el ZIP se descomprimió completo.
- **Todo se vuelve nulo al convertir**: el CSV usa coma decimal o un formato de fecha distinto; el código
  exige `YYYY-MM-DD` y punto decimal, y las filas que no encajan se rechazan con motivo.
- **El recuento baja de 180**: hay un `dropna()` escondido; la política del proyecto es separar, no borrar
  sin contar.
- **La asignación encadenada no cambia nada**: es lo esperado; usa `.loc` sobre una copia cuando quieras
  modificar de verdad.
- **Junio parece un mes malo**: tiene 29 días porque la serie acaba el 2026-06-29; la tabla lo marca con
  `incompleto=True` en vez de compararlo con enero.
