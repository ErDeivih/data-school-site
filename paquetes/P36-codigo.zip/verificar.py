#!/usr/bin/env python3
"""Puerta del proyecto P36 (pandas sin perder filas).

Ejecuta la carga, la limpieza, la agregación y la prueba de la copia sucia sobre los datos de ejemplo y
comprueba el resultado de verdad: grano, tipos, recuentos, totales al céntimo, junio incompleto y
cuarentena con motivo. No usa red.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla
"""
from __future__ import annotations

import csv
import hashlib
import sys

import pandas as pd

import limpiar

fallos: list[str] = []
comprobaciones = 0
registros: list[tuple[str, str]] = []


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    registros.append((mensaje, "OK" if condicion else "FALLO"))
    if not condicion:
        fallos.append(mensaje)
    return condicion


def sha256(ruta) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def main() -> int:
    print("== Puerta del proyecto P36 · pandas sin perder filas ==")

    # Paso 1 · Comprueba el origen antes de limpiar nada
    # Por qué: si el CSV de ejemplo no tiene las 180 filas y los 0 nulos que promete el README, cualquier
    #          recuento posterior mide otra cosa.
    # Salida esperada: "origen: 180 filas × 4 columnas, 0 nulos y 180 fechas únicas".
    # Si falla: falta el CSV o se ha copiado mal; el ZIP trae la copia literal de datasets/csv/.
    csv_origen = limpiar.DATOS / "ventas-mensuales.csv"
    hash_antes = sha256(csv_origen)
    bruto = limpiar.cargar()
    ok(len(bruto) == 180 and list(bruto.columns) == limpiar.COLUMNAS,
       f"origen: {len(bruto)} filas × {len(bruto.columns)} columnas")
    ok(int(bruto.isna().sum().sum()) == 0, "origen: 0 nulos en las 4 columnas")
    ok(bruto["fecha"].nunique() == 180 and bruto["fecha"].is_unique, "origen: 180 fechas únicas")

    # Paso 2 · Limpia y comprueba tipos y recuentos
    # Por qué: la política es no perder filas; la tabla limpia tiene que conservar las 180 y dejar cada
    #          columna en su tipo, o la agregación siguiente sumaría texto.
    # Salida esperada: "limpieza: 180 → 180 filas, fecha datetime, unidades Int64 y 0 rechazos".
    # Si falla: alguna conversión devuelve nulos → mira el informe de motivos.
    limpio, rechazadas, informe = limpiar.limpiar(bruto)
    ok((informe["filas_entrada"], informe["filas_validas"], informe["filas_rechazadas"]) == (180, 180, 0),
       f"limpieza: {informe['filas_entrada']} -> {informe['filas_validas']} filas, {informe['filas_rechazadas']} rechazos")
    ok(str(limpio["fecha"].dtype).startswith("datetime64"), f"tipo fecha: {limpio['fecha'].dtype}")
    ok(str(limpio["unidades"].dtype) == "Int64", f"tipo unidades: {limpio['unidades'].dtype}")
    ok(str(limpio["ingresos"].dtype) == "float64", f"tipo ingresos: {limpio['ingresos'].dtype}")

    # Paso 3 · Comprueba el grano
    # Por qué: una fila es un día de una tienda; si la clave se repite, la suma por tienda cuenta dos veces.
    # Salida esperada: "grano: 180 días, 3 tiendas y 60 filas por tienda".
    # Si falla: `clave_unica` es False → hay duplicados que no se fueron a cuarentena.
    grano = limpiar.validar_grano(limpio)
    ok(grano["dias_unicos"] == 180 and grano["filas_por_tienda"] == {"centro": 60, "norte": 60, "sur": 60},
       f"grano: {grano['dias_unicos']} días y {grano['filas_por_tienda']}")

    # Paso 4 · Agrega por tienda y comprueba los totales al céntimo
    # Por qué: el criterio de la ficha es que la tabla agregada cuadre con el origen; un céntimo de
    #          diferencia ya es un fallo, no un redondeo aceptable.
    # Salida esperada: "por tienda: 3 filas, 14.295 unidades y 192.292,08 €".
    # Si falla: el total no cuadra → alguna tienda se filtró o se sumó dos veces.
    por_tienda = limpiar.agregar_por_tienda(limpio)
    ok(len(por_tienda) == 3, f"por tienda: {len(por_tienda)} filas")
    ok(int(por_tienda["unidades"].sum()) == 14295, f"unidades totales: {int(por_tienda['unidades'].sum())}")
    ok(abs(float(por_tienda["ingresos"].sum()) - 192292.08) < 0.005,
       f"ingresos totales: {float(por_tienda['ingresos'].sum()):.2f} EUR")
    centro = por_tienda[por_tienda["tienda"] == "centro"].iloc[0]
    ok(int(centro["unidades"]) == 4892 and abs(float(centro["ingresos"]) - 65279.56) < 0.005,
       f"centro: {int(centro['unidades'])} unidades y {float(centro['ingresos']):.2f} EUR")

    # Paso 5 · Agrega por mes y comprueba que junio está incompleto
    # Por qué: el dataset se llama «mensuales» pero es diario; junio llega al día 29 y compararlo con un
    #          mes completo es un error de calendario, no de pandas.
    # Salida esperada: "meses: 6 · junio 29 días e incompleto · febrero 28 días y completo".
    # Si falla: `incompleto` marca febrero → la regla mira el máximo en vez de los días del mes.
    por_mes = limpiar.agregar_por_mes(limpio)
    ok(len(por_mes) == 6, f"meses: {len(por_mes)}")
    junio = por_mes[por_mes["mes"] == "2026-06"].iloc[0]
    febrero = por_mes[por_mes["mes"] == "2026-02"].iloc[0]
    ok(int(junio["dias"]) == 29 and bool(junio["incompleto"]),
       f"junio: {int(junio['dias'])} días, incompleto={bool(junio['incompleto'])}")
    ok(int(febrero["dias"]) == 28 and not bool(febrero["incompleto"]),
       f"febrero: {int(febrero['dias'])} días, incompleto={bool(febrero['incompleto'])}")

    # Paso 6 · Demuestra que una vista no modifica el original y una copia sí
    # Por qué: la asignación encadenada es el error silencioso más caro; el verificador ejecuta el caso y
    #          comprueba el DataFrame, no la intención del comentario.
    # Salida esperada: "vista y copia: original intacto y copia modificada".
    # Si falla: el original cambia → se está asignando sobre una vista real.
    demo = limpiar.prueba_vista_y_copia(limpio)
    ok(demo["original_intacto"] and demo["copia_solo_en_copia"],
       f"vista y copia: original intacto={demo['original_intacto']}, copia modificada={demo['copia_solo_en_copia']}")

    # Paso 7 · Procesa la copia sucia declarada y cuenta los rechazos
    # Por qué: el CSV original no tiene nulos y no demuestra la política; la copia sucia sí, y cada fila
    #          rechazada tiene que estar en cuarentena con su motivo.
    # Salida esperada: "fixture sucio: 9 entrada → 3 válidas y 6 rechazadas con motivo".
    # Si falla: válidas + rechazadas ≠ 9 → el filtro de duplicados se aplica antes de separar motivos.
    bruto_sucio = limpiar.cargar(limpiar.DATOS / "ventas-sucias.csv")
    validas_sucio, rechazadas_sucio, info_sucio = limpiar.limpiar(bruto_sucio)
    ok((info_sucio["filas_entrada"], info_sucio["filas_validas"], info_sucio["filas_rechazadas"]) == (9, 3, 6),
       f"fixture sucio: {info_sucio['filas_entrada']} -> {info_sucio['filas_validas']} válidas y {info_sucio['filas_rechazadas']} rechazadas")
    ok(int(validas_sucio["unidades"].sum()) == 212 and abs(float(validas_sucio["ingresos"].sum()) - 2907.00) < 0.005,
       f"fixture sucio válido: {int(validas_sucio['unidades'].sum())} unidades y {float(validas_sucio['ingresos'].sum()):.2f} EUR")
    motivos = info_sucio["motivos"]
    ok(motivos.get("unidades_nulas_o_no_numericas") == 2 and motivos.get("duplicado") == 1
       and motivos.get("fecha_invalida") == 1 and motivos.get("tienda_nula") == 1,
       f"fixture sucio: motivos {motivos}")

    # Paso 8 · Comprueba que el CSV original no se ha tocado
    # Por qué: la copia sucia es el banco de pruebas; si el original cambiara, el ejercicio dejaría de ser
    #          reproducible y la puerta mentiría.
    # Salida esperada: "el CSV original conserva su sha256".
    # Si falla: el fixture se escribió sobre el original → vuelve a copiarlo de datasets/csv/.
    ok(sha256(csv_origen) == hash_antes, "el CSV original conserva su sha256")

    # Paso 9 · Escribe las salidas y las comprueba como ficheros
    # Por qué: la entrega son tablas reproducibles, no prints; se verifica el recuento de los CSV escritos.
    # Salida esperada: "salidas: ventas-limpio 180 filas, por-tienda 3 filas y cuarentena 6 filas".
    # Si falla: falta una carpeta data/ o resultados/ → el proyecto no se ejecutó desde codigo/.
    limpiar.escribir_salidas(limpio, por_tienda, por_mes)
    limpiar.procesar_fixture_sucio()
    filas_limpias = len(pd.read_csv(limpiar.DATA / "ventas-limpio.csv"))
    filas_tienda = len(pd.read_csv(limpiar.RESULTADOS / "por-tienda.csv"))
    filas_cuarentena = len(pd.read_csv(limpiar.DATA / "cuarentena.csv"))
    ok((filas_limpias, filas_tienda, filas_cuarentena) == (180, 3, 6),
       f"salidas: ventas-limpio {filas_limpias} filas, por-tienda {filas_tienda} y cuarentena {filas_cuarentena}")

    # Paso 10 · Repite la limpieza y comprueba idempotencia
    # Por qué: reejecutar no puede cambiar el recuento ni los totales; si cambia, hay estado escondido.
    # Salida esperada: "repetición: mismas 180 filas y mismo total".
    # Si falla: la segunda carga concatena en vez de reconstruir.
    limpio2, _, informe2 = limpiar.limpiar(limpiar.cargar())
    ok(len(limpio2) == 180 and limpio.equals(limpio2) and informe2["filas_validas"] == 180,
       "repetición: mismas 180 filas y mismo total")

    # Paso 11 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red; una URL en el código de limpieza rompería esa promesa.
    # Salida esperada: "limpiar.py no hace peticiones de red".
    # Si falla: aparece un http(s) en el código → quítalo antes de empaquetar.
    codigo = (limpiar.RAIZ / "limpiar.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo, "limpiar.py no hace peticiones de red")

    # Deja el registro de comprobaciones que pide la ficha
    with (limpiar.RESULTADOS / "comprobaciones.csv").open("w", newline="", encoding="utf-8") as fichero:
        escritor = csv.writer(fichero)
        escritor.writerow(["comprobacion", "resultado"])
        escritor.writerows(registros)

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
