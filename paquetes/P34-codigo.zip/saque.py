"""P34 · Tenis: el saque y los puntos que deciden.

Mide el punto de saque desde los puntos jugados: tasa global, por sacador y por superficie, además de los
tipos de punto y la duración de los intercambios. Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import statistics
import sys as _sys
from collections import Counter, defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("partido", "superficie", "set", "juego", "sacador", "tipo", "duracion_intercambio_s", "gano")
SUPERFICIES = ("dura", "tierra", "hierba")
SACADORES = ("A", "B")
GANADORES = ("sacador", "resto")
PUNTOS_POR_PARTIDO = 60


def validar_fila(fila: dict, numero: int) -> None:
    # Paso 1 · Contrato de una fila: superficies, sacador, ganador y duración positiva.
    # Por qué: una categoría nueva o una duración negativa rompe cualquier tasa sin avisar.
    # Salida esperada: las 600 filas del catálogo pasan.
    # Si falla: dice la fila y la regla incumplida.
    if fila["superficie"] not in SUPERFICIES:
        raise ValueError(f"fila {numero}: superficie desconocida {fila['superficie']}")
    if fila["sacador"] not in SACADORES:
        raise ValueError(f"fila {numero}: sacador desconocido {fila['sacador']}")
    if fila["gano"] not in GANADORES:
        raise ValueError(f"fila {numero}: ganador desconocido {fila['gano']}")
    if float(fila["duracion_intercambio_s"]) <= 0:
        raise ValueError(f"fila {numero}: duración no positiva")


def leer(ruta: Path) -> list[dict]:
    # Paso 2 · Leer y comprobar el grano: 10 partidos de 60 puntos.
    # Por qué: comparar superficies con distinto número de puntos exige declarar el recuento.
    # Salida esperada: 600 filas, 10 partidos y 60 puntos por partido.
    # Si falla: «columnas inesperadas» o «partido incompleto».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if not filas:
        raise ValueError("el CSV está vacío")
    for i, fila in enumerate(filas, start=2):
        validar_fila(fila, i)
    por_partido = Counter(f["partido"] for f in filas)
    if len(por_partido) != 10 or any(n != PUNTOS_POR_PARTIDO for n in por_partido.values()):
        raise ValueError(f"se esperaban 10 partidos de {PUNTOS_POR_PARTIDO} puntos")
    return filas


def resumen(filas: list[dict]) -> dict:
    # Paso 3 · Calcular la tasa de punto de saque global y por sacador.
    # Por qué: el saque es la ventaja estructural del tenis; sin separar A y B se esconde.
    # Salida esperada: 58,17 % global, A 54,33 % y B 62,00 %.
    # Si falla: la columna gano no es «sacador/resto».
    total = len(filas)
    saque = sum(1 for f in filas if f["gano"] == "sacador")
    por_sacador = {}
    for s in SACADORES:
        puntos = [f for f in filas if f["sacador"] == s]
        por_sacador[s] = (len(puntos), sum(1 for f in puntos if f["gano"] == "sacador"))
    return {"total": total, "saque": saque, "por_sacador": por_sacador}


def por_superficie(filas: list[dict]) -> dict:
    # Paso 4 · Comparar la tasa de saque por superficie.
    # Por qué: hierba, tierra y dura no se comportan igual; mezclarlas borra la diferencia.
    # Salida esperada: dura 60,83 %, tierra 55,56 %, hierba 57,22 %.
    # Si falla: hay una superficie fuera del contrato.
    salida = {}
    for sup in SUPERFICIES:
        puntos = [f for f in filas if f["superficie"] == sup]
        salida[sup] = (len(puntos), sum(1 for f in puntos if f["gano"] == "sacador"))
    return salida


def tipos(filas: list[dict]) -> Counter:
    # Paso 5 · Contar tipos de punto: aces, dobles faltas, winners, errores e intercambios largos.
    # Por qué: el tipo explica el «por qué» de una tasa; solo la tasa no enseña nada.
    # Salida esperada: 48 aces, 22 dobles faltas, 189 winners, 157 errores y 184 intercambios largos.
    # Si falla: aparece un tipo nuevo sin declarar.
    return Counter(f["tipo"] for f in filas)


def duracion(filas: list[dict]) -> dict:
    # Paso 6 · Resumir la duración de los intercambios con media y mediana.
    # Por qué: la media se va con los puntos largos; la mediana dice cómo es un punto típico.
    # Salida esperada: media 7,787 s y mediana 7,2 s.
    # Si falla: hay duraciones no numéricas o no positivas.
    valores = [float(f["duracion_intercambio_s"]) for f in filas]
    return {"media": round(statistics.mean(valores), 5), "mediana": statistics.median(valores)}


def main() -> int:
    # Paso 7 · Publicar el resumen y declarar el límite de la muestra.
    # Por qué: 600 puntos sintéticos no describen el tenis real; el informe no puede extrapolar.
    # Salida esperada: tasas por sacador y superficie, recuento de tipos y duración.
    # Si falla: revisa --csv o si el fichero es el del catálogo.
    parser = argparse.ArgumentParser(description="El saque y los puntos que deciden (P34)")
    parser.add_argument("--csv", default="datos-ejemplo/tenis-puntos.csv")
    args = parser.parse_args()
    filas = leer(Path(args.csv))
    r = resumen(filas)
    print(f"puntos: {r['total']} · saque gana {r['saque']} ({r['saque']/r['total']:.2%})")
    for s, (n, gana) in r["por_sacador"].items():
        print(f"sacador {s}: {gana}/{n} ({gana/n:.2%})")
    for sup, (n, gana) in por_superficie(filas).items():
        print(f"superficie {sup}: {gana}/{n} ({gana/n:.2%})")
    print("tipos: " + " · ".join(f"{t} {n}" for t, n in sorted(tipos(filas).items())))
    d = duracion(filas)
    print(f"duración del intercambio: media {d['media']:.3f} s · mediana {d['mediana']:.1f} s")
    print("límite: 600 puntos sintéticos de 10 partidos; no describe el circuito real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
