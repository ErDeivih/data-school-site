#!/usr/bin/env python3
"""Puerta del proyecto P34 (saque y puntos que deciden).

Comprueba contrato, grano, tasa de saque global y por sacador, por superficie, tipos y duración.
Sin escribir en disco. VERDE (0) o ROJO (1).
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import saque

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "tenis-puntos.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = saque.leer(CSV)
    ok(len(filas) == 600, "el CSV tiene 600 puntos")
    ok(len({f["partido"] for f in filas}) == 10, "hay 10 partidos")
    ok(all(n == 60 for n in {p: sum(1 for f in filas if f["partido"] == p) for p in {f["partido"] for f in filas}}.values()),
       "cada partido tiene 60 puntos")

    r = saque.resumen(filas)
    ok(r["total"] == 600, "el resumen cubre los 600 puntos")
    ok(r["saque"] == 349, "el saque gana 349 puntos")
    ok(round(r["saque"] / r["total"], 5) == 0.58167, "la tasa de saque global es 58,167 %")
    ok(r["por_sacador"]["A"] == (300, 163), "el sacador A gana 163 de 300")
    ok(r["por_sacador"]["B"] == (300, 186), "el sacador B gana 186 de 300")
    ok(round(163 / 300, 5) == 0.54333, "la tasa del sacador A es 54,333 %")
    ok(round(186 / 300, 5) == 0.62, "la tasa del sacador B es 62,000 %")

    sup = saque.por_superficie(filas)
    ok(sup["dura"] == (240, 146), "dura: 146 de 240")
    ok(round(146 / 240, 5) == 0.60833, "la tasa en dura es 60,833 %")
    ok(sup["tierra"] == (180, 100), "tierra: 100 de 180")
    ok(sup["hierba"] == (180, 103), "hierba: 103 de 180")

    t = saque.tipos(filas)
    ok(t["ace"] == 48, "hay 48 aces")
    ok(t["doble falta"] == 22, "hay 22 dobles faltas")
    ok(t["winner"] == 189, "hay 189 winners")
    ok(t["error no forzado"] == 157, "hay 157 errores no forzados")
    ok(t["intercambio largo"] == 184, "hay 184 intercambios largos")
    ok(sum(t.values()) == 600, "los tipos suman los 600 puntos")

    d = saque.duracion(filas)
    ok(d["media"] == 7.78717, "la duración media es 7,787 s")
    ok(d["mediana"] == 7.2, "la duración mediana es 7,2 s")

    malas = [
        {"partido": "M01", "superficie": "moqueta", "set": "1", "juego": "1", "sacador": "A", "tipo": "ace", "duracion_intercambio_s": "5", "gano": "sacador"},
        {"partido": "M01", "superficie": "dura", "set": "1", "juego": "1", "sacador": "A", "tipo": "ace", "duracion_intercambio_s": "5", "gano": "empate"},
        {"partido": "M01", "superficie": "dura", "set": "1", "juego": "1", "sacador": "A", "tipo": "ace", "duracion_intercambio_s": "-1", "gano": "sacador"},
    ]
    for i, fila in enumerate(malas, start=1):
        try:
            saque.validar_fila(fila, i)
            ok(False, f"el contrato debería rechazar la fila mala {i}")
        except ValueError:
            ok(True, f"el contrato rechaza la fila mala {i}")

    codigo = (AQUI / "saque.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
