# P34 · Tenis: el saque y los puntos que deciden

Paquete descargable de **Data School** para el proyecto P34. Incluye los puntos de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python saque.py
python verificar.py
```

`saque.py` imprime la tasa de punto de saque global y por sacador, la compara por superficie, cuenta los
tipos de punto y resume la duración de los intercambios. `verificar.py` sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/tenis-puntos.csv`: **600 puntos × 8 columnas** (10 partidos de 60 puntos, tres
  superficies, sacador A/B, tipo de punto y duración). Sintético y **CC0-1.0**; es el `tenis-puntos`
  del catálogo de Data School.

## Salida esperada

```text
puntos: 600 · saque gana 349 (58.17%)
sacador A: 163/300 (54.33%)
sacador B: 186/300 (62.00%)
superficie dura: 146/240 (60.83%)
superficie tierra: 100/180 (55.56%)
superficie hierba: 103/180 (57.22%)
tipos: ace 48 · doble falta 22 · error no forzado 157 · intercambio largo 184 · winner 189
duración del intercambio: media 7.787 s · mediana 7.2 s
límite: 600 puntos sintéticos de 10 partidos; no describe el circuito real.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Contrato de fila | `validar_fila` comprueba superficie, sacador, ganador y duración | validación de datos |
| 2 · Grano | `leer` exige 10 partidos de 60 puntos | tablas y grano |
| 3 · Tasa de saque | `resumen` separa A y B | proporciones y tasas |
| 4 · Superficie | `por_superficie` compara dura, tierra y hierba | análisis por segmentos |
| 5 · Tipos de punto | `tipos` cuenta aces, dobles faltas, winners, errores e intercambios | distribuciones |
| 6 · Duración | `duracion` usa media y mediana | medidas de centralidad |
| 7 · Publicar | `main` resume y declara el límite | comunicación de resultados |

## Fallos típicos

- **`superficie desconocida`**: una categoría nueva (`moqueta`, `indoor`) sin declararla en el contrato.
- **`partido incompleto`**: un partido con más o menos de 60 puntos; las tasas dejarían de ser comparables.
- **Media de duración sin mediana**: los intercambios largos arrastran la media; se dan las dos.
- **Comparar tasas de saque entre superficies sin contar los puntos**: 60 puntos por partido es el mínimo
  para que la comparación tenga sentido.

## Límite

Son 600 puntos sintéticos de 10 partidos. Sirven para aprender a medir el saque, no para describir el
circuito ni predecir partidos.
