# P42 · Ingesta incremental idempotente — código ejecutable

Ingesta por lotes de una temporada de F1: guarda el **bruto inmutable** con fecha y `sha256`, tipa y valida
el esquema, deduplica por la clave `(carrera, piloto)` y usa una **marca de agua** con las carreras ya
cargadas, para que una carrera atrasada entre igual y no se relea lo anterior. Los lotes que rompen el
esquema van a **cuarentena** y un **429** se reintenta con espera declarada. Es el código que acompaña a
la ficha
`../../fichas-portfolio/p42-ingesta-incremental.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **requests 2.34.2** (probado; `>=2.28` sirve). Solo se usa en el modo con red de OpenF1; la ingesta, la
  verificación y los datos de ejemplo no necesitan red.
- No hay claves: OpenF1 y Jolpica son APIs públicas sin token.

## Instalación

```powershell
cd proyectos/p42-ingesta-incremental/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide `requests` (licencia Apache-2.0). El resto es la biblioteca estándar.

## Orden de ejecución

```powershell
python ingerir.py --reiniciar        # deja data/ y resultados/ como recién descargado
python ingerir.py                    # primera ingesta del snapshot: 400 filas nuevas
python ingerir.py --repetir          # repite y deja resultados/repeticion.json (0 nuevas)
python ingerir.py --simular-429      # ensayo de reintentos: 3 intentos, esperas [1, 2]
python ingerir.py --payload-roto     # ensayo de esquema roto: 1 entrada en cuarentena
python ingerir.py --carreras r01,r03 # prueba de huecos: solo esas carreras
python ingerir.py --openf1           # resumen de la fuente real con las respuestas grabadas
python ingerir.py --openf1 --con-red # lo mismo contra https://api.openf1.org/v1/
```

Las rutas de ejemplo llevan `r01`–`r20`, 20 pilotos y 20 filas por carrera. `--lote N` cambia el tamaño
de página (5 por defecto).

## Cómo se verifica

```powershell
python verificar.py
```

La puerta ejecuta, en carpetas temporales, la primera carga, la repetición, la marca de agua con huecos, el
429 y los dos casos de cuarentena; comprueba 400 filas y clave única, bruto con 20 entradas y `sha256`,
0 filas nuevas en la segunda pasada, lotes atrasados que entran una vez, el registro del 429 y que
`requests.get` no se llama nunca. Termina en `RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1).
La salida real está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/f1-clasificacion.csv`: **400 filas × 12 columnas** (`carrera`, `piloto`, `equipo`,
  `posicion_quali`, `vuelta_quali_s`, `sector1_s`, `sector2_s`, `sector3_s`, `compuesto`, `temperatura_c`,
  `posicion_final`, `puntos`). 20 carreras × 20 pilotos; clave `(carrera, piloto)` única. Copia literal de
  `datasets/csv/`, sintética y CC0-1.0.
- `datos-ejemplo/openf1-sessions.json`, `openf1-drivers.json`, `openf1-position.json`: **tres respuestas
  reales de OpenF1** capturadas el **2026-11-06** para la sesión `9472` (Race de Bahréin 2024): una
  sesión, 20 pilotos y las posiciones del líder. Sirven para documentar la forma de la fuente y ejecutar
  el resumen sin red.
- El snapshot se trata como **la forma del payload**, no como si lo hubiera devuelto OpenF1: el bruto de
  cada carrera es el lote recibido en esa forma.

## Fuente real y licencia

- **OpenF1** — <https://api.openf1.org/v1/>. Sin clave. Uso educativo, aprendizaje personal, investigación
  y afición no comercial; OpenF1 declara no reclamar la propiedad de los datos, marcas ni retransmisiones
  de F1. Se usa para sesiones, pilotos y posiciones.
- **Jolpica F1 (Ergast)** — <https://api.jolpi.ca/ergast/f1/>. Sin clave. Datos bajo **CC BY-NC-SA 4.0**
  (uso no comercial, atribución y compartir igual); el código del proyecto es Apache-2.0. Es la vía
  natural para los resultados de clasificación con paginación (`limit`/`offset`); esta entrega usa OpenF1
  para la fuente de sesiones y el snapshot para la forma del hecho.
- `requests`: licencia Apache-2.0 (`requests` en `requirements.txt`). Ninguna clave en el repositorio.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Snapshot como texto | Bruto frente a tipado; la forma del payload | `ETL frente a ELT` |
| 2 · Lotes por carrera | La carrera como unidad de ingesta | `Arquitectura medallion` |
| 3 · Páginas y bruto | Recorrer por páginas y guardar evidencia con hash | `Arquitectura medallion` |
| 4 · Esquema y tipos | Contrato de columnas y rechazo con motivo | `Contratos de datos` |
| 5 · 429 y reintentos | Espera declarada, máximo de intentos | `Idempotencia y reintentos` |
| 6 · Dedupe y marca de agua | Clave de idempotencia y huecos | `Ingesta incremental y CDC` |
| 7 · Cuarentena | No corregir a ciegas: guardar el original | `Calidad y SLAs` |
| 8 · Verificador | Recuentos y contrato como puerta | `Registro de esquemas` |

## Estructura

```text
codigo/
├── ingerir.py              # lotes, bruto, estado, 429, OpenF1 y CLI
├── staging.py              # contrato: columnas, tipos y validación de filas
├── cuarentena.py           # registro de rechazos y payload original
├── datos-ejemplo/          # snapshot 400×12 (CC0-1.0) y 3 capturas de OpenF1
├── verificar.py            # la puerta del proyecto (offline)
└── resultados/             # ejemplo-salida.txt y los JSON de cada ensayo (generados)
```

## Fallos típicos

- **`ModuleNotFoundError: requests`**: instala con el mismo Python que ejecuta el script,
  `python -m pip install -r requirements.txt`.
- **La segunda ejecución mete 400 filas nuevas**: no se cargó `data/estado.json` o la marca de agua no se
  guarda tras la primera pasada.
- **Una carrera atrasada se descarta**: la marca de agua es «la última carrera»; este proyecto usa el
  conjunto de carreras cargadas precisamente para evitarlo.
- **El 429 se reintenta sin esperar**: la espera sale de `Retry-After` o del backoff declarado; el
  registro de `resultados/429.json` debe enseñar los intentos y sus esperas.
- **El bruto cambia entre ejecuciones**: el nombre del fichero lleva `sha256`; si se sobrescribe, se
  pierde la evidencia y el manifiesto miente.
- **Cuarentena sin payload**: guardar solo el motivo impide reprocesar; el fichero
  `data/cuarentena/<carrera>-NN.json` conserva el lote recibido.
- **Mezclar CSV y API**: el CSV es la forma del payload, no una descarga de OpenF1; decirlo al revés se
  nota en el bruto.
