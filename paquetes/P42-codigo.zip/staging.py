#!/usr/bin/env python3
"""Esquema, tipado y validación de una tabla de clasificación de F1 (P42).

La forma del payload es la del snapshot `f1-clasificacion`: 12 columnas y clave `(carrera, piloto)`.
Aquí se decide qué entra en staging y qué va a cuarentena; no se escribe ningún fichero.
"""
from __future__ import annotations

import math

COLUMNAS = [
    "carrera",
    "piloto",
    "equipo",
    "posicion_quali",
    "vuelta_quali_s",
    "sector1_s",
    "sector2_s",
    "sector3_s",
    "compuesto",
    "temperatura_c",
    "posicion_final",
    "puntos",
]
CLAVE = ("carrera", "piloto")
TEXTOS_OBLIGATORIOS = ["carrera", "piloto", "equipo", "compuesto"]
ENTEROS = {"posicion_quali": (1, 20), "posicion_final": (1, 20), "puntos": (0, 25)}
DECIMALES = {
    "vuelta_quali_s": (50.0, 200.0),
    "sector1_s": (10.0, 100.0),
    "sector2_s": (10.0, 100.0),
    "sector3_s": (10.0, 100.0),
    "temperatura_c": (0.0, 60.0),
}
COMPUESTOS_VALIDOS = {"blando", "medio", "duro", "intermedio", "lluvia"}


def validar_esquema(columnas_recibidas) -> list[str]:
    """Devuelve las columnas del contrato que faltan en el payload; [] si el esquema está completo."""
    recibidas = {str(columna).strip() for columna in columnas_recibidas}
    return [columna for columna in COLUMNAS if columna not in recibidas]


def _texto(fila: dict, columna: str) -> str | None:
    valor = fila.get(columna)
    if valor is None or (isinstance(valor, float) and math.isnan(valor)):
        return None
    texto = str(valor).strip()
    return texto or None


def _entero(bruto: str) -> int:
    try:
        return int(bruto)
    except ValueError:
        numero = float(bruto)
        if not numero.is_integer():
            raise
        return int(numero)


def validar_fila(fila: dict) -> tuple[dict | None, list[str]]:
    """Tipa una fila cruda y devuelve (fila_tipada, motivos). Si hay motivos, la fila no entra."""
    motivos: list[str] = []
    tipada: dict = {}

    for columna in TEXTOS_OBLIGATORIOS:
        valor = _texto(fila, columna)
        if valor is None:
            motivos.append(f"{columna}_obligatorio")
        else:
            tipada[columna] = valor

    for columna, (minimo, maximo) in ENTEROS.items():
        bruto = _texto(fila, columna)
        if bruto is None:
            motivos.append(f"{columna}_nulo")
            continue
        try:
            numero = _entero(bruto)
        except (TypeError, ValueError):
            motivos.append(f"{columna}_no_entero")
            continue
        if not minimo <= numero <= maximo:
            motivos.append(f"{columna}_fuera_de_rango")
            continue
        tipada[columna] = numero

    for columna, (minimo, maximo) in DECIMALES.items():
        bruto = _texto(fila, columna)
        if bruto is None:
            motivos.append(f"{columna}_nulo")
            continue
        try:
            numero = float(bruto)
        except (TypeError, ValueError):
            motivos.append(f"{columna}_no_numerico")
            continue
        if not math.isfinite(numero) or not minimo <= numero <= maximo:
            motivos.append(f"{columna}_fuera_de_rango")
            continue
        tipada[columna] = numero

    if tipada.get("compuesto") and tipada["compuesto"] not in COMPUESTOS_VALIDOS:
        motivos.append("compuesto_desconocido")

    return (None, motivos) if motivos else (tipada, [])


def validar_lote(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    """Valida un lote completo y devuelve (filas tipadas, rechazos con su motivo y la fila original)."""
    validas: list[dict] = []
    rechazos: list[dict] = []
    vistas: set[tuple[str, str]] = set()
    for indice, fila in enumerate(filas):
        tipada, motivos = validar_fila(fila)
        if motivos:
            rechazos.append({"indice": indice, "fila": fila, "motivos": motivos})
            continue
        clave = (tipada["carrera"], tipada["piloto"])
        if clave in vistas:
            rechazos.append({"indice": indice, "fila": fila, "motivos": ["clave_duplicada_en_lote"]})
            continue
        vistas.add(clave)
        validas.append(tipada)
    return validas, rechazos


def formatear(tipada: dict) -> dict:
    """Devuelve la fila con el formato del CSV de salida (12 columnas en el orden del contrato)."""
    return {
        "carrera": tipada["carrera"],
        "piloto": tipada["piloto"],
        "equipo": tipada["equipo"],
        "posicion_quali": str(tipada["posicion_quali"]),
        "vuelta_quali_s": f"{tipada['vuelta_quali_s']:.3f}",
        "sector1_s": f"{tipada['sector1_s']:.3f}",
        "sector2_s": f"{tipada['sector2_s']:.3f}",
        "sector3_s": f"{tipada['sector3_s']:.3f}",
        "compuesto": tipada["compuesto"],
        "temperatura_c": f"{tipada['temperatura_c']:.1f}",
        "posicion_final": str(tipada["posicion_final"]),
        "puntos": str(tipada["puntos"]),
    }
