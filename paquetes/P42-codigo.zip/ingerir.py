#!/usr/bin/env python3
"""P42 · Ingesta incremental idempotente de una temporada de F1.

El snapshot `datos-ejemplo/f1-clasificacion.csv` tiene la forma del payload: 400 filas, 12 columnas y
clave `(carrera, piloto)`. La ingesta guarda el bruto inmutable, valida el esquema, deduplica por clave y
usa una marca de agua con las carreras ya cargadas (admite carreras atrasadas). Los fallos van a
cuarentena y un 429 se reintenta con espera declarada.

Uso:
    python ingerir.py --reiniciar           # deja data/ y resultados/ como recién descargado
    python ingerir.py                      # ingesta completa del snapshot
    python ingerir.py --repetir             # ingesta, repite y deja resultados/repeticion.json
    python ingerir.py --simular-429          # ensayo de reintentos con 429 grabado
    python ingerir.py --payload-roto         # manda a cuarentena un payload sin una columna
    python ingerir.py --carreras r01,r03     # solo esas carreras (prueba de huecos)
    python ingerir.py --openf1               # resumen de la fuente real con las respuestas grabadas
    python ingerir.py --openf1 --con-red     # lo mismo contra la API de OpenF1
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

import requests

import cuarentena
import staging

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
DATA = RAIZ / "data"
RESULTADOS = RAIZ / "resultados"
FECHA_CAPTURA = "2026-11-06"
MAX_INTENTOS = 3
BASE_OPENF1 = "https://api.openf1.org/v1"


class ErrorLimite(RuntimeError):
    """Error que pide esperar antes de repetir (429 o límite secundario)."""

    def __init__(self, estado: int, retry_after: int | None = None) -> None:
        super().__init__(f"límite de la fuente ({estado})")
        self.estado = estado
        self.retry_after = retry_after


def reintentar(descargar, dormir=time.sleep, max_intentos: int = MAX_INTENTOS) -> tuple[object | None, dict]:
    # Paso 5 · Reintenta con espera declarada y como mucho `max_intentos`
    # Por qué: tras un 429, tres llamadas seguidas agravan el bloqueo; la espera crece y el máximo se
    #          declara. Cada intento queda registrado para poder auditar el ensayo.
    # Salida esperada: "intentos: 3 · esperas [1, 2] · exito True" con una fuente que falla dos veces.
    # Si falla: si se repite sin dormir, el 429 se convierte en bloqueo largo y el registro lo delata.
    registro = {"intentos": [], "exito": False, "esperas": []}
    for numero in range(1, max_intentos + 1):
        try:
            payload = descargar()
        except ErrorLimite as error:
            espera = error.retry_after if error.retry_after is not None else 2 ** (numero - 1)
            registro["intentos"].append({"intento": numero, "resultado": f"error_{error.estado}", "espera": espera})
            if numero == max_intentos:
                break
            registro["esperas"].append(espera)
            dormir(espera)
            continue
        registro["intentos"].append({"intento": numero, "resultado": "ok", "espera": 0})
        registro["exito"] = True
        return payload, registro
    return None, registro


def cargar_snapshot(ruta: Path | None = None) -> tuple[list[dict], list[str]]:
    # Paso 1 · Lee el snapshot como texto, sin tipar todavía
    # Por qué: el bruto se guarda tal cual y el tipado se decide en staging; leer con tipos escondería
    #          los valores que no encajan antes de poder mandarlos a cuarentena.
    # Salida esperada: "snapshot: 400 filas · 20 carreras · 12 columnas"
    # Si falla: FileNotFoundError → falta datos-ejemplo/f1-clasificacion.csv.
    ruta = ruta or DATOS / "f1-clasificacion.csv"
    with ruta.open(newline="", encoding="utf-8") as fichero:
        lector = csv.DictReader(fichero)
        columnas = [str(columna).strip() for columna in (lector.fieldnames or [])]
        filas = [{str(k).strip(): v for k, v in fila.items()} for fila in lector]
    return filas, columnas


def lotes_por_carrera(filas: list[dict]) -> list[tuple[str, list[dict]]]:
    # Paso 2 · Agrupa el snapshot en lotes por carrera
    # Por qué: la unidad de ingesta es la carrera; así una carrera atrasada se puede cargar sola sin
    #          releer las demás, que es la base del incremental.
    # Salida esperada: "lotes: 20 carreras · 20 filas por carrera"
    # Si falla: si una fila no trae `carrera`, la clave del lote es cadena vacía; staging la rechaza.
    lotes: dict[str, list[dict]] = {}
    for fila in filas:
        carrera = str(fila.get("carrera", "")).strip()
        lotes.setdefault(carrera, []).append(fila)
    return list(lotes.items())


def paginar(lotes: list[tuple[str, list[dict]]], tamano: int = 5):
    # Paso 3 · Recorre los lotes en páginas de tamaño fijo
    # Por qué: la ingesta trabaja por páginas para poder parar y reanudar sin perder la marca de agua; el
    #          tamaño queda declarado y se ve en la salida.
    # Salida esperada: "páginas: 4 (lotes de 5 carreras)"
    # Si falla: si `tamano` es 0, no hay páginas y el total sale 0; el mínimo es 1.
    tamano = max(1, int(tamano))
    for inicio in range(0, len(lotes), tamano):
        yield lotes[inicio : inicio + tamano]


def leer_tabla(destino: Path, nombre: str) -> list[dict]:
    ruta = Path(destino) / "data" / nombre
    if not ruta.exists():
        return []
    with ruta.open(newline="", encoding="utf-8") as fichero:
        return list(csv.DictReader(fichero))


def escribir_tabla(destino: Path, nombre: str, filas: list[dict]) -> None:
    ruta = Path(destino) / "data" / nombre
    ruta.parent.mkdir(parents=True, exist_ok=True)
    with ruta.open("w", newline="", encoding="utf-8") as fichero:
        escritor = csv.DictWriter(fichero, fieldnames=staging.COLUMNAS)
        escritor.writeheader()
        escritor.writerows(sorted(filas, key=lambda fila: (fila["carrera"], fila["piloto"])))


def escribir_bruto(destino: Path, carrera: str, payload: list[dict], fecha: str) -> str:
    # Paso 4 · Guarda el bruto inmutable, con fecha y sha256
    # Por qué: el payload recibido es la evidencia que permite reprocesar y auditar; si se sobrescribe,
    #          una respuesta mala borraría la buena. El nombre lleva el hash, así que es idempotente.
    # Salida esperada: "bruto: r07-<hash>.json (20 filas) y manifiesto con 20 entradas al final".
    # Si falla: si el nombre no lleva hash, dos respuestas distintas se pisan y el manifiesto miente.
    texto = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    sha256 = hashlib.sha256(texto.encode("utf-8")).hexdigest()
    carpeta = Path(destino) / "data" / "raw"
    carpeta.mkdir(parents=True, exist_ok=True)
    fichero = carpeta / f"{carrera}-{sha256[:12]}.json"
    if not fichero.exists():
        fichero.write_text(
            json.dumps(
                {"carrera": carrera, "descargado": fecha, "sha256": sha256, "filas": payload},
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    manifiesto = carpeta / "manifiesto.json"
    entradas = json.loads(manifiesto.read_text(encoding="utf-8")) if manifiesto.exists() else []
    if not any(entrada["sha256"] == sha256 for entrada in entradas):
        entradas.append(
            {
                "carrera": carrera,
                "fichero": fichero.name,
                "sha256": sha256,
                "filas": len(payload),
                "descargado": fecha,
            }
        )
        manifiesto.write_text(json.dumps(entradas, ensure_ascii=False, indent=2), encoding="utf-8")
    return sha256


def cargar_estado(destino: Path) -> dict:
    ruta = Path(destino) / "data" / "estado.json"
    if not ruta.exists():
        return {"carreras": [], "filas": 0, "actualizado": ""}
    return json.loads(ruta.read_text(encoding="utf-8"))


def guardar_estado(destino: Path, estado: dict, fecha: str) -> None:
    ruta = Path(destino) / "data" / "estado.json"
    ruta.parent.mkdir(parents=True, exist_ok=True)
    estado["actualizado"] = fecha
    ruta.write_text(json.dumps(estado, ensure_ascii=False, indent=2), encoding="utf-8")


def ejecutar(
    filas: list[dict],
    columnas: list[str],
    destino: Path = RAIZ,
    *,
    tamano_pagina: int = 5,
    fecha: str = FECHA_CAPTURA,
) -> dict:
    # Paso 6 · Ejecuta una pasada de ingesta incremental
    # Por qué: la marca de agua son las carreras ya cargadas, no «la última»: una carrera atrasada entra
    #          igual y lo ya cargado no se relee. La clave `(carrera, piloto)` decide qué es fila nueva.
    # Salida esperada: "páginas: 4 · leídas: 400 · nuevas: 400 · saltadas: 0 · hechas: 400".
    # Si falla: si nuevas ≠ leídas - saltadas, o la clave no es única, el dedupe o el staging fallan.
    destino = Path(destino)
    estado = cargar_estado(destino)
    cargadas = set(estado.get("carreras", []))
    staging_filas = leer_tabla(destino, "staging.csv")
    claves = {(fila["carrera"], fila["piloto"]) for fila in staging_filas}

    auditoria: list[dict] = []
    nuevas_total = 0
    leidas = 0
    saltadas = 0
    cuarentenas = 0
    paginas = 0

    for pagina in paginar(lotes_por_carrera(filas), tamano_pagina):
        paginas += 1
        for carrera, payload in pagina:
            leidas += len(payload)
            if carrera in cargadas:
                saltadas += 1
                auditoria.append({"carrera": carrera, "filas_leidas": len(payload), "filas_nuevas": 0, "resultado": "saltada"})
                continue

            escribir_bruto(destino, carrera, payload, fecha)
            faltan = staging.validar_esquema(payload[0].keys() if payload else [])
            if faltan:
                cuarentena.registrar(
                    destino,
                    carrera,
                    "esquema_incompleto: " + ",".join(faltan),
                    payload=payload,
                    fecha=fecha,
                )
                cuarentenas += 1
                auditoria.append({"carrera": carrera, "filas_leidas": len(payload), "filas_nuevas": 0, "resultado": "cuarentena"})
                continue

            validas, rechazos = staging.validar_lote(payload)
            if rechazos:
                motivos = sorted({motivo for rechazo in rechazos for motivo in rechazo["motivos"]})
                cuarentena.registrar(
                    destino,
                    carrera,
                    "lote_rechazado: " + ",".join(motivos),
                    payload=payload,
                    fecha=fecha,
                )
                cuarentenas += 1
                auditoria.append({"carrera": carrera, "filas_leidas": len(payload), "filas_nuevas": 0, "resultado": "cuarentena"})
                continue

            nuevas = [fila for fila in validas if (fila["carrera"], fila["piloto"]) not in claves]
            for fila in nuevas:
                claves.add((fila["carrera"], fila["piloto"]))
            staging_filas.extend(staging.formatear(fila) for fila in nuevas)
            cargadas.add(carrera)
            nuevas_total += len(nuevas)
            auditoria.append(
                {
                    "carrera": carrera,
                    "filas_leidas": len(payload),
                    "filas_nuevas": len(nuevas),
                    "resultado": "ok" if nuevas else "sin_novedad",
                }
            )

    escribir_tabla(destino, "staging.csv", staging_filas)
    escribir_tabla(destino, "f1-clasificacion.csv", staging_filas)
    guardar_estado(destino, {"carreras": sorted(cargadas), "filas": len(staging_filas)}, fecha)
    (destino / "resultados").mkdir(parents=True, exist_ok=True)
    with (destino / "resultados" / "auditoria.csv").open("w", newline="", encoding="utf-8") as fichero:
        escritor = csv.DictWriter(fichero, fieldnames=["carrera", "filas_leidas", "filas_nuevas", "resultado"])
        escritor.writeheader()
        escritor.writerows(auditoria)

    return {
        "paginas": paginas,
        "leidas": leidas,
        "nuevas": nuevas_total,
        "saltadas": saltadas,
        "hecho": len(staging_filas),
        "carreras": sorted(cargadas),
        "cuarentenas": cuarentenas,
        "cuarentena_total": len(cuarentena.cargar(destino)),
        "auditoria": auditoria,
    }


def _openf1_json(recurso: str, parametros: dict, dormir=time.sleep):
    """Descarga un recurso de OpenF1 con reintentos. Solo se usa en modo con red."""

    def descargar():
        respuesta = requests.get(f"{BASE_OPENF1}/{recurso}", params=parametros, timeout=30)
        if respuesta.status_code == 429:
            raise ErrorLimite(429, int(respuesta.headers.get("Retry-After", "1")))
        respuesta.raise_for_status()
        return respuesta.json()

    payload, _ = reintentar(descargar, dormir)
    if payload is None:
        raise RuntimeError(f"OpenF1 no respondió a {recurso}")
    return payload


def resumen_openf1(datos: dict) -> dict:
    sesiones = datos.get("sessions", [])
    pilotos = datos.get("drivers", [])
    posiciones = datos.get("position", [])
    circuito = sesiones[0].get("circuit_short_name", "?") if sesiones else "?"
    return {"sesiones": len(sesiones), "pilotos": len(pilotos), "posiciones": len(posiciones), "circuito": circuito}


def cargar_openf1_sin_red() -> dict:
    # Paso 7 · Lee las respuestas grabadas de OpenF1 (sin red)
    # Por qué: el proyecto se puede ejecutar y verificar sin red; las respuestas capturadas documentan la
    #          forma real de la fuente y permiten probar el resumen sin depender del proveedor.
    # Salida esperada: "openf1 sin red: 1 sesión · 20 pilotos · 1 posición · Sakhir".
    # Si falla: JSONDecodeError → falta uno de los tres ficheros openf1-*.json en datos-ejemplo.
    nombres = ("sessions", "drivers", "position")
    return {nombre: json.loads((DATOS / f"openf1-{nombre}.json").read_text(encoding="utf-8")) for nombre in nombres}


def cargar_openf1_con_red(dormir=time.sleep, sesion_key: int = 9472) -> dict:
    sesiones = _openf1_json("sessions", {"session_key": sesion_key}, dormir)
    pilotos = _openf1_json("drivers", {"session_key": sesion_key}, dormir)
    posiciones = _openf1_json("position", {"session_key": sesion_key, "position": 1}, dormir)
    return {"sessions": sesiones, "drivers": pilotos, "position": posiciones}


def reiniciar(destino: Path = RAIZ) -> None:
    # Paso 8 · Deja la carpeta como recién descargada
    # Por qué: la verificación y las pruebas necesitan partir de cero; si no se limpia, la marca de agua
    #          vieja hace que todo salga "saltada" y el ensayo no demuestra nada.
    # Salida esperada: "reiniciar: data/ y resultados/ borrados".
    # Si falla: PermissionError → cierra el CSV abierto en Excel o el proceso que tenga data/ en uso.
    destino = Path(destino)
    shutil.rmtree(destino / "data", ignore_errors=True)
    resultados = destino / "resultados"
    if resultados.exists():
        for nombre in ("auditoria.csv", "429.json", "repeticion.json", "cuarentena.json"):
            (resultados / nombre).unlink(missing_ok=True)
    print("reiniciar: data/ y resultados/ borrados")


def _resumen(cifras: dict) -> None:
    print(f"páginas: {cifras['paginas']}")
    print(
        f"leídas: {cifras['leidas']} · nuevas: {cifras['nuevas']} · saltadas: {cifras['saltadas']} · "
        f"hechas: {cifras['hecho']} · cuarentena: {cifras['cuarentena_total']}"
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Ingesta incremental idempotente de F1 (P42)")
    parser.add_argument("--reiniciar", action="store_true", help="borra data/ y resultados/")
    parser.add_argument("--repetir", action="store_true", help="ingesta dos veces y guarda la comparación")
    parser.add_argument("--simular-429", action="store_true", help="ensayo de reintentos con 429 grabado")
    parser.add_argument("--payload-roto", action="store_true", help="manda a cuarentena un payload incompleto")
    parser.add_argument("--carreras", default="", help="lista separada por comas (r01,r03)")
    parser.add_argument("--lote", type=int, default=5, help="carreras por página (por defecto 5)")
    parser.add_argument("--openf1", action="store_true", help="resumen de la fuente real")
    parser.add_argument("--con-red", action="store_true", help="usa la API real en --openf1")
    args = parser.parse_args(argv)

    print("== P42 · ingesta incremental idempotente ==")
    if args.reiniciar:
        reiniciar()
        return 0

    if args.openf1:
        if args.con_red:
            datos = cargar_openf1_con_red()
            modo = "red"
        else:
            datos = cargar_openf1_sin_red()
            modo = "sin red"
        resumen = resumen_openf1(datos)
        print(
            f"openf1 {modo}: {resumen['sesiones']} sesión · {resumen['pilotos']} pilotos · "
            f"{resumen['posiciones']} posiciones · {resumen['circuito']}"
        )
        return 0

    if args.simular_429:
        secuencia = {"intento": 0}

        def descargar_que_falla():
            secuencia["intento"] += 1
            if secuencia["intento"] <= 2:
                raise ErrorLimite(429, retry_after=secuencia["intento"])
            return {"ok": True}

        esperas: list[int] = []
        payload, registro = reintentar(descargar_que_falla, dormir=lambda segundos: esperas.append(segundos))
        registro["esperas"] = esperas
        RESULTADOS.mkdir(parents=True, exist_ok=True)
        (RESULTADOS / "429.json").write_text(json.dumps(registro, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"429: {len(registro['intentos'])} intentos · esperas {esperas} · exito {registro['exito']}")
        return 0 if registro["exito"] else 1

    filas, columnas = cargar_snapshot()
    print(f"snapshot: {len(filas)} filas · {len(lotes_por_carrera(filas))} carreras · {len(columnas)} columnas")

    if args.carreras:
        pedidas = {carrera.strip() for carrera in args.carreras.split(",") if carrera.strip()}
        filas = [fila for fila in filas if fila.get("carrera") in pedidas]

    if args.payload_roto:
        filas = [dict(fila) for fila in filas[:20]]
        for fila in filas:
            fila["carrera"] = "r21"
            fila.pop("vuelta_quali_s", None)

    cifras = ejecutar(filas, columnas, tamano_pagina=args.lote)
    _resumen(cifras)

    if args.repetir:
        cifras2 = ejecutar(filas, columnas, tamano_pagina=args.lote)
        RESULTADOS.mkdir(parents=True, exist_ok=True)
        (RESULTADOS / "repeticion.json").write_text(
            json.dumps(
                {"antes": cifras["hecho"], "despues": cifras2["hecho"], "nuevas_en_la_repeticion": cifras2["nuevas"]},
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        print(f"repetición: antes {cifras['hecho']} · después {cifras2['hecho']} · nuevas {cifras2['nuevas']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
