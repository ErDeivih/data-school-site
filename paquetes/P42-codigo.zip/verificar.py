#!/usr/bin/env python3
"""Puerta del proyecto P42 (ingesta incremental idempotente).

Ejecuta la ingesta sobre el snapshot y los escenarios de la ficha en carpetas temporales: primera carga,
repetición, carrera atrasada, 429, esquema roto y fila con tipo malo. Comprueba recuentos, clave única,
bruto inmutable, cuarentena y que la verificación no toca la red.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla
"""
from __future__ import annotations

import csv
import hashlib
import json
import sys
import tempfile
from pathlib import Path

import requests

import ingerir
import staging

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def leer_csv(ruta: Path) -> list[dict]:
    with ruta.open(newline="", encoding="utf-8") as fichero:
        return list(csv.DictReader(fichero))


def subset(filas: list[dict], carreras: set[str]) -> list[dict]:
    return [fila for fila in filas if str(fila.get("carrera", "")).strip() in carreras]


def main() -> int:
    print("== Puerta del proyecto P42 · ingesta incremental idempotente ==")

    # Paso 1 · Comprueba el snapshot: filas, columnas y clave
    # Por qué: el proyecto define el grano antes de ingerir; si la clave `(carrera, piloto)` no es única,
    #          la idempotencia no se puede demostrar.
    # Salida esperada: "snapshot: 400 filas · 12 columnas · 20 carreras × 20 pilotos y clave única".
    # Si falla: el CSV de ejemplo no es el del catálogo o se copió mal.
    filas, columnas = ingerir.cargar_snapshot()
    carreras = {str(fila["carrera"]) for fila in filas}
    pilotos = {str(fila["piloto"]) for fila in filas}
    claves = [(fila["carrera"], fila["piloto"]) for fila in filas]
    ok(len(filas) == 400 and len(columnas) == 12, f"snapshot: {len(filas)} filas · {len(columnas)} columnas")
    ok(len(carreras) == 20 and len(pilotos) == 20, f"snapshot: {len(carreras)} carreras y {len(pilotos)} pilotos")
    ok(len(set(claves)) == len(claves) == 400, "snapshot: clave (carrera, piloto) única en las 400 filas")
    ok(ingerir.lotes_por_carrera(filas)[0][0] == "r01" and len(ingerir.lotes_por_carrera(filas)) == 20,
       "snapshot: 20 lotes de carreras, uno por carrera")

    with tempfile.TemporaryDirectory(prefix="p42-verificacion-") as carpeta:
        raiz = Path(carpeta)

        # Paso 2 · Primera ingesta completa: 400 filas nuevas, 4 páginas y bruto con 20 entradas
        # Por qué: es la línea base del incremental; todo lo demás se mide contra este estado.
        # Salida esperada: "carga 1: páginas 4 · nuevas 400 · hechas 400 · cuarentena 0".
        # Si falla: alguna carrera no entra o el paginador se deja lotes.
        t1 = raiz / "t1"
        cifras1 = ingerir.ejecutar(filas, columnas, destino=t1, tamano_pagina=5)
        ok(
            cifras1["paginas"] == 4 and cifras1["nuevas"] == 400 and cifras1["hecho"] == 400
            and cifras1["cuarentena_total"] == 0 and len(cifras1["carreras"]) == 20,
            f"carga 1: páginas {cifras1['paginas']} · nuevas {cifras1['nuevas']} · hechas {cifras1['hecho']} · "
            f"cuarentena {cifras1['cuarentena_total']}",
        )
        manifiesto = json.loads((t1 / "data" / "raw" / "manifiesto.json").read_text(encoding="utf-8"))
        ok(len(manifiesto) == 20, f"bruto: {len(manifiesto)} entradas en el manifiesto")
        entrada = next(item for item in manifiesto if item["carrera"] == "r07")
        fichero_bruto = t1 / "data" / "raw" / entrada["fichero"]
        contenido = json.loads(fichero_bruto.read_text(encoding="utf-8"))
        sha_recalculado = hashlib.sha256(
            json.dumps(contenido["filas"], ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()
        ok(entrada["sha256"] == sha_recalculado and fichero_bruto.name.startswith("r07-"),
           f"bruto inmutable: {entrada['fichero']} coincide con su sha256")
        hecho1 = leer_csv(t1 / "data" / "f1-clasificacion.csv")
        ok(len(hecho1) == 400 and len({(fila["carrera"], fila["piloto"]) for fila in hecho1}) == 400,
           "hecho: 400 filas y clave única")
        auditoria1 = leer_csv(t1 / "resultados" / "auditoria.csv")
        ok(len(auditoria1) == 20 and all(fila["resultado"] == "ok" for fila in auditoria1),
           f"auditoría: {len(auditoria1)} carreras, todas ok")

        # Paso 3 · Segunda ingesta: 0 filas nuevas, todas saltadas y el bruto no crece
        # Por qué: es el criterio central de la ficha; si el bruto creciera, el hash no estaría evitando
        #          duplicar evidencia y la reejecución no sería idempotente.
        # Salida esperada: "carga 2: nuevas 0 · saltadas 20 · hechas 400 · manifiesto 20".
        # Si falla: la marca de agua no se guardó o se está escribiendo el bruto sin hash.
        cifras2 = ingerir.ejecutar(filas, columnas, destino=t1, tamano_pagina=5)
        manifiesto2 = json.loads((t1 / "data" / "raw" / "manifiesto.json").read_text(encoding="utf-8"))
        ok(
            cifras2["nuevas"] == 0 and cifras2["saltadas"] == 20 and cifras2["hecho"] == 400,
            f"carga 2: nuevas {cifras2['nuevas']} · saltadas {cifras2['saltadas']} · hechas {cifras2['hecho']}",
        )
        ok(len(manifiesto2) == 20 == len(manifiesto), f"bruto: sigue con {len(manifiesto2)} entradas, sin duplicar")
        auditoria2 = leer_csv(t1 / "resultados" / "auditoria.csv")
        ok(len(auditoria2) == 20 and all(fila["resultado"] == "saltada" for fila in auditoria2),
           "auditoría 2: las 20 carreras se saltan")

        # Paso 4 · Marca de agua con huecos: una carrera atrasada entra igual y no se relee
        # Por qué: una marca de agua por «la última carrera» descartaría r02 si llega después de r05; la
        #          marca de agua es el conjunto de carreras cargadas, no el máximo.
        # Salida esperada: "huecos: tras [r01,r03] 40 filas; [r02,r05] +40; [r03,r04] +20 y r03 saltada".
        # Si falla: la marca de agua es un número y no un conjunto → r03 o r02 no se comportan así.
        t2 = raiz / "t2"
        h1 = ingerir.ejecutar(subset(filas, {"r01", "r03"}), columnas, destino=t2)
        h2 = ingerir.ejecutar(subset(filas, {"r02", "r05"}), columnas, destino=t2)
        h3 = ingerir.ejecutar(subset(filas, {"r03", "r04"}), columnas, destino=t2)
        ok(h1["nuevas"] == 40 and h2["nuevas"] == 40 and h3["nuevas"] == 20 and h3["saltadas"] == 1,
           f"huecos: {h1['nuevas']} + {h2['nuevas']} + {h3['nuevas']} filas nuevas y {h3['saltadas']} saltada")
        ok(h3["hecho"] == 100 and h3["carreras"] == ["r01", "r02", "r03", "r04", "r05"],
           f"huecos: {h3['hecho']} filas y carreras {h3['carreras']}")

        # Paso 5 · 429: reintenta con espera declarada y no duplica
        # Por qué: el reintento no puede ser un bucle caliente; se espera y se registra cada intento, y el
        #          éxito no puede haber escrito filas por su cuenta.
        # Salida esperada: "429: 3 intentos · esperas [1, 2] · exito True".
        # Si falla: si se reintenta sin espera o se supera el máximo, el registro lo delata.
        intentos = {"numero": 0}

        def descargar_que_falla():
            intentos["numero"] += 1
            if intentos["numero"] <= 2:
                raise ingerir.ErrorLimite(429, retry_after=intentos["numero"])
            return {"ok": True}

        esperas: list[int] = []
        payload, registro = ingerir.reintentar(descargar_que_falla, dormir=lambda segundos: esperas.append(segundos))
        ok(payload == {"ok": True} and registro["exito"], "429: el tercer intento devuelve el payload")
        ok([entrada["resultado"] for entrada in registro["intentos"]] == ["error_429", "error_429", "ok"],
           f"429: intentos {[entrada['resultado'] for entrada in registro['intentos']]}")
        ok(esperas == [1, 2], f"429: esperas declaradas {esperas}")

        # Paso 6 · Esquema roto: el payload va a cuarentena y el hecho no cambia
        # Por qué: una respuesta con columnas de menos no puede entrar; se guarda el original para poder
        #          reprocesarla cuando llegue bien, y la marca de agua no avanza.
        # Salida esperada: "esquema roto: 1 en cuarentena, 400 filas y r21 fuera de la marca de agua".
        # Si falla: el hecho gana filas o r21 queda marcada como cargada.
        t3 = raiz / "t3"
        ingerir.ejecutar(filas, columnas, destino=t3)
        roto = [dict(fila) for fila in subset(filas, {"r01"})]
        for fila in roto:
            fila["carrera"] = "r21"
            fila.pop("vuelta_quali_s", None)
        cifras_roto = ingerir.ejecutar(roto, columnas, destino=t3)
        cuarentena = json.loads((t3 / "resultados" / "cuarentena.json").read_text(encoding="utf-8"))
        estado = json.loads((t3 / "data" / "estado.json").read_text(encoding="utf-8"))
        ok(cifras_roto["cuarentenas"] == 1 and cifras_roto["hecho"] == 400,
           f"esquema roto: {cifras_roto['cuarentenas']} en cuarentena y {cifras_roto['hecho']} filas")
        ok(cuarentena and "esquema_incompleto" in cuarentena[0]["motivo"] and (t3 / cuarentena[0]["fichero"]).exists(),
           "esquema roto: motivo y payload original guardados")
        ok("r21" not in estado["carreras"], "esquema roto: r21 no entra en la marca de agua")

        # Paso 7 · Fila con tipo malo: el lote entero va a cuarentena y el hecho no cambia
        # Por qué: aceptar 19 de 20 filas deja una carrera a medias; el lote se rechaza completo y se
        #          arregla la fuente antes de reintentar.
        # Salida esperada: "tipo malo: 1 lote en cuarentena, 400 filas y motivo lote_rechazado".
        # Si falla: el hecho suma 19 → se está ingestando un lote parcial.
        malo = [dict(fila) for fila in subset(filas, {"r01"})]
        for indice, fila in enumerate(malo):
            fila["carrera"] = "r22"
            if indice == 0:
                fila["vuelta_quali_s"] = "rapidisimo"
        cifras_malo = ingerir.ejecutar(malo, columnas, destino=t3)
        cuarentena2 = json.loads((t3 / "resultados" / "cuarentena.json").read_text(encoding="utf-8"))
        ok(cifras_malo["hecho"] == 400 and len(cuarentena2) == 2,
           f"tipo malo: {cifras_malo['hecho']} filas y {len(cuarentena2)} entradas de cuarentena")
        ok(any("lote_rechazado" in entrada["motivo"] for entrada in cuarentena2),
           "tipo malo: el motivo del lote está registrado")

        # Paso 8 · OpenF1 sin red: las respuestas grabadas documentan la fuente real
        # Por qué: el proyecto no puede depender de la red para verificarse; las capturas enseñan la forma
        #          real del payload de sesiones, pilotos y posiciones.
        # Salida esperada: "openf1: 1 sesión, 20 pilotos, 3 posiciones y circuito Sakhir".
        # Si falla: falta una captura o el JSON no es válido.
        datos_openf1 = ingerir.cargar_openf1_sin_red()
        resumen = ingerir.resumen_openf1(datos_openf1)
        ok(resumen == {"sesiones": 1, "pilotos": 20, "posiciones": 3, "circuito": "Sakhir"},
           f"openf1 sin red: {resumen}")

        # Paso 9 · La verificación no toca la red: `requests.get` está prohibido durante la prueba
        # Por qué: el contrato exige un verificador offline; si el código llamara a la API, esta prueba
        #          fallaría con una excepción en vez de pasar desapercibido.
        # Salida esperada: "sin red: requests.get nunca se llama al verificar".
        # Si falla: alguna función del verificador intenta descargar → usa las capturas de datos-ejemplo.
        original_get = requests.get

        def prohibido(*args, **kwargs):
            raise AssertionError("la verificación intentó usar la red")

        requests.get = prohibido
        try:
            ingerir.cargar_openf1_sin_red()
            sin_red = True
        except AssertionError:
            sin_red = False
        finally:
            requests.get = original_get
        ok(sin_red, "sin red: requests.get nunca se llama al verificar")

        # Paso 10 · El esquema tipa bien una fila buena y rechaza los campos obligatorios vacíos
        # Por qué: la puerta comprueba el contrato de staging por separado del pipeline.
        # Salida esperada: "staging: fila buena tipada y fila sin piloto rechazada".
        # Si falla: el tipado no convierte a int/float o el motivo del rechazo no se genera.
        buena, motivos_buena = staging.validar_fila(filas[0])
        mala = dict(filas[0])
        mala["piloto"] = ""
        _, motivos_mala = staging.validar_fila(mala)
        ok(buena is not None and not motivos_buena and isinstance(buena["posicion_quali"], int)
           and isinstance(buena["vuelta_quali_s"], float),
           "staging: fila buena tipada a int/float")
        ok("piloto_obligatorio" in motivos_mala, f"staging: fila sin piloto rechazada por {motivos_mala}")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
