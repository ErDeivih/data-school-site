#!/usr/bin/env python3
"""Cuarentena de P42: guarda lo que no entra en staging con su motivo y el payload original.

Cada rechazo deja una entrada en `resultados/cuarentena.json` y, si el rechazo es de lote, el payload
completo en `data/cuarentena/<carrera>-<n>.json` para poder reprocesarlo cuando se arregle.
"""
from __future__ import annotations

import json
from pathlib import Path


def ruta_indice(destino: Path) -> Path:
    return Path(destino) / "resultados" / "cuarentena.json"


def cargar(destino: Path) -> list[dict]:
    ruta = ruta_indice(destino)
    if not ruta.exists():
        return []
    return json.loads(ruta.read_text(encoding="utf-8"))


def _guardar(destino: Path, entradas: list[dict]) -> None:
    ruta = ruta_indice(destino)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    ruta.write_text(json.dumps(entradas, ensure_ascii=False, indent=2), encoding="utf-8")


def registrar(
    destino: Path,
    carrera: str,
    motivo: str,
    *,
    payload: list[dict] | None = None,
    fila: dict | None = None,
    fecha: str = "2026-11-06",
) -> dict:
    """Añade una entrada a la cuarentena; si hay payload, lo guarda como fichero aparte."""
    entradas = cargar(destino)
    entrada: dict = {"carrera": carrera, "motivo": motivo, "fecha": fecha}
    if payload is not None:
        carpeta = Path(destino) / "data" / "cuarentena"
        carpeta.mkdir(parents=True, exist_ok=True)
        fichero = carpeta / f"{carrera}-{len(entradas) + 1:02d}.json"
        fichero.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        entrada["fichero"] = fichero.relative_to(Path(destino)).as_posix()
        entrada["filas"] = len(payload)
    if fila is not None:
        entrada["fila"] = fila
    entradas.append(entrada)
    _guardar(destino, entradas)
    return entrada
