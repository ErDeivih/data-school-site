"""P21 · Fútbol: el xG no es el marcador.

Usa el xG de cada partido para estimar la probabilidad 1-X-2, la compara con una línea base de
frecuencias y con el marcador real, y mide la calibración fuera de muestra: cuando el modelo dice
«60 % local», ¿gana el local el 60 % de las veces? Sin librerías: solo la estándar.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import Counter, defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("jornada", "local", "visitante", "goles_local", "goles_visitante",
            "tiros_local", "tiros_visitante", "xg_local", "xg_visitante",
            "posesion_local", "amarillas", "resultado")
CORTE = 27                 # jornadas 1–27 para ajustar; 28–38 fuera de muestra (11 jornadas)
MAX_GOLES = 8
RESULTADOS = ("1", "X", "2")


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar el grano: un partido por fila, con resultado coherente con los goles.
    # Por qué: si el resultado no cuadra con los goles, cualquier métrica de acierto es mentira.
    # Salida esperada: 380 partidos, 38 jornadas y 20 equipos.
    # Si falla: «columnas inesperadas», un resultado fuera de 1/X/2 o goles negativos.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 380:
        raise ValueError(f"se esperaban 380 partidos, hay {len(filas)}")
    for fila in filas:
        gl, gv = int(fila["goles_local"]), int(fila["goles_visitante"])
        if fila["resultado"] not in RESULTADOS:
            raise ValueError(f"resultado inesperado: {fila['resultado']}")
        esperado = "1" if gl > gv else "X" if gl == gv else "2"
        if fila["resultado"] != esperado:
            raise ValueError(f"resultado incoherente en jornada {fila['jornada']}: {gl}-{gv}")
        if gl < 0 or gv < 0:
            raise ValueError("goles negativos")
        float(fila["xg_local"]); float(fila["xg_visitante"])
    if len({fila["jornada"] for fila in filas}) != 38:
        raise ValueError("se esperaban 38 jornadas")
    return filas


def dividir(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    # Paso 2 · Separar por jornada, no al azar: el modelo se prueba con partidos posteriores.
    # Por qué: mezclar jornadas filtra el futuro al pasado y hace que la métrica suba sola.
    # Salida esperada: 270 partidos de ajuste (jornadas 1–27) y 110 de prueba (28–38).
    # Si falla: el corte deja una parte vacía o descompensada.
    ajuste = [f for f in filas if int(f["jornada"]) <= CORTE]
    prueba = [f for f in filas if int(f["jornada"]) > CORTE]
    if len(ajuste) != 270 or len(prueba) != 110:
        raise ValueError(f"partición inesperada: {len(ajuste)} / {len(prueba)}")
    return ajuste, prueba


def poisson(lam: float, k: int) -> float:
    return math.exp(-lam) * lam ** k / math.factorial(k)


def probabilidades_poisson(xg_local: float, xg_visitante: float) -> dict:
    # Paso 3 · Modelo: dos Poisson independientes con λ = xG de cada equipo.
    # Por qué: el xG es una tasa de goles esperados; Poisson convierte esa tasa en probabilidades.
    # Salida esperada: P(local), P(empate), P(visitante) que suman 1.
    # Si falla: un xG negativo o una suma que no cierra.
    if xg_local < 0 or xg_visitante < 0:
        raise ValueError("xG negativo")
    local = [poisson(xg_local, k) for k in range(MAX_GOLES + 1)]
    visitante = [poisson(xg_visitante, k) for k in range(MAX_GOLES + 1)]
    p1 = px = p2 = 0.0
    for i, pi in enumerate(local):
        for j, pj in enumerate(visitante):
            p = pi * pj
            if i > j:
                p1 += p
            elif i == j:
                px += p
            else:
                p2 += p
    total = p1 + px + p2
    return {"1": p1 / total, "X": px / total, "2": p2 / total}


def linea_base(ajuste: list[dict]) -> dict:
    # Paso 4 · Línea base honesta: las frecuencias de 1/X/2 en el periodo de ajuste.
    # Por qué: sin línea base no se sabe si el modelo aporta algo o solo repite lo obvio.
    cuenta = Counter(f["resultado"] for f in ajuste)
    return {r: cuenta[r] / len(ajuste) for r in RESULTADOS}


def metricas(partidos: list[dict], probabilidades: list[dict]) -> dict:
    # Paso 5 · Log loss, Brier y acierto multiclase.
    # Por qué: el acierto solo ignora la confianza; log loss y Brier la castigan.
    perdida = brier = 0.0
    aciertos = 0
    for partido, probs in zip(partidos, probabilidades):
        real = partido["resultado"]
        perdida -= math.log(max(probs[real], 1e-12))
        brier += sum((probs[r] - (1.0 if r == real else 0.0)) ** 2 for r in RESULTADOS)
        aciertos += 1 if max(RESULTADOS, key=lambda r: probs[r]) == real else 0
    n = len(partidos)
    return {"log_loss": perdida / n, "brier": brier / n, "acierto": aciertos / n, "n": n}


def calibracion(partidos: list[dict], probabilidades: list[dict]) -> list[dict]:
    # Paso 6 · Calibración de P(local) por tramos de 0,2.
    # Por qué: un modelo puede acertar y aun así estar mal calibrado (decir 80 % cuando gana 55 %).
    # Salida esperada: tramos con su probabilidad media y la frecuencia observada de victoria local.
    # Si falla: un tramo sin partidos; se omite en lugar de inventar.
    cubos = defaultdict(list)
    for partido, probs in zip(partidos, probabilidades):
        cubos[min(4, int(probs["1"] * 5))].append((probs["1"], 1 if partido["resultado"] == "1" else 0))
    salida = []
    for cubo in sorted(cubos):
        pares = cubos[cubo]
        predicha = sum(p for p, _ in pares) / len(pares)
        observada = sum(y for _, y in pares) / len(pares)
        salida.append({"tramo": f"{cubo / 5:.1f}–{(cubo + 1) / 5:.1f}", "n": len(pares),
                       "predicha": predicha, "observada": observada, "desvio": observada - predicha})
    # Un tramo con 3 partidos no estima una frecuencia: se fusiona con el anterior en vez de
    # presentar un desvío de 16 puntos que solo mide el tamaño de la muestra.
    fusionados = []
    for fila in salida:
        if fila["n"] < 10 and fusionados:
            previo = fusionados[-1]
            n = previo["n"] + fila["n"]
            previo["predicha"] = (previo["predicha"] * previo["n"] + fila["predicha"] * fila["n"]) / n
            previo["observada"] = (previo["observada"] * previo["n"] + fila["observada"] * fila["n"]) / n
            previo["desvio"] = previo["observada"] - previo["predicha"]
            previo["n"] = n
            previo["tramo"] = previo["tramo"].split("–")[0] + "–" + fila["tramo"].split("–")[1]
        else:
            fusionados.append(fila)
    return fusionados


def main() -> int:
    parser = argparse.ArgumentParser(description="P21 · xG, 1-X-2 y calibración")
    parser.add_argument("--csv", default="datos-ejemplo/futbol-partidos.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    ajuste, prueba = dividir(filas)
    base = linea_base(ajuste)
    probs_modelo = [probabilidades_poisson(float(f["xg_local"]), float(f["xg_visitante"])) for f in prueba]
    probs_base = [dict(base) for _ in prueba]
    m_modelo = metricas(prueba, probs_modelo)
    m_base = metricas(prueba, probs_base)
    cal = calibracion(prueba, probs_modelo)
    desvio_max = max(abs(c["desvio"]) for c in cal)

    print(f"datos: {len(filas)} partidos · ajuste {len(ajuste)} (jornadas 1–{CORTE}) · prueba {len(prueba)}")
    print(f"línea base 1-X-2: {base['1']:.3f} / {base['X']:.3f} / {base['2']:.3f}")
    print(f"modelo xG: log loss {m_modelo['log_loss']:.4f} · Brier {m_modelo['brier']:.4f} · acierto {m_modelo['acierto']:.3f}")
    print(f"baseline : log loss {m_base['log_loss']:.4f} · Brier {m_base['brier']:.4f} · acierto {m_base['acierto']:.3f}")
    for c in cal:
        print(f"  P(local) {c['tramo']}: n={c['n']:2} · predicha {c['predicha']:.3f} · observada {c['observada']:.3f} · desvío {c['desvio']:+.3f}")
    print(f"calibración: desvío máximo {desvio_max * 100:.1f} puntos (criterio ≤ 10)")
    print("lectura: el xG ordena mejor que el marcador, pero no convierte un 60 % en una certeza; "
          "la calibración dice cuánto se puede creer la probabilidad.")
    print("límite: 380 partidos sintéticos de una liga de 20 equipos; no describe ninguna liga real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
