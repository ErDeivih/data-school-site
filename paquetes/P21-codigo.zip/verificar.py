#!/usr/bin/env python3
"""Puerta del proyecto P21 (fútbol: el xG no es el marcador).

Comprueba partición temporal, probabilidades, métricas frente a la línea base, calibración y
ausencia de red/claves. VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import xg

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "futbol-partidos.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = xg.leer(CSV)
    ok(len(filas) == 380, "el CSV tiene 380 partidos")
    ok(len({f["jornada"] for f in filas}) == 38, "hay 38 jornadas")
    ok(len({f["local"] for f in filas} | {f["visitante"] for f in filas}) == 20, "hay 20 equipos")

    ajuste, prueba = xg.dividir(filas)
    ok(len(ajuste) == 270 and len(prueba) == 110, "partición temporal 270/110")
    ok(max(int(f["jornada"]) for f in ajuste) <= 27 < min(int(f["jornada"]) for f in prueba),
       "ninguna jornada de prueba entra en el ajuste")

    base = xg.linea_base(ajuste)
    cerca(base["1"], 0.467, 0.002, "frecuencia base de victoria local")
    cerca(base["X"], 0.281, 0.002, "frecuencia base de empate")
    cerca(base["2"], 0.252, 0.002, "frecuencia base de victoria visitante")

    probs = [xg.probabilidades_poisson(float(f["xg_local"]), float(f["xg_visitante"])) for f in prueba]
    ok(all(abs(sum(p.values()) - 1) < 1e-9 for p in probs), "cada 1-X-2 suma 1")
    ok(all(0 <= p[r] <= 1 for p in probs for r in xg.RESULTADOS), "todas las probabilidades están en [0, 1]")

    m_modelo = xg.metricas(prueba, probs)
    m_base = xg.metricas(prueba, [dict(base) for _ in prueba])
    cerca(m_modelo["log_loss"], 0.9497, 0.002, "log loss del modelo xG")
    cerca(m_modelo["brier"], 0.5757, 0.002, "Brier del modelo xG")
    cerca(m_modelo["acierto"], 0.536, 0.005, "acierto del modelo xG")
    cerca(m_base["log_loss"], 1.0714, 0.002, "log loss de la línea base")
    ok(m_modelo["log_loss"] < m_base["log_loss"], "el xG mejora el log loss de la línea base")
    ok(m_modelo["brier"] < m_base["brier"], "el xG mejora el Brier de la línea base")

    cal = xg.calibracion(prueba, probs)
    ok(len(cal) >= 3, "la calibración conserva tramos con muestra suficiente")
    ok(all(c["n"] >= 10 for c in cal), "ningún tramo de calibración tiene menos de 10 partidos")
    desvio = max(abs(c["desvio"]) for c in cal)
    ok(desvio <= 0.10, f"la calibración no se separa más de 10 puntos (máx {desvio * 100:.1f})")
    ok(sum(c["n"] for c in cal) == 110, "la calibración cubre los 110 partidos de prueba")

    codigo = (AQUI / "xg.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
