# P21 · Fútbol: el xG no es el marcador

Paquete descargable de **Data School** para el proyecto P21. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto no es «quién va a ganar», sino **cuánto se puede creer una probabilidad**.
El código usa el xG de cada partido para estimar la probabilidad 1-X-2 con dos Poisson, la compara
con una línea base de frecuencias y con el marcador real, y mide la calibración en las jornadas que
el modelo no vio: cuando dice «60 % local», el local gana el 56,8 % de esas veces.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice. Todo con la biblioteca estándar.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python xg.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P21-codigo
python xg.py --csv datos-ejemplo/futbol-partidos.csv
```

## Salida esperada

```text
datos: 380 partidos · ajuste 270 (jornadas 1–27) · prueba 110
línea base 1-X-2: 0.467 / 0.281 / 0.252
modelo xG: log loss 0.9497 · Brier 0.5757 · acierto 0.536
baseline : log loss 1.0714 · Brier 0.6488 · acierto 0.436
  P(local) 0.0–0.2: n=15 · predicha 0.146 · observada 0.067 · desvío -0.080
  P(local) 0.2–0.4: n=35 · predicha 0.288 · observada 0.286 · desvío -0.002
  P(local) 0.4–0.6: n=37 · predicha 0.486 · observada 0.568 · desvío +0.081
  P(local) 0.6–1.0: n=23 · predicha 0.683 · observada 0.696 · desvío +0.013
calibración: desvío máximo 8.1 puntos (criterio ≤ 10)
lectura: el xG ordena mejor que el marcador, pero no convierte un 60 % en una certeza; la
calibración dice cuánto se puede creer la probabilidad.
límite: 380 partidos sintéticos de una liga de 20 equipos; no describe ninguna liga real.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/futbol-partidos.csv`: **380 filas × 12 columnas**. 38 jornadas, 20 equipos, un
  partido por fila con goles, tiros, xG, posesión, amarillas y resultado (1/X/2).
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `futbol-partidos` del catálogo.
  No son datos reales de ninguna liga.
- `sha256` del fichero: `5cbc8977b6c9d4f7ae66bfcc7642c93a6655faf7b6e6524a6d40480e2e66a12e`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida 380 partidos y que el resultado cuadre con los goles | un dato incoherente invalida la métrica |
| 2 · Dividir | ajuste con jornadas 1–27, prueba con 28–38 | validación temporal, no aleatoria |
| 3 · Poisson | λ = xG de cada equipo, matriz 0..8 | convertir una tasa en probabilidad |
| 4 · Línea base | frecuencias 1-X-2 del ajuste | sin baseline no hay mérito |
| 5 · Métricas | log loss, Brier y acierto | la confianza también se evalúa |
| 6 · Calibración | predicha vs observada por tramos | «60 %» tiene que parecerse a 60 % |

## Las tres trampas que el código deja a la vista

1. **El acierto solo no basta.** El modelo acierta 53,6 % y la línea base 43,6 %, pero además baja
   log loss y Brier: acierta más **y** asigna mejor la confianza.
2. **Calibrar no es acertar.** Un tramo puede acertar y estar desviado 8 puntos; el código mide
   predicha frente a observada y fusiona tramos con menos de 10 partidos para no confundir muestra
   pequeña con mala calibración (el tramo 0,8–1,0 tenía 3 partidos y se fusiona).
3. **El futuro no se baraja.** El corte es por jornada: si se mezclan partidos al azar, el modelo
   «aprende» del futuro y la métrica sube sin mejorar nada.

## Fallos típicos

- **`ModuleNotFoundError: xg`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`**: el CSV no es el del catálogo.
- **`resultado incoherente`**: los goles y la etiqueta 1/X/2 no cuadran.
- **`partición inesperada`**: se cambió el corte de jornadas sin actualizar el código.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P21-codigo/
├── xg.py                       # pasos 1–6: partición, Poisson, baseline, métricas y calibración
├── verificar.py                # la puerta del proyecto: 22 comprobaciones
├── requirements.txt            # sin dependencias
├── datos-ejemplo/
│   └── futbol-partidos.csv     # 380 × 12 · sintético, CC0-1.0
└── resultados/
    └── ejemplo-salida.txt      # la salida real de una ejecución
```

## Límite

Son 380 partidos sintéticos de una liga de 20 equipos: no hay lesiones, fichajes, árbitros ni
calendario real. El paquete enseña el **método** (xG → Poisson → baseline → calibración), no un
pronóstico. El xG no es el marcador: es una tasa, y una tasa no garantiza un resultado.
