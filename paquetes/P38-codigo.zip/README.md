# P38 · XGBoost con clases desequilibradas — código ejecutable

El proyecto completo sobre el CSV sintético de 3000 pagos con un 2,3 % de fraude: mide el desbalanceo,
parte de forma estratificada, entrena un **boosting de árboles con XGBoost**, presenta la matriz de
confusión fuera de muestra y **elige el umbral por coste** (`FN·200 € + FP·5 €`, supuestos declarados).
Compara todo con la línea base «nunca fraude» y con una regresión logística simple. Es el código que
acompaña a la ficha
`../../fichas-portfolio/p38-xgboost-desequilibrado.md`.

El resultado que enseña el proyecto: a umbral 0,50 el boosting detecta **1 de los 21 fraudes del test**
(recall 0,048); a umbral **0,04** el coste baja de **4010 € a 1390 €**. Y una lectura honesta que se
publica: con 21 positivos en el test, **la regresión logística simple supera al boosting en PR-AUC**
(0,379 frente a 0,333); el proyecto lo dice en vez de esconderlo. La variable `hora` queda en el
puesto 8 de 13 importancias: no forma parte del generador del fraude.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **numpy** (2.5.2), **pandas** (3.0.6), **scikit-learn** (1.9.1) y **xgboost** (3.4.1). Se instalan en
  un comando.
- Windows, Linux o macOS. No hace falta red: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p38-xgboost-desequilibrado/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide las cuatro dependencias. Licencias: numpy, pandas y scikit-learn son
BSD-3-Clause; xgboost es Apache-2.0.

## Orden de ejecución

```powershell
python modelo.py          # carga, línea base, boosting, matriz, umbral y tablas
python modelo.py limpiar  # borra las tablas generadas y deja la carpeta como se descargó
```

La salida esperada de una ejecución es esta:

```text
datos: 3000 filas × 9 columnas · id único · 69 fraudes (2.30 %) · sha256 830cd8b8…
partición: 2100 train / 900 test · positivos 48 y 21
línea base: exactitud 0.977 · precisión 0.000 · recall 0.000 · detecta 0 de 21 fraudes
modelo simple: probabilidad media en test 0.0198
xgboost: 80 árboles de profundidad 3 · probabilidad media en test 0.0186
umbral 0,50: TP 1 · FP 2 · FN 20 · TN 877 · precisión 0.333 · recall 0.048 · F1 0.083 · PR-AUC 0.333 · ROC-AUC 0.930
umbral por coste: 0.04 cuesta 1390.00 EUR · el 0.50 cuesta 4010.00 EUR
importancias: top 5 dispositivo_movil 0.160, intentos_24h 0.131, importe_eur 0.123, dispositivo_escritorio 0.083, pais_MA 0.079 · hora en el puesto 8 de 13
comparación: línea base (nunca fraude) recall 0.000 PR-AUC 0.000 · logística simple recall 0.095 PR-AUC 0.379 · xgboost recall 0.048 PR-AUC 0.333
resultados: clases.csv, matriz.csv, umbrales.csv, comparacion-modelos.csv, importancias.csv
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula el crudo, la partición, la línea base, la matriz de confusión y el barrido de
umbrales; comprueba que la matriz cuadra con las métricas, que el umbral elegido no cuesta más que el
0,5, que el boosting y el modelo simple superan dos veces la prevalencia en PR-AUC, que `hora` está en
las importancias y que la misma semilla da las mismas probabilidades. No usa red y no escribe nada.
Termina en `RESULTADO: VERDE` (código 0) con **26 comprobaciones**; la salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- [`datos-ejemplo/transacciones-fraude.csv`](datos-ejemplo/transacciones-fraude.csv): **3000 filas ×
  9 columnas** (`id`, `importe_eur`, `hora`, `canal`, `pais`, `dispositivo`, `intentos_24h`,
  `antiguedad_dias`, `fraude`). 69 fraudes (2,3 %); `id` único; sin nulos.
- sha256 del fichero:
  `830cd8b8e2abf8479702530665490dbe2821dc674403471c3b35c25ee838b2a7`. Es copia literal del conjunto
  de práctica del portal del temario (`web/datos/datasets/transacciones-fraude.csv`), sintético,
  semilla fija y licencia **CC0-1.0**: no son transacciones reales ni hay clientes detrás.

Basta con ese CSV: el proyecto se ejecuta sin descargar nada. Para usar datos propios, se copian en
`datos-ejemplo/` con las mismas columnas o se edita la constante `DATOS` de `modelo.py`.

## Fuente real y licencia

- El catálogo no asigna API (`api: []`): el modelo y la evaluación usan **solo el CSV local**.
- El CSV es sintético; el fraude se sorteó con una fórmula logística del generador del portal, no es
  un registro real de pagos.
- xgboost: licencia Apache-2.0; el resto, BSD-3-Clause.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y medir el desbalanceo | La prevalencia antes de modelar y por qué importa | Desbalanceo de clases |
| 2 · Partir estratificado | Repartir sin romper la clase rara | Train, validación y test |
| 3 · Línea base | El suelo honesto: 97,7 % y cero detecciones | Métricas de clasificación |
| 4 · Modelo simple de comparación | Comparar el boosting con algo más barato | Regresión lineal |
| 5 · Entrenar XGBoost | Boosting de árboles con semilla y configuración declarada | XGBoost, LightGBM y CatBoost |
| 6 · Matriz de confusión | Qué se detecta y qué se cuela, fuera de muestra | Matriz de confusión |
| 7 · Umbral por coste | Convertir dos costes supuestos en una decisión | Umbrales y coste |
| 8 · Importancias y `hora` | Importancia no es causalidad | Causalidad y correlación |
| 9 · Verificador offline | Comprobar con tolerancias y sin red | Testing con pytest |

## Estructura

```text
codigo/
├── modelo.py             # pipeline: carga, partición, modelos, matriz, umbral, importancias
├── verificar.py          # la puerta del proyecto (26 comprobaciones, sin red, sin escribir)
├── requirements.txt      # numpy, pandas, scikit-learn, xgboost
├── datos-ejemplo/
│   └── transacciones-fraude.csv   # 3000 × 9 · CC0-1.0
└── resultados/
    └── ejemplo-salida.txt
```

Las tablas que escribe `python modelo.py` (`clases.csv`, `matriz.csv`, `umbrales.csv`,
`comparacion-modelos.csv`, `importancias.csv`) no viajan en el ZIP: se regeneran.

## Fallos típicos

- **`ModuleNotFoundError: xgboost`**: instala con `python -m pip install -r requirements.txt` con el
  mismo intérprete que lanza el pipeline.
- **Exactitud como métrica**: con 2,3 % de fraude, el 97,7 % de la línea base no detecta nada; el
  informe debe hablar de precisión, recall y coste.
- **Umbral fijo en 0,5**: el 0,5 se compara con el elegido, pero no es la decisión; los costes son un
  supuesto escrito.
- **Fuga por la etiqueta**: `fraude` no entra en la matriz de variables ni en ninguna transformación.
- **Partición temporal inventada**: no hay fechas; la partición es aleatoria y se declara.
- **Cazar el ruido**: `hora` no entra en el generador del fraude; su puesto en las importancias se
  publica sin llamarlo causal.
- **Pocos positivos**: 21 fraudes en el test; un recall sin advertencia se lee como cifra exacta.
- **Creer que el boosting gana siempre**: aquí no gana a la logística en PR-AUC; el README lo dice.
