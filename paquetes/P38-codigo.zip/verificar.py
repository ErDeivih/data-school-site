#!/usr/bin/env python3
"""Puerta del proyecto P38 (XGBoost con clases desequilibradas).

Comprueba el resultado de verdad, sin escribir nada y sin red: el CSV es el del catálogo (sha256) y
tiene 69 fraudes, la partición es estratificada, la matriz de confusión fuera de muestra cuadra con las
métricas, el umbral elegido por coste no cuesta más que el 0,5, el boosting se compara con la línea
base y con un modelo simple, y la misma semilla da las mismas probabilidades.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

import modelo as p

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P38 · XGBoost con clases desequilibradas ==")

    # Paso 1 · Comprueba el crudo: 3000 filas, 9 columnas, 69 fraudes y rangos
    # Por qué: con 69 positivos, un fichero distinto cambia todas las métricas; el contrato se
    #          comprueba antes de entrenar.
    # Salida esperada: "datos: 3000 filas × 9 columnas · id único · 69 fraudes (2.30 %)"
    # Si falla: FileNotFoundError → falta datos-ejemplo/transacciones-fraude.csv (el ZIP lo trae).
    df = p.cargar()
    ok(len(df) == 3000 and df.shape[1] == 9, f"CSV: {len(df)} filas × {df.shape[1]} columnas")
    ok(p.sha256(p.DATOS) == "830cd8b8e2abf8479702530665490dbe2821dc674403471c3b35c25ee838b2a7",
       "el sha256 del CSV de ejemplo es el de la copia del catálogo")
    ok(int(df["fraude"].sum()) == 69, f"fraudes: {int(df['fraude'].sum())} (deben ser 69)")
    ok(int(df["canal"].value_counts().get("web", 0)) == 1027
       and int(df["canal"].value_counts().get("app", 0)) == 1010
       and int(df["canal"].value_counts().get("tienda", 0)) == 963,
       f"canal: {df['canal'].value_counts().to_dict()}")
    ok(int(df["pais"].value_counts().get("MA", 0)) == 715
       and int(df["dispositivo"].value_counts().get("movil", 0)) == 1682,
       f"pais MA {int(df['pais'].value_counts().get('MA', 0))} · movil "
       f"{int(df['dispositivo'].value_counts().get('movil', 0))}")

    # Paso 2 · Comprueba la partición estratificada
    # Por qué: una partición al azar con 69 positivos puede dejar el test sin fraudes; la
    #          estratificación fija la proporción y el recuento se publica.
    # Salida esperada: "partición: 2100 train / 900 test · positivos 48 y 21"
    # Si falla: positivos 0 en test → falta stratify en train_test_split.
    particion = p.preparar(df)
    ok(len(particion["y_tr"]) == 2100 and len(particion["y_te"]) == 900,
       f"partición: {len(particion['y_tr'])} train / {len(particion['y_te'])} test")
    ok(int(particion["y_tr"].sum()) == 48 and int(particion["y_te"].sum()) == 21,
       f"positivos: {int(particion['y_tr'].sum())} train / {int(particion['y_te'].sum())} test")

    # Paso 3 · Comprueba la línea base y el modelo simple
    # Por qué: la línea base «nunca fraude» es el suelo que hay que batir; el modelo simple es el
    #          contraste con el boosting y tiene que estar en la misma tabla.
    # Salida esperada: "línea base: exactitud 0.977 · recall 0.000"
    # Si falla: la exactitud de la base no es 1 - 21/900 → el test no es el que se cree.
    base = p.linea_base(particion)
    ok(abs(base["exactitud"] - (1 - 21 / 900)) < 1e-12,
       f"línea base: exactitud {base['exactitud']:.4f}")
    ok(base["recall"] == 0.0, "la línea base no detecta ningún fraude (recall 0)")
    proba_simple = p.modelo_simple(particion)
    ok(len(proba_simple) == 900 and float(proba_simple.min()) >= 0 and float(proba_simple.max()) <= 1,
       "el modelo simple da una probabilidad por fila de test")

    # Paso 4 · Comprueba el boosting, la matriz fuera de muestra y las métricas
    # Por qué: el criterio de la ficha es matriz fuera de muestra con precisión y recall; se recalcula
    #          la matriz desde las probabilidades y se comprueba que cuadra con las métricas.
    # Salida esperada: "umbral 0,50: TP 1 · FP 2 · FN 20 · TN 877 · precisión 0.333 · recall 0.048"
    # Si falla: la matriz no suma 900 o la precisión no cuadra con las celdas.
    modelo, proba_xgb = p.entrenar_xgboost(particion)
    met = p.evaluar(particion, proba_xgb)
    ok(met["tp"] + met["fp"] + met["fn"] + met["tn"] == 900, "la matriz suma 900 (el test)")
    ok(met["tp"] + met["fn"] == 21, "los positivos de la matriz son los 21 del test")
    ok(abs(met["precision"] - met["tp"] / (met["tp"] + met["fp"])) < 1e-12,
       f"precisión coherente: {met['precision']:.3f}")
    ok(abs(met["recall"] - met["tp"] / (met["tp"] + met["fn"])) < 1e-12,
       f"recall coherente: {met['recall']:.3f}")
    ok(met["pr_auc"] > 2 * (69 / 3000), f"PR-AUC {met['pr_auc']:.3f} supera dos veces la prevalencia")
    ok(met["roc_auc"] > 0.7, f"ROC-AUC {met['roc_auc']:.3f} > 0.7")

    # Paso 5 · Comprueba el barrido de umbrales y el umbral por coste
    # Por qué: el umbral es una decisión de coste; se comprueba que el elegido no cuesta más que el 0,5
    #          con la misma tabla de costes.
    # Salida esperada: "umbral por coste: 0.04 cuesta 1390.00 EUR · el 0.50 cuesta 4010.00 EUR"
    # Si falla: el umbral elegido cuesta más que 0,50 → el barrido o los costes están mal.
    tabla = p.barrer_umbrales(particion, proba_xgb)
    ok(len(tabla) == 95, f"el barrido tiene {len(tabla)} cortes (0,01 a 0,95)")
    mejor = tabla.loc[tabla["coste_eur"].idxmin()]
    coste_050 = float(tabla.loc[tabla["umbral"].sub(0.50).abs().idxmin(), "coste_eur"])
    ok(mejor["coste_eur"] <= coste_050,
       f"umbral {mejor['umbral']:.2f} cuesta {mejor['coste_eur']:.2f} EUR y el 0,50 {coste_050:.2f} EUR")
    ok(mejor["umbral"] != 0.50, f"el umbral elegido ({mejor['umbral']:.2f}) no es el 0,5 por defecto")

    # Paso 6 · Comprueba la comparación con la línea base y el sitio de `hora`
    # Por qué: el informe tiene que distinguir señal de ruido; `hora` no entra en el generador del
    #          fraude, así que su puesto en las importancias se publica sin llamarlo causal.
    # Salida esperada: "comparación: línea base · logística simple · xgboost" y "hora en el puesto …"
    # Si falla: falta una fila de la comparación o falta la variable hora en las importancias.
    importancias_df = p.importancias(modelo, particion["columnas"])
    ok(abs(float(importancias_df["importancia"].sum()) - 1) < 1e-6,
       f"las importancias suman {importancias_df['importancia'].sum():.3f}")
    ok("hora" in set(importancias_df["variable"]), "las importancias incluyen la variable hora")
    comparacion = p.comparar(particion, base, proba_simple, proba_xgb, met)
    ok(len(comparacion) == 3, f"comparación con {len(comparacion)} modelos (base, simple, boosting)")
    ok(float(comparacion.loc[comparacion["modelo"] == "logística simple", "pr_auc"].iloc[0])
       > 2 * (69 / 3000), "el modelo simple también supera dos veces la prevalencia en PR-AUC")

    # Paso 7 · Comprueba la reproducibilidad con semilla fija
    # Por qué: un informe que no se puede repetir no sirve; la misma semilla tiene que dar las mismas
    #          probabilidades y el mismo umbral.
    # Salida esperada: "la misma semilla da las mismas probabilidades"
    # Si falla: dos ajustes dan probabilidades distintas → el modelo no es determinista.
    _, proba2 = p.entrenar_xgboost(particion)
    ok(np.array_equal(proba_xgb, proba2), "la misma semilla da las mismas probabilidades")

    # Paso 8 · Comprueba que el código es offline y no lleva secretos
    # Por qué: la puerta se ejecuta sin red y la carpeta se comparte.
    # Salida esperada: "código offline, sin claves"
    # Si falla: aparece una llamada de red o un token en el código.
    texto = (p.RAIZ / "modelo.py").read_text(encoding="utf-8")
    ok(not any(x in texto for x in ("import requests", "import urllib", "import socket",
                                    "urlopen(", "requests.get")),
       "el código no hace peticiones de red")
    ok(not any(x in texto for x in ("ghp_", "github_pat_", "Authorization:")),
       "el código no contiene claves ni cabeceras de autorización")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
