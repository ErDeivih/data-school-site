#!/usr/bin/env python3
"""P38 · XGBoost con clases desequilibradas.

Código ejecutable del proyecto P38 (ruta ciencia). Mide el desbalanceo, entrena un boosting de árboles
con partición estratificada, presenta la matriz de confusión fuera de muestra, barre umbrales con una
tabla de costes declarada y compara todo con una línea base y un modelo simple.

Uso:
    python modelo.py            # pipeline completo; escribe las tablas en resultados/
    python modelo.py limpiar    # borra las tablas generadas

Datos: datos-ejemplo/transacciones-fraude.csv (3000 filas × 9 columnas, CC0-1.0; procedencia en el
README). Sin red: solo numpy, pandas, scikit-learn y xgboost.
"""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo" / "transacciones-fraude.csv"
RESULTADOS = RAIZ / "resultados"

SEMILLA = 20261105
TEST = 0.30
UMBRAL_DEFECTO = 0.50
COSTE_FN = 200.0  # supuesto: un fraude no detectado cuesta 200 EUR (reclamación + gestión)
COSTE_FP = 5.0    # supuesto: una revisión manual de un pago legítimo cuesta 5 EUR
UMBRALES = np.round(np.arange(0.01, 0.951, 0.01), 2)

NUMERICAS = ["importe_eur", "hora", "intentos_24h", "antiguedad_dias"]
CATEGORICAS = ["canal", "pais", "dispositivo"]
COLUMNAS = ["id", "importe_eur", "hora", "canal", "pais", "dispositivo",
            "intentos_24h", "antiguedad_dias", "fraude"]
GENERADOS = ["clases.csv", "matriz.csv", "umbrales.csv", "comparacion-modelos.csv",
             "importancias.csv"]


def exigir(condicion: bool, mensaje: str) -> None:
    """Aborta con un mensaje legible; el pipeline devuelve 1 y no deja resultados a medias."""
    if not condicion:
        raise RuntimeError(mensaje)


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def cargar() -> pd.DataFrame:
    # Paso 1 · Carga el CSV y comprueba claves, rangos, categorías y prevalencia
    # Por qué: con 69 positivos, un fichero distinto o una categoría nueva cambian el resultado; el
    #          contrato del crudo se comprueba antes de entrenar.
    # Salida esperada: "datos: 3000 filas × 9 columnas · id único · 69 fraudes (2.30 %) · sha256 830cd8b8…"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o recupera el CSV de datos-ejemplo/.
    exigir(DATOS.exists(), f"no existe el dato de ejemplo: {DATOS}")
    df = pd.read_csv(DATOS)
    exigir(list(df.columns) == COLUMNAS, f"columnas inesperadas: {list(df.columns)}")
    exigir(len(df) == 3000, f"se esperaban 3000 filas y hay {len(df)}")
    exigir(df["id"].is_unique, "la columna id tiene duplicados")
    exigir(int(df.isna().sum().sum()) == 0, "el CSV trae valores nulos")
    exigir(int(df["fraude"].sum()) == 69, f"se esperaban 69 fraudes y hay {int(df['fraude'].sum())}")
    exigir(df["importe_eur"].between(5, 900).all(), "importe fuera de rango")
    exigir(df["hora"].between(0, 23).all(), "hora fuera de 0-23")
    exigir(df["intentos_24h"].between(1, 8).all(), "intentos fuera de 1-8")
    exigir(df["antiguedad_dias"].between(1, 1180).all(), "antigüedad fuera de rango")
    print(f"datos: {len(df)} filas × {df.shape[1]} columnas · id único · "
          f"{int(df['fraude'].sum())} fraudes ({df['fraude'].mean() * 100:.2f} %) · "
          f"sha256 {sha256(DATOS)[:8]}…")
    return df


def preparar(df: pd.DataFrame) -> dict:
    # Paso 2 · Parte de forma estratificada y construye la matriz sin la etiqueta
    # Por qué: con 69 positivos, una partición al azar puede dejar el test sin fraudes; la etiqueta no
    #          entra como variable y las categóricas se codifican una vez para train y test.
    # Salida esperada: "partición: 2100 train / 900 test · positivos 48 y 21"
    # Si falla: positivos 0 en test → falta stratify en train_test_split.
    dummies = pd.get_dummies(df[CATEGORICAS], dtype=float)
    X = np.hstack([df[NUMERICAS].to_numpy(float), dummies.to_numpy()])
    y = df["fraude"].to_numpy(int)
    indices = np.arange(len(df))
    idx_tr, idx_te = train_test_split(indices, test_size=TEST, random_state=SEMILLA, stratify=y)
    print(f"partición: {len(idx_tr)} train / {len(idx_te)} test · "
          f"positivos {int(y[idx_tr].sum())} y {int(y[idx_te].sum())}")
    return {"X_tr": X[idx_tr], "X_te": X[idx_te], "y_tr": y[idx_tr], "y_te": y[idx_te],
            "columnas": NUMERICAS + list(dummies.columns)}


def linea_base(particion: dict) -> dict:
    # Paso 3 · Mide la línea base «nunca fraude»
    # Por qué: con 2,3 % de positivos, decir siempre que no hay fraude acierta el 97,7 % y no detecta
    #          nada; sin ese suelo, una exactitud alta parece un resultado.
    # Salida esperada: "línea base: exactitud 0.977 · precisión 0.000 · recall 0.000"
    # Si falla: exactitud distinta de 1 - prevalencia → el test no es el que se cree.
    y_te = particion["y_te"]
    aciertos = int((y_te == 0).sum())
    exactitud = aciertos / len(y_te)
    print(f"línea base: exactitud {exactitud:.3f} · precisión 0.000 · recall 0.000 · "
          f"detecta 0 de {int(y_te.sum())} fraudes")
    return {"exactitud": exactitud, "precision": 0.0, "recall": 0.0, "pr_auc": 0.0,
            "roc_auc": 0.5, "tp": 0, "fp": 0, "fn": int(y_te.sum()), "tn": aciertos}


def modelo_simple(particion: dict) -> np.ndarray:
    # Paso 4 · Entrena el modelo simple de comparación (regresión logística escalada)
    # Por qué: la ficha pide un modelo simple con las mismas métricas que el boosting; si el boosting
    #          no lo supera, la conclusión es que el boosting no aporta.
    # Salida esperada: "modelo simple: probabilidad media en test 0.0…"
    # Si falla: ConvergenceWarning → sube max_iter; con 3000 filas no aparece.
    escalador = StandardScaler().fit(particion["X_tr"])
    modelo = LogisticRegression(max_iter=2000, random_state=SEMILLA)
    modelo.fit(escalador.transform(particion["X_tr"]), particion["y_tr"])
    proba = modelo.predict_proba(escalador.transform(particion["X_te"]))[:, 1]
    print(f"modelo simple: probabilidad media en test {proba.mean():.4f}")
    return proba


def entrenar_xgboost(particion: dict) -> tuple[XGBClassifier, np.ndarray]:
    # Paso 5 · Entrena el boosting de árboles con semilla fija
    # Por qué: el boosting es el modelo del proyecto; el desbalanceo no se corrige ponderando y
    #          moviendo el umbral a la vez, así que el umbral se decide después, en el barrido.
    # Salida esperada: "xgboost: 80 árboles de profundidad 3 · probabilidad media en test 0.0…"
    # Si falla: ValueError de xgboost → revisa que la etiqueta sea 0/1 y que eval_metric esté puesto.
    modelo = XGBClassifier(n_estimators=80, max_depth=3, learning_rate=0.1, subsample=0.9,
                           colsample_bytree=0.9, tree_method="hist", n_jobs=1,
                           random_state=SEMILLA, eval_metric="logloss", verbosity=0)
    modelo.fit(particion["X_tr"], particion["y_tr"])
    proba = modelo.predict_proba(particion["X_te"])[:, 1]
    print(f"xgboost: {modelo.n_estimators} árboles de profundidad {modelo.max_depth} · "
          f"probabilidad media en test {proba.mean():.4f}")
    return modelo, proba


def evaluar(particion: dict, proba: np.ndarray, verbose: bool = True) -> dict:
    # Paso 6 · Presenta la matriz de confusión fuera de muestra y las métricas que importan
    # Por qué: la exactitud sola esconde el fallo; precisión, recall y PR-AUC se calculan juntos y la
    #          matriz se publica para ver cuántos fraudes se cuelan y cuántos falsos positivos cuesta.
    # Salida esperada: "umbral 0,50: TP … · FP … · FN … · TN … · precisión … · recall … · PR-AUC …"
    # Si falla: la matriz no suma 900 → la partición y las probabilidades no son el mismo test.
    y = particion["y_te"]
    pred = (proba >= UMBRAL_DEFECTO).astype(int)
    tp = int(((pred == 1) & (y == 1)).sum())
    fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum())
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    pr_auc = float(average_precision_score(y, proba))
    roc_auc = float(roc_auc_score(y, proba))
    exactitud = (tp + tn) / len(y)
    if verbose:
        print(f"umbral 0,50: TP {tp} · FP {fp} · FN {fn} · TN {tn} · precisión {precision:.3f} · "
              f"recall {recall:.3f} · F1 {f1:.3f} · PR-AUC {pr_auc:.3f} · ROC-AUC {roc_auc:.3f}")
    return {"tp": tp, "fp": fp, "fn": fn, "tn": tn, "precision": precision, "recall": recall,
            "f1": f1, "pr_auc": pr_auc, "roc_auc": roc_auc, "exactitud": exactitud}


def barrer_umbrales(particion: dict, proba: np.ndarray, coste_fn: float = COSTE_FN,
                    coste_fp: float = COSTE_FP, verbose: bool = True) -> pd.DataFrame:
    # Paso 7 · Barre umbrales y calcula el coste esperado de cada corte
    # Por qué: el umbral es una decisión de coste; su valor sale de minimizar FN·200 + FP·5, no de
    #          heredar el 0,5. Los dos costes son supuestos y se declaran en el README.
    # Salida esperada: "umbral por coste: 0.0… cuesta … EUR · el 0.50 cuesta … EUR"
    # Si falla: todos los costes iguales → las probabilidades no varían; revisa el modelo.
    y = particion["y_te"]
    filas = []
    for umbral in UMBRALES:
        pred = (proba >= umbral).astype(int)
        tp = int(((pred == 1) & (y == 1)).sum())
        fp = int(((pred == 1) & (y == 0)).sum())
        fn = int(((pred == 0) & (y == 1)).sum())
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        filas.append({"umbral": float(umbral), "tp": tp, "fp": fp, "fn": fn,
                      "precision": round(precision, 4), "recall": round(recall, 4),
                      "coste_eur": round(fn * coste_fn + fp * coste_fp, 2)})
    tabla = pd.DataFrame(filas)
    mejor = tabla.loc[tabla["coste_eur"].idxmin()]
    peor = tabla.loc[tabla["umbral"].sub(UMBRAL_DEFECTO).abs().idxmin()]
    if verbose:
        print(f"umbral por coste: {mejor['umbral']:.2f} cuesta {mejor['coste_eur']:.2f} EUR · "
              f"el 0.50 cuesta {peor['coste_eur']:.2f} EUR")
    return tabla


def importancias(modelo: XGBClassifier, columnas: list[str]) -> pd.DataFrame:
    # Paso 8 · Publica las importancias y comprueba el sitio de `hora`
    # Por qué: `hora` se generó fuera de la fórmula del fraude; si el modelo la pone arriba, está
    #          explotando casualidad y el informe tiene que decirlo, no llamarlo causal.
    # Salida esperada: "importancias: top 5 … · hora en el puesto … de 13"
    # Si falla: la suma de importancias no es 1 → el modelo no es el esperado.
    tabla = pd.DataFrame({"variable": columnas, "importancia": modelo.feature_importances_})
    tabla = tabla.sort_values("importancia", ascending=False).reset_index(drop=True)
    puesto_hora = int(tabla.index[tabla["variable"] == "hora"][0]) + 1
    top = ", ".join(f"{fila.variable} {fila.importancia:.3f}"
                    for fila in tabla.head(5).itertuples())
    print(f"importancias: top 5 {top} · hora en el puesto {puesto_hora} de {len(tabla)}")
    return tabla


def comparar(particion: dict, base: dict, proba_simple: np.ndarray,
             proba_xgb: np.ndarray, met_xgb: dict) -> pd.DataFrame:
    # Paso 9 · Junta la línea base, el modelo simple y el boosting en una tabla
    # Por qué: el criterio de la ficha es comparar con la línea base; una tabla con las mismas
    #          métricas para los tres evita comparar peras con manzanas.
    # Salida esperada: "comparación: línea base 0.000 PR-AUC · simple … · xgboost …"
    # Si falla: la tabla no tiene tres filas → falta uno de los modelos.
    met_simple = evaluar(particion, proba_simple, verbose=False)
    filas = [
        {"modelo": "línea base (nunca fraude)", **base},
        {"modelo": "logística simple", **met_simple},
        {"modelo": "xgboost", **met_xgb},
    ]
    tabla = pd.DataFrame(filas)
    print("comparación: " + " · ".join(f"{fila.modelo} recall {fila.recall:.3f} PR-AUC "
                                       f"{fila.pr_auc:.3f}" for fila in tabla.itertuples()))
    return tabla


def escribir(df: pd.DataFrame, particion: dict, comparacion: pd.DataFrame, tabla: pd.DataFrame,
             importancias_df: pd.DataFrame) -> None:
    # Paso 10 · Escribe las tablas del proyecto
    # Por qué: cada cifra del README sale de estos CSV; sin ellos la comparación no se reproduce.
    # Salida esperada: "resultados: clases.csv, matriz.csv, umbrales.csv, comparacion-modelos.csv,
    #                   importancias.csv"
    # Si falla: PermissionError → revisa permisos de resultados/.
    RESULTADOS.mkdir(exist_ok=True)
    pd.DataFrame([
        {"particion": "todo", "filas": len(df), "fraudes": int(df["fraude"].sum())},
        {"particion": "train", "filas": len(particion["y_tr"]), "fraudes": int(particion["y_tr"].sum())},
        {"particion": "test", "filas": len(particion["y_te"]), "fraudes": int(particion["y_te"].sum())},
    ]).to_csv(RESULTADOS / "clases.csv", index=False)
    xgb = comparacion[comparacion["modelo"] == "xgboost"].iloc[0]
    pd.DataFrame([{"tp": xgb.tp, "fp": xgb.fp, "fn": xgb.fn, "tn": xgb.tn}]).to_csv(
        RESULTADOS / "matriz.csv", index=False)
    tabla.to_csv(RESULTADOS / "umbrales.csv", index=False)
    comparacion.to_csv(RESULTADOS / "comparacion-modelos.csv", index=False)
    importancias_df.to_csv(RESULTADOS / "importancias.csv", index=False)
    print("resultados: clases.csv, matriz.csv, umbrales.csv, comparacion-modelos.csv, importancias.csv")


def limpiar() -> None:
    # Paso 11 · Borra las tablas generadas y deja la carpeta como descargada
    # Por qué: el ZIP no lleva resultados derivados; se regeneran con `python modelo.py`.
    # Salida esperada: "limpiar: resultados/ generados borrados"
    # Si falla: PermissionError → cierra el programa que tenga abierto un CSV de resultados/.
    for nombre in GENERADOS:
        (RESULTADOS / nombre).unlink(missing_ok=True)
    print("limpiar: resultados/ generados borrados")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="XGBoost con clases desequilibradas (P38)")
    parser.add_argument("accion", nargs="?", default="todo", choices=["todo", "limpiar"])
    args = parser.parse_args(argv)
    if args.accion == "limpiar":
        limpiar()
        return 0
    try:
        df = cargar()
        particion = preparar(df)
        base = linea_base(particion)
        proba_simple = modelo_simple(particion)
        modelo, proba_xgb = entrenar_xgboost(particion)
        met_xgb = evaluar(particion, proba_xgb)
        tabla = barrer_umbrales(particion, proba_xgb)
        importancias_df = importancias(modelo, particion["columnas"])
        comparacion = comparar(particion, base, proba_simple, proba_xgb, met_xgb)
        escribir(df, particion, comparacion, tabla, importancias_df)
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con resultados a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
