"""P69 · Amarillas: el partido que se calienta.

Modela las tarjetas de un partido contra el volumen de juego y el desequilibrio de posesión:
¿se sacan más amarillas cuando hay más tiros o cuando un equipo domina? Sin librerías.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("jornada", "local", "visitante", "goles_local", "goles_visitante",
            "tiros_local", "tiros_visitante", "xg_local", "xg_visitante",
            "posesion_local", "amarillas", "resultado")


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: goles, tiros, posesión y amarillas numéricos.
    # Por qué: una tarjeta negativa o una posesión de 200 rompe el modelo sin dar error.
    # Salida esperada: 380 partidos con todas las columnas.
    # Si falla: «columnas inesperadas», un valor no numérico o posesión fuera de 0..100.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 380:
        raise ValueError(f"se esperaban 380 partidos, hay {len(filas)}")
    for fila in filas:
        for columna in ("goles_local", "goles_visitante", "tiros_local", "tiros_visitante", "amarillas"):
            if int(fila[columna]) < 0:
                raise ValueError(f"{columna} negativa")
        posesion = float(fila["posesion_local"])
        if not 0 <= posesion <= 100:
            raise ValueError("posesión fuera de 0..100")
    return filas


def variables(filas: list[dict]) -> list[dict]:
    # Paso 2 · Construir las variables del modelo: volumen de tiros y desequilibrio de posesión.
    # Por qué: «domina» no es lo mismo que «tira mucho»; se separan para no confundirlos.
    # Salida esperada: 380 filas con tiros_totales y desequilibrio.
    salida = []
    for fila in filas:
        tiros = int(fila["tiros_local"]) + int(fila["tiros_visitante"])
        desequilibrio = abs(float(fila["posesion_local"]) - 50)
        salida.append({**fila, "tiros_totales": tiros, "desequilibrio": desequilibrio,
                       "amarillas": int(fila["amarillas"])})
    return salida


def ols(filas: list[dict]) -> dict:
    # Paso 3 · OLS: amarillas = b0 + b1·tiros_totales + b2·desequilibrio.
    # Por qué: permite leer cada efecto manteniendo el otro; una correlación simple los mezcla.
    # Salida esperada: coeficientes, R² y error típico de la regresión.
    # Si falla: matriz singular (variables constantes).
    x = [[1.0, f["tiros_totales"], f["desequilibrio"]] for f in filas]
    y = [f["amarillas"] for f in filas]
    k = 3
    xtx = [[sum(x[i][a] * x[i][b] for i in range(len(x))) for b in range(k)] for a in range(k)]
    xty = [sum(x[i][a] * y[i] for i in range(len(x))) for a in range(k)]
    # Gauss-Jordan 3×3.
    m = [xtx[i][:] + [xty[i]] for i in range(k)]
    for col in range(k):
        piv = max(range(col, k), key=lambda r: abs(m[r][col]))
        if abs(m[piv][col]) < 1e-12:
            raise ValueError("matriz singular")
        m[col], m[piv] = m[piv], m[col]
        div = m[col][col]
        m[col] = [v / div for v in m[col]]
        for r in range(k):
            if r == col:
                continue
            f = m[r][col]
            m[r] = [m[r][c] - f * m[col][c] for c in range(k + 1)]
    beta = [m[i][k] for i in range(k)]
    residuos = [y[i] - sum(beta[j] * x[i][j] for j in range(k)) for i in range(len(y))]
    sc = sum(r * r for r in residuos)
    st = sum((v - sum(y) / len(y)) ** 2 for v in y)
    return {"beta": beta, "r2": 1 - sc / st, "rmse": math.sqrt(sc / len(y))}


def extremos(filas: list[dict]) -> list[dict]:
    # Paso 4 · Los partidos con más y menos amarillas, con su contexto.
    # Por qué: el modelo da una tendencia; los extremos dicen dónde mirar.
    orden = sorted(filas, key=lambda f: f["amarillas"], reverse=True)
    return [{"jornada": f["jornada"], "local": f["local"], "visitante": f["visitante"],
             "amarillas": f["amarillas"], "tiros": f["tiros_totales"], "desequilibrio": f["desequilibrio"]}
            for f in orden[:5]]


def main() -> int:
    parser = argparse.ArgumentParser(description="P69 · tarjetas, tiros y desequilibrio")
    parser.add_argument("--csv", default="datos-ejemplo/futbol-partidos.csv")
    args = parser.parse_args()

    filas = variables(leer(Path(args.csv)))
    modelo = ols(filas)
    print(f"datos: {len(filas)} partidos · amarillas medias {sum(f['amarillas'] for f in filas) / len(filas):.2f}")
    print(f"modelo: b0 {modelo['beta'][0]:+.3f} · tiros totales {modelo['beta'][1]:+.4f} · "
          f"desequilibrio {modelo['beta'][2]:+.4f} · R² {modelo['r2']:.3f} · RMSE {modelo['rmse']:.3f}")
    print("partidos con más amarillas:")
    for f in extremos(filas):
        print(f"  J{f['jornada']} {f['local']}–{f['visitante']}: {f['amarillas']} tarjetas · "
              f"{f['tiros']} tiros · desequilibrio {f['desequilibrio']:.0f}")
    print(f"lectura: R² {modelo['r2']:.3f}: tiros y desequilibrio casi no explican las tarjetas; el modelo "
          "sirve para descartar la explicación fácil, no para predecir un partido caliente.")
    print("límite: 380 partidos sintéticos y una sola cifra de tarjetas por partido; no distingue equipo, "
          "momento ni árbitro.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
