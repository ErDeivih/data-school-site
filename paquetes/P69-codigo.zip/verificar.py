#!/usr/bin/env python3
"""Puerta del proyecto P69 (amarillas: el partido que se calienta).

Comprueba datos, variables, coeficientes, R², extremos y ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import amarillas

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "futbol-partidos.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = amarillas.variables(amarillas.leer(CSV))
    ok(len(filas) == 380, "el CSV tiene 380 partidos")
    ok(all(f["tiros_totales"] > 0 for f in filas), "todos los partidos tienen tiros")
    ok(all(0 <= f["desequilibrio"] <= 50 for f in filas), "el desequilibrio está entre 0 y 50")
    cerca(sum(f["amarillas"] for f in filas) / 380, 3.208, 0.01, "amarillas medias por partido")

    modelo = amarillas.ols(filas)
    cerca(modelo["beta"][0], 3.197, 0.01, "intercepto del modelo")
    cerca(modelo["beta"][1], -0.0192, 0.001, "coeficiente de tiros totales")
    cerca(modelo["beta"][2], 0.0393, 0.001, "coeficiente de desequilibrio")
    cerca(modelo["r2"], 0.013, 0.002, "R² del modelo")
    cerca(modelo["rmse"], 1.823, 0.01, "RMSE del modelo")
    ok(modelo["r2"] < 0.05, "el modelo no pretende explicar las tarjetas con dos variables")

    extremos = amarillas.extremos(filas)
    ok(extremos[0]["amarillas"] == 6, "el partido con más amarillas tiene 6")
    ok(extremos[0]["jornada"] == "1", "el primer extremo es de la jornada 1")

    codigo = (AQUI / "amarillas.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
