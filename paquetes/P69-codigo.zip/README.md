# P69 · Amarillas: el partido que se calienta

Paquete descargable de **Data School** para el proyecto P69. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es si las tarjetas se explican por el juego: **¿hay más amarillas cuando hay
más tiros o cuando un equipo domina?** El código separa volumen (`tiros_totales`) y desequilibrio de
posesión, ajusta un OLS y encuentra que **casi no explican nada** (R² **0,013**): el modelo sirve
para descartar la explicación fácil, no para predecir un partido caliente.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python amarillas.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P69-codigo
python amarillas.py --csv datos-ejemplo/futbol-partidos.csv
```

## Salida esperada

```text
datos: 380 partidos · amarillas medias 3.21
modelo: b0 +3.197 · tiros totales -0.0192 · desequilibrio +0.0393 · R² 0.013 · RMSE 1.823
partidos con más amarillas:
  J1 equipo-02–equipo-11: 6 tarjetas · 16 tiros · desequilibrio 9
  …
lectura: R² 0.013: tiros y desequilibrio casi no explican las tarjetas; el modelo sirve para
descartar la explicación fácil, no para predecir un partido caliente.
límite: 380 partidos sintéticos y una sola cifra de tarjetas por partido; no distingue equipo,
momento ni árbitro.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/futbol-partidos.csv`: **380 filas × 12 columnas**. 38 jornadas, 20 equipos, goles,
  tiros, xG, posesión, amarillas y resultado.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `futbol-partidos` del catálogo.
- `sha256`: `5cbc8977b6c9d4f7ae66bfcc7642c93a6655faf7b6e6524a6d40480e2e66a12e`.

## Qué enseña

| Paso | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida 380 partidos y rangos | una posesión de 200 rompe el modelo |
| 2 · Variables | separa tiros totales y desequilibrio | «domina» no es «tira mucho» |
| 3 · OLS | ajusta tarjetas con dos variables | leer efectos, no correlaciones sueltas |
| 4 · Extremos | lista los partidos con más tarjetas | dónde mirar después del modelo |

## Las trampas que deja a la vista

1. **Correlación no es explicación.** El coeficiente de desequilibrio es positivo pero minúsculo
   (+0,039 por punto): con R² 0,013, el modelo no permite predecir.
2. **La variable depende del grano.** Solo hay **una cifra de tarjetas por partido**, sin equipo ni
   minuto; cualquier conclusión sobre «quién las recibe» excede estos datos.
3. **Un R² bajo también es un resultado.** Descartar la explicación fácil evita construir una
   narrativa sobre ruido; el artículo lo dice en vez de esconderlo.

## Fallos típicos

- **`ModuleNotFoundError: amarillas`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`**: el CSV no es el del catálogo.
- **`matriz singular`**: una variable es constante en la muestra.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P69-codigo/
├── amarillas.py               # variables, OLS y extremos
├── verificar.py               # 14 comprobaciones
├── requirements.txt
├── datos-ejemplo/futbol-partidos.csv
└── resultados/ejemplo-salida.txt
```

## Límite

380 partidos sintéticos y una sola cifra de tarjetas por partido; no hay equipo, minuto, árbitro ni
contexto. El paquete enseña a **descartar** una explicación con datos, no a predecir tarjetas.
