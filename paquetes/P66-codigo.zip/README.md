# P66 · La factura de la luz: dónde se va el dinero

Paquete descargable de **Data School** para el proyecto P66. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es de hogar, no de mercado: con 10 kWh diarios, **¿cuánto cuesta la
factura, qué horas son las caras y cuánto se ahorra moviendo el 20 % del consumo** de las 4 horas
más caras a las 4 más baratas? El resultado: coste base **0,4372 €/día**, trasladado **0,3328 €/día**
y un ahorro de **3,13 €/mes** (23,9 %). El límite: mover consumo, no consumir menos.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python factura.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P66-codigo
python factura.py --csv datos-ejemplo/precios-luz.csv
```

## Salida esperada

```text
datos: 1440 horas · 60 días · 24 horas del día
precio medio: 43.72 €/MWh
horas caras: 19, 20, 21, 22 · horas baratas: 12, 13, 14, 15
coste diario base (10 kWh): 0.4372 € · trasladando el 20 %: 0.3328 €
ahorro: 0.1044 €/día · 3.13 €/mes · 23.88 %
lectura: el ahorro sale de mover consumo, no de consumir menos; si no se puede mover, no existe.
límite: 60 días sintéticos y un consumo plano; no hay tarifas fijas, impuestos ni potencia contratada.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/precios-luz.csv`: **1440 filas × 7 columnas**. 60 días × 24 horas con precio
  €/MWh, demanda, eólica, solar y día de la semana.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `precios-luz` del catálogo. No son
  precios reales de ningún mercado.
- `sha256`: `e858a6605c840306c01c19f1343ef9bb2a765cf500b50c043c5a39ba8f244773`.

## Qué enseña cada paso

| Paso | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida 24 horas por día y precios positivos | el grano antes que la media |
| 2 · Perfil | media de cada hora, no media global | la factura depende de cuándo consumes |
| 3 · Coste | coste base de 10 kWh y horas caras/baratas | pasar €/MWh a euros de factura |
| 4 · Traslado | mover 20 % del consumo y medir ahorro | una promesa con euros, no con adjetivos |

## Las trampas que deja a la vista

1. **La media global esconde la decisión.** Dos días con la misma media pueden tener horas caras
   distintas; el perfil por hora es lo que permite mover consumo.
2. **Ahorrar no es consumir menos.** El código mueve kWh, no los elimina; si no se pueden mover, el
   ahorro no existe.
3. **La factura real no es solo el precio.** Faltan potencia contratada, impuestos y tarifas fijas;
   el artículo lo declara en el límite.

## Fallos típicos

- **`ModuleNotFoundError: factura`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`**: el CSV no es el del catálogo.
- **`horas caras y baratas se solapan`**: hay menos de 8 horas distintas.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P66-codigo/
├── factura.py                 # perfil por hora, coste y traslado del consumo
├── verificar.py               # 17 comprobaciones
├── requirements.txt
├── datos-ejemplo/precios-luz.csv
└── resultados/ejemplo-salida.txt
```

## Límite

60 días sintéticos y un consumo plano de 10 kWh/día; no hay tarifas fijas, impuestos, potencia
contratada ni cambios de hábito. El paquete enseña el **método** (perfil, coste, ahorro y límite),
no una factura real.
