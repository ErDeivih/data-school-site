"""P66 · La factura de la luz: dónde se va el dinero.

Convierte 60 días de precios horarios en una decisión de hogar: cuánto cuesta un consumo diario,
qué horas son las caras y cuánto se ahorra desplazando un 20 % del consumo de las 4 horas más caras
a las 4 más baratas. Sin librerías: solo la estándar.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("fecha", "hora", "precio_eur_mwh", "demanda_mw", "eolica_mw", "solar_mw", "dia_semana")
CONSUMO_DIA_KWH = 10.0
DIAS_MES = 30
HORAS_CARAS = 4
HORAS_BARATAS = 4
DESPLAZAR = 0.20


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: 24 horas por día, precios positivos y sin fechas repetidas.
    # Por qué: una hora duplicada o un precio no numérico rompe la media por hora.
    # Salida esperada: 1440 filas (60 días × 24 horas) y 24 horas distintas.
    # Si falla: «columnas inesperadas», una hora fuera de 0..23 o un precio no numérico.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 1440:
        raise ValueError(f"se esperaban 1440 filas, hay {len(filas)}")
    for fila in filas:
        hora = int(fila["hora"])
        if not 0 <= hora <= 23:
            raise ValueError(f"hora fuera de 0..23: {hora}")
        if float(fila["precio_eur_mwh"]) <= 0:
            raise ValueError("precio no positivo")
    if len({(f["fecha"], f["hora"]) for f in filas}) != len(filas):
        raise ValueError("hay (fecha, hora) repetidas")
    return filas


def perfil(filas: list[dict]) -> list[dict]:
    # Paso 2 · Precio medio por hora del día, no una media global.
    # Por qué: la factura depende de CUÁNDO se consume; la media global esconde las horas caras.
    # Salida esperada: 24 filas con media y número de días.
    # Si falla: una hora sin observaciones.
    por_hora = defaultdict(list)
    for fila in filas:
        por_hora[int(fila["hora"])].append(float(fila["precio_eur_mwh"]))
    if len(por_hora) != 24:
        raise ValueError("faltan horas en el CSV")
    return [{"hora": h, "media": sum(v) / len(v), "n": len(v)}
            for h, v in sorted(por_hora.items())]


def coste(filas: list[dict], perfil_: list[dict]) -> dict:
    # Paso 3 · Coste diario con consumo repartido y traslado del 20 % de las horas caras.
    # Por qué: «ahorrar» sin decir cuánto se mueve y a dónde es una promesa vacía.
    # Salida esperada: coste base, coste trasladado y ahorro mensual.
    # Si falla: las horas caras y baratas se solapan.
    orden = sorted(perfil_, key=lambda x: x["media"], reverse=True)
    caras = {f["hora"] for f in orden[:HORAS_CARAS]}
    baratas = {f["hora"] for f in orden[-HORAS_BARATAS:]}
    if caras & baratas:
        raise ValueError("las horas caras y baratas se solapan")
    kwh_hora = CONSUMO_DIA_KWH / 24
    base = sum(kwh_hora * f["media"] for f in perfil_) / 1000
    a_mover = CONSUMO_DIA_KWH * DESPLAZAR
    coste_caras = sum(kwh_hora * f["media"] for f in perfil_ if f["hora"] in caras) / 1000
    # Se retira de cada hora cara una parte proporcional y se reparte entre las baratas.
    retira = a_mover / HORAS_CARAS
    coste_caras_nuevo = sum((kwh_hora - retira) * f["media"] for f in perfil_ if f["hora"] in caras) / 1000
    anade = a_mover / HORAS_BARATAS
    coste_baratas = sum(kwh_hora * f["media"] for f in perfil_ if f["hora"] in baratas) / 1000
    coste_baratas_nuevo = sum((kwh_hora + anade) * f["media"] for f in perfil_ if f["hora"] in baratas) / 1000
    trasladado = base - coste_caras + coste_caras_nuevo - coste_baratas + coste_baratas_nuevo
    ahorro_dia = base - trasladado
    return {"caras": sorted(caras), "baratas": sorted(baratas), "base": base,
            "trasladado": trasladado, "ahorro_dia": ahorro_dia,
            "ahorro_mes": ahorro_dia * DIAS_MES,
            "ahorro_pct": (ahorro_dia / base) * 100 if base else 0.0}


def main() -> int:
    parser = argparse.ArgumentParser(description="P66 · factura de la luz y traslado de consumo")
    parser.add_argument("--csv", default="datos-ejemplo/precios-luz.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    perfil_ = perfil(filas)
    datos = coste(filas, perfil_)
    print(f"datos: {len(filas)} horas · {len({f['fecha'] for f in filas})} días · {len(perfil_)} horas del día")
    print(f"precio medio: {sum(f['media'] for f in perfil_) / 24:.2f} €/MWh")
    print(f"horas caras: {', '.join(map(str, datos['caras']))} · horas baratas: {', '.join(map(str, datos['baratas']))}")
    print(f"coste diario base (10 kWh): {datos['base']:.4f} € · trasladando el 20 %: {datos['trasladado']:.4f} €")
    print(f"ahorro: {datos['ahorro_dia']:.4f} €/día · {datos['ahorro_mes']:.2f} €/mes · {datos['ahorro_pct']:.2f} %")
    print("lectura: el ahorro sale de mover consumo, no de consumir menos; si no se puede mover, no existe.")
    print("límite: 60 días sintéticos y un consumo plano; no hay tarifas fijas, impuestos ni potencia contratada.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
