#!/usr/bin/env python3
"""Puerta del proyecto P66 (la factura de la luz).

Comprueba horas, perfil, coste base y traslado de consumo, y ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import factura

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "precios-luz.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = factura.leer(CSV)
    ok(len(filas) == 1440, "el CSV tiene 1440 horas")
    ok(len({f["fecha"] for f in filas}) == 60, "hay 60 días")
    ok(len({int(f["hora"]) for f in filas}) == 24, "hay 24 horas del día")

    perfil = factura.perfil(filas)
    ok(len(perfil) == 24, "el perfil tiene 24 horas")
    ok(all(p["n"] == 60 for p in perfil), "cada hora tiene 60 observaciones")
    cerca(sum(p["media"] for p in perfil) / 24, 43.72, 0.05, "precio medio del perfil")

    datos = factura.coste(filas, perfil)
    ok(datos["caras"] == [19, 20, 21, 22], "las horas caras son 19–22")
    ok(datos["baratas"] == [12, 13, 14, 15], "las horas baratas son 12–15")
    ok(not set(datos["caras"]) & set(datos["baratas"]), "horas caras y baratas no se solapan")
    cerca(datos["base"], 0.4372, 0.0002, "coste diario base de 10 kWh")
    cerca(datos["trasladado"], 0.3328, 0.0002, "coste trasladando el 20 %")
    cerca(datos["ahorro_dia"], 0.1044, 0.0002, "ahorro diario")
    cerca(datos["ahorro_mes"], 3.13, 0.01, "ahorro mensual (30 días)")
    cerca(datos["ahorro_pct"], 23.88, 0.05, "ahorro porcentual")
    ok(0 < datos["trasladado"] < datos["base"], "el traslado reduce el coste y no lo deja negativo")

    codigo = (AQUI / "factura.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
