# P51 · Valoración: DCF, comparables y rango objetivo — código ejecutable

Valora `EMP-A` con un descuento de flujos de caja libre, la compara con la otra empresa de su sector y
devuelve un rango objetivo con sensibilidad al WACC y al crecimiento terminal. El WACC se presenta con
sus piezas (tasa libre de riesgo, prima, beta, coste de la deuda) y el peso del valor terminal se
declara. Es el código que acompaña a la ficha
`../../fichas-ideas/p51-valoracion-dcf-y-comparables.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** (BSD-3-Clause) y **numpy >= 1.26** (BSD-3-Clause).
- Windows, Linux o macOS: sin red ni servicios externos.

## Instalación

```powershell
cd proyectos/p51-valoracion-dcf-y-comparables/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python valoracion.py
```

Recorre los pasos, imprime una línea por paso y escribe en `resultados/` los ficheros `dcf.csv`,
`comparables.csv`, `sensibilidad.csv`, `wacc.csv` e `informe.md`. Los generados no viajan en el ZIP:
solo `ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: los supuestos base de `EMP-A`, el WACC desde sus
componentes (6,66 %), el FCF de los cinco años (2026: 268,8 M€; 2030: 334,6 M€), el descuento y el valor
terminal (valor por acción 25,46 € con el 81,1 % del valor en el terminal), el múltiplo EV/EBITDA del
único comparable del sector (7,58x), la sensibilidad 3×3 (rango 17,12–46,28 €) y la declaración de
fuentes y límites. Termina en `RESULTADO: VERDE` (0) o `RESULTADO: ROJO` (1). No usa red. La salida real
está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/fundamentales-empresa.csv`: **50 filas × 16 columnas**, diez empresas (`EMP-A`…`EMP-J`)
  y cinco ejercicios (2021–2025). Importes en **millones de euros**; `acciones` en millones y
  `precio_accion` en euros por acción.
- **Sintético, determinista y CC0-1.0**: copia literal de `datasets/csv/`, con
  `sha256:e05cdc41668342dac3235cc7d8bd8f1871e355f8f720632ce681641c7b63f3cb`; tamaño y columnas en
  `datasets-nuevos-2026-11-05.json`.
- El CSV **no trae** capex, variación de capital circulante, caja, dividendos, beta, prima de riesgo ni
  tipos de interés: el código los sustituye por supuestos declarados y lo dice en el informe.

## Fuente real y licencia

- **Tipos:** el proyecto real toma la tasa libre de riesgo de **FRED**, serie `DGS10` (rendimiento del
  Tesoro de EE. UU. a 10 años, <https://fred.stlouisfed.org/series/DGS10>), con clave gratuita. Los
  términos de uso de FRED no alteran los derechos de las series, que pueden ser de terceros; la serie
  `DGS10` procede del H.15 de la Reserva Federal. **Aquí el 3,0 % es un supuesto de ejemplo** para poder
  ejecutar sin red; el informe lo declara y no lo presenta como dato descargado.
- **Estados financieros:** `sec-edgar` (<https://data.sec.gov/api/xbrl/>), sin clave; datos del Gobierno
  de EE. UU. reutilizables citando a la SEC. Es el contraste real de las cuentas.
- Dependencias: pandas BSD-3-Clause, numpy BSD-3-Clause.

## Supuestos declarados

- **Crecimiento, margen EBIT y coste de la deuda** salen de la serie 2021–2025 de `EMP-A`.
- **Capex = depreciación** (reposición) y **ΔWC = 10 % de la variación de ingresos**: supuestos escritos.
- **Prima de riesgo 5 %, beta 1,0, g terminal 2 % y tasa libre de riesgo 3,0 %**: supuestos declarados;
  el proyecto real cambia la tasa por el valor de FRED `DGS10` en la fecha de valoración.
- **Caja = 0**: el CSV no trae caja; el equity es valor de empresa menos deuda.
- **Comparables:** solo hay dos empresas por sector; se usa el par, se dice que es uno solo y que un
  múltiplo único no es una mediana de sector.
- **El rango no es un precio ni una recomendación**: es una horquilla con una variable movida cada vez.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y validar | Clave natural y series completas por empresa | `Calidad de datos` |
| 2 · Supuestos y WACC | Beta, prima y coste de capital con sus piezas | `Alpha y beta` |
| 3 · Flujo de caja libre | De EBITDA a FCF con capex y capital circulante | `Datos de mercado y acciones corporativas` |
| 4 · Descuento y terminal | Valor actual y peso del valor terminal | `Curva de tipos y descuento` |
| 5 · Comparables | Múltiplos con unidades homogéneas y un solo par | `Datos de mercado y acciones corporativas` |
| 6 · Sensibilidad | Mover una variable cada vez y dar un rango | `Predicción con incertidumbre` |
| 7 · Informe con límite | Separar valor, fuente y supuesto | `Escribir un informe` |

## Estructura

```text
codigo/
├── valoracion.py          # supuestos, WACC, FCF, DCF, comparables, sensibilidad e informe
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas y numpy
├── datos-ejemplo/         # fundamentales-empresa.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **`ModuleNotFoundError: pandas`**: instala las dependencias con el mismo Python que ejecuta el script.
- **`ValueError: WACC debe ser mayor que g terminal`**: has subido demasiado el crecimiento terminal o
  bajado el WACC en la sensibilidad; corrige el supuesto, no el divisor.
- **El valor por acción se dispara**: revisa si el terminal pesa más del 85 % del valor; es la señal de
  que el DCF depende casi solo del supuesto de crecimiento.
- **Múltiplo absurdo**: mezclar millones de euros con euros por acción; el EV se calcula con capital
  (precio × acciones) y deuda, ambos en millones.
- **`KeyError` de empresa**: el identificador debe existir en el CSV y tener cinco ejercicios.
