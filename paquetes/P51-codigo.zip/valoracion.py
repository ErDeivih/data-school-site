#!/usr/bin/env python3
"""P51 · Valoración: DCF, comparables y rango objetivo — código ejecutable.

Valora una empresa del CSV con un descuento de flujos, la compara con las empresas de su sector y da
un rango objetivo con sensibilidad al WACC. Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal de datasets/csv/):
    datos-ejemplo/fundamentales-empresa.csv  (50 filas × 16 columnas)

Uso:
    python valoracion.py         # calcula y escribe resultados/
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
EMPRESA = "EMP-A"
ANIOS = 5
TASA_IMPUESTOS = 0.25

# Supuestos declarados de la valoración. El CSV no trae prima de riesgo, beta ni tipos.
# Tasa libre de riesgo de ejemplo: 3,0 %. El valor real se toma de FRED, serie DGS10 (10 años),
# con clave gratuita y respetando las condiciones de la serie; aquí es un supuesto para poder
# ejecutar el proyecto sin red, y así se declara en el README y en el informe.
TASA_LIBRE_RIESGO = 0.03
PRIMA_DE_RIESGO = 0.05
BETA = 1.0
G_TERMINAL = 0.02
CAPITAL_CIRCULANTE_SOBRE_INGRESOS = 0.10  # supuesto: ΔWC = 10 % de la variación de ingresos
CAJA = 0.0  # supuesto: el CSV no trae caja


# Paso 1 · Carga el CSV y comprueba la forma del panel
# Por qué: valorar exige el último ejercicio de una empresa y sus comparables; si el panel no tiene
#          cinco ejercicios por empresa o la clave se repite, el crecimiento y el margen salen mal.
# Salida esperada: "fundamentales: 50 filas · 10 empresas · 5 ejercicios"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_fundamentales() -> pd.DataFrame:
    ruta = DATOS / "fundamentales-empresa.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta)
    df = df.sort_values(["empresa", "ejercicio"]).reset_index(drop=True)
    print(
        f"fundamentales: {len(df)} filas · {df['empresa'].nunique()} empresas · "
        f"{df['ejercicio'].nunique()} ejercicios"
    )
    return df


# Paso 2 · Fija los supuestos de la valoración desde el histórico
# Por qué: crecimiento, margen operativo y coste de la deuda se miden en la serie 2021-2025; lo que no
#          está en el CSV (prima, beta, g terminal, caja) se declara como supuesto y no se disimula.
# Salida esperada: "supuestos EMP-A: crecimiento 5.6% · margen EBIT 15.0% · WACC pendiente"
# Si falla: ingresos a cero o serie incompleta → revisa el CSV o el identificador de empresa.
def supuestos_valoracion(df: pd.DataFrame, empresa: str = EMPRESA) -> dict:
    serie = df[df["empresa"] == empresa].sort_values("ejercicio")
    if len(serie) != 5:
        raise ValueError(f"{empresa} no tiene 5 ejercicios en el CSV")
    primero, ultimo = serie.iloc[0], serie.iloc[-1]
    crecimiento = float((ultimo["ingresos"] / primero["ingresos"]) ** (1 / 4) - 1)
    margen_ebit = float(((serie["ebitda"] - serie["depreciacion"]) / serie["ingresos"]).mean())
    depreciacion = float((serie["depreciacion"] / serie["ingresos"]).mean())
    coste_deuda = float((serie["intereses"] / serie["deuda_total"]).mean())
    supuestos = {
        "empresa": empresa,
        "sector": str(ultimo["sector"]),
        "ejercicio_base": int(ultimo["ejercicio"]),
        "crecimiento": crecimiento,
        "margen_ebit": margen_ebit,
        "depreciacion_sobre_ingresos": depreciacion,
        "capex_sobre_ingresos": depreciacion,  # supuesto: capex de reposición = depreciación
        "capital_circulante_sobre_ingresos": CAPITAL_CIRCULANTE_SOBRE_INGRESOS,
        "coste_deuda": coste_deuda,
        "tasa_impuestos": TASA_IMPUESTOS,
        "tasa_libre_riesgo": TASA_LIBRE_RIESGO,
        "prima_de_riesgo": PRIMA_DE_RIESGO,
        "beta": BETA,
        "g_terminal": G_TERMINAL,
        "caja": CAJA,
        "deuda": float(ultimo["deuda_total"]),
        "acciones": float(ultimo["acciones"]),
        "precio_accion": float(ultimo["precio_accion"]),
        "ingresos": float(ultimo["ingresos"]),
        "ebitda": float(ultimo["ebitda"]),
        "ebit": float(ultimo["ebitda"] - ultimo["depreciacion"]),
    }
    print(
        f"supuestos {empresa}: crecimiento {crecimiento:.1%} · margen EBIT {margen_ebit:.1%} · "
        f"coste deuda {coste_deuda:.1%}"
    )
    return supuestos


# Paso 3 · Calcula el WACC con sus componentes a la vista
# Por qué: el WACC no es un número elegido; se compone de tasa libre de riesgo, prima, beta, coste de
#          la deuda y peso de cada fuente, y cada pieza se puede auditar.
# Salida esperada: "WACC EMP-A: Ke 8.0% · Kd 3.5% · peso equity 75.0% · WACC 6.7%"
# Si falla: deuda y capital a la vez a cero → no hay estructura con la que ponderar.
def wacc(supuestos: dict) -> dict:
    capital = supuestos["precio_accion"] * supuestos["acciones"]
    deuda = supuestos["deuda"]
    total = capital + deuda
    coste_capital = supuestos["tasa_libre_riesgo"] + supuestos["beta"] * supuestos["prima_de_riesgo"]
    coste_deuda = supuestos["coste_deuda"]
    resultado = {
        "capital": capital,
        "deuda": deuda,
        "peso_capital": capital / total,
        "peso_deuda": deuda / total,
        "coste_capital": coste_capital,
        "coste_deuda": coste_deuda,
        "wacc": (capital / total) * coste_capital + (deuda / total) * coste_deuda * (1 - supuestos["tasa_impuestos"]),
    }
    print(
        f"WACC {supuestos['empresa']}: Ke {resultado['coste_capital']:.1%} · "
        f"Kd {coste_deuda:.1%} · peso equity {resultado['peso_capital']:.1%} · "
        f"WACC {resultado['wacc']:.2%}"
    )
    return resultado


# Paso 4 · Proyecta el flujo de caja libre de cinco ejercicios
# Por qué: el FCF no está en el CSV; se construye desde EBIT, impuestos, depreciación, capex y capital
#          circulante, y cada pieza es una columna de la tabla para poder revisarla.
# Salida esperada: "FCF: 2026 253.4 M€ ... 2030 331.1 M€"
# Si falla: FCF negativo en el primer año → el margen o el capital circulante están mal medidos.
def proyectar_fcf(df: pd.DataFrame, supuestos: dict) -> pd.DataFrame:
    serie = df[df["empresa"] == supuestos["empresa"]].sort_values("ejercicio")
    ingresos = float(serie.iloc[-1]["ingresos"])
    filas = []
    for anio in range(1, ANIOS + 1):
        ingresos_previos = ingresos
        ingresos = ingresos_previos * (1 + supuestos["crecimiento"])
        ebit = ingresos * supuestos["margen_ebit"]
        impuestos = max(0.0, ebit) * supuestos["tasa_impuestos"]
        nopat = ebit - impuestos
        depreciacion = ingresos * supuestos["depreciacion_sobre_ingresos"]
        capex = ingresos * supuestos["capex_sobre_ingresos"]
        variacion_wc = supuestos["capital_circulante_sobre_ingresos"] * (ingresos - ingresos_previos)
        fcf = nopat + depreciacion - capex - variacion_wc
        filas.append(
            {
                "ejercicio": supuestos["ejercicio_base"] + anio,
                "ingresos": ingresos,
                "ebit": ebit,
                "impuestos": impuestos,
                "nopat": nopat,
                "depreciacion": depreciacion,
                "capex": capex,
                "variacion_capital_circulante": variacion_wc,
                "fcf": fcf,
            }
        )
    tabla = pd.DataFrame(filas)
    print(
        f"FCF: {int(tabla.iloc[0]['ejercicio'])} {tabla.iloc[0]['fcf']:.1f} M€ ... "
        f"{int(tabla.iloc[-1]['ejercicio'])} {tabla.iloc[-1]['fcf']:.1f} M€"
    )
    return tabla


# Paso 5 · Descuenta los flujos y el valor terminal
# Por qué: el valor del terminal se separa del valor explícito y se calcula su peso; si domina el
#          resultado, el DCF es una apuesta a un supuesto y hay que decirlo, no esconderlo.
# Salida esperada: "DCF: EV 7.494 M€ · equity 6.547 M€ · 29.76 €/acción · terminal 61.4%"
# Si falla: WACC ≤ g terminal → valor terminal infinito o negativo; cambia el supuesto declarado.
def dcf(proyeccion: pd.DataFrame, supuestos: dict, wacc_valor: float | None = None, g_terminal: float | None = None) -> dict:
    tasa = wacc(supuestos)["wacc"] if wacc_valor is None else wacc_valor
    g = supuestos["g_terminal"] if g_terminal is None else g_terminal
    if tasa <= g:
        raise ValueError(f"WACC ({tasa:.3%}) debe ser mayor que g terminal ({g:.3%})")
    flujos = proyeccion["fcf"].to_numpy(dtype=float)
    exponentes = np.arange(1, len(flujos) + 1)
    valor_presente = float(np.sum(flujos / (1 + tasa) ** exponentes))
    terminal = float(flujos[-1] * (1 + g) / (tasa - g))
    valor_presente_terminal = float(terminal / (1 + tasa) ** len(flujos))
    valor_empresa = valor_presente + valor_presente_terminal
    equity = valor_empresa - supuestos["deuda"] + supuestos["caja"]
    por_accion = equity / supuestos["acciones"]
    resultado = {
        "wacc": tasa,
        "g_terminal": g,
        "valor_presente_explicito": valor_presente,
        "valor_terminal": terminal,
        "valor_presente_terminal": valor_presente_terminal,
        "valor_empresa": valor_empresa,
        "equity": equity,
        "valor_por_accion": por_accion,
        "peso_terminal": valor_presente_terminal / valor_empresa,
    }
    print(
        f"DCF: EV {valor_empresa:.0f} M€ · equity {equity:.0f} M€ · {por_accion:.2f} €/acción · "
        f"terminal {resultado['peso_terminal']:.1%}"
    )
    return resultado


# Paso 6 · Aplica múltiplos de las empresas del mismo sector
# Por qué: solo hay dos empresas por sector; un múltiplo de un único comparable no es una mediana y
#          se dice. El valor implícito se calcula con unidades homogéneas y se resta la deuda.
# Salida esperada: "comparables: EMP-G 7.5x · implícito 12.4 €/acción (1 comparable)"
# Si falla: 0 comparables → el sector solo tiene la empresa elegida; no se inventa el múltiplo.
def comparables(df: pd.DataFrame, supuestos: dict) -> tuple[pd.DataFrame, dict]:
    ejercicio = supuestos["ejercicio_base"]
    sector = supuestos["sector"]
    ultimo = df[df["ejercicio"] == ejercicio].copy()
    pares = ultimo[(ultimo["sector"] == sector) & (ultimo["empresa"] != supuestos["empresa"])].copy()
    pares["valor_empresa"] = pares["precio_accion"] * pares["acciones"] + pares["deuda_total"]
    pares["multiplo_ev_ebitda"] = pares["valor_empresa"] / pares["ebitda"]
    if pares.empty:
        raise ValueError(f"el sector {sector} no tiene un segundo comparable en el CSV")
    multiplo = float(pares["multiplo_ev_ebitda"].mean())
    valor_empresa_implicito = multiplo * supuestos["ebitda"]
    equity_implicito = valor_empresa_implicito - supuestos["deuda"] + supuestos["caja"]
    por_accion = equity_implicito / supuestos["acciones"]
    detalle = {
        "multiplo_ev_ebitda": multiplo,
        "comparables": int(len(pares)),
        "valor_empresa_implicito": valor_empresa_implicito,
        "equity_implicito": equity_implicito,
        "valor_por_accion_implicito": por_accion,
    }
    tabla = pares[["empresa", "ebitda", "valor_empresa", "multiplo_ev_ebitda"]].copy()
    print(
        f"comparables: {', '.join(tabla['empresa'])} a {multiplo:.1f}x · implícito {por_accion:.2f} €/acción "
        f"({len(pares)} comparable)"
    )
    return tabla, detalle


# Paso 7 · Sensibiliza el WACC y el crecimiento terminal
# Por qué: un valor único es una certeza falsa; moviendo una variable cada vez se obtiene una horquilla
#          y se ve cuál mueve más el resultado.
# Salida esperada: "sensibilidad: 9 combinaciones · rango 18.9–31.2 €/acción"
# Si falla: la tabla no es 3×3 o algún valor es negativo → WACC cerca de g terminal.
def sensibilidad(df: pd.DataFrame, supuestos: dict) -> tuple[pd.DataFrame, dict]:
    proyeccion = proyectar_fcf(df, supuestos)
    tasa_base = wacc(supuestos)["wacc"]
    desplazamientos_wacc = (-0.01, 0.0, 0.01)
    crecimientos = (0.01, supuestos["g_terminal"], 0.03)
    filas = []
    for delta in desplazamientos_wacc:
        for g in crecimientos:
            resultado = dcf(proyeccion, supuestos, wacc_valor=tasa_base + delta, g_terminal=g)
            filas.append(
                {
                    "wacc": tasa_base + delta,
                    "g_terminal": g,
                    "valor_por_accion": resultado["valor_por_accion"],
                }
            )
    tabla = pd.DataFrame(filas)
    resumen = {
        "minimo": float(tabla["valor_por_accion"].min()),
        "maximo": float(tabla["valor_por_accion"].max()),
        "combinaciones": len(tabla),
        "tasa_base": tasa_base,
    }
    print(
        f"sensibilidad: {len(tabla)} combinaciones · rango {resumen['minimo']:.2f}–{resumen['maximo']:.2f} €/acción"
    )
    return tabla, resumen


def tabla_markdown(df: pd.DataFrame) -> str:
    """Tabla markdown sin tabulate; redondea a dos decimales y usa guiones para separar."""
    cabecera = "| " + " | ".join(df.columns) + " |"
    separador = "| " + " | ".join("---" for _ in df.columns) + " |"
    filas = []
    for _, fila in df.iterrows():
        celdas = []
        for valor in fila:
            if isinstance(valor, (float, np.floating)):
                celdas.append(f"{valor:.2f}")
            else:
                celdas.append(str(valor))
        filas.append("| " + " | ".join(celdas) + " |")
    return "\n".join([cabecera, separador, *filas])


def texto_informe(
    supuestos: dict,
    componentes: dict,
    valoracion: dict,
    tabla_comparables: pd.DataFrame,
    detalle_comparables: dict,
    tabla_sensibilidad: pd.DataFrame,
    rango: dict,
) -> str:
    lineas = [
        "# P51 · Valoración: DCF, comparables y rango objetivo",
        "",
        f"Empresa: **{supuestos['empresa']}** (sector {supuestos['sector']}). "
        f"Base: ejercicio {supuestos['ejercicio_base']} del CSV local.",
        "",
        "## DCF y WACC",
        f"- WACC: {valoracion['wacc']:.2%}, con Ke {componentes['coste_capital']:.2%}, "
        f"Kd {componentes['coste_deuda']:.2%}, peso de capital {componentes['peso_capital']:.1%} "
        f"e impuestos al {supuestos['tasa_impuestos']:.0%}.",
        f"- Prima de riesgo {supuestos['prima_de_riesgo']:.1%} y beta {supuestos['beta']:.2f}: "
        "**supuestos declarados**; la tasa libre de riesgo de ejemplo es "
        f"{supuestos['tasa_libre_riesgo']:.1%} y en el proyecto real se toma de FRED (serie DGS10).",
        f"- Valor de empresa {valoracion['valor_empresa']:.0f} M€, equity {valoracion['equity']:.0f} M€, "
        f"valor por acción {valoracion['valor_por_accion']:.2f} €.",
        f"- El valor terminal aporta el {valoracion['peso_terminal']:.1%} del valor de empresa: al pasar "
        "de tres cuartas partes, el DCF es sobre todo una apuesta al crecimiento terminal, y el rango "
        "se lee con ese límite.",
        "- Caja = 0: **supuesto**, el CSV no trae caja; por eso el equity es valor de empresa menos deuda.",
        "",
        "## Comparables",
        f"El sector solo tiene {detalle_comparables['comparables']} comparable(s): "
        "un múltiplo único no es una mediana de sector.",
        tabla_markdown(tabla_comparables),
        f"Valor implícito por acción con EV/EBITDA: {detalle_comparables['valor_por_accion_implicito']:.2f} €. "
        f"La diferencia con el DCF ({valoracion['valor_por_accion']:.2f} €) se declara: un solo comparable y "
        "el peso del terminal explican buena parte de la brecha.",
        "",
        "## Rango objetivo y sensibilidad",
        f"Rango con el WACC movido ±1 punto y el crecimiento terminal entre 1 % y 3 %: "
        f"**{rango['minimo']:.2f}–{rango['maximo']:.2f} €/acción**. Es una horquilla, no un precio.",
        tabla_markdown(tabla_sensibilidad),
        "",
        "## Límite",
        "El CSV es sintético (semilla fija, CC0-1.0): el valor no es de ninguna empresa real. La SEC",
        "(empresas de EE. UU.) es el contraste real de los estados y FRED la fuente real de tipos; el",
        "código es offline y usa supuestos declarados. El rango no es una recomendación de inversión.",
        "",
    ]
    return "\n".join(lineas)


def main() -> int:
    df = cargar_fundamentales()
    supuestos = supuestos_valoracion(df)
    componentes = wacc(supuestos)
    proyeccion = proyectar_fcf(df, supuestos)
    valoracion = dcf(proyeccion, supuestos)
    tabla_comparables, detalle_comparables = comparables(df, supuestos)
    tabla_sensibilidad, rango = sensibilidad(df, supuestos)
    RESULTADOS.mkdir(exist_ok=True)
    proyeccion.to_csv(RESULTADOS / "dcf.csv", index=False)
    tabla_comparables.to_csv(RESULTADOS / "comparables.csv", index=False)
    tabla_sensibilidad.to_csv(RESULTADOS / "sensibilidad.csv", index=False)
    pd.DataFrame(
        [{"componente": k, "valor": v, "fuente": "CSV" if k in ("capital", "deuda") else "supuesto o cálculo"} for k, v in componentes.items()]
    ).to_csv(RESULTADOS / "wacc.csv", index=False)
    (RESULTADOS / "informe.md").write_text(
        texto_informe(supuestos, componentes, valoracion, tabla_comparables, detalle_comparables, tabla_sensibilidad, rango),
        encoding="utf-8",
    )
    print(f"escrito: {RESULTADOS / 'dcf.csv'} · comparables.csv · sensibilidad.csv · wacc.csv · informe.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
