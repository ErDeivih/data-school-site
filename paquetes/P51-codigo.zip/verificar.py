#!/usr/bin/env python3
"""Puerta del proyecto P51 · valoración con DCF, comparables y rango objetivo.

Recalcula el WACC con sus componentes, el flujo de caja libre, el descuento y el valor terminal, los
múltiplos de las empresas del mismo sector y la sensibilidad al WACC. No usa red y **no escribe
ficheros**: solo calcula y saca conclusiones por stdout.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import valoracion

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P51 · valoración con DCF y comparables ==")

    # Paso 1 · Comprueba los datos y los supuestos declarados
    # Por qué: sin cinco ejercicios por empresa no hay crecimiento ni margen histórico que usar.
    # Salida esperada: "datos: 50 filas · 10 empresas · 5 ejercicios"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    df = valoracion.cargar_fundamentales()
    ok(
        (len(df), df["empresa"].nunique(), df["ejercicio"].nunique()) == (50, 10, 5),
        f"datos: {len(df)} filas · {df['empresa'].nunique()} empresas · {df['ejercicio'].nunique()} ejercicios",
    )
    supuestos = valoracion.supuestos_valoracion(df)
    ok(abs(supuestos["crecimiento"] - 0.056294) < 1e-5, f"crecimiento histórico de EMP-A: {supuestos['crecimiento']:.4f}")
    ok(0.14 < supuestos["margen_ebit"] < 0.16, f"margen EBIT de EMP-A: {supuestos['margen_ebit']:.4f}")
    ok(
        supuestos["tasa_libre_riesgo"] == 0.03 and supuestos["prima_de_riesgo"] == 0.05
        and supuestos["beta"] == 1.0 and supuestos["g_terminal"] == 0.02 and supuestos["caja"] == 0.0,
        "los supuestos que no están en el CSV están declarados (tipos, prima, beta, g y caja)",
    )

    # Paso 2 · Recalcula el WACC con sus componentes
    # Por qué: el WACC tiene que salir de sus piezas, no ser un número elegido; se reconstruye aparte.
    # Salida esperada: "WACC: Ke 8.0% · Kd 3.5% · peso equity 75.0% · WACC 6.66%"
    # Si falla: la ponderación no suma 1 o el WACC no coincide con la fórmula.
    componentes = valoracion.wacc(supuestos)
    recalculado = (
        componentes["peso_capital"] * componentes["coste_capital"]
        + componentes["peso_deuda"] * componentes["coste_deuda"] * (1 - supuestos["tasa_impuestos"])
    )
    ok(abs(componentes["wacc"] - recalculado) < 1e-12, f"WACC recalculado: {recalculado:.6f}")
    ok(abs(componentes["wacc"] - 0.066554) < 1e-5, f"WACC base: {componentes['wacc']:.4%}")
    ok(
        abs(componentes["peso_capital"] + componentes["peso_deuda"] - 1) < 1e-12
        and abs(componentes["coste_capital"] - 0.08) < 1e-12,
        "la ponderación suma 1 y Ke = tasa libre de riesgo + beta × prima = 8,0 %",
    )

    # Paso 3 · Recalcula el FCF y comprueba que sale de sus piezas
    # Por qué: el FCF es la base de todo el DCF; si sus componentes no encadenan, el valor no es auditable.
    # Salida esperada: "FCF: 5 ejercicios · 2026 268.8 · 2030 334.6 M€"
    # Si falla: FCF distinto de NOPAT + dep − capex − ΔWC → alguna pieza está mal restada.
    proyeccion = valoracion.proyectar_fcf(df, supuestos)
    ok(len(proyeccion) == 5, f"FCF: {len(proyeccion)} ejercicios proyectados")
    recalculado_fcf = (
        proyeccion["nopat"] + proyeccion["depreciacion"] - proyeccion["capex"]
        - proyeccion["variacion_capital_circulante"]
    )
    ok(bool((recalculado_fcf - proyeccion["fcf"]).abs().lt(1e-9).all()), "FCF = NOPAT + depreciación − capex − ΔWC")
    ok(bool((proyeccion["capex"] - proyeccion["depreciacion"]).abs().lt(1e-9).all()),
       "capex = depreciación: supuesto declarado de reposición")
    ok(
        abs(proyeccion.iloc[0]["fcf"] - 268.783226) < 1e-4 and abs(proyeccion.iloc[-1]["fcf"] - 334.612004) < 1e-4,
        f"FCF 2026 {proyeccion.iloc[0]['fcf']:.2f} M€ · 2030 {proyeccion.iloc[-1]['fcf']:.2f} M€",
    )

    # Paso 4 · Comprueba el descuento, el valor terminal y el valor por acción
    # Por qué: el valor por acción es la afirmación central; se reconstruye desde los flujos y el WACC.
    # Salida esperada: "DCF: EV 6548 M€ · equity 5601 M€ · 25.46 €/acción · terminal 81.1%"
    # Si falla: EV distinto de la suma de descuentos → el valor terminal no está bien descontado.
    valoracion_dcf = valoracion.dcf(proyeccion, supuestos)
    tasa = componentes["wacc"]
    flujos = proyeccion["fcf"].to_numpy(dtype=float)
    exponentes = np.arange(1, len(flujos) + 1)
    pv_explicito = float(np.sum(flujos / (1 + tasa) ** exponentes))
    terminal = float(flujos[-1] * (1 + supuestos["g_terminal"]) / (tasa - supuestos["g_terminal"]))
    pv_terminal = float(terminal / (1 + tasa) ** len(flujos))
    ok(abs(valoracion_dcf["valor_presente_explicito"] - pv_explicito) < 1e-6, "el valor explícito descuenta los cinco flujos")
    ok(abs(valoracion_dcf["valor_empresa"] - (pv_explicito + pv_terminal)) < 1e-6, "EV = valor explícito + valor terminal descontado")
    ok(
        abs(valoracion_dcf["equity"] - (valoracion_dcf["valor_empresa"] - supuestos["deuda"] + supuestos["caja"])) < 1e-9,
        "equity = EV − deuda (+ caja declarada 0)",
    )
    por_accion = valoracion_dcf["equity"] / supuestos["acciones"]
    ok(abs(valoracion_dcf["valor_por_accion"] - por_accion) < 1e-12 and abs(por_accion - 25.458723) < 1e-5,
       f"valor por acción: {por_accion:.4f} €")
    ok(0.75 < valoracion_dcf["peso_terminal"] < 0.9,
       f"el valor terminal pesa {valoracion_dcf['peso_terminal']:.1%}: se declara, no se esconde")

    # Paso 5 · Comprueba los comparables del mismo sector
    # Por qué: solo hay dos empresas por sector; el código debe usar el par y declarar que es uno solo.
    # Salida esperada: "comparables: EMP-G 7.58x · implícito 12.87 €/acción (1 comparable)"
    # Si falla: el comparable es de otro sector o el valor implícito no resta la deuda.
    tabla_comparables, detalle = valoracion.comparables(df, supuestos)
    ok(list(tabla_comparables["empresa"]) == ["EMP-G"] and detalle["comparables"] == 1,
       f"comparable del sector energia: {list(tabla_comparables['empresa'])}")
    ok(abs(detalle["multiplo_ev_ebitda"] - 7.580142) < 1e-5, f"múltiplo EV/EBITDA: {detalle['multiplo_ev_ebitda']:.4f}x")
    implicito = (detalle["multiplo_ev_ebitda"] * supuestos["ebitda"] - supuestos["deuda"]) / supuestos["acciones"]
    ok(abs(detalle["valor_por_accion_implicito"] - implicito) < 1e-9, f"valor implícito: {implicito:.4f} €/acción")
    ok(detalle["valor_por_accion_implicito"] < valoracion_dcf["valor_por_accion"],
       "el comparable da menos que el DCF: la brecha se declara en el informe")

    # Paso 6 · Comprueba la sensibilidad y el rango
    # Por qué: un rango solo vale si mueve una variable cada vez y la dirección es la esperada.
    # Salida esperada: "sensibilidad: 9 combinaciones · rango 17.12–46.28 €/acción"
    # Si falla: 9 combinaciones mal o un valor no monótono → la rejilla está mal construida.
    tabla_sensibilidad, rango = valoracion.sensibilidad(df, supuestos)
    ok(rango["combinaciones"] == 9 and len(tabla_sensibilidad) == 9, f"sensibilidad: {rango['combinaciones']} combinaciones")
    wacc_bajo = tabla_sensibilidad[tabla_sensibilidad["wacc"] < rango["tasa_base"]]
    wacc_alto = tabla_sensibilidad[tabla_sensibilidad["wacc"] > rango["tasa_base"]]
    ok(
        float(wacc_bajo.groupby("g_terminal")["valor_por_accion"].mean().iloc[0]) > float(wacc_alto.groupby("g_terminal")["valor_por_accion"].mean().iloc[0]),
        "más WACC implica menos valor por acción",
    )
    por_g = tabla_sensibilidad.groupby("g_terminal")["valor_por_accion"].mean()
    ok(bool(por_g.is_monotonic_increasing), "más crecimiento terminal implica más valor por acción")
    ok(abs(rango["minimo"] - 17.120860) < 1e-5 and abs(rango["maximo"] - 46.282542) < 1e-5,
       f"rango objetivo: {rango['minimo']:.2f}–{rango['maximo']:.2f} €/acción")

    # Paso 7 · Comprueba que el informe declara fuentes, supuestos y límite
    # Por qué: la valoración sin fuente ni límite es una opinión con formato de tabla.
    # Salida esperada: "el informe declara FRED, supuestos, terminal y límite"
    # Si falla: falta la procedencia de la tasa o el aviso de que es una horquilla.
    informe = valoracion.texto_informe(
        supuestos, componentes, valoracion_dcf, tabla_comparables, detalle, tabla_sensibilidad, rango
    )
    ok("FRED" in informe and "supuesto" in informe.lower(), "el informe nombra FRED y marca los supuestos")
    ok("horquilla" in informe and "no es una recomendación" in informe, "el rango se presenta como horquilla y sin consejo")
    ok("SEC" in informe and "Límite" in informe, "el informe declara el contraste real y su límite")

    # Paso 8 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (valoracion.RAIZ / "valoracion.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
