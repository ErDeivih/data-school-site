#!/usr/bin/env python3
"""Puerta del proyecto P19 (¿merece la pena el undercut?).

Comprueba stints, pares a igual edad de neumático, efecto con intervalo, prueba de signos, informe
con regla/grupos/límite y ausencia de red/claves. VERDE (0) solo si todo pasa; ROJO (1) si falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import undercut

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "telemetria-f1.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = undercut.leer(CSV)
    ok(len(filas) == 180, "el CSV tiene 180 vueltas")
    ok(len({(f["carrera"], f["piloto"]) for f in filas}) == 6, "hay 6 pares carrera/piloto")
    ok(all(f["compuesto"] in undercut.COMPUESTOS for f in filas), "todas las vueltas declaran compuesto válido")

    stints_ = undercut.stints(filas)
    ok(len(stints_) == 6, "hay 6 stints (3 carreras × 2 pilotos)")
    ok(all(v["parada"] == 18 for (c, p), v in stints_.items() if p == "A"), "A para en la vuelta 18")
    ok(all(v["parada"] == 22 for (c, p), v in stints_.items() if p == "B"), "B espera a la vuelta 22")
    ok(all(v["despues"] for v in stints_.values()), "cada stint tiene vueltas posteriores con edad de neumático")

    pares_ = undercut.pares(stints_)
    ok(len(pares_) == 24, "hay 24 pares (3 carreras × 8 edades)")
    ok(all(p["B"] > 0 and p["A"] > 0 for p in pares_), "todos los pares tienen tiempos positivos")

    datos = undercut.informe(pares_)
    ok(datos["n"] == 24, "el informe usa 24 pares")
    cerca(datos["a_media"], 88.567, 0.01, "media posterior de A (paró antes)")
    cerca(datos["b_media"], 88.552, 0.01, "media posterior de B (esperó)")
    cerca(datos["media"], -0.0145, 0.001, "efecto medio B − A")
    cerca(datos["sd"], 0.2831, 0.002, "desviación de las diferencias")
    cerca(datos["ee"], 0.0578, 0.001, "error típico")
    cerca(datos["bajo"], -0.1278, 0.002, "límite inferior del IC95 %")
    cerca(datos["alto"], 0.0988, 0.002, "límite superior del IC95 %")
    ok(datos["bajo"] < 0 < datos["alto"], "el intervalo cruza 0")
    ok(datos["positivas"] == 12 and datos["p_signos"] == 1.0, "12 de 24 positivas y p de signos 1,0")

    documento = undercut.texto(pares_, datos)
    for fragmento, descripcion in [
        ("undercut = parar antes", "regla del undercut"),
        ("A · paró antes", "grupo que para antes"),
        ("B · esperó", "grupo que espera"),
        ("Intervalo al 95 %", "intervalo"),
        ("Límite causal", "límite causal"),
        ("no hay evidencia", "lectura honesta"),
    ]:
        ok(fragmento in documento, f"el informe incluye {descripcion}")
    ok("0.0145" in documento or "0,0145" in documento, "el informe cifra el efecto")

    codigo = (AQUI / "undercut.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
