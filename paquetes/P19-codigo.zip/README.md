# P19 · ¿Merece la pena el undercut?

Paquete descargable de **Data School** para el proyecto P19. Incluye el CSV de ejemplo, el código
comentado paso a paso, un informe Markdown y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es si adelantar la parada (undercut) gana algo. El código compara a los dos
pilotos de cada carrera **a la misma edad de neumático** después de la parada —uno paró antes y otro
esperó—, calcula el efecto medio con su intervalo y lo somete a una prueba de signos. El resultado
honesto: **−0,0145 s** de media, intervalo **[−0,1278, +0,0988]** que cruza 0 y 12 diferencias de 24
en cada sentido: con estos datos **no hay evidencia** de que esperar gane; leer el −0,01 s como
estrategia sería leer ruido.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice. Todo con la biblioteca estándar.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python undercut.py
python verificar.py
```

Para guardar el informe:

```bash
python undercut.py --informe resultados/informe.md
```

Desde la carpeta del paquete:

```bash
cd P19-codigo
python undercut.py --csv datos-ejemplo/telemetria-f1.csv --informe resultados/informe.md
```

## Salida esperada

```text
datos: 180 vueltas · 6 stints · 24 pares a igual edad
grupos: A (paró antes) 88.567 s · B (esperó) 88.552 s
efecto B − A: -0.0145 s · IC95 % [-0.1278, +0.0988] · p_signos 1.000
signos: 12 de 24 positivas
informe: escrito en resultados/informe.md
lectura: el intervalo cruza 0; no hay evidencia de que esperar gane con estos datos.
límite: Sin posiciones, sin tráfico y sin una sola parada por piloto: no se puede atribuir la
diferencia a la estrategia; el undercut real depende de la pista y del rival.
```

El informe completo está en `resultados/informe.md`; la salida de consola, en
`resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/telemetria-f1.csv`: **180 filas × 10 columnas**. 3 carreras (`bahrein`, `monza`,
  `suzuka`) × 2 pilotos × 30 vueltas, con compuesto, edad del neumático, sectores, tiempo de vuelta
  y marca de parada. A para en la vuelta 18; B espera a la 22.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `telemetria-f1` del catálogo.
  No son datos reales de ningún equipo ni circuito.
- `sha256` del fichero: `c232e767dc95184fddeb329f6a7c4c72ccb13423a2961bea717cd464150c2c3b`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida grano y compuesto declarado | la comparación exige datos completos |
| 2 · Stints | separa antes/después y guarda la edad del neumático | la unidad de análisis correcta |
| 3 · Emparejar | A contra B en la misma carrera y edad | controlar la variable que confunde |
| 4 · Efecto | media, desviación, error típico, IC95 % y prueba de signos | incertidumbre, no una cifra sola |
| 5 · Informe | regla, grupos, intervalo y límite causal | publicar lo que el diseño permite decir |

## Las tres trampas que el código deja a la vista

1. **Comparar «después» sin emparejar la edad es comparar neumáticos.** A lleva neumático más nuevo
   en la misma vuelta; por eso se empareja por edad 1..8 (24 pares) y no por vuelta.
2. **Un −0,01 s no es un efecto.** Con 24 pares, el error típico es 0,0578 s: el intervalo va de
   −0,13 a +0,10. Publicar la media sin intervalo convierte ruido en recomendación.
3. **Sin posiciones no hay undercut.** El CSV no trae pista, tráfico ni posición; el código lo dice en
   el límite causal en lugar de fingir que mide una estrategia real.

## Fallos típicos

- **`ModuleNotFoundError: undercut`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`** o **`compuesto desconocido`**: el CSV no es el del catálogo.
- **`se esperaba A parando antes que B`**: se han cambiado las vueltas de parada.
- **`se esperaban 24 pares`**: falta una edad de neumático o una carrera.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P19-codigo/
├── undercut.py                # pasos 1–5: stints, pares, intervalo y prueba de signos
├── verificar.py               # la puerta del proyecto: 28 comprobaciones
├── requirements.txt           # sin dependencias
├── datos-ejemplo/
│   └── telemetria-f1.csv      # 180 × 10 · sintético, CC0-1.0
└── resultados/
    ├── informe.md             # regla, grupos, intervalo y límite causal
    └── ejemplo-salida.txt     # la salida real de una ejecución
```

## Límite

Son 3 carreras sintéticas, una parada por piloto y **ninguna posición en pista**: no se puede
atribuir la diferencia a la estrategia. El undercut real depende de la pista, del tráfico y del
rival, y exige datos que este CSV no tiene. El paquete enseña el método (emparejar, intervalo,
prueba de signos, límite causal), no una conclusión sobre F1.
