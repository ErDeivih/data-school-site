"""P19 · ¿Merece la pena el undercut?

Compara a los dos pilotos de cada carrera a la MISMA edad de neumático después de la parada:
uno paró antes (undercut) y otro esperó. Así se quita el efecto del neumático nuevo y se ve si
quien esperó gana algo… o si la diferencia es ruido. El informe da la regla, los dos grupos, el
intervalo y el límite causal.

Sin dependencias externas: solo la biblioteca estándar. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("carrera", "piloto", "vuelta", "compuesto", "edad_neumatico",
            "sector1_s", "sector2_s", "sector3_s", "tiempo_vuelta_s", "parada")
COMPUESTOS = {"blando", "medio", "duro"}
EDADES = range(1, 9)
REGLA = ("undercut = parar antes que el rival (A para en la vuelta 18; B espera a la 22). "
         "Se comparan las vueltas posteriores a la MISMA edad de neumático, carrera a carrera.")
LIMITE = ("Sin posiciones, sin tráfico y sin una sola parada por piloto: no se puede atribuir "
          "la diferencia a la estrategia; el undercut real depende de la pista y del rival.")


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar el grano y el compuesto declarado.
    # Por qué: si un stint no declara compuesto, comparar ritmos mezcla neumáticos distintos.
    # Salida esperada: 180 filas, 6 pares, 30 vueltas, compuesto en {blando, medio, duro}.
    # Si falla: «columnas inesperadas», un par sin 30 vueltas o un compuesto desconocido.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 180:
        raise ValueError(f"se esperaban 180 filas, hay {len(filas)}")
    for fila in filas:
        if fila["compuesto"] not in COMPUESTOS:
            raise ValueError(f"compuesto desconocido: {fila['compuesto']}")
        for columna in ("vuelta", "edad_neumatico", "tiempo_vuelta_s"):
            float(fila[columna])
    grupos = defaultdict(list)
    for fila in filas:
        grupos[(fila["carrera"], fila["piloto"])].append(fila)
    if len(grupos) != 6 or any(len(g) != 30 for g in grupos.values()):
        raise ValueError("cada par carrera/piloto debe tener 30 vueltas")
    return filas


def stints(filas: list[dict]) -> dict:
    # Paso 2 · Separar antes/después de la parada y guardar la edad del neumático de cada vuelta.
    # Por qué: comparar «después» sin emparejar la edad es comparar neumático nuevo con gastado.
    # Salida esperada: por par, vueltas posteriores indexadas por edad 1..12.
    # Si falla: falta la parada o hay dos.
    salida = {}
    for (carrera, piloto), grupo in grupos(filas).items():
        grupo.sort(key=lambda f: int(f["vuelta"]))
        paradas = [f for f in grupo if f["parada"] == "1"]
        if len(paradas) != 1:
            raise ValueError(f"{carrera}/{piloto}: se esperaba una parada, hay {len(paradas)}")
        vuelta_parada = int(paradas[0]["vuelta"])
        despues = {}
        for fila in grupo:
            if fila["parada"] == "1":
                continue
            if int(fila["vuelta"]) > vuelta_parada and int(fila["edad_neumatico"]) in EDADES:
                despues[int(fila["edad_neumatico"])] = float(fila["tiempo_vuelta_s"])
        salida[(carrera, piloto)] = {"parada": vuelta_parada, "despues": despues}
    return salida


def grupos(filas: list[dict]) -> dict:
    salida = defaultdict(list)
    for fila in filas:
        salida[(fila["carrera"], fila["piloto"])].append(fila)
    return dict(salida)


def media(valores: list[float]) -> float:
    return sum(valores) / len(valores)


def desviacion(valores: list[float]) -> float:
    m = media(valores)
    return math.sqrt(sum((v - m) ** 2 for v in valores) / (len(valores) - 1))


def pares(stints_: dict) -> list[dict]:
    # Paso 3 · Emparejar por carrera y edad de neumático: A (paró antes) contra B (esperó).
    # Por qué: el par elimina la carrera y la edad; lo que queda es la diferencia de estrategia
    # (más el combustible, que se declara en el límite).
    # Salida esperada: 3 carreras × 8 edades = 24 diferencias (B − A).
    # Si falla: una carrera no tiene los dos pilotos o falta alguna edad.
    salida = []
    carreras = sorted({c for (c, _p) in stints_})
    for carrera in carreras:
        a = stints_.get((carrera, "A"))
        b = stints_.get((carrera, "B"))
        if not a or not b or a["parada"] >= b["parada"]:
            raise ValueError(f"{carrera}: se esperaba A parando antes que B")
        for edad in EDADES:
            if edad in a["despues"] and edad in b["despues"]:
                salida.append({"carrera": carrera, "edad": edad,
                               "A": a["despues"][edad], "B": b["despues"][edad],
                               "diferencia": b["despues"][edad] - a["despues"][edad]})
    if len(salida) != 24:
        raise ValueError(f"se esperaban 24 pares, hay {len(salida)}")
    return salida


def informe(pares_: list[dict]) -> dict:
    # Paso 4 · Efecto medio, desviación, error típico, intervalo al 95 % y prueba de signos.
    # Por qué: «esperar gana 0,01 s» sin intervalo no es un resultado; con intervalo, se discute.
    # Salida esperada: media ≈ -0,0145 s, IC que cruza 0 y 12 diferencias positivas de 24.
    # Si falla: los pares no están completos o la media se calcula sobre otra muestra.
    diferencias = [p["diferencia"] for p in pares_]
    m = media(diferencias)
    sd = desviacion(diferencias)
    ee = sd / math.sqrt(len(diferencias))
    positivas = sum(1 for d in diferencias if d > 0)
    n = len(diferencias)
    # Prueba de signos bilateral exacta: 2 × P(X ≤ min(positivas, n-positivas)).
    k = min(positivas, n - positivas)
    p_signos = min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n)
    return {"n": n, "media": m, "sd": sd, "ee": ee,
            "bajo": m - 1.96 * ee, "alto": m + 1.96 * ee,
            "positivas": positivas, "p_signos": p_signos,
            "a_media": media([p["A"] for p in pares_]),
            "b_media": media([p["B"] for p in pares_])}


def texto(pares_: list[dict], datos: dict) -> str:
    # Paso 5 · El informe: regla, dos grupos, intervalo y límite causal.
    lineas = [
        "# ¿Merece la pena el undercut?",
        "",
        f"**Regla:** {REGLA}",
        "",
        "## Los dos grupos",
        f"- **A · paró antes (undercut):** ritmo medio posterior en las edades 1–8: {datos['a_media']:.3f} s.",
        f"- **B · esperó:** ritmo medio posterior en las edades 1–8: {datos['b_media']:.3f} s.",
        f"- Pares comparables: {datos['n']} (3 carreras × 8 edades de neumático).",
        "",
        "## Diferencia a la misma edad (B − A)",
        f"- Media: {datos['media']:+.4f} s · desviación {datos['sd']:.3f} · error típico {datos['ee']:.4f}.",
        f"- Intervalo al 95 %: [{datos['bajo']:+.4f}, {datos['alto']:+.4f}] s.",
        f"- Signos: {datos['positivas']} de {datos['n']} diferencias son positivas; prueba de signos p = {datos['p_signos']:.3f}.",
        "",
        "## Lectura",
        "El intervalo cruza 0 y los signos están repartidos: con estos datos no hay evidencia de que "
        "esperar gane nada. Publicar «el undercut gana 0,01 s» sería leer ruido como estrategia.",
        "",
        f"**Límite causal:** {LIMITE}",
    ]
    return "\n".join(lineas)


def main() -> int:
    parser = argparse.ArgumentParser(description="P19 · undercut con control de edad de neumático")
    parser.add_argument("--csv", default="datos-ejemplo/telemetria-f1.csv")
    parser.add_argument("--informe", default="", help="ruta donde escribir el informe Markdown")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    stints_ = stints(filas)
    pares_ = pares(stints_)
    datos = informe(pares_)
    documento = texto(pares_, datos)
    if args.informe:
        Path(args.informe).write_text(documento, encoding="utf-8")

    print(f"datos: {len(filas)} vueltas · {len(stints_)} stints · {datos['n']} pares a igual edad")
    print(f"grupos: A (paró antes) {datos['a_media']:.3f} s · B (esperó) {datos['b_media']:.3f} s")
    print(f"efecto B − A: {datos['media']:+.4f} s · IC95 % [{datos['bajo']:+.4f}, {datos['alto']:+.4f}] · "
          f"p_signos {datos['p_signos']:.3f}")
    print(f"signos: {datos['positivas']} de {datos['n']} positivas")
    print(f"informe: {'escrito en ' + args.informe if args.informe else 'generado en memoria'}")
    print("lectura: el intervalo cruza 0; no hay evidencia de que esperar gane con estos datos.")
    print(f"límite: {LIMITE}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
