# ¿Merece la pena el undercut?

**Regla:** undercut = parar antes que el rival (A para en la vuelta 18; B espera a la 22). Se comparan las vueltas posteriores a la MISMA edad de neumático, carrera a carrera.

## Los dos grupos
- **A · paró antes (undercut):** ritmo medio posterior en las edades 1–8: 88.567 s.
- **B · esperó:** ritmo medio posterior en las edades 1–8: 88.552 s.
- Pares comparables: 24 (3 carreras × 8 edades de neumático).

## Diferencia a la misma edad (B − A)
- Media: -0.0145 s · desviación 0.283 · error típico 0.0578.
- Intervalo al 95 %: [-0.1278, +0.0988] s.
- Signos: 12 de 24 diferencias son positivas; prueba de signos p = 1.000.

## Lectura
El intervalo cruza 0 y los signos están repartidos: con estos datos no hay evidencia de que esperar gane nada. Publicar «el undercut gana 0,01 s» sería leer ruido como estrategia.

**Límite causal:** Sin posiciones, sin tráfico y sin una sola parada por piloto: no se puede atribuir la diferencia a la estrategia; el undercut real depende de la pista y del rival.