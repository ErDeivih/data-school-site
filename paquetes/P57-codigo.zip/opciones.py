#!/usr/bin/env python3
"""P57 · Opciones: Black-Scholes y un millón de caminos.

Proyecto completo de la ficha P57. Estima la volatilidad de la serie diaria del CSV, valora una opción
call europea con Black-Scholes y con un millón de caminos Monte Carlo (semilla fija), compara los dos
precios contra el error estándar de la simulación y muestra cómo el error baja como 1/√n. No usa red:
los precios vienen del CSV local y la simulación se ejecuta en el propio equipo.

    python opciones.py               # valora, compara, imprime la convergencia y guarda resultados/
    python opciones.py --figura      # además dibuja la distribución del precio final (matplotlib)
    python opciones.py --comprobar   # solo valida el CSV y muestra volatilidad y precio analítico

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"

COLUMNAS = ["fecha", "apertura", "cierre", "maximo", "minimo", "volumen"]
FILAS_ESPERADAS = 250
# Checksum del CSV del catálogo (`precios-accion`): permite comprobar que la copia local es literal.
SHA256_CATALOGO = "15c9d071f65b8e34061f757405bb3a74021bd4cb7d8b333364fe215038911de7"


def cargar_parametros() -> dict:
    # Paso 1 · Lee las entradas del modelo desde datos-ejemplo/parametros.json
    # Por qué: strike, plazo, tasa y semilla se fijan antes de mirar el precio; si se eligen después de
    #          ver el resultado, la comparación deja de ser una comprobación.
    # Salida esperada: las claves del contrato cargadas sin error (el resumen imprime «modelo: …» después)
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o restaura datos-ejemplo/parametros.json.
    ruta = DATOS / "parametros.json"
    parametros = json.loads(ruta.read_text(encoding="utf-8"))
    obligatorias = ("semilla", "strike", "plazo_dias", "tasa", "caminos", "convencion_anualizacion", "tipo")
    faltan = [clave for clave in obligatorias if clave not in parametros]
    if faltan:
        raise RuntimeError(f"faltan claves en {ruta.name}: {', '.join(faltan)}")
    if int(parametros["plazo_dias"]) <= 0 or int(parametros["caminos"]) <= 0:
        raise RuntimeError("«plazo_dias» y «caminos» tienen que ser positivos")
    if int(parametros["convencion_anualizacion"]) not in (252, 365):
        raise RuntimeError("la convención de anualización declarada tiene que ser 252 o 365")
    if parametros["tipo"] not in ("call", "put"):
        raise RuntimeError("«tipo» tiene que ser «call» o «put»")
    return parametros


def cargar_precios() -> dict:
    # Paso 2 · Carga el CSV y valida la serie: 250 filas, fechas únicas y coherencia de precios
    # Por qué: la volatilidad que entra en el modelo sale de estos retornos; si la serie está mal
    #          ordenada o la apertura no es el cierre anterior, el número de partida ya no vale.
    # Salida esperada: "precios: 250 filas · 6 columnas · cierre 85.66-102.89 EUR · ultimo 93.81"
    # Si falla: FileNotFoundError → falta datos-ejemplo/precios-accion.csv (viaja en el ZIP, CC0-1.0).
    ruta = DATOS / "precios-accion.csv"
    with ruta.open(encoding="utf-8", newline="") as f:
        lector = csv.DictReader(f)
        columnas = lector.fieldnames or []
        filas = [fila for fila in lector if fila]
    if columnas != COLUMNAS:
        raise RuntimeError(f"columnas del CSV: {columnas} (se esperaban {COLUMNAS})")
    if len(filas) != FILAS_ESPERADAS:
        raise RuntimeError(f"filas del CSV: {len(filas)} (se esperaban {FILAS_ESPERADAS})")
    fechas = [fila["fecha"] for fila in filas]
    if len(set(fechas)) != len(fechas):
        raise RuntimeError("hay fechas repetidas en el CSV")
    apertura = np.array([float(fila["apertura"]) for fila in filas], dtype=np.float64)
    cierre = np.array([float(fila["cierre"]) for fila in filas], dtype=np.float64)
    maximo = np.array([float(fila["maximo"]) for fila in filas], dtype=np.float64)
    minimo = np.array([float(fila["minimo"]) for fila in filas], dtype=np.float64)
    volumen = np.array([int(fila["volumen"]) for fila in filas], dtype=np.int64)
    # La apertura es el cierre del día anterior en las 249 comparaciones posibles; si deja de serlo,
    # la serie tendría huecos intradía que el modelo no contempla.
    diferencias = np.abs(apertura[1:] - cierre[:-1])
    if float(diferencias.max()) > 1e-6:
        raise RuntimeError(f"la apertura no coincide con el cierre anterior (máximo {float(diferencias.max()):.4f})")
    if not (bool(np.all(maximo >= np.maximum(apertura, cierre))) and bool(np.all(minimo <= np.minimum(apertura, cierre)))):
        raise RuntimeError("hay filas donde máximo o mínimo no acotan apertura y cierre")
    sha256 = hashlib.sha256(ruta.read_bytes()).hexdigest()
    return {
        "filas": filas,
        "fechas": fechas,
        "apertura": apertura,
        "cierre": cierre,
        "maximo": maximo,
        "minimo": minimo,
        "volumen": volumen,
        "sha256": sha256,
        "coincidencias_apertura": int(np.sum(diferencias <= 1e-6)),
    }


def volatilidad(precios: dict, convencion: int) -> dict:
    # Paso 3 · Calcula retornos logarítmicos y la volatilidad con la convención declarada
    # Por qué: mezclar √252 con √365, o anualizar y luego usar T en días, rompe la comparación entre el
    #          precio analítico y el simulado; aquí se declara √365 porque la serie es de calendario natural.
    # Salida esperada: "volatilidad: diaria 1.16 % (249 retornos) · anual 22.24 % con sqrt(365)"
    # Si falla: ValueError → la serie tiene menos de dos cierres y no hay retornos.
    cierre = precios["cierre"]
    if cierre.size < 2:
        raise ValueError("hacen falta al menos dos cierres para calcular retornos")
    retornos = np.diff(np.log(cierre))
    diaria = float(np.std(retornos, ddof=1))
    return {"retornos": retornos, "diaria": diaria, "anual": diaria * math.sqrt(convencion), "n": int(retornos.size)}


def norm_cdf(x: float) -> float:
    """Función de distribución de la normal estándar, con `math.erf` (sin dependencias extra)."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def black_scholes(precio: float, strike: float, plazo: float, tasa: float, volatilidad: float, tipo: str = "call") -> float:
    # Paso 4 · Implementa Black-Scholes con sus entradas declaradas
    # Por qué: el precio analítico es la referencia de la simulación; se calcula con la misma S, K, T, r
    #          y σ que los caminos, y con la fórmula escrita para poder auditar cada término.
    # Salida esperada: "black-scholes: 3.796263" (call europea con S=93.81, K=95, T=90/365, r=2 %, σ=22.24 %)
    # Si falla: ValueError → σ o plazo son cero; revisa parametros.json y la volatilidad.
    if volatilidad <= 0.0 or plazo <= 0.0:
        raise ValueError("la volatilidad y el plazo tienen que ser positivos")
    raiz_t = volatilidad * math.sqrt(plazo)
    d1 = (math.log(precio / strike) + (tasa + 0.5 * volatilidad ** 2) * plazo) / raiz_t
    d2 = d1 - raiz_t
    if tipo == "call":
        return precio * norm_cdf(d1) - strike * math.exp(-tasa * plazo) * norm_cdf(d2)
    return strike * math.exp(-tasa * plazo) * norm_cdf(-d2) - precio * norm_cdf(-d1)


def precio_con_normales(z: np.ndarray, precio: float, strike: float, plazo: float, tasa: float, volatilidad: float, tipo: str) -> dict:
    """Valora la opción a partir de normales estándar ya generadas: separa la simulación de la puerta."""
    precios_finales = precio * np.exp((tasa - 0.5 * volatilidad ** 2) * plazo + volatilidad * math.sqrt(plazo) * z)
    if tipo == "call":
        pagos = np.maximum(precios_finales - strike, 0.0)
    else:
        pagos = np.maximum(strike - precios_finales, 0.0)
    descontados = math.exp(-tasa * plazo) * pagos
    precio_mc = float(descontados.mean())
    error = float(descontados.std(ddof=1) / math.sqrt(descontados.size))
    return {
        "precio": precio_mc,
        "error_estandar": error,
        "precios_finales": precios_finales,
        "descontados": descontados,
    }


def simular_caminos(precio: float, strike: float, plazo: float, tasa: float, volatilidad: float, caminos: int, semilla: int, tipo: str) -> dict:
    # Paso 5 · Simula los caminos con semilla fija y calcula el precio con su error estándar
    # Por qué: el error estándar no es la desviación de los precios finales, sino la de los pagos
    #          descontados dividida por √n; sin él, la diferencia entre analítico y Monte Carlo no se juzga.
    # Salida esperada: "monte carlo: 3.792080 · error estandar 0.006210"
    # Si falla: MemoryError → reduce «caminos» en el JSON; con 1.000.000 de caminos son unos 8 MB por vector.
    rng = np.random.default_rng(int(semilla))
    z = rng.standard_normal(int(caminos))
    resultado = precio_con_normales(z, precio, strike, plazo, tasa, volatilidad, tipo)
    resultado["normales"] = z
    return resultado


def tabla_convergencia(precio: float, strike: float, plazo: float, tasa: float, volatilidad: float, semilla: int, tamanos: list, tipo: str) -> list:
    # Paso 6 · Repite la simulación con n creciente reutilizando las mismas normales
    # Por qué: con una sola tirada grande y sus primeros n valores, la comparación entre tamaños mide el
    #          efecto de n (el error cae como 1/√n), no el ruido de generar otra muestra distinta.
    # Salida esperada: una fila por n con precio, error estándar y diferencia frente a Black-Scholes
    # Si falla: ValueError → algún tamaño es mayor que el número de caminos declarado.
    mayor = max(int(n) for n in tamanos)
    if mayor > int(1000000):
        raise ValueError("el mayor tamaño de convergencia no puede superar el millón de caminos")
    rng = np.random.default_rng(int(semilla))
    z = rng.standard_normal(mayor)
    filas = []
    for n in tamanos:
        n = int(n)
        resultado = precio_con_normales(z[:n], precio, strike, plazo, tasa, volatilidad, tipo)
        filas.append({"n": n, "precio": resultado["precio"], "error_estandar": resultado["error_estandar"]})
    return filas


def ejecutar(parametros: dict) -> dict:
    """Carga, valora y compara, imprimiendo el resumen que la puerta necesita."""
    precios = cargar_precios()
    convencion = int(parametros["convencion_anualizacion"])
    vol = volatilidad(precios, convencion)
    precio_actual = float(precios["cierre"][-1])
    strike = float(parametros["strike"])
    plazo = int(parametros["plazo_dias"]) / 365.0
    tasa = float(parametros["tasa"])
    tipo = str(parametros["tipo"])
    semilla = int(parametros["semilla"])
    caminos = int(parametros["caminos"])

    bs = black_scholes(precio_actual, strike, plazo, tasa, vol["anual"], tipo)
    put = black_scholes(precio_actual, strike, plazo, tasa, vol["anual"], "put")
    mc = simular_caminos(precio_actual, strike, plazo, tasa, vol["anual"], caminos, semilla, tipo)
    diferencia = mc["precio"] - bs
    ratio = abs(diferencia) / mc["error_estandar"]
    convergencia = tabla_convergencia(
        precio_actual, strike, plazo, tasa, vol["anual"], semilla, parametros.get("tamanos_convergencia", [1000, 10000, 100000, 1000000]), tipo
    )

    print(
        f"precios: {len(precios['filas'])} filas · {len(COLUMNAS)} columnas · cierre {precios['cierre'].min():.2f}"
        f"-{precios['cierre'].max():.2f} EUR · primer cierre {precios['cierre'][0]:.2f} · ultimo {precio_actual:.2f}"
    )
    print(
        f"volatilidad: diaria {vol['diaria'] * 100:.2f} % ({vol['n']} retornos) · anual {vol['anual'] * 100:.2f} %"
        f" con sqrt({convencion})"
    )
    print(
        f"modelo: S={precio_actual:.2f} · K={strike:.2f} · T={int(parametros['plazo_dias'])}/365 ({plazo:.4f} años)"
        f" · r={tasa * 100:.2f} % · sigma {vol['anual'] * 100:.2f} % · {tipo} europea"
    )
    print(f"black-scholes: {bs:.6f}")
    print(
        f"monte carlo ({caminos} caminos, semilla {semilla}): {mc['precio']:.6f}"
        f" · error estandar {mc['error_estandar']:.6f} · diferencia {diferencia:+.6f} ({ratio:.2f} errores estandar)"
    )
    print(f"veredicto: la diferencia cabe en el error estandar: {'si' if ratio < 1.0 else 'no'}")
    print(
        "convergencia: "
        + " · ".join(f"n={fila['n']}: {fila['precio']:.5f} (se {fila['error_estandar']:.5f})" for fila in convergencia)
    )
    print(f"paridad put-call: {bs - put:+.6f} = S - K e^-rT = {precio_actual - strike * math.exp(-tasa * plazo):+.6f}")
    return {
        "precios": precios,
        "volatilidad": vol,
        "precio_actual": precio_actual,
        "strike": strike,
        "plazo": plazo,
        "tasa": tasa,
        "tipo": tipo,
        "semilla": semilla,
        "caminos": caminos,
        "bs": bs,
        "put": put,
        "mc": mc,
        "diferencia": diferencia,
        "ratio": ratio,
        "convergencia": convergencia,
    }


def guardar(resultados: dict, parametros: dict) -> None:
    # Paso 7 · Guarda la tabla de convergencia y un resumen con todas las entradas del modelo
    # Por qué: un precio sin sus entradas no es auditable; el resumen deja S, K, T, r, σ y semilla al lado
    #          del precio, y la convergencia enseña el error estándar de cada tamaño de muestra.
    # Salida esperada: "resultados: resumen.csv, convergencia.csv, caminos-muestra.csv"
    # Si falla: PermissionError → resultados/ no es escribible; ejecuta desde codigo/.
    RESULTADOS.mkdir(parents=True, exist_ok=True)
    with (RESULTADOS / "resumen.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(
            ["precio", "strike", "plazo_anyos", "tasa", "volatilidad_diaria", "volatilidad_anual", "tipo", "semilla", "caminos", "precio_bs", "precio_mc", "error_estandar", "diferencia"]
        )
        escritor.writerow(
            [
                f"{resultados['precio_actual']:.2f}",
                f"{resultados['strike']:.2f}",
                f"{resultados['plazo']:.6f}",
                f"{resultados['tasa']:.4f}",
                f"{resultados['volatilidad']['diaria']:.6f}",
                f"{resultados['volatilidad']['anual']:.6f}",
                resultados["tipo"],
                resultados["semilla"],
                resultados["caminos"],
                f"{resultados['bs']:.6f}",
                f"{resultados['mc']['precio']:.6f}",
                f"{resultados['mc']['error_estandar']:.6f}",
                f"{resultados['diferencia']:+.6f}",
            ]
        )
    with (RESULTADOS / "convergencia.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["caminos", "precio_mc", "error_estandar", "diferencia_frente_bs"])
        for fila in resultados["convergencia"]:
            escritor.writerow([fila["n"], f"{fila['precio']:.6f}", f"{fila['error_estandar']:.6f}", f"{fila['precio'] - resultados['bs']:+.6f}"])
    muestra = int(parametros.get("muestra_caminos", 20))
    precios_finales = resultados["mc"]["precios_finales"][:muestra]
    pagos = resultados["mc"]["descontados"][:muestra]
    with (RESULTADOS / "caminos-muestra.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["camino", "precio_final", "pago_descontado"])
        for indice, (precio_final, pago) in enumerate(zip(precios_finales, pagos), start=1):
            escritor.writerow([indice, f"{precio_final:.4f}", f"{pago:.4f}"])
    print("resultados: resumen.csv, convergencia.csv, caminos-muestra.csv")


def figura(resultados: dict) -> None:
    # Paso 8 · Dibuja la distribución del precio final con el strike y la media (opcional)
    # Por qué: la figura enseña que la prima es el valor esperado descontado de los pagos, no una promesa.
    # Salida esperada: resultados/opciones.png
    # Si falla: ModuleNotFoundError de matplotlib → `python -m pip install matplotlib`.
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ModuleNotFoundError as exc:
        raise RuntimeError("para --figura hace falta matplotlib: python -m pip install matplotlib") from exc

    precios_finales = resultados["mc"]["precios_finales"]
    fig, eje = plt.subplots(figsize=(7, 4))
    eje.hist(precios_finales, bins=120, color="#4c72b0", alpha=0.85)
    eje.axvline(resultados["strike"], color="black", linestyle="--", linewidth=1, label=f"strike {resultados['strike']:.2f}")
    eje.axvline(float(np.mean(precios_finales)), color="#c44e52", linewidth=1, label="media de los caminos")
    eje.set_xlabel("precio final del subyacente (EUR)")
    eje.set_ylabel("caminos")
    eje.set_title("Un millón de caminos · Black-Scholes = {0:.4f}".format(resultados["bs"]))
    eje.legend()
    fig.tight_layout()
    fig.savefig(RESULTADOS / "opciones.png", dpi=120)
    plt.close(fig)
    print("figura: opciones.png")


def main(argv: list) -> int:
    try:
        parametros = cargar_parametros()
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    if "--comprobar" in argv:
        try:
            precios = cargar_precios()
        except (OSError, RuntimeError) as exc:
            print(f"error: {exc}")
            return 1
        vol = volatilidad(precios, int(parametros["convencion_anualizacion"]))
        precio_actual = float(precios["cierre"][-1])
        bs = black_scholes(precio_actual, float(parametros["strike"]), int(parametros["plazo_dias"]) / 365.0,
                           float(parametros["tasa"]), vol["anual"], str(parametros["tipo"]))
        print(f"precios: {precios['filas'][0]['fecha']} a {precios['filas'][-1]['fecha']} · {len(precios['filas'])} filas")
        print(f"volatilidad anual: {vol['anual'] * 100:.2f} % · black-scholes: {bs:.6f}")
        return 0
    print("== P57 · Opciones: Black-Scholes y un millón de caminos ==")
    try:
        resultados = ejecutar(parametros)
        guardar(resultados, parametros)
        if "--figura" in argv:
            figura(resultados)
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
