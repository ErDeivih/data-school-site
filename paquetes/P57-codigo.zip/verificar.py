#!/usr/bin/env python3
"""Puerta del proyecto P57 (Black-Scholes y Monte Carlo).

Comprueba el resultado de verdad, sin escribir en disco y sin red: integridad del CSV y su checksum de
catálogo, volatilidad con la convención declarada, precio analítico con su paridad put-call, un millón
de caminos con semilla fija, diferencia dentro del error estándar, convergencia como 1/√n y código
offline. Termina en RESULTADO: VERDE (código 0) o ROJO (código 1).

Uso:
    python verificar.py

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import math
import sys

sys.dont_write_bytecode = True  # la puerta no escribe nada: ni resultados ni caché de bytecode

import numpy as np

import opciones

fallos: list = []
comprobaciones = 0

# Anclas externas al módulo: valores medidos en la compilación del 2026-11-05 y en esta entrega.
SIGMA_DIARIA_ESPERADA = 0.011643065577938741
SIGMA_ANUAL_ESPERADA = 0.2224404555359623
BS_ESPERADO = 3.7962632808021652


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P57 · opciones: Black-Scholes y Monte Carlo ==")

    # Paso 1 · Comprueba la serie de precios del CSV y su procedencia
    # Por qué: la volatilidad que entra en el modelo sale de esta serie; si la copia no es la del
    #          catálogo, el número de partida deja de ser el declarado en la ficha.
    # Salida esperada: "OK precios: 250 filas · 6 columnas · 250 fechas unicas" y checksum correcto.
    # Si falla: RuntimeError de cargar_precios → falta datos-ejemplo/precios-accion.csv o está mal.
    parametros = opciones.cargar_parametros()
    precios = opciones.cargar_precios()
    ok(
        len(precios["filas"]) == 250 and len(opciones.COLUMNAS) == 6,
        f"precios: {len(precios['filas'])} filas · {len(opciones.COLUMNAS)} columnas · {len(set(precios['fechas']))} fechas unicas",
    )
    ok(
        precios["coincidencias_apertura"] == 249,
        f"coherencia: la apertura coincide con el cierre anterior en {precios['coincidencias_apertura']}/249 comparaciones",
    )
    acotan = int(np.sum((precios["maximo"] >= np.maximum(precios["apertura"], precios["cierre"])) & (precios["minimo"] <= np.minimum(precios["apertura"], precios["cierre"]))))
    ok(acotan == 250, f"coherencia: máximo y mínimo acotan apertura y cierre en {acotan}/250 filas")
    ok(precios["sha256"] == opciones.SHA256_CATALOGO, f"procedencia: sha256 del CSV coincide con el del catálogo ({precios['sha256'][:12]}…)")

    # Paso 2 · Comprueba la volatilidad con la convención declarada
    # Por qué: mezclar √252 y √365, o anualizar y luego usar T en días, hace que los dos precios no sean
    #          comparables; la volatilidad se calcula una vez y se usa en todo el proyecto.
    # Salida esperada: "OK volatilidad: diaria 1.16 % (249 retornos) · anual 22.24 % con sqrt(365)".
    # Si falla: la σ difiere → el CSV no es el de la ficha o se cambió la convención.
    vol = opciones.volatilidad(precios, int(parametros["convencion_anualizacion"]))
    ok(abs(vol["diaria"] - SIGMA_DIARIA_ESPERADA) < 1e-9, f"volatilidad: diaria {vol['diaria'] * 100:.2f} % con {vol['n']} retornos")
    ok(
        abs(vol["anual"] - SIGMA_ANUAL_ESPERADA) < 1e-9,
        f"volatilidad: anual {vol['anual'] * 100:.2f} % con sqrt({int(parametros['convencion_anualizacion'])})",
    )

    # Paso 3 · Ejecuta la valoración (analítica y Monte Carlo) y comprueba el precio analítico
    # Por qué: el precio de Black-Scholes es la referencia; se comprueba con propiedades independientes
    #          de la fórmula (cota, paridad put-call y monotonía en el strike).
    # Salida esperada: las líneas del resumen y los OK de Black-Scholes, paridad y monotonía.
    # Si falla: la paridad no cuadra → hay un descuento o una normal mal calculada.
    resultados = opciones.ejecutar(parametros)
    bs = resultados["bs"]
    precio_actual = resultados["precio_actual"]
    strike = resultados["strike"]
    plazo = resultados["plazo"]
    tasa = resultados["tasa"]
    ok(abs(bs - BS_ESPERADO) < 1e-9, f"black-scholes: {bs:.6f} para S={precio_actual:.2f}, K={strike:.2f}, T={plazo:.4f}, r={tasa:.2f}, sigma={vol['anual']:.4f}")
    intrínseco = max(precio_actual - strike * math.exp(-tasa * plazo), 0.0)
    ok(intrínseco <= bs < precio_actual, f"black-scholes: el precio esta entre el valor intrinseco ({intrínseco:.4f}) y S ({precio_actual:.2f})")
    paridad = bs - resultados["put"]
    paridad_teorica = precio_actual - strike * math.exp(-tasa * plazo)
    ok(abs(paridad - paridad_teorica) < 1e-9, f"paridad put-call: C - P = {paridad:+.6f} = S - K e^-rT = {paridad_teorica:+.6f}")
    bs_100 = opciones.black_scholes(precio_actual, strike + 5.0, plazo, tasa, vol["anual"], "call")
    bs_105 = opciones.black_scholes(precio_actual, strike + 10.0, plazo, tasa, vol["anual"], "call")
    ok(bs > bs_100 > bs_105 > 0.0, f"monotonia: el precio del call baja al subir el strike ({bs:.4f} > {bs_100:.4f} > {bs_105:.4f})")

    # Paso 4 · Comprueba el millón de caminos: reproducibilidad y diferencia dentro del error estándar
    # Por qué: el criterio del catálogo exige que la diferencia entre analítico y Monte Carlo quede por
    #          debajo del error estándar; además la semilla fija forma parte del contrato.
    # Salida esperada: "OK diferencia: ... 0.67 errores estandar (< 1)" y la misma semilla repite.
    # Si falla: la diferencia supera el error → revisa σ, T o el descuento; no cambies la semilla a ciegas.
    mc = resultados["mc"]
    ok(
        abs(resultados["diferencia"]) < mc["error_estandar"],
        f"diferencia: |BS - MC| = {abs(resultados['diferencia']):.6f} = {resultados['ratio']:.2f} errores estandar (< 1)",
    )
    segunda = opciones.simular_caminos(
        precio_actual, strike, plazo, tasa, vol["anual"], int(parametros["caminos"]), int(parametros["semilla"]), resultados["tipo"]
    )
    ok(segunda["precio"] == mc["precio"], "reproducibilidad: la misma semilla da exactamente el mismo precio Monte Carlo")
    otra = opciones.simular_caminos(
        precio_actual, strike, plazo, tasa, vol["anual"], int(parametros["caminos"]), int(parametros["semilla"]) + 1, resultados["tipo"]
    )
    ok(
        otra["precio"] != mc["precio"] and abs(otra["precio"] - mc["precio"]) < 4.0 * mc["error_estandar"],
        f"otra semilla: el precio cambia ({otra['precio']:.6f} frente a {mc['precio']:.6f}) pero sigue dentro de 4 errores estandar",
    )

    # Paso 5 · Comprueba que el error estándar baja como 1/√n al crecer el número de caminos
    # Por qué: la convergencia de Monte Carlo es la propiedad que justifica simular; sin ella, el error
    #          estándar sería una cifra decorativa.
    # Salida esperada: el error de n=1.000 es ~31,6 veces el de n=1.000.000 (sqrt(1000)).
    # Si falla: los tamaños de convergencia no son los declarados o no se reutilizan las normales.
    convergencia = resultados["convergencia"]
    errores = [fila["error_estandar"] for fila in convergencia]
    ok(
        all(errores[i] > errores[i + 1] for i in range(len(errores) - 1)),
        f"convergencia: el error estandar baja con n ({', '.join(f'{e:.5f}' for e in errores)})",
    )
    cociente = errores[0] / errores[-1]
    ok(28.0 <= cociente <= 36.0, f"convergencia: el error cae por {cociente:.2f} al pasar de {convergencia[0]['n']} a {convergencia[-1]['n']} caminos (teorico sqrt(1000)=31.6)")

    # Paso 6 · Comprueba que todos los caminos parten del mismo precio (martingala bajo r)
    # Por qué: si los caminos no arrancan de S, el precio simulado no corresponde al subyacente del CSV.
    # Salida esperada: la media de los precios finales coincide con S·e^{rT} dentro de 3 errores estándar.
    # Si falla: falta la deriva (r - σ²/2) o el descuento → los caminos no son geométricos.
    precios_finales = mc["precios_finales"]
    esperado = precio_actual * math.exp(tasa * plazo)
    error_medio = float(np.std(precios_finales, ddof=1) / math.sqrt(precios_finales.size))
    ok(
        abs(float(np.mean(precios_finales)) - esperado) < 3.0 * error_medio,
        f"caminos: la media de los precios finales es {float(np.mean(precios_finales)):.4f} frente a S·e^rT = {esperado:.4f} (<= 3 errores)",
    )
    ok(bool(np.all(precios_finales > 0.0)), "caminos: los 1.000.000 de precios finales son positivos (movimiento browniano geometrico)")

    # Paso 7 · Comprueba que el código es offline y no lleva secretos
    # Por qué: la entrega se comparte y la puerta se ejecuta sin red.
    # Salida esperada: "el código del proyecto no hace peticiones de red" y "no contiene claves".
    # Si falla: aparece un http(s) o un patrón de token en opciones.py → quítalo antes de empaquetar.
    fuente = (opciones.RAIZ / "opciones.py").read_text(encoding="utf-8")
    ok("http://" not in fuente and "https://" not in fuente, "el código del proyecto no hace peticiones de red")
    ok(
        not any(patron in fuente for patron in ("ghp_", "github_pat_", "Authorization:", "api_key")),
        "el código del proyecto no contiene claves ni cabeceras de autorización",
    )

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
