# P57 · Opciones: Black-Scholes y un millón de caminos — código ejecutable

Estima la volatilidad de la serie diaria del CSV (`precios-accion`, CC0-1.0), valora una **call europea**
con Black-Scholes y con **un millón de caminos** Monte Carlo de movimiento browniano geométrico (semilla
fija), compara los dos precios contra el **error estándar** de la simulación y muestra cómo el error baja
como 1/√n. No usa red: los precios vienen del CSV local y la simulación se ejecuta en el propio equipo.
Es el código que acompaña a la ficha
`../../fichas-ideas/p57-opciones-black-scholes-y-monte-carlo.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **NumPy** `>=1.26` (probado con 2.5.2; licencia BSD-3-Clause). Genera el millón de normales y calcula
  media y desviación de los pagos descontados.
- **matplotlib** (opcional, licencia PSF/Matplotlib): solo para `python opciones.py --figura`.
- No hace falta red ni ninguna cuenta: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p57-opciones-black-scholes-y-monte-carlo/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` solo exige NumPy; matplotlib queda comentado porque la figura es opcional.

## Orden de ejecución

```powershell
python opciones.py --comprobar   # solo valida el CSV y muestra volatilidad y precio analítico
python opciones.py               # valora, compara, imprime la convergencia y guarda resultados/
python opciones.py --figura      # además dibuja la distribución del precio final (matplotlib)
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta es **solo stdout** (no escribe en disco) y no usa red. Comprueba **19 cosas**: 250 filas × 6
columnas con 250 fechas únicas, que la apertura coincide con el cierre anterior en las 249 comparaciones
posibles, que máximo y mínimo acotan apertura y cierre en 250/250 filas, que el sha256 del CSV coincide
con el del catálogo, la volatilidad con su convención (diaria 1,16 %, anual 22,24 % con √365), el precio
analítico y su paridad put-call, la monotonía en el strike, que la diferencia |BS − MC| quede por debajo
del error estándar, la reproducibilidad con la semilla 20261112, la convergencia del error como 1/√n, que
los caminos parten del mismo precio y que el código no haga red ni lleve claves. Termina en
`RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). La salida real es la de
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt), con 19 comprobaciones en verde:

- **Entradas:** S = 93,81 € (último cierre), K = 95,00 €, T = 90/365 = 0,2466 años, r = 2,00 % (supuesto
  declarado) y σ = 22,24 % (√365 de la volatilidad diaria del CSV).
- **Black-Scholes:** 3,796263 €. Paridad put-call: −0,722660 = S − K·e^(−rT).
- **Monte Carlo (1.000.000 caminos, semilla 20261112):** 3,792085 €, error estándar 0,006206 €,
  diferencia −0,004179 € = **0,67 errores estándar** (cabe, que es lo que pide el criterio).
- **Convergencia:** n=1.000 → se 0,20090 · n=10.000 → 0,06241 · n=100.000 → 0,01951 · n=1.000.000 →
  0,00621; el error cae por 32,37 al crecer mil veces (teórico √1000 = 31,6).

## Datos de ejemplo

- `datos-ejemplo/precios-accion.csv`: **250 filas × 6 columnas** (`fecha`, `apertura`, `cierre`,
  `maximo`, `minimo`, `volumen`). Serie diaria del 2026-01-01 al 2026-09-07, calendario natural (incluye
  fines de semana), cierre entre 85,66 y 102,89 €. Es copia literal de
  `../../../datasets/csv/precios-accion.csv`, sintética y
  **CC0-1.0**; su sha256 (`15c9d071…`) coincide con el del manifiesto del catálogo.
- `datos-ejemplo/parametros.json`: semilla **20261112**, strike 95,00, plazo 90 días, tasa 2 %, 1.000.000
  de caminos, convención de anualización 365 y tipo `call`.
- `resultados/`: `resumen.csv` (1 fila con todas las entradas y los dos precios), `convergencia.csv` (4
  filas) y `caminos-muestra.csv` (20 caminos finales). Se regeneran al ejecutar `opciones.py`.

## Fuente real y licencia

- **No hay API**: el catálogo declara `api: []` para P57; el CSV es la única fuente y viaja en el ZIP.
- Datos: sintéticos, deterministas y **CC0-1.0**, copiados del catálogo `datasets/`. No proceden de
  personas ni de terceros; un activo anónimo no sirve para conclusiones de mercado.
- NumPy: **BSD-3-Clause**. matplotlib (opcional): **PSF/Matplotlib**.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · CSV y procedencia | Integridad, checksum y contrato de columnas | `Contratos de datos` |
| 2 · Volatilidad con convención | Retornos logarítmicos y anualizar con √365 | `Varianza y desviación típica` |
| 3 · Black-Scholes y paridad | El precio como cartera réplica; la paridad como comprobación | `Valoración de opciones` |
| 4 · Caminos con semilla | Movimiento browniano geométrico y deriva bajo r | `Movimiento browniano` |
| 5 · Error estándar | s/√n sobre pagos descontados, no sobre precios | `Simulación de Monte Carlo` |
| 6 · Diferencia y convergencia | Comparar contra el error y no contra la intuición | `Ley de los grandes números` |
| 7 · Puerta offline | Estabilidad, paridad y tolerancias como contrato | `Precisión y error numérico` |

## Estructura

```text
codigo/
├── opciones.py             # CSV, volatilidad, Black-Scholes, Monte Carlo, convergencia y figuras
├── datos-ejemplo/          # precios-accion.csv (CC0-1.0) y parametros.json
├── verificar.py            # la puerta del proyecto (solo stdout, sin red)
└── resultados/             # ejemplo-salida.txt y los CSV generados
```

## Fallos típicos

- **`ModuleNotFoundError: numpy`**: instala con el mismo Python que ejecuta el script,
  `python -m pip install -r requirements.txt`.
- **Dos convenciones de anualización**: estimar σ con √252 y usar T en días de calendario; el precio se
  desvía y la diferencia deja de caber en el error estándar. Aquí se declara √365 en todo el proyecto.
- **Error estándar mal calculado**: usar la desviación de los precios finales o dividir por n en vez de
  por √n; el error estándar es la desviación de los **pagos descontados** entre √n.
- **Olvidar el descuento**: comparar el pago esperado sin descontar con el precio analítico; la diferencia
  sale del orden de r·T y no del error de la simulación.
- **Semilla no declarada**: un millón de caminos sin semilla no se repite; aquí la semilla 20261112 forma
  parte del contrato y la puerta comprueba que la misma semilla da el mismo precio.
- **Elegir el strike después**: probar strikes hasta que la diferencia quede pequeña es trampa; K y T se
  fijan en `parametros.json` antes de mirar el resultado.
- **`FileNotFoundError` del CSV**: falta `datos-ejemplo/precios-accion.csv`; el ZIP lo trae y no hace
  falta descargarlo de ningún sitio.
