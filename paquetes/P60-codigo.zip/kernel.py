#!/usr/bin/env python3
"""P60 · Regresión por kernel: ancho de banda y compromiso sesgo-varianza — código ejecutable.

Implementa Nadaraya-Watson a mano sobre la serie diaria de ventas, barre anchos de banda a ambos lados
del ciclo semanal, elige por error de validación temporal y estima sesgo y varianza por bootstrap.
Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal de datasets/csv/):
    datos-ejemplo/ventas-mensuales.csv  (180 filas × 4 columnas)

Uso:
    python kernel.py             # calcula y escribe resultados/
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
OBJETIVO = "unidades"  # `ingresos` es derivada (unidades × precio); se declara y no se modela
H_VALORES = (0.5, 1.0, 2.0, 3.5, 7.0, 14.0, 21.0)
CORTE = 150
REPLICAS_BOOTSTRAP = 30
SEMILLA = 20261001


# Paso 1 · Carga la serie y comprueba que es diaria y continua
# Por qué: el nombre «ventas mensuales» engaña; si la frecuencia no es diaria o hay fechas repetidas, el
#          ancho de banda en días no significa lo mismo.
# Salida esperada: "ventas: 180 filas · 4 columnas · 180 días consecutivos"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_ventas() -> pd.DataFrame:
    ruta = DATOS / "ventas-mensuales.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta, parse_dates=["fecha"]).sort_values("fecha").reset_index(drop=True)
    print(f"ventas: {len(df)} filas · {df.shape[1]} columnas · {df['fecha'].nunique()} días")
    return df


def validar_ventas(df: pd.DataFrame) -> dict:
    diferencias = df["fecha"].diff().dropna().dt.days
    resumen = {
        "filas": len(df),
        "columnas": int(df.shape[1]),
        "dias": int(df["fecha"].nunique()),
        "desde": df["fecha"].min().date().isoformat(),
        "hasta": df["fecha"].max().date().isoformat(),
        "consecutivos": bool((diferencias == 1).all()),
        "nulos": int(df.isna().sum().sum()),
        "tiendas": {k: int(v) for k, v in df["tienda"].value_counts().items()},
        "rango_unidades": (int(df["unidades"].min()), int(df["unidades"].max())),
        "total_unidades": int(df["unidades"].sum()),
        "total_ingresos": round(float(df["ingresos"].sum()), 2),
        "junio": int((df["fecha"].dt.month == 6).sum()),
    }
    print(
        f"validación: {resumen['dias']} días consecutivos {resumen['desde']} a {resumen['hasta']} · "
        f"unidades {resumen['rango_unidades'][0]}–{resumen['rango_unidades'][1]} · junio {resumen['junio']} días"
    )
    return resumen


# Paso 2 · Prepara la serie y la partición temporal
# Por qué: la serie está ordenada en el tiempo; una validación aleatoria metería días futuros en el
#          entrenamiento. Se entrena con los primeros 150 días y se valida con los 30 últimos.
# Salida esperada: "partición: 150 train (2026-01-01 a 2026-05-30) · 30 validación (2026-05-31 a 2026-06-29)"
# Si falla: el corte no deja 30 filas → revisa CORTE o el número de filas.
def preparar_serie(df: pd.DataFrame) -> dict:
    serie = df.copy()
    serie["dia"] = np.arange(len(serie))
    serie["dia_semana"] = serie["fecha"].dt.dayofweek
    x = serie["dia"].to_numpy(dtype=float)
    y = serie[OBJETIVO].to_numpy(dtype=float)
    train = np.arange(CORTE)
    validacion = np.arange(CORTE, len(serie))
    print(
        f"partición: {len(train)} train ({serie['fecha'].iloc[0].date()} a {serie['fecha'].iloc[CORTE - 1].date()}) · "
        f"{len(validacion)} validación ({serie['fecha'].iloc[CORTE].date()} a {serie['fecha'].iloc[-1].date()})"
    )
    return {"serie": serie, "x": x, "y": y, "train": train, "validacion": validacion}


# Paso 3 · Implementa Nadaraya-Watson a mano
# Por qué: la predicción es una media ponderada de las observaciones de entrenamiento; los pesos son un
#          kernel gaussiano normalizado por su suma. No se usa una función de librería que lo oculte.
# Salida esperada: "kernel: predicción en el día 160 con h=7 · media ponderada de 150 puntos"
# Si falla: la suma de pesos es 0 → h es tan pequeño que ningún punto pesa; no se divide por cero.
def nadaraya_watson(x_train: np.ndarray, y_train: np.ndarray, x_eval: np.ndarray, h: float) -> np.ndarray:
    distancias = (x_eval[:, None] - x_train[None, :]) / h
    pesos = np.exp(-0.5 * distancias ** 2)
    suma = pesos.sum(axis=1)
    prediccion = (pesos * y_train[None, :]).sum(axis=1) / np.where(suma == 0, 1.0, suma)
    # Con h muy pequeño y un punto de evaluación lejos del entrenamiento, todos los pesos desbordan a
    # cero; en ese caso la estimación honesta es el vecino más cercano, no dividir por cero.
    vacios = np.where(suma == 0)[0]
    if len(vacios) > 0:
        cercano = np.argmin(np.abs(distancias[vacios]), axis=1)
        prediccion[vacios] = y_train[cercano]
    return prediccion


# Paso 4 · Barre los anchos de banda y mide error, con referencia trivial
# Por qué: con h menor que un día se copia el ruido y con h mayor que una semana se aplana el ciclo;
#          el barrido tiene que cubrir los dos lados de 7. Sin RMSE de referencia, el error no dice nada.
# Salida esperada: "barrido: h=21 RMSE validación 16.69 · base 17.23 · puntos efectivos 27.5"
# Si falla: RMSE de validación menor que el de train en todos los h → revisa la partición.
def barrido_anchos(x: np.ndarray, y: np.ndarray, train: np.ndarray, validacion: np.ndarray) -> pd.DataFrame:
    x_train, y_train = x[train], y[train]
    x_validacion, y_validacion = x[validacion], y[validacion]
    media_base = float(y_train.mean())
    rmse_base = float(np.sqrt(np.mean((y_validacion - media_base) ** 2)))
    filas = []
    for h in H_VALORES:
        prediccion_train = nadaraya_watson(x_train, y_train, x_train, h)
        prediccion_validacion = nadaraya_watson(x_train, y_train, x_validacion, h)
        distancias = (x_validacion[:, None] - x_train[None, :]) / h
        pesos = np.exp(-0.5 * distancias ** 2)
        suma = pesos.sum(axis=1)
        with np.errstate(divide="ignore", invalid="ignore"):
            pesos_normalizados = pesos / np.where(suma == 0, 1.0, suma)[:, None]
            puntos_por_fila = np.where(suma == 0, 1.0, 1 / np.sum(pesos_normalizados ** 2, axis=1))
        puntos_efectivos = float(np.mean(puntos_por_fila))
        filas.append(
            {
                "h": h,
                "rmse_train": float(np.sqrt(np.mean((y_train - prediccion_train) ** 2))),
                "rmse_validacion": float(np.sqrt(np.mean((y_validacion - prediccion_validacion) ** 2))),
                "rmse_base": rmse_base,
                "puntos_efectivos": puntos_efectivos,
            }
        )
    tabla = pd.DataFrame(filas)
    elegido = tabla.loc[tabla["rmse_validacion"].idxmin()]
    print(
        f"barrido: h={elegido['h']:g} RMSE validación {elegido['rmse_validacion']:.2f} · "
        f"base {rmse_base:.2f} · puntos efectivos {elegido['puntos_efectivos']:.1f}"
    )
    return tabla


# Paso 5 · Elige el ancho por validación, no por lo bonita que queda la curva
# Por qué: el hiperparámetro se elige fuera de la muestra de entrenamiento; si se elige a ojo, no es una
#          decisión reproducible.
# Salida esperada: "elegido: h=7 (menor RMSE de validación)"
# Si falla: empate entre varios h → se documenta el criterio del primero.
def elegir_h(tabla: pd.DataFrame) -> dict:
    elegido = tabla.loc[tabla["rmse_validacion"].idxmin()]
    return {"h": float(elegido["h"]), "rmse_validacion": float(elegido["rmse_validacion"])}


# Paso 6 · Estima sesgo y varianza por bootstrap
# Por qué: el error total esconde dos componentes; con réplicas sobre el entrenamiento se estima la
#          varianza del estimador y, descomponiendo el error de validación, el sesgo al cuadrado.
# Salida esperada: "sesgo-varianza: h=0.5 varianza 12.3 · h=21 varianza 2.1"
# Si falla: varianza negativa → la descomposición está mal; se informa, no se recorta a escondidas.
def sesgo_varianza(x: np.ndarray, y: np.ndarray, train: np.ndarray, validacion: np.ndarray) -> pd.DataFrame:
    generador = np.random.default_rng(SEMILLA)
    x_train, y_train = x[train], y[train]
    x_validacion, y_validacion = x[validacion], y[validacion]
    filas = []
    for h in H_VALORES:
        prediccion_completa = nadaraya_watson(x_train, y_train, x_validacion, h)
        replicas = []
        for _ in range(REPLICAS_BOOTSTRAP):
            indices = generador.integers(0, len(x_train), len(x_train))
            replicas.append(nadaraya_watson(x_train[indices], y_train[indices], x_validacion, h))
        replicas = np.array(replicas)
        varianza = float(np.mean(np.var(replicas, axis=0)))
        error_cuadratico = float(np.mean((prediccion_completa - y_validacion) ** 2))
        sesgo_cuadrado = max(0.0, error_cuadratico - varianza)
        filas.append(
            {
                "h": h,
                "varianza": varianza,
                "sesgo_cuadrado": sesgo_cuadrado,
                "error_cuadratico_validacion": error_cuadratico,
                "replicas": REPLICAS_BOOTSTRAP,
            }
        )
    tabla = pd.DataFrame(filas)
    print(
        f"sesgo-varianza: h={H_VALORES[0]:g} varianza {tabla.iloc[0]['varianza']:.1f} · "
        f"h={H_VALORES[-1]:g} varianza {tabla.iloc[-1]['varianza']:.1f}"
    )
    return tabla


def texto_informe(
    validacion: dict,
    particion: dict,
    tabla_barrido: pd.DataFrame,
    elegido: dict,
    tabla_sesgo: pd.DataFrame,
) -> str:
    fila = tabla_barrido.set_index("h").loc[elegido["h"]]
    extremo_bajo = tabla_barrido.set_index("h").loc[H_VALORES[0]]
    extremo_alto = tabla_barrido.set_index("h").loc[H_VALORES[-1]]
    return "\n".join(
        [
            "# P60 · Regresión por kernel: ancho de banda y sesgo-varianza",
            "",
            "## Serie y partición",
            f"- Serie **diaria** aunque el fichero se llame «ventas mensuales»: {validacion['filas']} días de",
            f"  {validacion['desde']} a {validacion['hasta']}. junio está incompleto "
            f"({validacion['junio']} días): sus totales no se comparan con meses cerrados.",
            f"- Objetivo: `{OBJETIVO}`. `ingresos` es una columna derivada (unidades × precio) y modelarla",
            "  contra `unidades` sería casi una tautología; se declara y no se usa.",
            f"- Partición temporal sin barajar: {len(particion['train'])} días de entrenamiento y",
            f"  {len(particion['validacion'])} de validación (los últimos 30).",
            "",
            "## Barrido de anchos de banda",
            "| h (días) | RMSE train | RMSE validación | RMSE base | puntos efectivos |",
            "| --- | --- | --- | --- | --- |",
            *[
                f"| {f.h:g} | {f.rmse_train:.2f} | {f.rmse_validacion:.2f} | {f.rmse_base:.2f} | "
                f"{f.puntos_efectivos:.1f} |"
                for f in tabla_barrido.itertuples()
            ],
            "",
            f"El ancho elegido por validación es **h = {elegido['h']:g}** con RMSE "
            f"{elegido['rmse_validacion']:.2f}, frente a {extremo_bajo['rmse_base']:.2f} del modelo trivial.",
            f"- **h pequeño ({H_VALORES[0]:g}) copia el ruido:** su RMSE de entrenamiento es "
            f"{extremo_bajo['rmse_train']:.2f}, pero en validación se dispara a "
            f"{extremo_bajo['rmse_validacion']:.2f}.",
            f"- **h grande ({H_VALORES[-1]:g}) suaviza de más en entrenamiento:** RMSE "
            f"{extremo_alto['rmse_train']:.2f}, con el coste en sesgo; aun así es el que mejor extrapola "
            f"({extremo_alto['rmse_validacion']:.2f} en validación).",
            "- La lectura es que los 30 días de validación caen **fuera** del rango de entrenamiento "
            "(días 150–179 frente a 0–149): el kernel local tiene que extrapolar y un ancho grande es más "
            "estable. En interpolación el ancho óptimo estaría cerca del ciclo semanal; aquí la "
            "comparación con la base muestra que el kernel gana por poco y no se promete más.",
            "",
            "## Sesgo y varianza",
            "| h (días) | varianza | sesgo² | error de validación |",
            "| --- | --- | --- | --- |",
            *[
                f"| {f.h:g} | {f.varianza:.1f} | {f.sesgo_cuadrado:.1f} | {f.error_cuadratico_validacion:.1f} |"
                for f in tabla_sesgo.itertuples()
            ],
            "",
            "La varianza tiende a bajar al crecer h (más puntos pesan en cada predicción) y el sesgo",
            "sube (la media ponderada se aleja de la curva real); con 30 réplicas la estimación es ruidosa",
            "y se declara el método: bootstrap sobre el entrenamiento, no una descomposición exacta.",
            "",
            "## Límite",
            "180 puntos son pocos y la serie es sintética (semilla fija, CC0-1.0): el ancho elegido no se",
            "extrapola fuera del periodo ni a otras tiendas, y 30 días de validación son cuatro ciclos",
            "semanales. El ciclo está atado al índice del generador, no a la semana ISO.",
            "",
        ]
    )


def main() -> int:
    df = cargar_ventas()
    validacion = validar_ventas(df)
    particion = preparar_serie(df)
    tabla_barrido = barrido_anchos(particion["x"], particion["y"], particion["train"], particion["validacion"])
    elegido = elegir_h(tabla_barrido)
    print(f"elegido: h={elegido['h']:g} (menor RMSE de validación)")
    tabla_sesgo = sesgo_varianza(particion["x"], particion["y"], particion["train"], particion["validacion"])
    RESULTADOS.mkdir(exist_ok=True)
    particion["serie"].to_csv(RESULTADOS / "ventas-limpio.csv", index=False)
    tabla_barrido.to_csv(RESULTADOS / "barrido-anchos.csv", index=False)
    tabla_sesgo.to_csv(RESULTADOS / "sesgo-varianza.csv", index=False)
    (RESULTADOS / "informe.md").write_text(
        texto_informe(validacion, particion, tabla_barrido, elegido, tabla_sesgo), encoding="utf-8"
    )
    print(f"escrito: {RESULTADOS / 'informe.md'} · ventas-limpio.csv · barrido-anchos.csv · sesgo-varianza.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
