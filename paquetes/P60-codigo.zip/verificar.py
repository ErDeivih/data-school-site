#!/usr/bin/env python3
"""Puerta del proyecto P60 · regresión por kernel: ancho de banda y sesgo-varianza.

Recalcula la serie, la partición temporal, Nadaraya-Watson, el barrido de anchos, la elección por
validación y la descomposición sesgo-varianza por bootstrap. No usa red y **no escribe ficheros**.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import kernel

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P60 · regresión por kernel ==")

    # Paso 1 · Comprueba la serie y su frecuencia
    # Por qué: el fichero se llama «mensual» pero es diario; si no se declara, el ancho de banda en días
    #          no significa lo que el README dice.
    # Salida esperada: "datos: 180 filas · 180 días consecutivos · junio 29 días"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    df = kernel.cargar_ventas()
    validacion = kernel.validar_ventas(df)
    ok(
        (validacion["filas"], validacion["columnas"], validacion["dias"]) == (180, 4, 180),
        f"datos: {validacion['filas']} filas · {validacion['columnas']} columnas · {validacion['dias']} días",
    )
    ok(
        validacion["consecutivos"] and validacion["nulos"] == 0
        and validacion["desde"] == "2026-01-01" and validacion["hasta"] == "2026-06-29",
        f"180 días consecutivos de {validacion['desde']} a {validacion['hasta']}, sin nulos",
    )
    ok(validacion["tiendas"] == {"centro": 60, "norte": 60, "sur": 60}, f"tiendas en rotación: {validacion['tiendas']}")
    ok(
        validacion["rango_unidades"] == (49, 121)
        and validacion["total_unidades"] == 14295
        and abs(validacion["total_ingresos"] - 192292.08) < 0.01,
        f"rangos y totales: {validacion['rango_unidades']} unidades · {validacion['total_ingresos']:.2f} €",
    )
    ok(validacion["junio"] == 29, "junio está incompleto (29 días) y se declara")

    # Paso 2 · Comprueba la partición temporal
    # Por qué: la validación es temporal; si se barajara, el futuro entraría en el entrenamiento.
    # Salida esperada: "partición: 150 train (2026-01-01 a 2026-05-30) · 30 validación"
    # Si falla: el corte no deja 30 filas o las fechas no son consecutivas.
    particion = kernel.preparar_serie(df)
    ok(
        (len(particion["train"]), len(particion["validacion"])) == (150, 30),
        "partición: 150 días de entrenamiento y 30 de validación",
    )
    fecha_train_fin = particion["serie"]["fecha"].iloc[149].date().isoformat()
    fecha_val_inicio = particion["serie"]["fecha"].iloc[150].date().isoformat()
    ok(fecha_train_fin == "2026-05-30" and fecha_val_inicio == "2026-05-31",
       f"el corte es temporal: train hasta {fecha_train_fin}, validación desde {fecha_val_inicio}")
    ok(particion["serie"]["dia_semana"].between(0, 6).all() and set(particion["serie"]["dia_semana"]) == set(range(7)),
       "los días de la semana están calculados (0–6)")

    # Paso 3 · Comprueba Nadaraya-Watson con la media ponderada a mano
    # Por qué: si la predicción no es la media ponderada por el kernel normalizado, el método no es NW.
    # Salida esperada: "kernel: la predicción es una media ponderada con pesos gaussianos"
    # Si falla: la predicción no coincide con la calculada a mano → el kernel o la normalización están mal.
    x_train, y_train = particion["x"][particion["train"]], particion["y"][particion["train"]]
    punto = np.array([160.0])
    prediccion = kernel.nadaraya_watson(x_train, y_train, punto, 7.0)[0]
    pesos = np.exp(-0.5 * ((punto[:, None] - x_train[None, :]) / 7.0) ** 2)
    manual = float(np.sum(pesos * y_train) / np.sum(pesos))
    ok(abs(prediccion - manual) < 1e-10, "la predicción con h=7 es la media ponderada gaussiana normalizada")
    vecino = kernel.nadaraya_watson(x_train, y_train, punto, 1e-9)[0]
    ok(abs(vecino - float(y_train[150 - 1])) < 1e-12, "con h muy pequeño la estimación es el vecino más cercano")

    # Paso 4 · Comprueba el barrido de anchos de banda
    # Por qué: el criterio exige al menos tres anchos con valores a ambos lados de 7 y RMSE de train,
    #          validación y referencia trivial.
    # Salida esperada: "barrido: 7 anchos · h=21 RMSE validación 16.69 · base 17.23"
    # Si falla: no hay valores por debajo o por encima de 7 → el barrido no cubre el ciclo semanal.
    tabla = kernel.barrido_anchos(particion["x"], particion["y"], particion["train"], particion["validacion"])
    ok(len(tabla) == 7 and min(tabla["h"]) < 7 < max(tabla["h"]), f"barrido: {len(tabla)} anchos de banda a ambos lados de 7")
    ok(abs(float(tabla["rmse_base"].iloc[0]) - 17.233741) < 1e-5, f"RMSE de referencia trivial: {tabla['rmse_base'].iloc[0]:.4f}")
    ok(
        abs(float(tabla.set_index('h').loc[0.5, 'rmse_train']) - 2.418001) < 1e-5
        and abs(float(tabla.set_index('h').loc[0.5, 'rmse_validacion']) - 38.286936) < 1e-5,
        "h pequeño: RMSE de train 2.42 y de validación 38.29 (el ruido no generaliza)",
    )
    ok(
        bool(tabla["rmse_train"].is_monotonic_increasing) and bool(tabla["rmse_validacion"].is_monotonic_decreasing),
        "el RMSE de train sube con h y el de validación baja: el compromiso se ve en la tabla",
    )

    # Paso 5 · Comprueba la elección por validación
    # Por qué: el ancho se elige fuera de la muestra; el elegido tiene que ser el mínimo de validación.
    # Salida esperada: "elegido: h=21 (menor RMSE de validación 16.69)"
    # Si falla: el h elegido no es el mínimo → la elección no es reproducible.
    elegido = kernel.elegir_h(tabla)
    ok(elegido["h"] == float(tabla.loc[tabla["rmse_validacion"].idxmin(), "h"]), f"elegido por validación: h={elegido['h']:g}")
    ok(abs(elegido["rmse_validacion"] - 16.688609) < 1e-5, f"RMSE de validación del elegido: {elegido['rmse_validacion']:.4f}")
    ok(elegido["rmse_validacion"] < float(tabla["rmse_base"].iloc[0]), "el kernel supera al modelo trivial en validación")

    # Paso 6 · Comprueba la descomposición sesgo-varianza
    # Por qué: el error total no basta; se estiman las dos componentes por bootstrap y se declara el método.
    # Salida esperada: "sesgo-varianza: h=0.5 varianza 162.6 · h=21 varianza 8.6"
    # Si falla: error_cuadratico ≠ varianza + sesgo² → la descomposición está mal.
    tabla_sesgo = kernel.sesgo_varianza(particion["x"], particion["y"], particion["train"], particion["validacion"])
    ok(len(tabla_sesgo) == 7 and int(tabla_sesgo["replicas"].iloc[0]) == 30, "7 anchos con 30 réplicas de bootstrap")
    ok(
        abs(float(tabla_sesgo.set_index('h').loc[0.5, 'varianza']) - 162.619149) < 1e-4
        and abs(float(tabla_sesgo.set_index('h').loc[21.0, 'varianza']) - 8.618065) < 1e-4,
        "la varianza baja al crecer h (162.62 → 8.62)",
    )
    suma = tabla_sesgo["varianza"] + tabla_sesgo["sesgo_cuadrado"]
    ok(bool((suma - tabla_sesgo["error_cuadratico_validacion"]).abs().lt(1e-9).all()),
       "error² de validación = varianza + sesgo² (descomposición declarada)")
    ok(bool((tabla_sesgo["sesgo_cuadrado"] >= 0).all()), "ningún sesgo cuadrado negativo tras el recorte")

    # Paso 7 · Comprueba que el informe declara frecuencia, elegido y límite
    # Por qué: el entregable explica que la serie es diaria, que junio está incompleto, que `ingresos` es
    #          derivada y que el ancho no se extrapola fuera del periodo.
    # Salida esperada: "el informe declara diaria, junio, ingresos derivada, h elegido y límite"
    # Si falla: falta alguna de las advertencias del README.
    informe = kernel.texto_informe(validacion, particion, tabla, elegido, tabla_sesgo)
    ok("diaria" in informe and "junio" in informe and "derivada" in informe, "el informe declara diaria, junio incompleto e ingresos derivada")
    ok(f"h = {elegido['h']:g}" in informe and "extrapolar" in informe and "Límite" in informe,
       "el informe declara el ancho elegido, la extrapolación y el límite")

    # Paso 8 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (kernel.RAIZ / "kernel.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
