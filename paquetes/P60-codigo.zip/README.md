# P60 · Regresión por kernel: ancho de banda y compromiso sesgo-varianza — código ejecutable

Implementa Nadaraya-Watson a mano sobre la serie diaria de ventas, barre siete anchos de banda a ambos
lados del ciclo semanal, elige por error de validación temporal y estima sesgo y varianza por bootstrap.
Es el código que acompaña a la ficha
`../../fichas-ideas/p60-regresion-por-kernel.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** y **numpy >= 1.26** (ambas BSD-3-Clause).
- Windows, Linux o macOS: sin red ni servicios externos.

## Instalación

```powershell
cd proyectos/p60-regresion-por-kernel/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python kernel.py
```

Recorre los pasos, imprime una línea por paso y escribe en `resultados/` los ficheros
`ventas-limpio.csv`, `barrido-anchos.csv`, `sesgo-varianza.csv` e `informe.md`. Los generados no viajan
en el ZIP: solo `ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: 180 días consecutivos (junio incompleto, 29 días),
totales 14 295 unidades y 192 292,08 €, la partición temporal 150/30, la predicción de Nadaraya-Watson
como media ponderada gaussiana, siete anchos de banda (0,5 a 21, con valores a ambos lados de 7), el
RMSE de referencia trivial (17,23), el ancho elegido por validación (h = 21, RMSE 16,69) y la
descomposición varianza + sesgo² = error² con 30 réplicas de bootstrap. Termina en `RESULTADO: VERDE`
(0) o `RESULTADO: ROJO` (1). No usa red. La salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/ventas-mensuales.csv`: **180 filas × 4 columnas** (`fecha`, `tienda`, `unidades`,
  `ingresos`); 180 días consecutivos del 2026-01-01 al 2026-06-29, una fila por fecha, tres tiendas en
  rotación.
- **Sintético, determinista y CC0-1.0**: copia literal de `datasets/csv/`, con
  `sha256:afa71a0b0ae0189e863247ff5a25f4ebe1836742ac7686f929d6a42565ecf7f6`; tamaño y columnas en
  `datasets.json`.
- El CSV **no trae** precio, coste, margen ni calendario laboral; `ingresos` es derivada
  (`unidades × precio`) y no se modela.

## Fuente real y licencia

- **No hay API**: la ficha declara `api: []`; el proyecto usa solo el CSV local.
- Datos sintéticos CC0-1.0. Dependencias: pandas y numpy BSD-3-Clause.

## Supuestos declarados

- **Variable objetivo `unidades`**; `ingresos` es derivada y modelarla contra `unidades` sería una
  tautología. Se declara y no se usa.
- **Partición temporal sin barajar:** 150 días de entrenamiento y los 30 últimos de validación.
- **Anchos de banda:** 0,5, 1, 2, 3,5, 7, 14 y 21 días; el elegido es el de menor RMSE de validación.
- **Lectura de la validación:** los 30 días de validación caen fuera del rango de entrenamiento
  (días 150–179 frente a 0–149), así que el kernel **extrapola**; por eso gana el ancho grande. En la
  tabla, el RMSE de train sube con h (sesgo) y el de validación baja (estabilidad). El modelo trivial
  (media de train) da 17,23 y el kernel 16,69: gana por poco y no se promete más.
- **Sesgo-varianza:** varianza por bootstrap (30 réplicas sobre el entrenamiento) y sesgo² como
  `error² de validación − varianza`, recortado a cero. Es una estimación declarada, no una
  descomposición exacta.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Serie y frecuencia | Una serie diaria con nombre engañoso | `Series temporales en pandas` |
| 2 · Partición temporal | Validar sin ver el futuro | `Validación temporal` |
| 3 · Nadaraya-Watson | Media ponderada por kernel | `KNN y métodos locales` |
| 4 · Barrido de h | Elegir hiperparámetro por validación | `Selección de hiperparámetros` |
| 5 · Sesgo-varianza | Las dos componentes del error | `Sesgo, varianza y MSE` |
| 6 · Lectura y límite | Leer una curva sin prometer de más | `Visualización honesta` |

## Estructura

```text
codigo/
├── kernel.py              # serie, partición, Nadaraya-Watson, barrido, sesgo-varianza e informe
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas y numpy
├── datos-ejemplo/         # ventas-mensuales.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **Validación aleatoria:** barajar la serie mete días futuros en el entrenamiento; la partición es
  temporal y se declara.
- **Confundir el nombre:** el fichero se llama «mensual» y es diario; los meses hay que agregarlos y
  junio está incompleto.
- **Modelar `ingresos`:** es `unidades × precio`; predecirla contra `unidades` da una R² de tautología.
- **h a ojo:** el ancho se elige por validación, no por lo bonita que queda la curva.
- **Extrapolar sin decirlo:** la validación cae fuera del rango de entrenamiento; el informe lo explica.
- **`ModuleNotFoundError: pandas`**: instala las dependencias con el mismo Python que ejecuta el script.
