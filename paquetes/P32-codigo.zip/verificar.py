#!/usr/bin/env python3
"""Puerta del proyecto P32 (eficiencia por posesión).

Comprueba emparejamiento de los 120 partidos, totales, puntos por posesión, triples y ventaja de casa.
Sin escribir en disco. VERDE (0) o ROJO (1).
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import eficiencia

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "nba-partidos.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    datos = eficiencia.leer(CSV)
    ok(len(datos["filas"]) == 240, "el CSV tiene 240 filas (120 partidos × 2 lados)")
    ok(len(datos["partidos"]) == 120, "hay 120 partidos emparejados")
    ok(all(p["a"]["equipo"] == p["b"]["rival"] for p in datos["partidos"]), "los 120 pares son recíprocos")

    tabla = eficiencia.tabla_equipos(datos)
    ok(len(tabla) == 12, "hay 12 equipos")
    ok(all(e["partidos"] == 20 for e in tabla.values()), "cada equipo juega 20 partidos")
    ok(sum(e["partidos"] for e in tabla.values()) == 240, "los partidos por equipo suman 240 lados")
    ok(sum(e["victorias"] for e in tabla.values()) == 120, "las victorias suman 120")
    ok(sum(e["puntos"] for e in tabla.values()) == 24947, "los puntos suman 24.947")
    ok(sum(e["posesiones"] for e in tabla.values()) == 22948, "las posesiones suman 22.948")
    ok(sum(e["triples_aciertos"] for e in tabla.values()) == 2835, "los triples anotados suman 2.835")
    ok(sum(e["triples_intentos"] for e in tabla.values()) == 8284, "los intentos de triple suman 8.284")

    ppp = sum(e["puntos"] for e in tabla.values()) / sum(e["posesiones"] for e in tabla.values())
    ok(round(ppp, 5) == 1.08711, "los puntos por posesión globales son 1,08711")
    t3 = sum(e["triples_aciertos"] for e in tabla.values()) / sum(e["triples_intentos"] for e in tabla.values())
    ok(round(t3, 5) == 0.34223, "el acierto en triples global es 34,223 %")

    casa = eficiencia.ventaja_casa(datos)
    ok(casa["partidos"] == 120, "la ventaja de casa se mide sobre 120 partidos")
    ok(casa["victorias_local"] == 70, "el local gana 70 partidos")
    ok(round(casa["tasa"], 5) == 0.58333, "la tasa de victoria local es 58,333 %")
    ok(sum(1 for e in tabla.values() if e["victorias"] > 10) > 0, "hay equipos por encima del 50 % de victorias")

    codigo = (AQUI / "eficiencia.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
