# P32 · NBA: del box score a la eficiencia por posesión

Paquete descargable de **Data School** para el proyecto P32. Incluye el box score de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python eficiencia.py
python verificar.py
```

`eficiencia.py` empareja los dos lados de cada partido, comprueba que son recíprocos y calcula por equipo
puntos por posesión, acierto en triples y ventaja de casa. `verificar.py` sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/nba-partidos.csv`: **240 filas × 11 columnas** (120 partidos × 2 lados, 12 equipos, 20
  partidos por equipo). Sintético y **CC0-1.0**; es el `nba-partidos` del catálogo de Data School.

## Salida esperada

```text
partidos: 120 · equipos: 12 · filas: 240
ventaja de casa: 70/120 (58.33%)
equipo       PJ  V   puntos  posesiones  puntos/posesión  3P%
...
límite: 20 partidos por equipo en una sola temporada sintética; no decide quién es mejor.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Emparejar los lados | `leer` comprueba rival recíproco y un local por partido | pandas: agrupaciones y joins |
| 2 · Acumular por equipo | `tabla_equipos` suma puntos, posesiones y triples | hechos y dimensiones |
| 3 · Eficiencia | puntos / posesiones, no puntos / partido | hechos y dimensiones |
| 4 · Ventaja de casa | `ventaja_casa` mide 70/120 | visualización estadística |
| 5 · Publicar y acotar | `main` ordena por victorias y declara el límite | visualización estadística |

## Fallos típicos

- **`el partido no tiene dos lados`**: falta una fila del box score; los totales no cuadrarían.
- **`rival no recíproco`**: el equipo A dice B pero B no dice A; los cruces están mal.
- **`debe haber exactamente un local`**: el campo `local` está duplicado o vacío.
- **Dividir puntos entre partidos en vez de posesiones**: la eficiencia se mide por posesión.

## Límite

Son 20 partidos por equipo de una temporada sintética. Sirven para aprender a emparejar lados y medir
eficiencia, no para decidir qué equipo es mejor.
