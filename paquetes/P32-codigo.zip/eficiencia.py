"""P32 · NBA: del box score a la eficiencia por posesión.

Empareja los dos lados de cada partido, comprueba los marcadores y calcula puntos por posesión, acierto
en triples y ventaja de casa por equipo. Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("fecha", "equipo", "rival", "local", "puntos", "posesiones",
            "triples_intentos", "triples_aciertos", "rebotes", "perdidas", "victoria")


def leer(ruta: Path) -> dict:
    # Paso 1 · Leer y comprobar el grano: dos lados por partido, equipos recíprocos y un local.
    # Por qué: si los dos lados no se emparejan, los totales de puntos no cuadran.
    # Salida esperada: 120 partidos y 240 filas.
    # Si falla: «partido sin dos lados» o «rival no recíproco».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 240:
        raise ValueError(f"se esperaban 240 filas, hay {len(filas)}")
    por_fecha = defaultdict(list)
    for fila in filas:
        por_fecha[fila["fecha"]].append(fila)
    if len(por_fecha) != 120:
        raise ValueError(f"se esperaban 120 fechas, hay {len(por_fecha)}")
    partidos = []
    for fecha, lados in por_fecha.items():
        if len(lados) != 2:
            raise ValueError(f"{fecha}: el partido no tiene dos lados")
        a, b = lados
        if a["equipo"] != b["rival"] or b["equipo"] != a["rival"]:
            raise ValueError(f"{fecha}: rival no recíproco")
        if int(a["local"]) + int(b["local"]) != 1:
            raise ValueError(f"{fecha}: debe haber exactamente un local")
        if int(a["victoria"]) + int(b["victoria"]) != 1:
            raise ValueError(f"{fecha}: debe haber exactamente un ganador")
        partidos.append({"fecha": fecha, "a": a, "b": b, "local": a if int(a["local"]) == 1 else b})
    return {"filas": filas, "partidos": partidos}


def tabla_equipos(datos: dict) -> dict:
    # Paso 2 · Acumular por equipo: partidos, victorias, puntos, posesiones y triples.
    # Por qué: la eficiencia se mide por posesión, no por partido; el denominador es la clave.
    # Salida esperada: 12 equipos con 20 partidos cada uno.
    # Si falla: algún equipo no aparece en los dos lados.
    equipos = defaultdict(lambda: {"partidos": 0, "victorias": 0, "puntos": 0, "posesiones": 0,
                                   "triples_intentos": 0, "triples_aciertos": 0, "local": 0, "visitante": 0,
                                   "victorias_local": 0, "victorias_visitante": 0})
    for fila in datos["filas"]:
        e = equipos[fila["equipo"]]
        e["partidos"] += 1
        e["victorias"] += int(fila["victoria"])
        e["puntos"] += int(fila["puntos"])
        e["posesiones"] += int(fila["posesiones"])
        e["triples_intentos"] += int(fila["triples_intentos"])
        e["triples_aciertos"] += int(fila["triples_aciertos"])
        if int(fila["local"]) == 1:
            e["local"] += 1
            e["victorias_local"] += int(fila["victoria"])
        else:
            e["visitante"] += 1
            e["victorias_visitante"] += int(fila["victoria"])
    return dict(equipos)


def ventaja_casa(datos: dict) -> dict:
    # Paso 3 · Medir la ventaja de casa: victorias del local sobre partidos.
    # Por qué: antes de comparar equipos hay que saber si el calendario está equilibrado.
    # Salida esperada: 70 victorias locales de 120 partidos (58,33 %).
    # Si falla: la columna local no está bien repartida.
    locales = sum(int(p["local"]["victoria"]) for p in datos["partidos"])
    return {"partidos": len(datos["partidos"]), "victorias_local": locales,
            "tasa": locales / len(datos["partidos"])}


def main() -> int:
    # Paso 4 · Publicar la tabla y el límite de la muestra.
    # Por qué: 20 partidos por equipo no bastan para concluir quién es mejor; se declara.
    # Salida esperada: 12 equipos, puntos por posesión y ventaja de casa.
    # Si falla: revisa la ruta del CSV o el emparejamiento de lados.
    parser = argparse.ArgumentParser(description="Eficiencia por posesión (P32)")
    parser.add_argument("--csv", default="datos-ejemplo/nba-partidos.csv")
    args = parser.parse_args()
    datos = leer(Path(args.csv))
    tabla = tabla_equipos(datos)
    casa = ventaja_casa(datos)
    print(f"partidos: {len(datos['partidos'])} · equipos: {len(tabla)} · filas: {len(datos['filas'])}")
    print(f"ventaja de casa: {casa['victorias_local']}/{casa['partidos']} ({casa['tasa']:.2%})")
    print("equipo       PJ  V   puntos  posesiones  puntos/posesión  3P%")
    for equipo, e in sorted(tabla.items(), key=lambda kv: -kv[1]["victorias"]):
        ppp = e["puntos"] / e["posesiones"]
        t3 = e["triples_aciertos"] / e["triples_intentos"]
        print(f"{equipo:<10} {e['partidos']:>3} {e['victorias']:>2} {e['puntos']:>8} {e['posesiones']:>11} {ppp:>15.3f} {t3:>6.2%}")
    print("límite: 20 partidos por equipo en una sola temporada sintética; no decide quién es mejor.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
