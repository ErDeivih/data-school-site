# P16 · Un memo de inversión con supuestos y sensibilidad

Paquete descargable de **Data School** para el proyecto P16. Incluye el CSV de ejemplo, el código
comentado paso a paso, un **memo Markdown de una página** y un verificador. No necesita conexión ni
dependencias.

La pregunta del proyecto es cómo se escribe una recomendación que se pueda discutir: una cartera
equiponderada de cinco acciones, sus métricas de retorno y riesgo, **dos escenarios** (base y
adverso) y una **tabla de sensibilidad** al supuesto de retorno. El memo declara sus supuestos, su
fuente, su fecha y sus límites; sin eso, no es un memo, es una opinión.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice. El memo se genera como Markdown.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python memo.py
python verificar.py
```

Para guardar el memo:

```bash
python memo.py --memo resultados/memo.md
```

Desde la carpeta del paquete (el CSV se busca en `datos-ejemplo/`):

```bash
cd P16-codigo
python memo.py --csv datos-ejemplo/cartera-acciones.csv --memo resultados/memo.md
```

## Salida esperada

```text
cartera: 60 meses · media mensual -0.046 % · volatilidad anual 8.38 %
retorno anualizado: aritmético -0.55 % · geométrico -0.89 % · Sharpe -0.07
riesgo: VaR95 mensual -3.63 % · máxima caída -21.37 %
escenarios a 12 meses: base -0.89 % · adverso -38.93 %
sensibilidad (10.000 €): -4.9%→9.511 € a 1 a. · -2.9%→9.711 € · -0.9%→9.911 € · +1.1%→10.111 € · +3.1%→10.311 €
memo: escrito en resultados/memo.md
fuente: cartera-acciones (catálogo Data School) · 60 meses sintéticos · 5 acciones · fecha 2026-11-10
límite: datos sintéticos y 60 meses; no es asesoramiento financiero.
```

El memo completo está en `resultados/memo.md`; la salida de consola, en
`resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/cartera-acciones.csv`: **360 filas × 3 columnas** (`mes`, `activo`, `retorno`).
  60 meses × 6 activos: el índice y cinco acciones. Retornos mensuales en tanto por uno.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `cartera-acciones` del catálogo.
  No son datos reales de ninguna acción ni índice.
- `sha256` del fichero: `62ccc9a7355a27559024f7e4b725792d2be58a379fad4b4740a8a6fd25eacd51`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida grano, 60 meses y 6 activos | base de una cartera |
| 2 · Cartera | equipondera las cinco acciones | decisión explícita de pesos |
| 3 · Métricas | retorno aritmético y geométrico, volatilidad, Sharpe, VaR y máxima caída | riesgo y retorno no son una cifra |
| 4 · Escenarios | base (geométrico) y adverso (percentil 5 mensual compuesto) | incertidumbre con una regla |
| 5 · Sensibilidad | ±4 y ±2 puntos de retorno anual | qué pasa si el supuesto se equivoca |
| 6 · Memo | recomendación, supuestos, cifras, límites y fuente | escribir para que se pueda discutir |

## Las tres trampas que el código deja a la vista

1. **Retorno medio no es riqueza final.** La media aritmética anual es −0,55 % y la geométrica
   −0,89 %: la volatilidad se come la diferencia (volatility drag). El memo usa la geométrica en la
   base y la aritmética solo como referencia.
2. **Un escenario adverso no es «un mal año».** Se define como componer el percentil 5 mensual
   durante 12 meses (−4,03 % mensual → −38,93 % anual): es una hipótesis explícita, no una predicción.
3. **Una cifra sin sensibilidad no se puede discutir.** La tabla muestra qué pasa con 10.000 € si el
   retorno se desvía ±2 y ±4 puntos; la conclusión se apoya en la tabla, no en el número central.

## Fallos típicos

- **`ModuleNotFoundError: memo`**: ejecuta desde la carpeta del paquete.
- **`FileNotFoundError`**: `--memo` y `--csv` son relativos al directorio actual.
- **`cada activo debe tener los 60 meses`**: falta un mes o una fila duplicada.
- **Volatilidad 0**: una serie constante; el Sharpe no estaría definido y el código lo evita.
- **El memo no cambia al cambiar el CSV**: se está escribiendo en otra ruta o no se pasó `--memo`.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P16-codigo/
├── memo.py                    # pasos 1–6: cartera, métricas, escenarios y memo
├── verificar.py               # la puerta del proyecto: 34 comprobaciones
├── requirements.txt           # sin dependencias
├── datos-ejemplo/
│   └── cartera-acciones.csv   # 360 × 3 · sintético, CC0-1.0
└── resultados/
    ├── memo.md                # el memo de una página listo para leer
    └── ejemplo-salida.txt     # la salida real de una ejecución
```

## Límite

Son 60 meses sintéticos de cinco acciones equiponderadas. El memo enseña el **método** (métricas,
escenarios, sensibilidad, supuestos y límites), no una recomendación de inversión: no describe
ninguna acción real, no predice rentabilidades y no es asesoramiento financiero.
