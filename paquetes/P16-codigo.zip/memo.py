"""P16 · Un memo de inversión con supuestos y sensibilidad.

Construye una cartera equiponderada con cinco acciones, mide su retorno y su riesgo históricos y
escribe un memo de una página con dos escenarios (base y adverso), una tabla de sensibilidad al
supuesto de retorno y los límites de la muestra. Sin promesas: el memo dice qué asume y qué no.

Sin dependencias externas: solo la biblioteca estándar. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("mes", "activo", "retorno")
MERCADO = "indice"
ACCIONES = ("accion-a", "accion-b", "accion-c", "accion-d", "accion-e")
MESES = 60
Z = 1.645          # cola del 5 % en una normal
INVERSION = 10_000.0
FECHA = "2026-11-10"
FUENTE = "cartera-acciones (catálogo Data School) · 60 meses sintéticos · 5 acciones"


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el grano: una fila por mes y activo.
    # Por qué: una cartera equiponderada necesita la MISMA fecha en todos los activos.
    # Salida esperada: 360 filas, 60 meses y 6 activos.
    # Si falla: «columnas inesperadas» o un activo con menos meses que otro.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 360:
        raise ValueError(f"se esperaban 360 filas, hay {len(filas)}")
    por_activo = defaultdict(int)
    for fila in filas:
        float(fila["retorno"])
        por_activo[fila["activo"]] += 1
    if set(por_activo) != {MERCADO, *ACCIONES}:
        raise ValueError(f"activos inesperados: {sorted(por_activo)}")
    if any(n != MESES for n in por_activo.values()):
        raise ValueError("cada activo debe tener los 60 meses")
    return filas


def cartera(filas: list[dict]) -> list[float]:
    # Paso 2 · Cartera equiponderada: el retorno de cada mes es la media de las cinco acciones.
    # Por qué: equiponderar es una decisión explícita; si se pondera por algo, hay que decirlo.
    # Salida esperada: 60 retornos mensuales de la cartera.
    por_mes = defaultdict(dict)
    for fila in filas:
        por_mes[fila["mes"]][fila["activo"]] = float(fila["retorno"])
    meses = sorted(por_mes)
    return [sum(por_mes[m][a] for a in ACCIONES) / len(ACCIONES) for m in meses]


def media(valores: list[float]) -> float:
    return sum(valores) / len(valores)


def desviacion(valores: list[float]) -> float:
    m = media(valores)
    return math.sqrt(sum((v - m) ** 2 for v in valores) / (len(valores) - 1))


def percentil(valores: list[float], p: float) -> float:
    orden = sorted(valores)
    pos = (len(orden) - 1) * p
    bajo, alto = math.floor(pos), math.ceil(pos)
    return orden[bajo] + (orden[alto] - orden[bajo]) * (pos - bajo)


def metricas(retornos: list[float]) -> dict:
    # Paso 3 · Métricas de la cartera: retorno anualizado (aritmético y geométrico), volatilidad,
    # Sharpe con tipo libre de riesgo 0, VaR histórico al 95 % y máxima caída.
    # Por qué: el retorno medio no basta; dos carteras con la misma media acaban en sitios distintos.
    # Salida esperada: cifras coherentes (vol > 0, drawdown entre -100 % y 0).
    mensual = media(retornos)
    sd = desviacion(retornos)
    riqueza = 1.0
    pico, caida = 1.0, 0.0
    for r in retornos:
        riqueza *= 1 + r
        pico = max(pico, riqueza)
        caida = min(caida, riqueza / pico - 1)
    anual_aritmetico = mensual * 12
    anual_geometrico = riqueza ** (12 / MESES) - 1
    volatilidad = sd * math.sqrt(12)
    return {"mensual": mensual, "sd_mensual": sd, "anual_aritmetico": anual_aritmetico,
            "anual_geometrico": anual_geometrico, "volatilidad": volatilidad,
            "sharpe": anual_aritmetico / volatilidad if volatilidad else 0.0,
            "var95_mensual": percentil(retornos, 0.05), "max_caida": caida,
            "riqueza_final": riqueza}


def escenarios(m: dict) -> dict:
    # Paso 4 · Dos escenarios, base y adverso, con la MISMA lógica de composición mensual.
    # Por qué: el adverso no es «un mal año»: es el percentil 5 de la distribución mensual
    # compuesto 12 veces, que es una hipótesis explícita y discutible.
    adverso_mensual = m["mensual"] - Z * m["sd_mensual"]
    # Base = retorno geométrico histórico (incluye el coste de la volatilidad); adverso = componer
    # el percentil 5 mensual durante 12 meses. Las dos son hipótesis, no predicciones.
    base = m["anual_geometrico"]
    adverso = (1 + adverso_mensual) ** 12 - 1
    return {"base": base, "adverso": adverso, "adverso_mensual": adverso_mensual}


def sensibilidad(base_anual: float) -> list[dict]:
    # Paso 5 · Sensibilidad al supuesto de retorno anual: qué pasa si se equivoca en ±2 puntos.
    # Por qué: un memo con una sola cifra no se puede discutir; con una tabla, sí.
    # Salida esperada: 5 filas de retorno supuesto con valor a 1 y 5 años.
    filas = []
    for delta in (-0.04, -0.02, 0.0, 0.02, 0.04):
        anual = base_anual + delta
        filas.append({"anual": anual,
                      "un_anio": INVERSION * (1 + anual),
                      "cinco_anios": INVERSION * (1 + anual) ** 5})
    return filas


def dinero(valor: float) -> str:
    return f"{valor:,.0f} €".replace(",", ".")


def memo(m: dict, e: dict, tabla: list[dict]) -> str:
    # Paso 6 · Componer el memo de una página: recomendación, supuestos, escenarios, sensibilidad
    # y límites. Sin fuente ni supuestos no es un memo, es una opinión.
    lineas = [
        "# Memo de una página · cartera equiponderada de cinco acciones",
        "",
        f"**Fecha:** {FECHA} · **Fuente:** {FUENTE} · **Inversión de referencia:** {dinero(INVERSION)}",
        "",
        "## Qué se propone",
        "Mantener una cartera equiponderada de las cinco acciones de la muestra durante 12 meses, "
        "con reequilibrio anual y sin apalancamiento. La recomendación es **condicional**: depende "
        "de que se acepten los supuestos de abajo.",
        "",
        "## Supuestos",
        f"1. Los 60 meses sintéticos son representativos del próximo año (no lo son: es un CSV de práctica).",
        "2. Los retornos se componen mes a mes y no hay costes de transacción ni impuestos.",
        "3. El tipo libre de riesgo es 0 y la cartera se mantiene equiponderada.",
        "",
        "## Escenarios a 12 meses",
        f"- **Base:** retorno anual compuesto {e['base'] * 100:+.2f} % → {dinero(INVERSION * (1 + e['base']))}.",
        f"- **Adverso (percentil 5 mensual):** retorno mensual {e['adverso_mensual'] * 100:+.2f} % → "
        f"{e['adverso'] * 100:+.2f} % anual → {dinero(INVERSION * (1 + e['adverso']))}.",
        f"- Volatilidad anualizada: {m['volatilidad'] * 100:.2f} % · Sharpe (rf=0): {m['sharpe']:.2f}.",
        f"- VaR histórico mensual al 95 %: {m['var95_mensual'] * 100:+.2f} % · máxima caída: {m['max_caida'] * 100:.2f} %.",
        "",
        "## Sensibilidad al supuesto de retorno",
        "| Retorno anual supuesto | Valor a 1 año | Valor a 5 años |",
        "| ---: | ---: | ---: |",
        *[f"| {f['anual'] * 100:+.1f} % | {dinero(f['un_anio'])} | {dinero(f['cinco_anios'])} |" for f in tabla],
        "",
        "## Límites",
        "- Datos **sintéticos**: no describen ninguna acción, fondo ni índice real.",
        "- 60 meses es una muestra corta; el escenario adverso es una hipótesis, no una predicción.",
        "- Sin costes, impuestos ni liquidez: un backtest de juguete no es una cartera real.",
        "- Esto **no es asesoramiento financiero**.",
        "",
        f"**Conclusión:** con los supuestos aceptados, el escenario base da {e['base'] * 100:+.1f} % y el "
        f"adverso {e['adverso'] * 100:+.1f} %; el valor del memo está en que las dos cifras y la "
        "sensibilidad se pueden discutir, no en la recomendación.",
    ]
    return "\n".join(lineas)


def main() -> int:
    parser = argparse.ArgumentParser(description="P16 · memo de inversión con escenarios y sensibilidad")
    parser.add_argument("--csv", default="datos-ejemplo/cartera-acciones.csv")
    parser.add_argument("--memo", default="", help="ruta donde escribir el memo en Markdown")
    args = parser.parse_args()

    retornos = cartera(leer(Path(args.csv)))
    m = metricas(retornos)
    e = escenarios(m)
    tabla = sensibilidad(e["base"])
    texto = memo(m, e, tabla)
    if args.memo:
        Path(args.memo).write_text(texto, encoding="utf-8")

    print(f"cartera: {len(retornos)} meses · media mensual {m['mensual'] * 100:+.3f} % · "
          f"volatilidad anual {m['volatilidad'] * 100:.2f} %")
    print(f"retorno anualizado: aritmético {m['anual_aritmetico'] * 100:+.2f} % · "
          f"geométrico {m['anual_geometrico'] * 100:+.2f} % · Sharpe {m['sharpe']:.2f}")
    print(f"riesgo: VaR95 mensual {m['var95_mensual'] * 100:+.2f} % · máxima caída {m['max_caida'] * 100:.2f} %")
    print(f"escenarios a 12 meses: base {e['base'] * 100:+.2f} % · adverso {e['adverso'] * 100:+.2f} %")
    print("sensibilidad (10.000 €):", " · ".join(
        f"{f['anual'] * 100:+.1f}%→{dinero(f['un_anio'])} a 1 a." for f in tabla))
    print("memo: " + ("escrito en " + args.memo if args.memo else "generado en memoria; usa --memo salida.md para guardarlo"))
    print(f"fuente: {FUENTE} · fecha {FECHA}")
    print("límite: datos sintéticos y 60 meses; no es asesoramiento financiero.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
