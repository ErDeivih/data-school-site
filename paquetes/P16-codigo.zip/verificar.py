#!/usr/bin/env python3
"""Puerta del proyecto P16 (memo de inversión con escenarios y sensibilidad).

Comprueba la cartera, sus métricas, los dos escenarios, la tabla de sensibilidad, que el memo
declara supuestos, fuente y límites, y que el código no usa red ni claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import memo

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "cartera-acciones.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.5f} ≈ {esperado:.5f})")


def main() -> int:
    filas = memo.leer(CSV)
    ok(len(filas) == 360, "el CSV tiene 360 filas")
    ok(len({f["mes"] for f in filas}) == 60, "hay 60 meses")
    ok({f["activo"] for f in filas} == {"indice", *memo.ACCIONES}, "están el índice y las 5 acciones")

    retornos = memo.cartera(filas)
    ok(len(retornos) == 60, "la cartera tiene 60 retornos mensuales")
    m = memo.metricas(retornos)
    cerca(m["mensual"], -0.000457, 0.00001, "retorno mensual medio de la cartera")
    cerca(m["sd_mensual"], 0.024199, 0.00005, "desviación mensual")
    cerca(m["anual_aritmetico"], -0.00548, 0.0005, "retorno anual aritmético")
    cerca(m["anual_geometrico"], -0.008896, 0.0005, "retorno anual geométrico")
    cerca(m["volatilidad"], 0.083829, 0.0005, "volatilidad anualizada")
    cerca(m["sharpe"], -0.065371, 0.002, "Sharpe con rf = 0")
    cerca(m["var95_mensual"], -0.036348, 0.0005, "VaR histórico mensual al 95 %")
    cerca(m["max_caida"], -0.213716, 0.001, "máxima caída")
    ok(m["volatilidad"] > 0 and -1 < m["max_caida"] <= 0, "las métricas de riesgo son coherentes")

    e = memo.escenarios(m)
    cerca(e["base"], -0.008896, 0.0005, "escenario base = geométrico histórico")
    cerca(e["adverso_mensual"], -0.040265, 0.0005, "percentil 5 mensual del escenario adverso")
    cerca(e["adverso"], -0.389314, 0.002, "escenario adverso compuesto a 12 meses")
    ok(e["adverso"] < e["base"], "el adverso es peor que la base")

    tabla = memo.sensibilidad(e["base"])
    ok(len(tabla) == 5, "la tabla de sensibilidad tiene 5 supuestos")
    cerca(tabla[2]["anual"], -0.008896, 0.0005, "el centro de la tabla es la base")
    cerca(tabla[0]["un_anio"], 9511.04, 0.01, "con −4,89 % anual, 10.000 € → 9.511 € a 1 año")
    cerca(tabla[4]["cinco_anios"], 11655.0, 0.02, "con +3,11 % anual, 10.000 € → 11.655 € a 5 años")
    ok(tabla[0]["cinco_anios"] < tabla[0]["un_anio"], "un retorno negativo reduce el valor con los años")

    documento = memo.memo(m, e, tabla)
    for fragmento, descripcion in [
        ("# Memo de una página", "título de memo"),
        ("## Supuestos", "sección de supuestos"),
        ("## Escenarios a 12 meses", "sección de escenarios"),
        ("## Sensibilidad al supuesto de retorno", "tabla de sensibilidad"),
        ("## Límites", "sección de límites"),
        (memo.FUENTE, "fuente"),
        (memo.FECHA, "fecha"),
        ("no es asesoramiento financiero", "aviso de no asesoramiento"),
    ]:
        ok(fragmento in documento, f"el memo incluye {descripcion}")
    ok(documento.count("|") >= 18, "la tabla de sensibilidad tiene 5 filas y 3 columnas")
    ok("-0.9 %" in documento or "-0,9 %" in documento or "-0.89" in documento, "el memo cifra la base")

    codigo = (AQUI / "memo.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
