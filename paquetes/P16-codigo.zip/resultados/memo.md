# Memo de una página · cartera equiponderada de cinco acciones

**Fecha:** 2026-11-10 · **Fuente:** cartera-acciones (catálogo Data School) · 60 meses sintéticos · 5 acciones · **Inversión de referencia:** 10.000 €

## Qué se propone
Mantener una cartera equiponderada de las cinco acciones de la muestra durante 12 meses, con reequilibrio anual y sin apalancamiento. La recomendación es **condicional**: depende de que se acepten los supuestos de abajo.

## Supuestos
1. Los 60 meses sintéticos son representativos del próximo año (no lo son: es un CSV de práctica).
2. Los retornos se componen mes a mes y no hay costes de transacción ni impuestos.
3. El tipo libre de riesgo es 0 y la cartera se mantiene equiponderada.

## Escenarios a 12 meses
- **Base:** retorno anual compuesto -0.89 % → 9.911 €.
- **Adverso (percentil 5 mensual):** retorno mensual -4.03 % → -38.93 % anual → 6.107 €.
- Volatilidad anualizada: 8.38 % · Sharpe (rf=0): -0.07.
- VaR histórico mensual al 95 %: -3.63 % · máxima caída: -21.37 %.

## Sensibilidad al supuesto de retorno
| Retorno anual supuesto | Valor a 1 año | Valor a 5 años |
| ---: | ---: | ---: |
| -4.9 % | 9.511 € | 7.783 € |
| -2.9 % | 9.711 € | 8.636 € |
| -0.9 % | 9.911 € | 9.563 € |
| +1.1 % | 10.111 € | 10.568 € |
| +3.1 % | 10.311 € | 11.655 € |

## Límites
- Datos **sintéticos**: no describen ninguna acción, fondo ni índice real.
- 60 meses es una muestra corta; el escenario adverso es una hipótesis, no una predicción.
- Sin costes, impuestos ni liquidez: un backtest de juguete no es una cartera real.
- Esto **no es asesoramiento financiero**.

**Conclusión:** con los supuestos aceptados, el escenario base da -0.9 % y el adverso -38.9 %; el valor del memo está en que las dos cifras y la sensibilidad se pueden discutir, no en la recomendación.