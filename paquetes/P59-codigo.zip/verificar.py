#!/usr/bin/env python3
"""Puerta del proyecto P59 · red neuronal desde cero en NumPy.

Recalcula el forward, el backward, la comprobación numérica del gradiente, el entrenamiento, la
precisión por clase y el paisaje de pérdida. No usa red y **no escribe ficheros**.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import red

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P59 · red neuronal desde cero ==")

    # Paso 1 · Comprueba los datos y las clases
    # Por qué: 120 por clase y píxeles 0–255 son la base de la partición y de la normalización.
    # Salida esperada: "datos: 1200 filas · 66 columnas · 120 por clase"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    df = red.cargar_digitos()
    validacion = red.validar_digitos(df)
    ok((validacion["filas"], validacion["columnas"]) == (1200, 66), "datos: 1200 filas · 66 columnas")
    ok(validacion["por_clase"] == {c: 120 for c in range(10)}, f"120 imágenes por dígito: {validacion['por_clase']}")
    ok(validacion["ids_unicos"] and (validacion["minimo"], validacion["maximo"]) == (0.0, 255.0),
       f"ids únicos y píxeles 0–255 (media {validacion['media']:.2f})")

    # Paso 2 · Comprueba la partición estratificada
    # Por qué: con casi duplicados, la partición es parte del resultado; se declara y se comprueba.
    # Salida esperada: "partición: 900 train · 300 test · 30 por clase en test"
    # Si falla: alguna clase sin test o proporciones distintas → la estratificación está mal.
    particion = red.particion_estratificada(df)
    ok((len(particion["train"]), len(particion["test"])) == (900, 300), "partición: 900 train · 300 test")
    y_test = particion["y"][particion["test"]]
    ok(list(np.bincount(y_test)) == [30] * 10, f"30 imágenes de cada clase en test: {list(np.bincount(y_test))}")
    ok(len(np.intersect1d(particion["train"], particion["test"])) == 0, "train y test no comparten índices")

    # Paso 3 · Comprueba la arquitectura y el número de parámetros
    # Por qué: la ficha declara 64–16–10 y 1210 parámetros; si cambian, el proyecto no es el mismo.
    # Salida esperada: "red: W1 (64, 16) · W2 (16, 10) · 1210 parámetros"
    # Si falla: el recuento no es 1210 → las formas de las capas están mal.
    params = red.inicializar_pesos()
    total = sum(valor.size for valor in params.values())
    ok(
        params["W1"].shape == (64, 16) and params["W2"].shape == (16, 10)
        and params["b1"].shape == (16,) and params["b2"].shape == (10,),
        "arquitectura 64–16–10",
    )
    ok(total == 1210, f"parámetros totales: {total}")

    # Paso 4 · Comprueba el forward y que el softmax normaliza
    # Por qué: si las probabilidades no suman 1 por fila, la entropía cruzada y el gradiente no valen.
    # Salida esperada: "forward: P (1200, 10) · suma 1.0"
    # Si falla: NaN en P → el softmax no restó el máximo.
    cache = red.forward(params, particion["X"])
    ok(
        cache["Z1"].shape == (1200, 16) and cache["A1"].shape == (1200, 16) and cache["P"].shape == (1200, 10),
        "el forward encadena X·W1+b1, ReLU, A1·W2+b2 y softmax",
    )
    ok(bool(np.allclose(cache["P"].sum(axis=1), 1.0)) and np.isfinite(cache["P"]).all(),
       "las probabilidades de cada fila suman 1 y son finitas")

    # Paso 5 · Comprueba el gradiente con diferencias centrales
    # Por qué: es la prueba de que el backward deriva la pérdida que se entrena; con un error mayor que
    #          la tolerancia, el entrenamiento no demuestra nada.
    # Salida esperada: "gradiente: 6 parámetros · error máximo 4.7e-09 ≤ 1e-05"
    # Si falla: error > tolerancia → revisa las transposiciones del backward.
    gradientes = red.backward(params, cache, particion["X"], particion["Y"])
    ok(
        gradientes["W1"].shape == (64, 16) and gradientes["W2"].shape == (16, 10)
        and gradientes["b1"].shape == (16,) and gradientes["b2"].shape == (10,),
        "las formas del gradiente coinciden con los pesos",
    )
    tabla_gradiente = red.comprobar_gradiente(params, particion)
    error_maximo = float(tabla_gradiente["error_relativo"].max())
    ok(len(tabla_gradiente) == 6, "se comprueban 6 parámetros frente a los numéricos")
    ok(error_maximo < red.TOLERANCIA, f"error relativo máximo del gradiente: {error_maximo:.2e} < {red.TOLERANCIA:.0e}")
    ok(red.EPS == 1e-4, "el epsilon de las diferencias centrales está declarado (1e-4)")

    # Paso 6 · Entrena y comprueba que la pérdida baja
    # Por qué: el criterio pide que la pérdida baje entre la primera y la última época, con train y test.
    # Salida esperada: "entreno: pérdida 2.68 → 0.21 · acierto test 0.60"
    # Si falla: la pérdida no baja o hay NaN → tasa de aprendizaje o softmax mal.
    params, historial, acierto_train, acierto_test = red.entrenar(params, particion)
    ok(
        float(historial.iloc[-1]["perdida_train"]) < float(historial.iloc[0]["perdida_train"]),
        f"pérdida de train: {historial.iloc[0]['perdida_train']:.2f} → {historial.iloc[-1]['perdida_train']:.2f}",
    )
    ok(
        float(historial.iloc[-1]["perdida_test"]) < float(historial.iloc[0]["perdida_test"]),
        f"pérdida de test: {historial.iloc[0]['perdida_test']:.2f} → {historial.iloc[-1]['perdida_test']:.2f}",
    )
    ok(abs(acierto_train - 0.967778) < 1e-5 and abs(acierto_test - 0.596667) < 1e-5,
       f"acierto: train {acierto_train:.2%} · test {acierto_test:.2%} (el hueco se declara)")

    # Paso 7 · Comprueba la matriz de confusión y la precisión por clase
    # Por qué: un acierto global puede esconder una clase que no se aprende; la matriz 10×10 lo enseña.
    # Salida esperada: "matriz 10×10 con 300 · peor clase (9) 8 de 30"
    # Si falla: la matriz no suma 300 → el índice de test está mal.
    confusion, tabla_clase, acierto_train, acierto_test = red.evaluar(params, particion)
    ok(confusion.shape == (10, 10) and int(confusion.sum()) == 300, f"matriz 10×10 con {int(confusion.sum())} casos")
    ok(len(tabla_clase) == 10 and int(tabla_clase["n"].sum()) == 300, "precisión por clase con su n")
    ok(
        abs(float(tabla_clase.set_index("clase").loc[9, "precision"]) - 8 / 30) < 1e-12,
        f"la clase 9 acierta {int(confusion[9, 9])} de 30 (se declara la confusión)",
    )

    # Paso 8 · Comprueba el paisaje de pérdida
    # Por qué: el paisaje debe mover exactamente dos pesos y contener el punto entrenado; si no, es un
    #          dibujo decorativo.
    # Salida esperada: "paisaje: 225 puntos · pérdida 0.21 a 0.24"
    # Si falla: la rejilla no está centrada en los pesos entrenados.
    tabla_paisaje = red.paisaje(params, particion)
    ok(len(tabla_paisaje) == 225, f"paisaje: {len(tabla_paisaje)} puntos (15×15)")
    ok(
        tabla_paisaje["w1_00"].nunique() == 15 and tabla_paisaje["w2_00"].nunique() == 15,
        "la rejilla mueve dos pesos con el resto fijos",
    )
    centro = tabla_paisaje[
        (tabla_paisaje["w1_00"] - params["W1"][0, 0]).abs().lt(1e-12)
        & (tabla_paisaje["w2_00"] - params["W2"][0, 0]).abs().lt(1e-12)
    ].iloc[0]
    ok(abs(float(centro["perdida"]) - float(historial.iloc[-1]["perdida_train"])) < 1e-9,
       "el centro del paisaje es la pérdida del punto entrenado")

    # Paso 9 · Comprueba que el informe declara el gradiente, las curvas y el límite
    # Por qué: el entregable incluye arquitectura, tolerancia, casi duplicados y límites de generalización.
    # Salida esperada: "el informe declara 1210 parámetros, tolerancia, casi duplicados y límite"
    # Si falla: falta la advertencia de los casi duplicados o la comparación train/test.
    informe = red.texto_informe(validacion, particion, historial, acierto_train, acierto_test, tabla_clase, tabla_gradiente, tabla_paisaje)
    ok("1210 parámetros" in informe and "tolerancia" in informe, "el informe declara arquitectura y tolerancia del gradiente")
    ok("casi duplicados" in informe and "Límite" in informe and "no es" in informe,
       "el informe declara los casi duplicados y el límite de generalización")
    ok(f"{acierto_test:.1%}" in informe, "el informe publica el acierto de test junto al de train")

    # Paso 10 · Comprueba que el código es offline y sin frameworks
    # Por qué: el proyecto debe ser NumPy puro y ejecutarse sin red; un import de framework lo invalidaría.
    # Salida esperada: "offline: sin red y sin frameworks de autograd"
    # Si falla: aparece torch/keras/tensorflow o una URL en las fuentes.
    fuentes = (red.RAIZ / "red.py").read_text(encoding="utf-8")
    ok(
        not any(framework in fuentes for framework in ("import torch", "import keras", "import tensorflow", "from torch")),
        "NumPy puro: sin torch, keras ni tensorflow",
    )
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
