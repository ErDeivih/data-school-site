# P59 · Red neuronal desde cero en NumPy, y su paisaje de pérdida — código ejecutable

Implementa con NumPy puro una red 64–16–10: forward, retropropagación derivada a mano, comprobación del
gradiente con diferencias centrales, entrenamiento, precisión por clase y paisaje de pérdida moviendo dos
pesos. Es el código que acompaña a la ficha
`../../fichas-ideas/p59-red-neuronal-desde-cero.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **numpy >= 1.26** (BSD-3-Clause) y **pandas >= 2.2** (BSD-3-Clause, solo para leer el CSV).
- Windows, Linux o macOS: sin red ni servicios externos.

## Instalación

```powershell
cd proyectos/p59-red-neuronal-desde-cero/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python red.py
```

Entrena y escribe en `resultados/` los ficheros `gradiente.csv`, `perdida.csv`, `precision-clase.csv`,
`paisaje.csv`, `confusion.csv` e `informe.md`. Los generados no viajan en el ZIP: solo
`ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: 1200 imágenes × 66 columnas con 120 por dígito, la
partición estratificada 900/300, los 1210 parámetros de la red 64–16–10, el forward con softmax estable,
el gradiente analítico frente al numérico (error relativo máximo 4,7e-09 con tolerancia 1e-05), la
pérdida de train que baja de 2,68 a 0,21, el acierto por clase, la matriz 10×10 con 300 casos y el
paisaje 15×15. Termina en `RESULTADO: VERDE` (0) o `RESULTADO: ROJO` (1). No usa red. La salida real
está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/pixeles-digitos.csv`: **1200 filas × 66 columnas** (`id`, `p00`…`p63`, `etiqueta`),
  120 imágenes por dígito, píxeles enteros 0–255.
- **Sintético, determinista y CC0-1.0**: copia literal del CSV servido por el portal en
  `aprender/web/datos/datasets/pixeles-digitos.csv` (no está en `datasets/csv/` del repositorio), con
  `sha256:5b952ad4297923f67284ebab2e377bfcb7ad6fd1511fdf7ad5adfb32fac7928c`.
- El CSV **no trae** escritores, resolución mayor, rotaciones grandes ni clases extra: no se puede medir
  generalización real.

## Fuente real y licencia

- **No hay API**: la ficha declara `api: []`; el proyecto usa solo el CSV local.
- Datos sintéticos CC0-1.0. Dependencias: numpy y pandas BSD-3-Clause.

## Supuestos declarados

- **Arquitectura 64–16–10** con ReLU y softmax; 1210 parámetros para 1200 imágenes.
- **Partición estratificada** 75/25 por clase con semilla 20261117; las imágenes salen de diez plantillas
  con desplazamiento y ruido, así que hay casi duplicados y una partición aleatoria inflaría el acierto.
- **Gradiente:** diferencias centrales con ε = 1e-4 y tolerancia 1e-5; se valida con la misma pérdida
  (entropía cruzada) con la que se entrena.
- **Entrenamiento:** descenso de gradiente de lote completo, 300 épocas, tasa 0,5, sin regularización;
  se publica la pérdida de train y la de test, y el hueco se declara (train 96,8 % frente a test 59,7 %).

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Datos y clases | Clases balanceadas y normalización | `Perceptrón y MLP` |
| 2 · Forward | Capas, activación y softmax estable | `Perceptrón y MLP` |
| 3 · Backward a mano | Regla de la cadena sobre matrices | `Retropropagación` |
| 4 · Gradiente numérico | Derivadas parciales y diferencias centrales | `Derivadas parciales y gradiente` |
| 5 · Entrenamiento | Descenso de gradiente y tasa de aprendizaje | `Optimizadores` |
| 6 · Evaluación | Matriz de confusión y precisión por clase | `Matriz de confusión` |
| 7 · Paisaje y límite | Sobreajuste en un juguete | `Sobreajuste en redes` |

## Estructura

```text
codigo/
├── red.py                 # forward, backward, gradiente, entrenamiento, evaluación y paisaje
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # numpy y pandas
├── datos-ejemplo/         # pixeles-digitos.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **Framework escondido:** usar autograd, Keras o PyTorch y llamarlo «NumPy puro».
- **Gradiente comprobado a la ligera:** ε sin declarar o tolerancia ausente; aquí ε = 1e-4 y 1e-5.
- **Softmax inestable:** `exp` sin restar el máximo desborda y devuelve `NaN`.
- **Sobreajuste silencioso:** publicar solo el acierto de train; aquí se acompaña del de test.
- **Partición aleatoria con casi duplicados:** reparte variantes de la misma plantilla e infla el acierto.
- **`ModuleNotFoundError: numpy`**: instala las dependencias con el mismo Python que ejecuta el script.
