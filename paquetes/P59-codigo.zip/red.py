#!/usr/bin/env python3
"""P59 · Red neuronal desde cero en NumPy, y su paisaje de pérdida — código ejecutable.

Implementa con NumPy puro una red 64–16–10: forward, retropropagación derivada a mano, comprobación del
gradiente con diferencias centrales, entrenamiento con descenso de gradiente, métricas por clase y
paisaje de pérdida moviendo dos pesos. Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal del portal):
    datos-ejemplo/pixeles-digitos.csv  (1200 filas × 66 columnas)

Uso:
    python red.py                # entrena y escribe resultados/
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
SEMILLA = 20261117
OCULTAS = 16
EPOCAS = 300
TASA_APRENDIZAJE = 0.5
EPS = 1e-4
TOLERANCIA = 1e-5
FRACCION_TEST = 0.25
PIXELES = 64
CLASES = 10


# Paso 1 · Carga las imágenes y comprueba clases, identificadores y rango
# Por qué: si las clases no están balanceadas o los píxeles no van de 0 a 255, la partición y la
#          normalización dejan de ser las que dice el README.
# Salida esperada: "digitos: 1200 filas · 66 columnas · 120 por clase · píxeles 0–255"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_digitos() -> pd.DataFrame:
    ruta = DATOS / "pixeles-digitos.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta)
    print(
        f"digitos: {len(df)} filas · {df.shape[1]} columnas · "
        f"{df['etiqueta'].value_counts().min()} por clase · píxeles "
        f"{df[[f'p{i:02d}' for i in range(PIXELES)]].to_numpy().min()}–"
        f"{df[[f'p{i:02d}' for i in range(PIXELES)]].to_numpy().max()}"
    )
    return df


def validar_digitos(df: pd.DataFrame) -> dict:
    columnas_pixel = [f"p{i:02d}" for i in range(PIXELES)]
    X = df[columnas_pixel].to_numpy(dtype=float)
    resumen = {
        "filas": len(df),
        "columnas": int(df.shape[1]),
        "por_clase": {int(k): int(v) for k, v in df["etiqueta"].value_counts().sort_index().items()},
        "ids_unicos": bool(df["id"].is_unique),
        "minimo": float(X.min()),
        "maximo": float(X.max()),
        "media": float(X.mean()),
    }
    print(
        f"validación: {len(resumen['por_clase'])} clases · ids únicos {resumen['ids_unicos']} · "
        f"media {resumen['media']:.1f}"
    )
    return resumen


# Paso 2 · Parte la muestra de forma estratificada y normaliza con la media de train
# Por qué: las imágenes salen de diez plantillas con desplazamientos y ruido, así que hay casi duplicados;
#          un corte aleatorio repartiría variantes de la misma plantilla entre train y test e inflaría
#          el acierto. Se estratifica por clase y se declara.
# Salida esperada: "partición: 900 train · 300 test · 90 por clase en test"
# Si falla: alguna clase sin test → la semilla o la fracción están mal.
def particion_estratificada(df: pd.DataFrame) -> dict:
    columnas_pixel = [f"p{i:02d}" for i in range(PIXELES)]
    X_crudo = df[columnas_pixel].to_numpy(dtype=float)
    y = df["etiqueta"].to_numpy(dtype=int)
    generador = np.random.default_rng(SEMILLA)
    indices_train: list[np.ndarray] = []
    indices_test: list[np.ndarray] = []
    for clase in range(CLASES):
        indices = np.where(y == clase)[0]
        generador.shuffle(indices)
        corte = int(len(indices) * FRACCION_TEST)
        indices_test.append(indices[:corte])
        indices_train.append(indices[corte:])
    train = np.sort(np.concatenate(indices_train))
    test = np.sort(np.concatenate(indices_test))
    media = X_crudo[train].mean(axis=0)
    desviacion = X_crudo[train].std(axis=0)
    desviacion[desviacion == 0] = 1.0
    X = (X_crudo - media) / desviacion
    Y = np.eye(CLASES)[y]
    print(
        f"partición: {len(train)} train · {len(test)} test · "
        f"{int(np.bincount(y[test]).min())} por clase en test"
    )
    return {"X": X, "Y": Y, "y": y, "train": train, "test": test}


# Paso 3 · Inicializa la red 64–16–10 con inicialización de He
# Por qué: la escala de los pesos importa; sin ella, con 64 entradas y 16 neuronas, la primera época
#          puede saturar la activación. La red tiene 1210 parámetros para 1200 imágenes.
# Salida esperada: "red: W1 (64, 16) · W2 (16, 10) · 1210 parámetros"
# Si falla: el número de parámetros no es 1210 → las formas de las capas están mal.
def inicializar_pesos() -> dict:
    generador = np.random.default_rng(SEMILLA + 1)
    params = {
        "W1": generador.standard_normal((PIXELES, OCULTAS)) * np.sqrt(2 / PIXELES),
        "b1": np.zeros(OCULTAS),
        "W2": generador.standard_normal((OCULTAS, CLASES)) * np.sqrt(2 / OCULTAS),
        "b2": np.zeros(CLASES),
    }
    total = sum(valor.size for valor in params.values())
    print(f"red: W1 {params['W1'].shape} · W2 {params['W2'].shape} · {total} parámetros")
    return params


# Paso 4 · Forward completo: capa oculta con ReLU, salida con softmax estable
# Por qué: se escribe el forward para poder derivarlo; el softmax resta el máximo para no desbordar con
#          exp y devolver NaN.
# Salida esperada: "forward: Z1 (1200, 16) · A1 (1200, 16) · P (1200, 10) · suma 1.0"
# Si falla: las probabilidades no suman 1 por fila → el softmax está mal normalizado.
def forward(params: dict, X: np.ndarray) -> dict:
    Z1 = X @ params["W1"] + params["b1"]
    A1 = np.maximum(Z1, 0)
    Z2 = A1 @ params["W2"] + params["b2"]
    Z2_estable = Z2 - Z2.max(axis=1, keepdims=True)
    exp = np.exp(Z2_estable)
    P = exp / exp.sum(axis=1, keepdims=True)
    return {"Z1": Z1, "A1": A1, "Z2": Z2, "P": P}


def perdida(P: np.ndarray, Y: np.ndarray) -> float:
    """Entropía cruzada media; el log se estabiliza con un epsilon."""
    return float(-np.mean(np.sum(Y * np.log(P + 1e-12), axis=1)))


# Paso 5 · Retropropagación derivada a mano
# Por qué: si el gradiente está mal, el entrenamiento puede bajar la pérdida por casualidad; la
#          comprobación numérica de después es la que delata el error.
# Salida esperada: "backward: dW1 (64, 16) · dW2 (16, 10) · formas correctas"
# Si falla: formas distintas de las de los pesos → alguna transposición está mal.
def backward(params: dict, cache: dict, X: np.ndarray, Y: np.ndarray) -> dict:
    n = len(X)
    P, A1, Z1 = cache["P"], cache["A1"], cache["Z1"]
    dZ2 = (P - Y) / n
    dW2 = A1.T @ dZ2
    db2 = dZ2.sum(axis=0)
    dA1 = dZ2 @ params["W2"].T
    dZ1 = dA1 * (Z1 > 0)
    dW1 = X.T @ dZ1
    db1 = dZ1.sum(axis=0)
    return {"W1": dW1, "b1": db1, "W2": dW2, "b2": db2}


# Paso 6 · Comprueba el gradiente con diferencias centrales
# Por qué: es la prueba de que la derivada es la de la pérdida que se entrena; se publica el error
#          relativo máximo con su epsilon y su tolerancia.
# Salida esperada: "gradiente: 6 parámetros · error relativo máximo 4.7e-09 · tolerancia 1e-05"
# Si falla: error > tolerancia → el backward no corresponde a la pérdida.
def comprobar_gradiente(params: dict, particion: dict) -> pd.DataFrame:
    X = particion["X"][particion["train"]]
    Y = particion["Y"][particion["train"]]
    cache = forward(params, X)
    gradientes = backward(params, cache, X, Y)
    seleccion = [("W1", (0, 0)), ("W1", (10, 5)), ("b1", (3,)), ("W2", (0, 0)), ("W2", (5, 7)), ("b2", (2,))]
    filas = []
    for nombre, indice in seleccion:
        original = params[nombre][indice]
        params[nombre][indice] = original + EPS
        mas = perdida(forward(params, X)["P"], Y)
        params[nombre][indice] = original - EPS
        menos = perdida(forward(params, X)["P"], Y)
        params[nombre][indice] = original
        numerico = (mas - menos) / (2 * EPS)
        analitico = float(gradientes[nombre][indice])
        error = abs(analitico - numerico) / max(1e-8, abs(analitico) + abs(numerico))
        filas.append({"parametro": f"{nombre}{list(indice)}", "analitico": analitico, "numerico": numerico, "error_relativo": error})
    tabla = pd.DataFrame(filas)
    print(
        f"gradiente: {len(tabla)} parámetros · error relativo máximo {tabla['error_relativo'].max():.2e} · "
        f"tolerancia {TOLERANCIA:.0e}"
    )
    return tabla


# Paso 7 · Entrena con descenso de gradiente y guarda la curva de pérdida
# Por qué: se publica la pérdida de train y de validación, no sola la de train: si bajan juntas, la red
#          aprende; si se separan, memoriza.
# Salida esperada: "entreno: pérdida 2.68 → 0.21 · acierto test 0.60"
# Si falla: la pérdida sube o aparece NaN → tasa de aprendizaje o softmax mal ajustados.
def entrenar(params: dict, particion: dict) -> tuple[dict, pd.DataFrame, float, float]:
    X_train = particion["X"][particion["train"]]
    Y_train = particion["Y"][particion["train"]]
    X_test = particion["X"][particion["test"]]
    Y_test = particion["Y"][particion["test"]]
    historial = []
    for epoca in range(1, EPOCAS + 1):
        cache = forward(params, X_train)
        gradientes = backward(params, cache, X_train, Y_train)
        for nombre in params:
            params[nombre] -= TASA_APRENDIZAJE * gradientes[nombre]
        if epoca == 1 or epoca % 25 == 0 or epoca == EPOCAS:
            p_train = forward(params, X_train)["P"]
            p_test = forward(params, X_test)["P"]
            historial.append(
                {
                    "epoca": epoca,
                    "perdida_train": perdida(p_train, Y_train),
                    "perdida_test": perdida(p_test, Y_test),
                    "acierto_train": float((p_train.argmax(axis=1) == Y_train.argmax(axis=1)).mean()),
                    "acierto_test": float((p_test.argmax(axis=1) == Y_test.argmax(axis=1)).mean()),
                }
            )
    tabla = pd.DataFrame(historial)
    print(
        f"entreno: pérdida {tabla.iloc[0]['perdida_train']:.2f} → {tabla.iloc[-1]['perdida_train']:.2f} · "
        f"acierto test {tabla.iloc[-1]['acierto_test']:.2f}"
    )
    return params, tabla, float(tabla.iloc[-1]["acierto_train"]), float(tabla.iloc[-1]["acierto_test"])


# Paso 8 · Evalúa por clase y construye la matriz de confusión
# Por qué: el acierto global puede esconder una clase que no se aprende; la matriz 10×10 y la precisión
#          por clase lo enseñan.
# Salida esperada: "evaluación: acierto train 0.97 · test 0.60 · matriz 10×10 con 300"
# Si falla: la matriz no suma el test → el índice de evaluación está mal.
def evaluar(params: dict, particion: dict) -> tuple[np.ndarray, pd.DataFrame, float, float]:
    X = particion["X"]
    y = particion["y"]
    P = forward(params, X)["P"]
    predicho = P.argmax(axis=1)
    train, test = particion["train"], particion["test"]
    acierto_train = float((predicho[train] == y[train]).mean())
    acierto_test = float((predicho[test] == y[test]).mean())
    confusion = np.zeros((CLASES, CLASES), dtype=int)
    for real, pred in zip(y[test], predicho[test]):
        confusion[real, pred] += 1
    filas = []
    for clase in range(CLASES):
        total = confusion[clase].sum()
        aciertos = confusion[clase, clase]
        filas.append(
            {
                "clase": clase,
                "n": int(total),
                "aciertos": int(aciertos),
                "precision": aciertos / total if total else 0.0,
            }
        )
    tabla = pd.DataFrame(filas)
    print(
        f"evaluación: acierto train {acierto_train:.2f} · test {acierto_test:.2f} · "
        f"matriz 10×10 con {int(confusion.sum())}"
    )
    return confusion, tabla, acierto_train, acierto_test


# Paso 9 · Dibuja el paisaje de pérdida moviendo exactamente dos pesos
# Por qué: un paisaje se lee, no se decora; se fijan todos los parámetros menos dos, se evalúa la pérdida
#          en una rejilla y se marca el punto entrenado.
# Salida esperada: "paisaje: rejilla 15×15 · pérdida 0.21 a 0.24 alrededor de W1[0,0] y W2[0,0]"
# Si falla: la rejilla no contiene el punto entrenado → las coordenadas están desplazadas.
def paisaje(params: dict, particion: dict, lado: int = 15, radio: float = 0.5) -> pd.DataFrame:
    X = particion["X"][particion["train"]]
    Y = particion["Y"][particion["train"]]
    base_w1 = float(params["W1"][0, 0])
    base_w2 = float(params["W2"][0, 0])
    rejilla_w1 = np.linspace(base_w1 - radio, base_w1 + radio, lado)
    rejilla_w2 = np.linspace(base_w2 - radio, base_w2 + radio, lado)
    filas = []
    for valor_w1 in rejilla_w1:
        for valor_w2 in rejilla_w2:
            params["W1"][0, 0] = valor_w1
            params["W2"][0, 0] = valor_w2
            valor_perdida = perdida(forward(params, X)["P"], Y)
            filas.append({"w1_00": float(valor_w1), "w2_00": float(valor_w2), "perdida": valor_perdida})
    params["W1"][0, 0] = base_w1
    params["W2"][0, 0] = base_w2
    tabla = pd.DataFrame(filas)
    print(
        f"paisaje: rejilla {lado}×{lado} · pérdida {tabla['perdida'].min():.2f} a {tabla['perdida'].max():.2f} "
        "alrededor de W1[0,0] y W2[0,0]"
    )
    return tabla


def texto_informe(
    validacion: dict,
    particion: dict,
    historial: pd.DataFrame,
    acierto_train: float,
    acierto_test: float,
    tabla_clase: pd.DataFrame,
    gradiente: pd.DataFrame,
    tabla_paisaje: pd.DataFrame,
) -> str:
    return "\n".join(
        [
            "# P59 · Red neuronal desde cero en NumPy",
            "",
            "## Arquitectura",
            "Red 64–16–10 con NumPy puro: `Z1 = X·W1 + b1`, ReLU, `Z2 = A1·W2 + b2`, softmax y entropía",
            "cruzada. W1 (64, 16), b1 (16), W2 (16, 10), b2 (10): 1210 parámetros para 1200 imágenes.",
            "No hay autograd, ni Keras, ni PyTorch.",
            "",
            "## Gradiente",
            f"Se comprueban {len(gradiente)} parámetros con diferencias centrales (ε = {EPS:g}); el error",
            f"relativo máximo es {gradiente['error_relativo'].max():.2e} y la tolerancia escrita es {TOLERANCIA:g}.",
            "",
            "## Entrenamiento",
            f"- Pérdida de train: {historial.iloc[0]['perdida_train']:.2f} → {historial.iloc[-1]['perdida_train']:.2f}",
            f"  (test: {historial.iloc[0]['perdida_test']:.2f} → {historial.iloc[-1]['perdida_test']:.2f}).",
            f"- Acierto: train {acierto_train:.1%}, test {acierto_test:.1%}.",
            "- La curva de train y la de test bajan juntas; cuando se separan, el modelo empieza a memorizar.",
            "",
            "## Precisión por clase",
            "| clase | n | aciertos | precision |",
            "| --- | --- | --- | --- |",
            *[f"| {f.clase} | {f.n} | {f.aciertos} | {f.precision:.2f} |" for f in tabla_clase.itertuples()],
            "",
            "## Paisaje de pérdida",
            f"Se mueven exactamente dos pesos, W1[0,0] y W2[0,0], con el resto fijos, en una rejilla de",
            f"{int(tabla_paisaje.shape[0])} puntos; la pérdida va de {tabla_paisaje['perdida'].min():.2f} a",
            f"{tabla_paisaje['perdida'].max():.2f} y el punto entrenado está en el centro.",
            "",
            "## Límite",
            "Las imágenes salen de diez plantillas con desplazamiento y ruido: hay casi duplicados y una",
            "partición aleatoria inflaría el acierto, por eso se estratifica. El acierto del juguete no es",
            "reconocimiento de escritura: no hay escritores nuevos, ni resolución mayor, ni rotaciones.",
            "",
        ]
    )


def main() -> int:
    df = cargar_digitos()
    validacion = validar_digitos(df)
    particion = particion_estratificada(df)
    params = inicializar_pesos()
    cache = forward(params, particion["X"])
    print(
        f"forward: Z1 {cache['Z1'].shape} · A1 {cache['A1'].shape} · P {cache['P'].shape} · "
        f"suma {cache['P'][0].sum():.1f}"
    )
    gradientes = backward(params, cache, particion["X"], particion["Y"])
    print(f"backward: dW1 {gradientes['W1'].shape} · dW2 {gradientes['W2'].shape} · formas correctas")
    tabla_gradiente = comprobar_gradiente(params, particion)
    params, historial, acierto_train, acierto_test = entrenar(params, particion)
    confusion, tabla_clase, acierto_train, acierto_test = evaluar(params, particion)
    tabla_paisaje = paisaje(params, particion)
    RESULTADOS.mkdir(exist_ok=True)
    tabla_gradiente.to_csv(RESULTADOS / "gradiente.csv", index=False)
    historial.to_csv(RESULTADOS / "perdida.csv", index=False)
    tabla_clase.to_csv(RESULTADOS / "precision-clase.csv", index=False)
    tabla_paisaje.to_csv(RESULTADOS / "paisaje.csv", index=False)
    pd.DataFrame(confusion).to_csv(RESULTADOS / "confusion.csv", index=False, header=False)
    (RESULTADOS / "informe.md").write_text(
        texto_informe(validacion, particion, historial, acierto_train, acierto_test, tabla_clase, tabla_gradiente, tabla_paisaje),
        encoding="utf-8",
    )
    print(f"escrito: {RESULTADOS / 'informe.md'} · gradiente.csv · perdida.csv · precision-clase.csv · paisaje.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
