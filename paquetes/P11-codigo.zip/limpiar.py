﻿"""P11 · Limpiar y unir la telemetría de una carrera.

Lee el CSV de telemetría, comprueba el grano (una vuelta por piloto y carrera), separa las vueltas de
parada y publica una tabla de ritmo por piloto y compuesto. Sin dependencias: solo la biblioteca estándar.
"""
from __future__ import annotations

import argparse
import csv
import statistics
from collections import defaultdict
from pathlib import Path
# La consola de Windows puede estar en cp1252: se fuerza UTF-8 para que los acentos y las flechas no
# rompan la salida al redirigirla a un fichero.
import sys as _sys
for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("carrera", "piloto", "vuelta", "compuesto", "edad_neumatico",
            "sector1_s", "sector2_s", "sector3_s", "tiempo_vuelta_s", "parada")
VUELTAS_POR_PILOTO = 30


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer el CSV y declarar el grano: una fila por carrera, piloto y vuelta.
    # Por qué: si el grano no es único, cualquier media de ritmo está mezclando cosas distintas.
    # Salida esperada: 180 filas y exactamente las 10 columnas del contrato.
    # Si falla: «faltan columnas» o «hay filas repetidas»; el fichero no es el del catálogo.
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if not filas:
        raise ValueError("el CSV está vacío")
    claves = [(f["carrera"], f["piloto"], f["vuelta"]) for f in filas]
    if len(claves) != len(set(claves)):
        raise ValueError("hay filas repetidas: el grano no es único")
    return filas


def validar_grano(filas: list[dict]) -> dict:
    # Paso 2 · Comprobar que cada piloto tiene sus 30 vueltas en cada carrera.
    # Por qué: un hueco de vueltas cambia la media y no se nota si solo se cuenta el total.
    # Salida esperada: 0 incidencias y 6 combinaciones carrera-piloto con 30 vueltas.
    # Si falla: la lista de incidencias dice qué combinación no llega a 30.
    vueltas = defaultdict(int)
    for f in filas:
        vueltas[(f["carrera"], f["piloto"])] += 1
    incidencias = [f"{carrera}/{piloto}: {n}" for (carrera, piloto), n in vueltas.items()
                   if n != VUELTAS_POR_PILOTO]
    return {
        "combinaciones": len(vueltas),
        "incidencias": incidencias,
        "vueltas": len(filas),
    }


def separar_paradas(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    # Paso 3 · Separar las vueltas de parada de las de ritmo.
    # Por qué: una vuelta de boxes tarda mucho más y contaminaría la media si se cuela.
    # Salida esperada: 6 vueltas de parada y 174 de ritmo.
    # Si falla: «parada» no vale 0/1 o hay más paradas de las que declara la carrera.
    ritmo = [f for f in filas if f["parada"] == "0"]
    paradas = [f for f in filas if f["parada"] == "1"]
    if len(ritmo) + len(paradas) != len(filas):
        raise ValueError("la columna parada debe ser 0 o 1")
    return ritmo, paradas


def tabla_ritmo(ritmo: list[dict]) -> list[dict]:
    # Paso 4 · Agregar por piloto y compuesto: vueltas, ritmo medio y mejor vuelta.
    # Por qué: el compuesto cambia el ritmo; mezclar medio y duro esconde la diferencia.
    # Salida esperada: 4 filas (A/B × medio/duro) y 174 vueltas sumadas.
    # Si falla: una clave sin tiempos o un compuesto distinto de medio/duro.
    grupos = defaultdict(list)
    for f in ritmo:
        grupos[(f["piloto"], f["compuesto"])].append(float(f["tiempo_vuelta_s"]))
    tabla = []
    for (piloto, compuesto), tiempos in sorted(grupos.items()):
        tabla.append({
            "piloto": piloto,
            "compuesto": compuesto,
            "vueltas": len(tiempos),
            "ritmo_medio_s": round(statistics.mean(tiempos), 3),
            "mejor_vuelta_s": round(min(tiempos), 3),
        })
    return tabla


def main() -> int:
    # Paso 5 · Publicar la tabla y un resumen; el límite se escribe, no se esconde.
    # Por qué: el CSV es sintético y de una sola temporada; el informe no puede extrapolar.
    # Salida esperada: tabla de 4 filas con 174 vueltas y el aviso de dato sintético.
    # Si falla: el CSV no está en datos-ejemplo/ o el esquema ha cambiado.
    parser = argparse.ArgumentParser(description="Ritmo por piloto y compuesto (P11)")
    parser.add_argument("--csv", default="datos-ejemplo/telemetria-f1.csv")
    parser.add_argument("--salida", default=None, help="CSV de salida (opcional)")
    args = parser.parse_args()
    filas = leer(Path(args.csv))
    grano = validar_grano(filas)
    ritmo, paradas = separar_paradas(filas)
    tabla = tabla_ritmo(ritmo)
    print(f"filas: {len(filas)} · combinaciones carrera-piloto: {grano['combinaciones']} · incidencias: {len(grano['incidencias'])}")
    print(f"vueltas de ritmo: {len(ritmo)} · paradas: {len(paradas)}")
    print("piloto compuesto vueltas ritmo_medio_s mejor_vuelta_s")
    for fila in tabla:
        print(f"{fila['piloto']}      {fila['compuesto']:<8} {fila['vueltas']:>3}      {fila['ritmo_medio_s']:>8.3f}      {fila['mejor_vuelta_s']:>8.3f}")
    print("límite: CSV sintético de tres carreras; no sirve para comparar coches ni temporadas.")
    if args.salida:
        destino = Path(args.salida)
        destino.parent.mkdir(parents=True, exist_ok=True)
        with destino.open("w", encoding="utf-8", newline="") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=list(tabla[0]))
            escritor.writeheader()
            escritor.writerows(tabla)
        print(f"escrito: {destino}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
