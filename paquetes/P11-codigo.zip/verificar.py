﻿#!/usr/bin/env python3
"""Puerta del proyecto P11 (limpieza y ritmo de la telemetría de F1).

Comprueba el resultado de verdad, sin escribir en disco y sin red: esquema del CSV, grano, 30 vueltas por
piloto y carrera, separación de paradas, tabla de ritmo por piloto y compuesto, sus cifras y el límite.
Termina en RESULTADO: VERDE (código 0) o ROJO (código 1).
"""
from __future__ import annotations

from pathlib import Path
# La consola de Windows puede estar en cp1252: se fuerza UTF-8 para que los acentos y las flechas no
# rompan la salida al redirigirla a un fichero.
import sys as _sys
for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

import limpiar

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "telemetria-f1.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = limpiar.leer(CSV)
    ok(len(filas) == 180, "el CSV tiene 180 vueltas")
    ok(len(filas[0]) == 10, "el CSV trae las 10 columnas del contrato")

    grano = limpiar.validar_grano(filas)
    ok(grano["combinaciones"] == 6, "hay 6 combinaciones carrera-piloto")
    ok(grano["incidencias"] == [], "las 6 combinaciones tienen 30 vueltas (0 incidencias)")

    ritmo, paradas = limpiar.separar_paradas(filas)
    ok(len(paradas) == 6, "hay 6 vueltas de parada")
    ok(len(ritmo) == 174, "quedan 174 vueltas de ritmo")
    ok(len(ritmo) + len(paradas) == 180, "ritmo + paradas suma las 180 vueltas")

    tabla = limpiar.tabla_ritmo(ritmo)
    ok(len(tabla) == 4, "la tabla de ritmo tiene una fila por piloto y compuesto")
    ok(sum(f["vueltas"] for f in tabla) == 174, "la tabla suma las 174 vueltas de ritmo")
    por_clave = {(f["piloto"], f["compuesto"]): f for f in tabla}
    ok(set(por_clave) == {("A", "duro"), ("A", "medio"), ("B", "duro"), ("B", "medio")},
       "las claves son A/B × duro/medio")
    ok(por_clave[("A", "duro")]["vueltas"] == 36, "A/duro tiene 36 vueltas")
    ok(por_clave[("A", "medio")]["vueltas"] == 51, "A/medio tiene 51 vueltas")
    ok(por_clave[("B", "duro")]["vueltas"] == 24, "B/duro tiene 24 vueltas")
    ok(por_clave[("B", "medio")]["vueltas"] == 63, "B/medio tiene 63 vueltas")
    ok(por_clave[("A", "duro")]["ritmo_medio_s"] == 88.601, "el ritmo medio de A/duro es 88.601 s")
    ok(por_clave[("A", "duro")]["mejor_vuelta_s"] == 83.147, "la mejor vuelta de A/duro es 83.147 s")
    ok(por_clave[("B", "medio")]["ritmo_medio_s"] == 89.543, "el ritmo medio de B/medio es 89.543 s")

    # Las vueltas de parada son más lentas que la media de su piloto: si no, no se separaron bien.
    medias_por_piloto = {}
    for f in ritmo:
        medias_por_piloto.setdefault(f["piloto"], []).append(float(f["tiempo_vuelta_s"]))
    for f in paradas:
        media = sum(medias_por_piloto[f["piloto"]]) / len(medias_por_piloto[f["piloto"]])
        ok(float(f["tiempo_vuelta_s"]) > media, f"la parada de {f['piloto']} en {f['carrera']} es más lenta que su media")

    codigo = (AQUI / "limpiar.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
