﻿# P11 · Limpiar y unir la telemetría de una carrera

Paquete descargable de **Data School** para el proyecto P11. Incluye el CSV de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión: se ejecuta tal cual se descomprime.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): todo va con la biblioteca estándar.

## Ejecutar

```bash
python limpiar.py
python limpiar.py --csv datos-ejemplo/telemetria-f1.csv --salida resultados/ritmo.csv
python verificar.py
```

`limpiar.py` imprime el recuento de filas, las vueltas de ritmo y parada y la tabla por piloto y
compuesto. Con `--salida` escribe además un CSV con esa tabla. `verificar.py` comprueba el resultado y
sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/telemetria-f1.csv`: **180 filas × 10 columnas** (3 carreras × 2 pilotos × 30 vueltas;
  medio y duro; 6 vueltas de parada). Sintético y **CC0-1.0**; es el `telemetria-f1` del catálogo de
  Data School, no una captura real de un equipo.

## Salida esperada

```text
filas: 180 · combinaciones carrera-piloto: 6 · incidencias: 0
vueltas de ritmo: 174 · paradas: 6
piloto compuesto vueltas ritmo_medio_s mejor_vuelta_s
A      duro      36        88.601        83.147
A      medio     51        89.487        84.090
B      duro      24        88.552        83.160
B      medio     63        89.543        84.036
límite: CSV sintético de tres carreras; no sirve para comparar coches ni temporadas.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Leer y declarar el grano | `leer` valida columnas y claves únicas | pandas: fundamentos |
| 2 · Comprobar 30 vueltas | `validar_grano` cuenta por carrera y piloto | calidad de datos |
| 3 · Separar paradas | `separar_paradas` deja fuera las vueltas de boxes | calidad de datos |
| 4 · Agregar el ritmo | `tabla_ritmo` agrupa por piloto y compuesto | pandas: agrupaciones y joins |
| 5 · Publicar con límite | `main` imprime la tabla y el aviso | visualización estadística |

## Fallos típicos

- **`columnas inesperadas`**: el CSV no es el del catálogo o se ha abierto con otro separador.
- **`hay filas repetidas`**: el grano no es carrera-piloto-vuelta; el fichero está mezclado.
- **`la columna parada debe ser 0 o 1`**: se ha usado `true/false` o un texto.
- **Tabla con más de 4 filas**: se está agrupando por carrera además de por piloto y compuesto.

## Límite

El CSV es sintético y de tres carreras. Sirve para aprender limpieza y agregación, no para comparar
coches, estrategias ni temporadas reales.
