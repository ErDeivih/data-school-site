﻿#!/usr/bin/env python3
"""Puerta del proyecto P31 (contrato, frescura y linaje de datos abiertos).

Comprueba el resultado de verdad, sin escribir en disco y sin red: contrato, rechazos, claves únicas,
frescura en horas, linaje de cada columna e idempotencia. Termina en RESULTADO: VERDE (0) o ROJO (1).
"""
from __future__ import annotations

from datetime import date
from pathlib import Path
# La consola de Windows puede estar en cp1252: se fuerza UTF-8 para que los acentos y el euro no rompan
# la salida al redirigirla a un fichero.
import sys as _sys
for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

import publicar

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "ventas-mensuales.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = publicar.leer(CSV)
    ok(len(filas) == 180, "el CSV tiene 180 filas")
    ok(len(filas[0]) == 4, "el CSV trae las 4 columnas del contrato")

    resultado = publicar.validar(filas)
    ok(len(resultado["validas"]) == 180, "las 180 filas son válidas")
    ok(resultado["rechazos"] == [], "no hay filas rechazadas con el CSV del catálogo")
    ok(resultado["duplicadas"] == 0, "la clave fecha-tienda es única (0 duplicadas)")

    tiendas = sorted({f["tienda"] for f in resultado["validas"]})
    ok(tiendas == ["centro", "norte", "sur"], "hay exactamente 3 tiendas")
    por_tienda = {}
    for f in resultado["validas"]:
        por_tienda[f["tienda"]] = por_tienda.get(f["tienda"], 0) + 1
    ok(all(n == 60 for n in por_tienda.values()), "cada tienda tiene 60 días")

    fechas = sorted(f["fecha"] for f in resultado["validas"])
    ok(fechas[0] == date(2026, 1, 1), "la primera fecha es 2026-01-01")
    ok(fechas[-1] == date(2026, 6, 29), "la última fecha es 2026-06-29")
    ok(sum(f["unidades"] for f in resultado["validas"]) == 14295, "las unidades suman 14.295")
    ok(round(sum(f["ingresos"] for f in resultado["validas"]), 2) == 192292.08, "los ingresos suman 192.292,08 €")

    f = publicar.frescura(resultado["validas"], date(2026, 6, 30))
    ok(f["horas"] == 24, "la frescura con corte 2026-06-30 es de 24 horas")
    ok(f["fresco"] is True, "24 horas está dentro del umbral de 48 horas")
    ok(publicar.frescura(resultado["validas"], date(2026, 7, 10))["fresco"] is False, "con corte 2026-07-10 el dato está caducado")

    l = publicar.linaje()
    ok(len(l) == 4, "el linaje cubre las 4 columnas publicadas")
    ok(set(l) == set(publicar.COLUMNAS), "las columnas del linaje son exactamente las del contrato")
    ok(all("ventas-mensuales.csv" in origen for origen in l.values()), "las 4 columnas apuntan al mismo origen")

    c = publicar.cargar_dos_veces(resultado["validas"])
    ok(c["claves"] == 180, "hay 180 claves únicas")
    ok(c["nuevas"] == 0, "la segunda carga añade 0 filas")

    # El contrato tiene que rechazar de verdad: se prueban tres filas malas sintéticas.
    malas = [
        {"fecha": "2026-01-01", "tienda": "centro", "unidades": "-1", "ingresos": "10.0"},
        {"fecha": "2026-01-01", "tienda": "este", "unidades": "1", "ingresos": "10.0"},
        {"fecha": "no-es-fecha", "tienda": "centro", "unidades": "1", "ingresos": "10.0"},
    ]
    for i, fila in enumerate(malas, start=1):
        ok(len(publicar.validar([fila])["rechazos"]) == 1, f"el contrato rechaza la fila mala {i}")

    codigo = (AQUI / "publicar.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
