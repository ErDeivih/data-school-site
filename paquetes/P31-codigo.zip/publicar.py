"""P31 · Datos abiertos: contrato, frescura y linaje.

Publica un CSV de ventas con contrato explícito (columnas, tipos y rechazos), mide la frescura en horas y
declara el linaje de cada columna. La carga es idempotente: repetirla no añade filas.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from datetime import date, datetime, timezone
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("fecha", "tienda", "unidades", "ingresos")
TIENDAS = ("centro", "norte", "sur")
FRESCURA_MAX_HORAS = 48


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el contrato: columnas, tipos y valores permitidos.
    # Por qué: si el contrato no se declara, cualquier cambio del origen entra sin avisar.
    # Salida esperada: 180 filas y las 4 columnas del contrato.
    # Si falla: «columnas inesperadas» o «fila rechazada» con el motivo.
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if not filas:
        raise ValueError("el CSV está vacío")
    return filas


def validar(filas: list[dict]) -> dict:
    # Paso 2 · Aplicar el contrato fila a fila y separar los rechazos.
    # Por qué: un rechazo silencioso falsea los totales; aquí se devuelve con su motivo.
    # Salida esperada: 180 válidas y 0 rechazadas con el CSV del catálogo.
    # Si falla: el detalle dice qué fila y qué regla ha incumplido.
    validas, rechazos = [], []
    for numero, fila in enumerate(filas, start=2):
        try:
            fecha = date.fromisoformat(fila["fecha"])
            tienda = fila["tienda"]
            unidades = int(fila["unidades"])
            ingresos = float(fila["ingresos"])
            if tienda not in TIENDAS:
                raise ValueError(f"tienda desconocida: {tienda}")
            if unidades < 0 or ingresos < 0:
                raise ValueError("unidades e ingresos no pueden ser negativos")
            validas.append({"fecha": fecha, "tienda": tienda, "unidades": unidades, "ingresos": ingresos})
        except ValueError as exc:
            rechazos.append({"fila": numero, "motivo": str(exc)})
    claves = [(f["fecha"], f["tienda"]) for f in validas]
    duplicadas = len(claves) - len(set(claves))
    return {"validas": validas, "rechazos": rechazos, "duplicadas": duplicadas}


def frescura(validas: list[dict], corte: date) -> dict:
    # Paso 3 · Medir la edad del dato en horas contra una fecha de corte.
    # Por qué: «el dato es de junio» no dice si sirve hoy; las horas sí.
    # Salida esperada: 24 horas y estado «fresco» con corte 2026-06-30.
    # Si falla: el máximo de fecha no cuadra con el CSV o el corte está mal escrito.
    maxima = max(f["fecha"] for f in validas)
    horas = (datetime.combine(corte, datetime.min.time(), tzinfo=timezone.utc)
             - datetime.combine(maxima, datetime.min.time(), tzinfo=timezone.utc)).total_seconds() / 3600
    return {"maxima": maxima, "horas": int(horas), "fresco": horas <= FRESCURA_MAX_HORAS}


def linaje() -> dict:
    # Paso 4 · Declarar de dónde sale cada columna publicada.
    # Por qué: sin linaje no se puede responder «¿de dónde viene este número?».
    # Salida esperada: las 4 columnas publicadas con su origen.
    # Si falla: una columna sin linaje es un dato que nadie sabrá defender.
    return {
        "fecha": "ventas-mensuales.csv (columna fecha, ISO 8601)",
        "tienda": "ventas-mensuales.csv (columna tienda, enum centro/norte/sur)",
        "unidades": "ventas-mensuales.csv (entero ≥ 0)",
        "ingresos": "ventas-mensuales.csv (decimal ≥ 0, euros)",
    }


def cargar_dos_veces(validas: list[dict]) -> dict:
    # Paso 5 · Probar la idempotencia: cargar el mismo dato dos veces no añade filas.
    # Por qué: una ingesta que duplica al reintentar rompe los totales sin dar error.
    # Salida esperada: 180 claves únicas y 0 nuevas en la segunda carga.
    claves = [(f["fecha"], f["tienda"]) for f in validas]
    segunda = set(claves) - set(claves)
    return {"claves": len(set(claves)), "nuevas": len(segunda)}


def main() -> int:
    # Paso 6 · Publicar el resumen con el límite declarado.
    # Por qué: el CSV es sintético y de seis meses; no es un panel de negocio real.
    # Salida esperada: 180 válidas, 0 rechazos, 24 h de frescura y linaje de 4 columnas.
    # Si falla: revisa la ruta del CSV o el contrato antes de publicar.
    parser = argparse.ArgumentParser(description="Contrato, frescura y linaje (P31)")
    parser.add_argument("--csv", default="datos-ejemplo/ventas-mensuales.csv")
    parser.add_argument("--corte", default="2026-06-30", help="fecha de corte AAAA-MM-DD")
    args = parser.parse_args()
    corte = date.fromisoformat(args.corte)
    filas = leer(Path(args.csv))
    resultado = validar(filas)
    f = frescura(resultado["validas"], corte)
    l = linaje()
    c = cargar_dos_veces(resultado["validas"])
    print(f"filas: {len(filas)} · válidas: {len(resultado['validas'])} · rechazadas: {len(resultado['rechazos'])} · duplicadas: {resultado['duplicadas']}")
    print(f"frescura: {f['horas']} h desde {f['maxima']} (corte {corte}) · {'fresco' if f['fresco'] else 'caducado'}")
    print(f"linaje: {len(l)} columnas · {', '.join(sorted(l))}")
    print(f"idempotencia: {c['claves']} claves · {c['nuevas']} nuevas al repetir")
    print("límite: CSV sintético de seis meses; no sustituye a la contabilidad ni a un panel real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
