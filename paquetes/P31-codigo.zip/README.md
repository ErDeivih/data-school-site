﻿# P31 · Datos abiertos: contrato, frescura y linaje

Paquete descargable de **Data School** para el proyecto P31. Incluye el CSV de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python publicar.py
python publicar.py --csv datos-ejemplo/ventas-mensuales.csv --corte 2026-06-30
python verificar.py
```

`publicar.py` imprime filas válidas y rechazadas, la frescura en horas, el linaje y la prueba de
idempotencia. `verificar.py` comprueba el contrato, los totales, la frescura y el linaje; sale 0 si todo
cuadra.

## Datos

- `datos-ejemplo/ventas-mensuales.csv`: **180 filas × 4 columnas** (3 tiendas × 60 días, enero–junio de
  2026; 14.295 unidades y 192.292,08 €). Sintético y **CC0-1.0**; es el `ventas-mensuales` del catálogo
  de Data School.

## Salida esperada

```text
filas: 180 · válidas: 180 · rechazadas: 0 · duplicadas: 0
frescura: 24 h desde 2026-06-29 (corte 2026-06-30) · fresco
linaje: 4 columnas · fecha, ingresos, tienda, unidades
idempotencia: 180 claves · 0 nuevas al repetir
límite: CSV sintético de seis meses; no sustituye a la contabilidad ni a un panel real.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Contrato | `leer` exige las 4 columnas y el orden | contratos de datos |
| 2 · Validar y cuarentena | `validar` tipa cada fila y devuelve rechazos con motivo | calidad y SLAs |
| 3 · Frescura | `frescura` mide horas contra la fecha de corte | calidad y SLAs |
| 4 · Linaje | `linaje` declara el origen de cada columna | catálogo y linaje |
| 5 · Idempotencia | `cargar_dos_veces` prueba que repetir no añade filas | contratos de datos |
| 6 · Publicar | `main` resume y declara el límite | catálogo y linaje |

## Fallos típicos

- **`columnas inesperadas`**: el CSV trae otro orden o columnas de más; el contrato no se relaja.
- **Rechazos con `tienda desconocida`**: se ha añadido una tienda fuera del enum `centro/norte/sur`.
- **`unidades e ingresos no pueden ser negativos`**: hay devoluciones o un signo mal puesto; van a
  cuarentena, no se corrigen a ciegas.
- **Frescura negativa**: la fecha de corte es anterior al último dato; revisa el `--corte`.
- **Filas nuevas al repetir**: la clave no es `(fecha, tienda)` o se está duplicando la carga.

## Límite

El CSV es sintético y de seis meses. El contrato y la frescura enseñan el proceso; no sustituyen a la
contabilidad ni a un panel de negocio real.
