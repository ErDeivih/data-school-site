# P58 · Ecuación de onda: la membrana de un tambor — código ejecutable

Resuelve la ecuación de onda en una membrana cuadrada con **diferencias finitas centradas**, bordes
fijos y una condición inicial generada con **semilla fija**. Comprueba la **condición CFL en 2D**, enseña
con un caso aparte que un paso por encima del límite **explota**, y mide el **error frente a la solución
analítica** de un modo propio al refinar la rejilla, con su orden de convergencia. No usa red. Es el
código que acompaña a la ficha
`../../fichas-ideas/p58-ecuacion-de-onda.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **NumPy** `>=1.26` (probado con 2.5.2; licencia BSD-3-Clause). Hace las operaciones de rejilla del
  esquema, que en Python puro serían mucho más lentas.
- **matplotlib** (opcional, licencia PSF/Matplotlib): solo para `python onda.py --figura`.
- No hace falta red ni ninguna cuenta: la rejilla y la condición inicial las genera el proyecto.

## Instalación

```powershell
cd proyectos/p58-ecuacion-de-onda/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` solo exige NumPy; matplotlib queda comentado porque las figuras son opcionales.

## Orden de ejecución

```powershell
python onda.py --regenerar-muestra   # reescribe datos-ejemplo/membrana-inicial.csv (semilla 20261111)
python onda.py                       # simula, comprueba CFL y mide el error; guarda resultados/
python onda.py --figura              # además dibuja la membrana y la convergencia (matplotlib)
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta es **solo stdout** (no escribe en disco) y no usa red. Comprueba **14 cosas**: los parámetros y
la semilla 20261111, que los cuatro tamaños de rejilla calculan bien dx y respetan el margen CFL
(c·dt/dx ≤ 1/√2 ≈ 0,7071), que la condición inicial de ejemplo se regenera exacta, que el caso principal
se mantiene acotado (max|u| = 1,010860), que los bordes siguen a cero, que el caso inestable explota
(max|u| ≈ 1,00e+27), que el error frente a la analítica baja al afinar con orden ≈ 2, que la solución
exacta coincide con la condición inicial en t = 0 y que el código no hace red ni lleva claves. Termina en
`RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). La salida real es la de
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt), con 14 comprobaciones en verde:

- **Rejilla principal:** 64 × 64, dx = 0,015873, c·dt/dx = 0,6364 (límite 2D 0,7071), 99 pasos hasta
  t = 1,00; max|u| = 1,010860 al final 0,281243 (acotado, no explota).
- **Caso inestable:** con margen 1,3 → c·dt/dx = 0,9130, por encima del límite; max|u| llega a 1,00e+27.
- **Error frente a la analítica:** N=16 → 1,699e−03 · N=32 → 3,649e−04 (orden 2,22) · N=64 → 8,431e−05
  (orden 2,11) · N=128 → 2,113e−05 (orden 2,00); el error baja por un factor ≈ 80 al pasar de 16 a 128
  nodos.
- **Arranque de segundo orden:** con velocidad inicial nula se usa u⁻¹ = u⁰ + (dt²/2)·c²·∇²u⁰. Si se usa
  u⁻¹ = u⁰, el primer paso inyecta el doble de curvatura y el error baja como dx (orden 1) en vez de dx².

## Datos de ejemplo

- `datos-ejemplo/parametros.json`: semilla **20261111**, lado 1,0 m, velocidad 1,0 m/s, modo (1, 1),
  margen CFL 0,9 (y 1,3 para el caso inestable), t_final 1,0 s, rejilla principal 64 y barrido
  [16, 32, 64, 128], amplitud de ruido 0,01.
- `datos-ejemplo/membrana-inicial.csv`: **4.096 filas × 3 columnas** (`x`, `y`, `u`) — la superficie
  inicial de la rejilla de 64 × 64, modo propio más ruido, generada por el proyecto con la semilla fija.
  No es un CSV del catálogo y la puerta comprueba que se regenera exactamente.
- `resultados/`: `estabilidad.csv` (99 pasos con max|u|), `convergencia-onda.csv` (4 filas con error y
  orden) y `ejemplo-salida.txt`. Se regeneran al ejecutar `onda.py`.

## Fuente real y licencia

- **No hay API ni fuente externa**: el proyecto es local por diseño y la ficha declara `api: []`. La
  membrana es un modelo, no un objeto físico medido; la solución analítica solo existe para modos propios.
- Datos propios sintéticos y deterministas, generados por el proyecto: **CC0-1.0**.
- NumPy: **BSD-3-Clause**. matplotlib (opcional): **PSF/Matplotlib**.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · La ecuación y sus derivadas | La ecuación de onda como relación entre derivadas parciales | `Derivadas parciales y gradiente` |
| 2 · Rejilla y paso espacial | Discretizar el dominio y construir la malla | `Derivadas parciales y gradiente` |
| 3 · Condición inicial con semilla | Reproducibilidad de la superficie de partida | `Aleatoriedad y muestreo` |
| 4 · Esquema y CFL | Estabilidad de un esquema explícito en 2D | `Ecuaciones diferenciales estocásticas` |
| 5 · Arranque de segundo orden | Por qué el primer paso decide el orden del error | `Precisión y error numérico` |
| 6 · Error y convergencia | Comparar con la solución exacta y estimar el orden | `Precisión y error numérico` |
| 7 · Animación y figuras | Enseñar la vibración sin que la estética tape la estabilidad | `Visualización con Matplotlib` |

## Estructura

```text
codigo/
├── onda.py                 # rejilla, condición inicial, esquema, CFL, error, CSV y figuras
├── datos-ejemplo/          # parametros.json y la membrana inicial de 64 × 64 (semilla 20261111)
├── verificar.py            # la puerta del proyecto (solo stdout, sin red)
└── resultados/             # ejemplo-salida.txt y los CSV generados
```

## Fallos típicos

- **`ModuleNotFoundError: numpy`**: instala con el mismo Python que ejecuta el script,
  `python -m pip install -r requirements.txt`.
- **El esquema explota**: dt elegido por encima del límite (c·dt/dx > 1/√2 ≈ 0,7071); la serie max|u|
  crece sin límite y la animación deja de tener sentido. El proyecto incluye el caso inestable a propósito.
- **Refinar dx sin tocar dt**: al afinar la rejilla se incumple CFL; el paso temporal se recalcula en cada
  tamaño con el mismo margen.
- **Arranque de primer orden**: usar u⁻¹ = u⁰ hace que el error baje como dx en vez de dx²; la puerta mide
  el orden y lo exige ≈ 2.
- **Confundir estabilidad con precisión**: cumplir CFL no garantiza exactitud; el error se mide contra la
  solución analítica y el orden se estima con la tabla.
- **Medir el error donde la solución es cero**: un t o un punto con u ≈ 0 da un error pequeño sin que la
  simulación sea buena; se usa el máximo en toda la rejilla en un t fijo.
- **Bordes mal puestos**: la solución analítica de referencia supone bordes fijos a cero; cambiar la
  condición de contorno invalida la comparación.
- **`FileNotFoundError` en `parametros.json`**: el script se lanza desde otra carpeta; `datos-ejemplo/`
  tiene que existir junto al código (el ZIP lo trae).
