#!/usr/bin/env python3
"""P58 · Ecuación de onda: la membrana de un tambor.

Proyecto completo de la ficha P58. Resuelve la ecuación de onda en una membrana cuadrada con
diferencias finitas centradas, bordes fijos y una condición inicial generada con semilla fija; comprueba
la condición CFL en 2D, muestra cómo un paso por encima del límite explota, y mide el error frente a la
solución analítica de un modo propio al refinar la rejilla. No usa red.

    python onda.py                     # simula, imprime estabilidad y error, y guarda resultados/
    python onda.py --figura            # además dibuja la membrana y la convergencia (matplotlib)
    python onda.py --regenerar-muestra # reescribe datos-ejemplo/membrana-inicial.csv

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
LIMITE_CFL_2D = 1.0 / math.sqrt(2.0)


def cargar_parametros() -> dict:
    # Paso 1 · Lee los parámetros de la membrana desde datos-ejemplo/parametros.json
    # Por qué: la velocidad, el lado, el modo y los márgenes de CFL se declaran antes de simular; si se
    #          eligen después de ver si el esquema explota, la comprobación no vale nada.
    # Salida esperada: las claves cargadas sin error (el resumen imprime «rejilla: …» justo después)
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o restaura datos-ejemplo/parametros.json.
    ruta = DATOS / "parametros.json"
    parametros = json.loads(ruta.read_text(encoding="utf-8"))
    obligatorias = ("semilla", "lado", "velocidad", "modo", "margen_cfl", "t_final", "nodos_principal", "nodos_barrido")
    faltan = [clave for clave in obligatorias if clave not in parametros]
    if faltan:
        raise RuntimeError(f"faltan claves en {ruta.name}: {', '.join(faltan)}")
    if float(parametros["lado"]) <= 0.0 or float(parametros["velocidad"]) <= 0.0:
        raise RuntimeError("«lado» y «velocidad» tienen que ser positivos")
    if not 0.0 < float(parametros["margen_cfl"]) <= 1.0:
        raise RuntimeError("«margen_cfl» es una fracción del límite (0, 1]; para ver la inestabilidad hay otro margen")
    if float(parametros["t_final"]) <= 0.0:
        raise RuntimeError("«t_final» tiene que ser positivo")
    return parametros


def malla(nodos: int, lado: float) -> dict:
    """Rejilla cuadrada de `nodos` × `nodos` puntos con paso espacial dx = lado/(nodos−1)."""
    if nodos < 3:
        raise RuntimeError("una rejilla necesita al menos 3 nodos por lado")
    x = np.linspace(0.0, lado, nodos)
    y = np.linspace(0.0, lado, nodos)
    return {"x": x, "y": y, "dx": lado / (nodos - 1), "nodos": nodos}


def condicion_inicial(x: np.ndarray, y: np.ndarray, parametros: dict, amplitud_ruido: float = 0.0) -> np.ndarray:
    # Paso 2 · Genera la condición inicial: el modo propio más un ruido pequeño con la semilla fija
    # Por qué: el ruido hace la membrana menos artificial y da algo que la semilla debe reproducir; para
    #          medir el error contra la solución analítica se apaga (ruido 0), porque la analítica es del modo.
    # Salida esperada: una matriz 64×64 con bordes a cero y máximo cercano a 1
    # Si falla: ValueError → x e y no forman una rejilla cuadrada (nodos distintos por lado).
    modo_x, modo_y = int(parametros["modo"][0]), int(parametros["modo"][1])
    lado = float(parametros["lado"])
    forma = np.sin(modo_x * math.pi * x / lado)[:, None] * np.sin(modo_y * math.pi * y / lado)[None, :]
    rng = np.random.default_rng(int(parametros["semilla"]))
    ruido = amplitud_ruido * rng.standard_normal(forma.shape) if amplitud_ruido > 0.0 else np.zeros_like(forma)
    superficie = forma + ruido
    superficie[0, :] = superficie[-1, :] = 0.0
    superficie[:, 0] = superficie[:, -1] = 0.0
    return superficie


def solucion_analitica(x: np.ndarray, y: np.ndarray, t: float, parametros: dict) -> np.ndarray:
    """Solución exacta del modo propio con bordes fijos: sen·sen·cos(ωt), con ω = cπ√(m²+n²)/L."""
    modo_x, modo_y = int(parametros["modo"][0]), int(parametros["modo"][1])
    lado = float(parametros["lado"])
    velocidad = float(parametros["velocidad"])
    omega = velocidad * math.pi * math.sqrt(modo_x ** 2 + modo_y ** 2) / lado
    forma = np.sin(modo_x * math.pi * x / lado)[:, None] * np.sin(modo_y * math.pi * y / lado)[None, :]
    return forma * math.cos(omega * t)


def simular(parametros: dict, nodos: int, margen_cfl: float, amplitud_ruido: float = 0.0, guardar_serie: bool = True) -> dict:
    # Paso 3 · Aplica el esquema explícito de cinco puntos y comprueba la condición CFL
    # Por qué: en 2D el esquema es estable solo si c·dt/dx <= 1/√2 ≈ 0,7071; el paso temporal se calcula
    #          como fracción de ese límite y se declara, en vez de elegir un dt «pequeño» a ojo.
    # Salida esperada: "rejilla: 64x64 · dx=0.015873 · c·dt/dx=0.6364 (limite 0.7071) · pasos=200"
    # Si falla: los valores crecen sin límite → el margen elegido incumple CFL (mira el caso inestable).
    rejilla = malla(nodos, float(parametros["lado"]))
    dx = rejilla["dx"]
    velocidad = float(parametros["velocidad"])
    dt_limite = dx / (velocidad * math.sqrt(2.0))
    dt = margen_cfl * dt_limite
    pasos = max(1, int(math.ceil(float(parametros["t_final"]) / dt)))
    dt = float(parametros["t_final"]) / pasos
    cfl = velocidad * dt / dx
    if cfl > LIMITE_CFL_2D + 1e-12:
        # No se aborta: el proyecto incluye a propósito un caso inestable para demostrar el límite.
        print(f"aviso: c·dt/dx = {cfl:.4f} supera el limite CFL 2D = {LIMITE_CFL_2D:.4f}; se simula para verlo")
    cfl2 = cfl ** 2
    inicial = condicion_inicial(rejilla["x"], rejilla["y"], parametros, amplitud_ruido)
    u_actual = inicial.copy()
    # Arranque de segundo orden: con velocidad inicial nula, u^{-1} = u^0 + (dt²/2)·c²·∇²u^0. Si se usa
    # u^{-1} = u^0 el primer paso inyecta el doble de curvatura y el error global baja como dx, no como dx².
    laplaciano_inicial = (
        inicial[2:, 1:-1]
        + inicial[:-2, 1:-1]
        + inicial[1:-1, 2:]
        + inicial[1:-1, :-2]
        - 4.0 * inicial[1:-1, 1:-1]
    )
    u_anterior = inicial.copy()
    u_anterior[1:-1, 1:-1] += 0.5 * cfl2 * laplaciano_inicial
    max_abs = np.empty(pasos, dtype=np.float64)
    for paso in range(pasos):
        laplaciano = (
            u_actual[2:, 1:-1]
            + u_actual[:-2, 1:-1]
            + u_actual[1:-1, 2:]
            + u_actual[1:-1, :-2]
            - 4.0 * u_actual[1:-1, 1:-1]
        )
        u_siguiente = 2.0 * u_actual - u_anterior
        u_siguiente[1:-1, 1:-1] += cfl2 * laplaciano
        u_anterior, u_actual = u_actual, u_siguiente
        max_abs[paso] = float(np.max(np.abs(u_actual)))
    return {
        "nodos": nodos,
        "dx": dx,
        "dt": dt,
        "cfl": cfl,
        "pasos": pasos,
        "t_final": float(parametros["t_final"]),
        "rejilla": rejilla,
        "inicial": inicial,
        "final": u_actual,
        "max_abs": max_abs if guardar_serie else np.array([max_abs[-1]]),
    }


def error_frente_analitica(parametros: dict, nodos: int) -> dict:
    """Corre la rejilla sin ruido y mide el error máximo frente a la solución exacta del modo propio."""
    simulacion = simular(parametros, nodos, float(parametros["margen_cfl"]), amplitud_ruido=0.0, guardar_serie=False)
    exacta = solucion_analitica(simulacion["rejilla"]["x"], simulacion["rejilla"]["y"], simulacion["t_final"], parametros)
    error = float(np.max(np.abs(simulacion["final"] - exacta)))
    return {"nodos": nodos, "dx": simulacion["dx"], "dt": simulacion["dt"], "cfl": simulacion["cfl"],
            "error": error, "final": simulacion["final"]}


def tabla_convergencia(parametros: dict) -> list:
    # Paso 4 · Refina la rejilla y mide el error: al dividir dx entre 2, el error debe bajar ≈ ÷4
    # Por qué: la estabilidad (CFL) no es precisión; el orden del esquema se demuestra con la tabla de
    #          errores y el orden estimado, no con que la animación «se vea bien».
    # Salida esperada: N=16, 32, 64, 128 con error decreciente y orden estimado ≈ 2
    # Si falla: el error no baja → se está comparando en tiempos distintos o la condición de borde no cuadra.
    filas = []
    anterior = None
    for nodos in [int(n) for n in parametros["nodos_barrido"]]:
        fila = error_frente_analitica(parametros, nodos)
        fila["orden"] = (
            math.log2(anterior["error"] / fila["error"]) if anterior is not None and fila["error"] > 0.0 and anterior["error"] > 0.0 else float("nan")
        )
        filas.append(fila)
        anterior = fila
    return filas


def ejecutar(parametros: dict) -> dict:
    """Simula el caso principal, el inestable y el barrido, imprimiendo el resumen que la puerta necesita."""
    principal = simular(parametros, int(parametros["nodos_principal"]), float(parametros["margen_cfl"]), float(parametros["amplitud_ruido"]))
    margen_inestable = float(parametros.get("margen_inestable", 1.3))
    inestable = simular(parametros, int(parametros["nodos_principal"]), margen_inestable, amplitud_ruido=0.0, guardar_serie=False)
    barrido = tabla_convergencia(parametros)

    print(
        f"rejilla: {principal['nodos']}x{principal['nodos']} · dx={principal['dx']:.6f}"
        f" · c·dt/dx={principal['cfl']:.4f} (limite CFL 2D={LIMITE_CFL_2D:.4f}) · pasos={principal['pasos']}"
    )
    print(
        f"estabilidad: max|u| = {float(principal['max_abs'].max()):.6f}"
        f" al final {float(principal['max_abs'][-1]):.6f} (acotado, no explota)"
    )
    print(
        f"inestable: con margen {margen_inestable:.2f} → c·dt/dx={inestable['cfl']:.4f}"
        f" · max|u| = {float(inestable['max_abs'].max()):.3e} (el esquema explota al superar CFL)"
    )
    print(
        "error frente a la analitica: "
        + " · ".join(
            f"N={fila['nodos']}: {fila['error']:.3e}" + ("" if math.isnan(fila["orden"]) else f" (orden {fila['orden']:.2f})")
            for fila in barrido
        )
    )
    print(
        f"convergencia: el error baja de {barrido[0]['error']:.3e} a {barrido[-1]['error']:.3e}"
        f" al pasar de {barrido[0]['nodos']} a {barrido[-1]['nodos']} nodos"
    )
    return {"principal": principal, "inestable": inestable, "barrido": barrido}


def guardar(resultados: dict, parametros: dict) -> None:
    # Paso 5 · Guarda la serie de estabilidad y la tabla de error en resultados/
    # Por qué: la serie max|u| por paso demuestra que el esquema no explota, y la tabla de error deja el
    #          refinamiento por escrito; sin esos ficheros la afirmación «baja al afinar» no se audita.
    # Salida esperada: "resultados: estabilidad.csv, convergencia-onda.csv"
    # Si falla: PermissionError → resultados/ no es escribible; ejecuta desde codigo/.
    RESULTADOS.mkdir(parents=True, exist_ok=True)
    serie = resultados["principal"]["max_abs"]
    dt = resultados["principal"]["dt"]
    with (RESULTADOS / "estabilidad.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["paso", "tiempo", "max_abs_u"])
        for paso, valor in enumerate(serie, start=1):
            escritor.writerow([paso, f"{paso * dt:.6f}", f"{float(valor):.6f}"])
    with (RESULTADOS / "convergencia-onda.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["nodos", "dx", "dt", "cfl", "error_maximo", "orden_estimado"])
        for fila in resultados["barrido"]:
            escritor.writerow(
                [fila["nodos"], f"{fila['dx']:.8f}", f"{fila['dt']:.8f}", f"{fila['cfl']:.6f}",
                 f"{fila['error']:.6e}", "" if math.isnan(fila["orden"]) else f"{fila['orden']:.3f}"]
            )
    print("resultados: estabilidad.csv, convergencia-onda.csv")


def escribir_muestra(parametros: dict) -> Path:
    # Paso 6 · Escribe la superficie inicial de ejemplo con la semilla fija (formato largo x, y, u)
    # Por qué: la muestra es la condición inicial del caso principal, no un dato inventado; así la puerta
    #          comprueba que se regenera exactamente con la semilla 20261111.
    # Salida esperada: "muestra: datos-ejemplo/membrana-inicial.csv (4096 nodos)"
    # Si falla: PermissionError → datos-ejemplo/ tiene que existir y ser escribible.
    nodos = int(parametros["nodos_principal"])
    rejilla = malla(nodos, float(parametros["lado"]))
    superficie = condicion_inicial(rejilla["x"], rejilla["y"], parametros, float(parametros.get("amplitud_ruido", 0.0)))
    ruta = DATOS / "membrana-inicial.csv"
    with ruta.open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["x", "y", "u"])
        for i, x in enumerate(rejilla["x"]):
            for j, y in enumerate(rejilla["y"]):
                escritor.writerow([f"{x:.6f}", f"{y:.6f}", f"{superficie[i, j]:.8f}"])
    print(f"muestra: {ruta.relative_to(RAIZ).as_posix()} ({nodos * nodos} nodos)")
    return ruta


def figura(resultados: dict, parametros: dict) -> None:
    # Paso 7 · Dibuja la membrana inicial, la final y la convergencia del error (opcional)
    # Por qué: la figura muestra la vibración, pero la prueba es la serie max|u| y la tabla de error.
    # Salida esperada: resultados/membrana.png
    # Si falla: ModuleNotFoundError de matplotlib → `python -m pip install matplotlib`.
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ModuleNotFoundError as exc:
        raise RuntimeError("para --figura hace falta matplotlib: python -m pip install matplotlib") from exc

    rejilla = resultados["principal"]["rejilla"]
    fig, ejes = plt.subplots(2, 2, figsize=(9, 8))
    for eje, (titulo, superficie) in zip(
        ejes[0],
        [
            ("t = 0 (condicion inicial con semilla)", resultados["principal"]["inicial"]),
            (f"t = {resultados['principal']['t_final']:.2f}", resultados["principal"]["final"]),
        ],
    ):
        imagen = eje.imshow(superficie, origin="lower", extent=[0, float(parametros["lado"]), 0, float(parametros["lado"])], cmap="viridis")
        eje.set_title(titulo)
        eje.set_xlabel("x")
        eje.set_ylabel("y")
        fig.colorbar(imagen, ax=eje, shrink=0.8)
    serie = resultados["principal"]["max_abs"]
    ejes[1][0].plot(np.arange(1, len(serie) + 1), serie, color="#4c72b0")
    ejes[1][0].set_xlabel("paso temporal")
    ejes[1][0].set_ylabel("max |u|")
    ejes[1][0].set_title("estabilidad: la serie se mantiene acotada")
    nodos = [fila["nodos"] for fila in resultados["barrido"]]
    errores = [fila["error"] for fila in resultados["barrido"]]
    ejes[1][1].loglog(nodos, errores, "o-", color="#c44e52")
    ejes[1][1].set_xlabel("nodos por lado")
    ejes[1][1].set_ylabel("error maximo")
    ejes[1][1].set_title("convergencia al refinar la rejilla")
    fig.tight_layout()
    fig.savefig(RESULTADOS / "membrana.png", dpi=120)
    plt.close(fig)
    print("figura: membrana.png")


def main(argv: list) -> int:
    try:
        parametros = cargar_parametros()
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    if "--regenerar-muestra" in argv:
        try:
            escribir_muestra(parametros)
        except OSError as exc:
            print(f"error: {exc}")
            return 1
        return 0
    print("== P58 · ecuacion de onda: la membrana de un tambor ==")
    try:
        resultados = ejecutar(parametros)
        guardar(resultados, parametros)
        if "--figura" in argv:
            figura(resultados, parametros)
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
