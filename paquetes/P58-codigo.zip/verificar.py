﻿#!/usr/bin/env python3
"""Puerta del proyecto P58 (ecuación de onda en una membrana).

Comprueba el resultado de verdad, sin escribir en disco y sin red: rejilla y paso declarados, condición
CFL en 2D, estabilidad del caso principal, explosión cuando se supera el límite, condición inicial
reproducible con la semilla, error frente a la solución analítica y su orden de convergencia, y código
offline. Termina en RESULTADO: VERDE (código 0) o ROJO (código 1).

Uso:
    python verificar.py

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

# La consola de Windows puede estar en cp1252: si la salida lleva flechas o signos Unicode, la puerta
# fallaría al imprimir y no por un error del proyecto. Se fuerza UTF-8 en stdout/stderr.
import sys as _sys
for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

import csv
import math
import sys

sys.dont_write_bytecode = True  # la puerta no escribe nada: ni resultados ni caché de bytecode

import numpy as np

import onda

fallos: list = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P58 · ecuacion de onda: la membrana de un tambor ==")

    # Paso 1 · Comprueba los parámetros y la rejilla de cada tamaño del barrido
    # Por qué: la rejilla y el paso temporal se calculan, no se escriben a mano; si dx no es L/(N−1) o
    #          el paso no respeta el margen declarado, la comparación entre tamaños no significa nada.
    # Salida esperada: "OK rejilla: N=16 ... c·dt/dx=... (<= 0.7071)" para los cuatro tamaños.
    # Si falla: RuntimeError de cargar_parametros → falta datos-ejemplo/parametros.json.
    parametros = onda.cargar_parametros()
    ok(
        (int(parametros["semilla"]), int(parametros["nodos_principal"]), tuple(int(m) for m in parametros["modo"])) == (20261111, 64, (1, 1)),
        f"parámetros: semilla {int(parametros['semilla'])} · rejilla principal {int(parametros['nodos_principal'])}x{int(parametros['nodos_principal'])} · modo {tuple(int(m) for m in parametros['modo'])}",
    )
    lado = float(parametros["lado"])
    velocidad = float(parametros["velocidad"])
    margen = float(parametros["margen_cfl"])
    rejillas_ok = True
    for nodos in [int(n) for n in parametros["nodos_barrido"]]:
        rejilla = onda.malla(nodos, lado)
        dx = rejilla["dx"]
        dt_limite = dx / (velocidad * math.sqrt(2.0))
        dt = margen * dt_limite
        pasos = max(1, int(math.ceil(float(parametros["t_final"]) / dt)))
        dt = float(parametros["t_final"]) / pasos
        cfl = velocidad * dt / dx
        rejillas_ok = rejillas_ok and abs(dx - lado / (nodos - 1)) < 1e-12 and cfl <= onda.LIMITE_CFL_2D + 1e-12
        print(f"      rejilla N={nodos}: dx={dx:.6f} · c·dt/dx={cfl:.4f} (<= {onda.LIMITE_CFL_2D:.4f}) · pasos={pasos}")
    ok(rejillas_ok, f"rejilla: los cuatro tamaños declaran dx y respetan el margen CFL (limite 2D {onda.LIMITE_CFL_2D:.4f})")

    # Paso 2 · Comprueba la condición inicial de ejemplo: se regenera exacta con la semilla
    # Por qué: la muestra es la condición inicial del caso principal; si no se reproduce, la semilla no
    #          fija nada y la animación no sería repetible.
    # Salida esperada: "OK muestra: 4096 nodos ... coinciden con la semilla 20261111".
    # Si falla: el CSV no existe o se regeneró con otra semilla / otro tamaño de rejilla.
    nodos = int(parametros["nodos_principal"])
    rejilla = onda.malla(nodos, lado)
    superficie = onda.condicion_inicial(rejilla["x"], rejilla["y"], parametros, float(parametros.get("amplitud_ruido", 0.0)))
    ruta = onda.DATOS / "membrana-inicial.csv"
    filas = []
    if ruta.exists():
        with ruta.open(encoding="utf-8", newline="") as f:
            filas = list(csv.DictReader(f))
    diferencias = []
    for indice, fila in enumerate(filas):
        i, j = divmod(indice, nodos)
        diferencias.append(abs(float(fila["u"]) - float(superficie[i, j])))
    ok(
        len(filas) == nodos * nodos and max(diferencias, default=1.0) < 1e-7,
        f"muestra: {len(filas)} nodos en datos-ejemplo/membrana-inicial.csv y coinciden con la semilla {int(parametros['semilla'])}",
    )
    ok(0.9 <= float(np.max(np.abs(superficie))) <= 1.1, f"muestra: la condicion inicial tiene amplitud {float(np.max(np.abs(superficie))):.4f} (modo propio + ruido)")

    # Paso 3 · Ejecuta el caso principal y comprueba que es estable
    # Por qué: CFL garantiza estabilidad con el paso elegido, pero se comprueba en la serie max|u|, que es
    #          la prueba de que la animación no explota en ningún paso.
    # Salida esperada: las líneas del resumen y "OK estabilidad: max|u| acotado".
    # Si falla: la serie crece con el tiempo → el paso elegido no cumple CFL o el esquema tiene un error.
    resultados = onda.ejecutar(parametros)
    principal = resultados["principal"]
    serie = principal["max_abs"]
    ok(
        bool(np.all(np.isfinite(serie))) and float(serie.max()) < 1.1,
        f"estabilidad: max|u| = {float(serie.max()):.6f} y final {float(serie[-1]):.6f} (acotado, sin explotar)",
    )
    ok(len(serie) == principal["pasos"], f"estabilidad: {len(serie)} pasos simulados hasta t={principal['t_final']:.2f}")
    bordes = np.concatenate([principal["final"][0, :], principal["final"][-1, :], principal["final"][:, 0], principal["final"][:, -1]])
    ok(bool(np.all(np.abs(bordes) < 1e-12)), "bordes fijos: los cuatro lados de la membrana final siguen a cero")

    # Paso 4 · Comprueba que superar CFL hace explotar el esquema
    # Por qué: es la demostración de que la condición no es un formalismo; si el caso inestable no explota,
    #          el margen elegido no está haciendo nada.
    # Salida esperada: con margen 1,3 el máximo crece a escala astronómica (> 10).
    # Si falla: el esquema sigue estable por encima del límite → hay un dt mal calculado.
    inestable = resultados["inestable"]
    ok(
        inestable["cfl"] > onda.LIMITE_CFL_2D and float(inestable["max_abs"].max()) > 10.0,
        f"inestable: con c·dt/dx={inestable['cfl']:.4f} (> {onda.LIMITE_CFL_2D:.4f}) max|u| llega a {float(inestable['max_abs'].max()):.2e}",
    )

    # Paso 5 · Comprueba el error frente a la solución analítica y su orden de convergencia
    # Por qué: estabilidad no es precisión; el orden del esquema se demuestra con la tabla de errores al
    #          refinar la rejilla (al dividir dx entre 2, el error debe bajar ≈ ÷4).
    # Salida esperada: error decreciente y orden estimado ≈ 2 en las tres parejas.
    # Si falla: el orden sale 1 → el arranque u^{-1} no es de segundo orden (mira el comentario del Paso 3).
    barrido = resultados["barrido"]
    errores = [fila["error"] for fila in barrido]
    ok(all(errores[i] > errores[i + 1] for i in range(len(errores) - 1)), f"error: baja al afinar ({', '.join(f'{e:.3e}' for e in errores)})")
    ordenes = [fila["orden"] for fila in barrido if not math.isnan(fila["orden"])]
    ok(
        len(ordenes) == len(barrido) - 1 and all(1.7 <= orden <= 2.5 for orden in ordenes),
        "orden: el error se reduce como dx² (" + ", ".join(f"{orden:.2f}" for orden in ordenes) + ")",
    )
    ok(
        errores[-1] < errores[0] / 40.0,
        f"error: de {errores[0]:.3e} a {errores[-1]:.3e} al pasar de {barrido[0]['nodos']} a {barrido[-1]['nodos']} nodos",
    )
    analitica_inicial = onda.solucion_analitica(rejilla["x"], rejilla["y"], 0.0, parametros)
    inicial_sin_ruido = onda.condicion_inicial(rejilla["x"], rejilla["y"], parametros, 0.0)
    ok(
        float(np.max(np.abs(analitica_inicial - inicial_sin_ruido))) < 1e-12,
        "analitica: en t=0 la solución exacta coincide con la condición inicial del modo",
    )

    # Paso 6 · Comprueba que el código es offline y no lleva secretos
    # Por qué: la entrega se comparte y la puerta se ejecuta sin red.
    # Salida esperada: "el código del proyecto no hace peticiones de red" y "no contiene claves".
    # Si falla: aparece un http(s) o un patrón de token en onda.py → quítalo antes de empaquetar.
    fuente = (onda.RAIZ / "onda.py").read_text(encoding="utf-8")
    ok("http://" not in fuente and "https://" not in fuente, "el código del proyecto no hace peticiones de red")
    ok(
        not any(patron in fuente for patron in ("ghp_", "github_pat_", "Authorization:", "api_key")),
        "el código del proyecto no contiene claves ni cabeceras de autorización",
    )

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
