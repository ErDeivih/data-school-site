﻿#!/usr/bin/env python3
"""Puerta del proyecto P62 (frenada de dos pilotos en la misma curva).

Comprueba el resultado de verdad, sin escribir nada y sin red: el CSV es el del catálogo (sha256), la
rejilla de 20 m y las 120 combinaciones están completas, los 60 pares A–B son de la misma carrera y
curva, el punto de frenada se estima desde `freno_pct` con resolución de 20 m, el umbral «freno > 0»
se contamina (y el código lo cuenta), A frena más tarde y más fuerte que B en los 60 pares, y el
contraste real está documentado con su licencia.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

# La consola de Windows puede estar en cp1252: si la salida lleva flechas o signos Unicode, la puerta
# fallaría al imprimir y no por un error del proyecto. Se fuerza UTF-8 en stdout/stderr.
import sys as _sys
for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

import sys

import frenadas as p

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P62 · frenada de dos pilotos en la misma curva ==")

    # Paso 1 · Comprueba el dato de ejemplo y la rejilla
    # Por qué: el punto de frenada se estima con la rejilla; si falta una distancia o hay una de más,
    #          el espaciado cambia y la resolución de 20 m deja de ser cierta.
    # Salida esperada: "datos: 1200 filas × 8 columnas · 120 grupos de 10 muestras · rejilla 210…30 m"
    # Si falla: FileNotFoundError → falta datos-ejemplo/frenadas-f1.csv (el ZIP lo trae).
    df = p.cargar()
    ok(len(df) == 1200 and df.shape[1] == 8, f"CSV: {len(df)} filas × {df.shape[1]} columnas")
    ok(p.sha256(p.DATOS) == "ddddfeec43b9f59c2af11cb5756efef93ce4d2835a205a3869aa61c5822210e8",
       "el sha256 del CSV de ejemplo es el de la copia del catálogo")
    ok(sorted(df["distancia_m"].unique()) == sorted(p.DISTANCIAS), "la rejilla es 210…30 m en pasos de 20")
    grano = p.declarar_grano(df)
    ok(grano["grupos"] == 120 and grano["muestras"] == 10,
       f"grano: {grano['grupos']} grupos × {grano['muestras']} muestras")

    # Paso 2 · Comprueba la condición del criterio: misma carrera y misma curva
    # Por qué: comparar al piloto A en una carrera con el B en otra mide escenarios; el recuento de
    #          pares cruzados tiene que ser 0 y es la comprobación que pide la ficha.
    # Salida esperada: "misma carrera: 60 pares A–B en la misma carrera y curva · pares cruzados 0"
    # Si falla: pares cruzados > 0 → el filtro de pares está mezclando carreras.
    pares = p.comprobar_misma_carrera(df)
    ok(pares["pares"] == 60 and pares["cruzados"] == 0,
       f"pares A–B: {pares['pares']} · cruzados {pares['cruzados']}")

    # Paso 3 · Comprueba la estimación del punto de frenada y su resolución
    # Por qué: no hay columna de punto de frenada; la estimación tiene que caer en la rejilla y ser
    #          reproducible, y el umbral tiene que estar declarado y aplicado.
    # Salida esperada: "punto de frenada (umbral 10 %): 120 grupos · de 110 a 210 m · resolución 20 m"
    # Si falla: distancias fuera de la rejilla → el estimador está interpolando o sumando metros.
    puntos = p.estimar_punto_frenada(df)
    ok(len(puntos) == 120, f"puntos de frenada: {len(puntos)} grupos")
    ok(bool(puntos["punto_frenada_m"].isin(p.DISTANCIAS).all()),
       "todos los puntos de frenada caen en la rejilla de 20 m")
    ok(puntos["punto_frenada_m"].between(30, 210).all(),
       f"distancias entre {puntos['punto_frenada_m'].min()} y {puntos['punto_frenada_m'].max()} m")
    ok(puntos["velocidad_entrada_kmh"].between(83, 275).all(), "velocidad de entrada en el rango del CSV")
    puntos2 = p.estimar_punto_frenada(df, verbose=False)
    ok(puntos.equals(puntos2), "la estimación es determinista")

    # Paso 4 · Comprueba que el umbral «freno > 0» se contamina y que el código lo cuenta
    # Por qué: hay muestras previas con 1-2 % de freno; usar > 0 adelanta el punto una muestra. Si el
    #          informe no lo dice, la comparación se mueve 20 m sin avisar.
    # Salida esperada: "contaminación: el umbral > 0 cambia el punto de frenada en 71 grupos"
    # Si falla: 0 grupos cambiados → el CSV ya no trae esas muestras; actualiza el texto del README.
    contaminacion = p.medir_contaminacion(df, puntos)
    ok(contaminacion["cambiados"] == 71,
       f"el umbral > 0 cambia el punto en {contaminacion['cambiados']} grupos (deben ser 71)")

    # Paso 5 · Comprueba la comparación en la misma curva y carrera
    # Por qué: la tabla de comparación es el resultado; se comprueba que A frena más tarde en todos
    #          los pares y que la diferencia por curva es la de la rejilla.
    # Salida esperada: "comparación: A frena más tarde que B en 60 de 60 pares"
    # Si falla: algún par con A más tarde falso → los puntos o el cruce de pilotos están mal.
    tabla = p.comparar_por_curva(df, puntos)
    ok(len(tabla) == 60, f"comparaciones: {len(tabla)} pares carrera–curva")
    ok(int(tabla["A_frena_mas_tarde"].sum()) == 60, "A frena más tarde que B en los 60 pares")
    diferencia_por_curva = tabla.groupby("curva")["diferencia_m"].agg(lambda s: sorted(set(s)))
    ok(all(d == [-20] for c, d in diferencia_por_curva.items() if c in ("1", "2", "3", "4"))
       and all(d == [-40] for c, d in diferencia_por_curva.items() if c in ("5", "6")),
       f"diferencia A−B por curva: {dict(diferencia_por_curva)}")

    # Paso 6 · Comprueba la agresividad separada del punto de frenada
    # Por qué: frenar más tarde no es frenar más fuerte; A tiene que ganar en las dos cosas para que la
    #          conclusión del README no sea una coincidencia de una sola medida.
    # Salida esperada: "agresividad: freno máximo A 89–99 % frente a B 71–78 %"
    # Si falla: A no frena más fuerte en algún par → revisa la columna freno_pct.
    agresividad = p.medir_agresividad(df, tabla)
    freno = agresividad.groupby("piloto")["freno_max_pct"].agg(["min", "max"])
    ok(freno.loc["A", "min"] >= freno.loc["B", "max"],
       f"freno máximo: A {freno.loc['A', 'min']}-{freno.loc['A', 'max']} % · "
       f"B {freno.loc['B', 'min']}-{freno.loc['B', 'max']} %")
    ok(agresividad["acelerador_salida_pct"].between(0, 100).all(), "acelerador a la salida en 0-100 %")

    # Paso 7 · Comprueba que el contraste real está documentado y que no hay red ni secretos
    # Por qué: el CSV es sintético; el contraste se cita con licencia y límite, y la puerta se ejecuta
    #          sin red, así que no puede haber una descarga escondida.
    # Salida esperada: "contraste documentado y código offline"
    # Si falla: aparece una llamada de red o falta la mención a OpenF1 en el código.
    fuentes = [p.RAIZ / "frenadas.py"]
    texto = "\n".join(ruta.read_text(encoding="utf-8") for ruta in fuentes)
    ok("OpenF1" in texto and "CC0-1.0" in texto, "el código cita OpenF1 y la licencia del CSV")
    ok(not any(x in texto for x in ("import requests", "import urllib", "import socket",
                                    "urlopen(", "requests.get")),
       "el código no hace peticiones de red")
    ok(not any(x in texto for x in ("ghp_", "github_pat_", "Authorization:")),
       "el código no contiene claves ni cabeceras de autorización")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
