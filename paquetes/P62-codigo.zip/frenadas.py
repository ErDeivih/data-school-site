#!/usr/bin/env python3
"""P62 · Frenada de dos pilotos en la misma curva.

Código ejecutable del proyecto P62 (ruta datos). Compara el punto de frenada, la velocidad de
entrada y la agresividad de los pilotos A y B **en la misma carrera y la misma curva**, con la
rejilla de 20 m del CSV y el contraste real documentado de OpenF1 (sin descargar nada).

Uso:
    python frenadas.py            # pipeline completo; escribe las tablas en resultados/
    python frenadas.py limpiar    # borra las tablas generadas y deja el proyecto como descargado

Datos: datos-ejemplo/frenadas-f1.csv (1200 filas × 8 columnas, CC0-1.0; procedencia en el README).
Sin red: solo pandas y la biblioteca estándar.
"""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

import pandas as pd

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo" / "frenadas-f1.csv"
RESULTADOS = RAIZ / "resultados"

UMBRAL_FRENO = 10  # % de pedal: por debajo hay muestras del 1-2 % que no son frenada
RESOLUCION_M = 20
DISTANCIAS = [210, 190, 170, 150, 130, 110, 90, 70, 50, 30]
CURVAS = ["1", "2", "3", "4", "5", "6"]
COLUMNAS = ["carrera", "curva", "piloto", "distancia_m", "velocidad_kmh", "acelerador_pct",
            "freno_pct", "marcha"]
GENERADOS = ["punto-frenada.csv", "por-curva.csv", "agresividad.csv", "contraste-openf1.md"]


def exigir(condicion: bool, mensaje: str) -> None:
    """Aborta con un mensaje legible; el pipeline devuelve 1 y no deja resultados a medias."""
    if not condicion:
        raise RuntimeError(mensaje)


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def cargar() -> pd.DataFrame:
    # Paso 1 · Carga el CSV y comprueba la rejilla, las claves y los recuentos
    # Por qué: si falta una muestra o se repite, el punto de frenada se estima con otro espaciado y
    #          la comparación entre pilotos deja de ser la misma medida para los dos.
    # Salida esperada: "datos: 1200 filas × 8 columnas · 120 grupos de 10 muestras · rejilla 210…30 m"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o recupera el CSV de datos-ejemplo/.
    exigir(DATOS.exists(), f"no existe el dato de ejemplo: {DATOS}")
    df = pd.read_csv(DATOS)
    df["curva"] = df["curva"].astype(str)
    exigir(list(df.columns) == COLUMNAS, f"columnas inesperadas: {list(df.columns)}")
    exigir(len(df) == 1200, f"se esperaban 1200 filas y hay {len(df)}")
    exigir(sorted(df["distancia_m"].unique()) == sorted(DISTANCIAS), "la rejilla de distancias no es la del CSV")
    exigir(sorted(df["curva"].unique()) == CURVAS, f"curvas inesperadas: {sorted(df['curva'].unique())}")
    exigir(sorted(df["piloto"].unique()) == ["A", "B"], "faltan pilotos A y B")
    exigir(df.duplicated(["carrera", "curva", "piloto", "distancia_m"]).sum() == 0,
           "la clave (carrera, curva, piloto, distancia_m) no es única")
    print(f"datos: {len(df)} filas × {df.shape[1]} columnas · "
          f"{df.groupby(['carrera', 'curva', 'piloto']).ngroups} grupos de 10 muestras · "
          f"rejilla 210…30 m · sha256 {sha256(DATOS)[:8]}…")
    return df


def declarar_grano(df: pd.DataFrame) -> dict:
    # Paso 2 · Declara qué es una fila y qué identifica una vuelta
    # Por qué: una fila es una muestra de la aproximación al ápice, no una vuelta; el grano es lo
    #          primero que hay que escribir porque de él depende qué se puede comparar.
    # Salida esperada: "grano: una fila = una muestra · 120 grupos (carrera, curva, piloto) × 10 muestras"
    # Si falla: "grupos incompletos" → hay una combinación con más o menos de diez muestras.
    grupos = df.groupby(["carrera", "curva", "piloto"]).size()
    exigir(grupos.nunique() == 1, f"grupos incompletos: {sorted(set(grupos))}")
    print(f"grano: una fila = una muestra · {len(grupos)} grupos (carrera, curva, piloto) × "
          f"{int(grupos.iloc[0])} muestras")
    return {"grupos": len(grupos), "muestras": int(grupos.iloc[0])}


def comprobar_misma_carrera(df: pd.DataFrame) -> dict:
    # Paso 3 · Comprueba que cada par A–B está en la misma carrera y la misma curva
    # Por qué: es la condición del criterio de terminado; comparar al piloto A en una carrera con el
    #          B en otra mide el escenario, no al piloto, y con una cuenta se ve antes que mirando.
    # Salida esperada: "misma carrera: 60 pares A–B en la misma carrera y curva · pares cruzados 0"
    # Si falla: pares cruzados > 0 → el filtro que construye los pares está mezclando carreras.
    parejas = (df[["carrera", "curva", "piloto"]].drop_duplicates()
               .groupby(["carrera", "curva"])["piloto"].agg(list))
    completas = parejas[parejas.map(lambda pilotos: sorted(pilotos) == ["A", "B"])]
    cruzados = len(parejas) - len(completas)
    print(f"misma carrera: {len(completas)} pares A–B en la misma carrera y curva · "
          f"pares cruzados {cruzados}")
    return {"pares": len(completas), "cruzados": cruzados}


def estimar_punto_frenada(df: pd.DataFrame, umbral: int = UMBRAL_FRENO,
                         estricto: bool = False, verbose: bool = True) -> pd.DataFrame:
    # Paso 4 · Estima el punto de frenada desde freno_pct y distancia_m
    # Por qué: no hay columna de punto de frenada; se estima como la primera muestra (la más lejana)
    #          con freno por encima de un umbral, y con una rejilla de 20 m la resolución es esa.
    # Salida esperada: "punto de frenada (umbral 10 %): 120 grupos · de 110 a 210 m · resolución 20 m"
    # Si falla: "muestra 0" → hay un grupo donde no se supera el umbral; revisa el CSV.
    filas = []
    for (carrera, curva, piloto), grupo in df.groupby(["carrera", "curva", "piloto"]):
        ordenado = grupo.sort_values("distancia_m", ascending=False)
        if estricto:
            candidatas = ordenado[ordenado["freno_pct"] > umbral]
        else:
            candidatas = ordenado[ordenado["freno_pct"] >= umbral]
        exigir(len(candidatas) > 0, f"sin frenada en {carrera}/{curva}/{piloto}")
        muestra = candidatas.iloc[0]
        filas.append({"carrera": carrera, "curva": curva, "piloto": piloto,
                      "punto_frenada_m": int(muestra["distancia_m"]),
                      "velocidad_entrada_kmh": int(muestra["velocidad_kmh"]),
                      "freno_pct": int(muestra["freno_pct"])})
    puntos = pd.DataFrame(filas)
    if verbose:
        print(f"punto de frenada (umbral {umbral} %): {len(puntos)} grupos · "
              f"de {puntos['punto_frenada_m'].min()} a {puntos['punto_frenada_m'].max()} m · "
              f"resolución {RESOLUCION_M} m")
    return puntos


def medir_contaminacion(df: pd.DataFrame, puntos: pd.DataFrame) -> dict:
    # Paso 5 · Cuenta cuántos grupos cambiaría el umbral «freno > 0»
    # Por qué: antes de la frenada real hay muestras con 1-2 % de freno; si se usa > 0, el punto se
    #          adelanta una muestra y la comparación se mueve 20 m sin que nadie lo note.
    # Salida esperada: "contaminación: el umbral > 0 cambia el punto de frenada en 110 grupos"
    # Si falla: 0 grupos cambiados → la rejilla no tiene esas muestras; el riesgo no aplica.
    ingenuo = estimar_punto_frenada(df, umbral=0, estricto=True, verbose=False)
    fusion = ingenuo.merge(puntos, on=["carrera", "curva", "piloto"], suffixes=("_ingenuo", ""))
    cambiados = int((fusion["punto_frenada_m_ingenuo"] != fusion["punto_frenada_m"]).sum())
    print(f"contaminación: el umbral > 0 cambia el punto de frenada en {cambiados} grupos")
    return {"cambiados": cambiados}


def comparar_por_curva(df: pd.DataFrame, puntos: pd.DataFrame) -> pd.DataFrame:
    # Paso 6 · Compara A con B en la misma carrera y curva
    # Por qué: se compara el mismo escenario; además se separa «frenar más tarde» (distancia al ápice)
    #          de «frenar más fuerte» (freno máximo) y de la velocidad de entrada.
    # Salida esperada: "comparación: A frena más tarde que B en 60 de 60 pares"
    # Si falla: pares que no son 60 → falta una combinación carrera–curva en el CSV.
    filas = []
    for (carrera, curva), grupo in puntos.groupby(["carrera", "curva"]):
        a = grupo[grupo["piloto"] == "A"].iloc[0]
        b = grupo[grupo["piloto"] == "B"].iloc[0]
        filas.append({"carrera": carrera, "curva": curva,
                      "punto_A_m": int(a["punto_frenada_m"]), "punto_B_m": int(b["punto_frenada_m"]),
                      "diferencia_m": int(a["punto_frenada_m"] - b["punto_frenada_m"]),
                      "velocidad_A_kmh": int(a["velocidad_entrada_kmh"]),
                      "velocidad_B_kmh": int(b["velocidad_entrada_kmh"]),
                      "A_frena_mas_tarde": bool(a["punto_frenada_m"] < b["punto_frenada_m"])})
    tabla = pd.DataFrame(filas).sort_values(["curva", "carrera"]).reset_index(drop=True)
    tardes = int(tabla["A_frena_mas_tarde"].sum())
    print(f"comparación: A frena más tarde que B en {tardes} de {len(tabla)} pares")
    return tabla


def medir_agresividad(df: pd.DataFrame, tabla: pd.DataFrame) -> pd.DataFrame:
    # Paso 7 · Mide la agresividad con el freno máximo y el acelerador a la salida
    # Por qué: frenar más tarde no es frenar más fuerte; sin las dos medidas la conclusión se queda a
    #          medias y el CSV permite separarlas.
    # Salida esperada: "agresividad: freno máximo A 95–99 % frente a B 74–78 %"
    filas = []
    for (carrera, curva, piloto), grupo in df.groupby(["carrera", "curva", "piloto"]):
        salida = grupo[grupo["distancia_m"] == grupo["distancia_m"].min()].iloc[0]
        filas.append({"carrera": carrera, "curva": curva, "piloto": piloto,
                      "freno_max_pct": int(grupo["freno_pct"].max()),
                      "acelerador_salida_pct": int(salida["acelerador_pct"])})
    tabla_agr = pd.DataFrame(filas)
    resumen = tabla_agr.groupby("piloto").agg(freno_min=("freno_max_pct", "min"),
                                             freno_max=("freno_max_pct", "max"),
                                             acelerador_medio=("acelerador_salida_pct", "mean"))
    a, b = resumen.loc["A"], resumen.loc["B"]
    print(f"agresividad: freno máximo A {a['freno_min']}–{a['freno_max']} % frente a "
          f"B {b['freno_min']}–{b['freno_max']} % · acelerador a la salida "
          f"{a['acelerador_medio']:.1f} % y {b['acelerador_medio']:.1f} %")
    return tabla_agr


def documentar_contraste() -> None:
    # Paso 8 · Documenta el contraste real con OpenF1, sin descargar nada
    # Por qué: el CSV es sintético; la fuente real se cita con su licencia y su límite, y la consulta
    #          se deja escrita para que el lector la ejecute si quiere, no para fingir que está hecha.
    # Salida esperada: "contraste: OpenF1 documentado (sin clave, uso educativo) — sin descargar"
    # Si falla: PermissionError → la carpeta resultados/ no se puede escribir.
    RESULTADOS.mkdir(exist_ok=True)
    texto = (
        "# Contraste con OpenF1 (documentado, no ejecutado)\n\n"
        "- Fuente: OpenF1, <https://api.openf1.org/v1/>. Sin clave.\n"
        "- Licencia: uso educativo, aprendizaje personal, investigación y afición no comercial; OpenF1\n"
        "  declara no reclamar la propiedad de los datos, marcas ni retransmisiones de F1.\n"
        "- Consulta prevista: sesiones y vueltas de una carrera (`/v1/sessions` y `/v1/laps`) y sus\n"
        "  canales de coche (`/v1/car_data`) para situar frenada y velocidad.\n"
        "- Qué se puede comparar: que exista una frenada antes del ápice, en qué rango de velocidad y\n"
        "  si A y B difieren en el mismo sentido que en el CSV.\n"
        "- Qué no: la rejilla. Aquí hay diez muestras cada 20 m; OpenF1 publica otra frecuencia, así\n"
        "  que el contraste es cualitativo y no valida estas filas.\n"
        "- El CSV es sintético (CC0-1.0) y el portal no descarga nada en ejecución.\n"
    )
    (RESULTADOS / "contraste-openf1.md").write_text(texto, encoding="utf-8")
    print("contraste: OpenF1 documentado (sin clave, uso educativo) — sin descargar")


def escribir(puntos: pd.DataFrame, tabla: pd.DataFrame, agresividad: pd.DataFrame) -> None:
    # Paso 9 · Escribe las tablas del proyecto
    # Por qué: cada cifra del README sale de estos CSV; si no se escriben, el informe no se reproduce.
    # Salida esperada: "resultados: punto-frenada.csv, por-curva.csv, agresividad.csv, contraste-openf1.md"
    # Si falla: PermissionError → revisa permisos de resultados/.
    RESULTADOS.mkdir(exist_ok=True)
    puntos.to_csv(RESULTADOS / "punto-frenada.csv", index=False)
    tabla.to_csv(RESULTADOS / "por-curva.csv", index=False)
    agresividad.to_csv(RESULTADOS / "agresividad.csv", index=False)
    print("resultados: punto-frenada.csv, por-curva.csv, agresividad.csv, contraste-openf1.md")


def limpiar() -> None:
    # Paso 10 · Borra las tablas generadas
    # Por qué: el ZIP no lleva derivados; se regeneran con `python frenadas.py`.
    # Salida esperada: "limpiar: resultados/ generados borrados"
    # Si falla: PermissionError → cierra el programa que tenga abierto un CSV de resultados/.
    for nombre in GENERADOS:
        (RESULTADOS / nombre).unlink(missing_ok=True)
    print("limpiar: resultados/ generados borrados")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Frenada de dos pilotos en la misma curva (P62)")
    parser.add_argument("accion", nargs="?", default="todo", choices=["todo", "limpiar"])
    args = parser.parse_args(argv)
    if args.accion == "limpiar":
        limpiar()
        return 0
    try:
        df = cargar()
        declarar_grano(df)
        comprobar_misma_carrera(df)
        puntos = estimar_punto_frenada(df)
        medir_contaminacion(df, puntos)
        tabla = comparar_por_curva(df, puntos)
        agresividad = medir_agresividad(df, tabla)
        documentar_contraste()
        escribir(puntos, tabla, agresividad)
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con resultados a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
