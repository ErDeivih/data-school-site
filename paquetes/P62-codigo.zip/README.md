# P62 · Frenada de dos pilotos en la misma curva — código ejecutable

El proyecto completo sobre el CSV sintético de 1200 muestras de frenada: se declara el grano, se
comprueba que los 60 pares A–B son de la misma carrera y la misma curva, se estima el punto de
frenada desde `freno_pct` con la rejilla de 20 m, se separa la agresividad (freno máximo) del punto
de frenada y se documenta el contraste real con OpenF1 sin descargar nada. Es el código que acompaña
a la ficha
`../../fichas-ideas/p62-frenada-de-dos-pilotos.md`.

El resultado que enseña el proyecto: **A frena más tarde que B en los 60 pares** (una muestra de 20 m,
que en las curvas 5 y 6 son 40 m) y **también más fuerte** (freno máximo 89–99 % frente a 71–78 %);
y el umbral «freno > 0» cambia el punto de frenada en **71 de 120 grupos** porque hay muestras con
1–2 % de freno antes de la frenada real. Sin declarar ese umbral, la comparación se mueve sola.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas** (probado con 3.0.6). Se instala en un comando.
- Windows, Linux o macOS. No hace falta red: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p62-frenada-de-dos-pilotos/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide `pandas`. Licencia: pandas es BSD-3-Clause.

## Orden de ejecución

```powershell
python frenadas.py          # carga, grano, misma carrera, punto de frenada, comparación y tablas
python frenadas.py limpiar  # borra las tablas generadas y deja la carpeta como se descargó
```

La salida esperada de una ejecución es esta:

```text
datos: 1200 filas × 8 columnas · 120 grupos de 10 muestras · rejilla 210…30 m · sha256 ddddfeec…
grano: una fila = una muestra · 120 grupos (carrera, curva, piloto) × 10 muestras
misma carrera: 60 pares A–B en la misma carrera y curva · pares cruzados 0
punto de frenada (umbral 10 %): 120 grupos · de 110 a 210 m · resolución 20 m
contaminación: el umbral > 0 cambia el punto de frenada en 71 grupos
comparación: A frena más tarde que B en 60 de 60 pares
agresividad: freno máximo A 89–99 % frente a B 71–78 % · acelerador a la salida 10.2 % y 9.8 %
contraste: OpenF1 documentado (sin clave, uso educativo) — sin descargar
resultados: punto-frenada.csv, por-curva.csv, agresividad.csv, contraste-openf1.md
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula recuentos, rejilla, pares A–B, puntos de frenada, contaminación del umbral y
agresividad; comprueba que el punto de frenada cae en la rejilla de 20 m, que el sha256 del CSV es el
del catálogo y que la comparación no mezcla carreras. No usa red y no escribe nada. Termina en
`RESULTADO: VERDE` (código 0) con **19 comprobaciones**; la salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- [`datos-ejemplo/frenadas-f1.csv`](datos-ejemplo/frenadas-f1.csv): **1200 filas × 8 columnas**
  (`carrera`, `curva`, `piloto`, `distancia_m`, `velocidad_kmh`, `acelerador_pct`, `freno_pct`,
  `marcha`). 10 carreras × 6 curvas × 2 pilotos × 10 muestras; rejilla 210, 190, …, 30 m.
- sha256 del fichero:
  `ddddfeec43b9f59c2af11cb5756efef93ce4d2835a205a3869aa61c5822210e8`. Es copia literal de
  `datasets/csv/frenadas-f1.csv` del repositorio (manifiesto
  `datasets/datasets-nuevos-2026-11-05.json`), sintético, semilla fija y licencia **CC0-1.0**.

Basta con ese CSV: el proyecto se ejecuta sin descargar nada. Para usar datos propios, se copian en
`datos-ejemplo/` con las mismas columnas o se edita la constante `DATOS` de `frenadas.py`.

## Fuente real y licencia

- **OpenF1** (<https://api.openf1.org/v1/>): sin clave. Uso educativo, aprendizaje personal,
  investigación y afición no comercial; OpenF1 declara no reclamar la propiedad de los datos, marcas
  ni retransmisiones de F1. El código **no descarga**: deja documentada la consulta y el límite.
- El contraste es cualitativo: OpenF1 publica otra frecuencia, no esta rejilla de diez muestras cada
  20 m. El CSV es sintético y no sustituye telemetría oficial.
- `resultados/contraste-openf1.md` recoge la fuente, la licencia, la consulta prevista y qué se puede
  y no se puede comparar.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y validar | Rejilla, claves y recuentos de un panel largo | Pandas: fundamentos |
| 2 · Declarar el grano | Qué es una fila y qué identifica una vuelta | Pandas: agrupaciones y joins |
| 3 · Misma carrera y curva | Comparar en condiciones equivalentes | Tests no paramétricos |
| 4 · Punto de frenada | Estimar una magnitud con resolución declarada | Precisión y error numérico |
| 5 · Contaminación del umbral | Por qué «freno > 0» no es una frenada | Series temporales en pandas |
| 6 · Agresividad | Separar frenar tarde de frenar fuerte | Visualización estadística |
| 7 · Contraste real | Citar una API con licencia sin fingir la descarga | APIs y peticiones HTTP |

## Estructura

```text
codigo/
├── frenadas.py           # pipeline: carga, grano, estimación, comparación, contraste, tablas
├── verificar.py          # la puerta del proyecto (19 comprobaciones, sin red, sin escribir)
├── requirements.txt      # pandas
├── datos-ejemplo/
│   └── frenadas-f1.csv   # 1200 × 8 · CC0-1.0
└── resultados/
    └── ejemplo-salida.txt
```

Las tablas que escribe `python frenadas.py` (`punto-frenada.csv`, `por-curva.csv`,
`agresividad.csv`, `contraste-openf1.md`) no viajan en el ZIP: se regeneran.

## Fallos típicos

- **`ModuleNotFoundError: pandas`**: instala con `python -m pip install -r requirements.txt` usando el
  mismo intérprete con el que lanzas el pipeline.
- **`FALLO: la rejilla de distancias no es la del CSV`**: el fichero de `datos-ejemplo/` no es el del
  catálogo; compara el sha256 con el del README.
- **Punto de frenada en 210 m para todos**: has usado `freno_pct >= 0`; el umbral tiene que ser 10 %
  (o el que declares) y el umbral ingenuo se cuenta aparte.
- **Comparar curvas distintas**: la 4 se entra a 265 km/h y la 5 a 160; sin el filtro de la misma
  curva el resultado es una diferencia de escenario.
- **Presentar OpenF1 como si fueran estas filas**: el contraste es cualitativo, con otra frecuencia;
  el README y `contraste-openf1.md` lo dicen.
