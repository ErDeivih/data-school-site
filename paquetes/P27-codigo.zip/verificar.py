#!/usr/bin/env python3
"""Puerta del proyecto P27 (alerta de deriva del sensor).

Comprueba grano, baseline robusto, umbral, alertas, falsos positivos y turnos. Sin escribir en disco.
VERDE (0) o ROJO (1).
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import deriva

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "sensores-planta.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = deriva.leer(CSV)
    ok(len(filas) == 240, "el CSV tiene 240 lecturas")
    ok(len({f["hora"] for f in filas}) == 240, "las horas son únicas (0–239)")
    ok(sum(1 for f in filas if f["estado"] == "averia") == 18, "hay 18 lecturas de avería")
    ok(sum(1 for f in filas if f["estado"] != "averia") == 222, "hay 222 lecturas sanas")

    base = deriva.baseline(filas)
    ok(base["n"] == 222, "el baseline usa solo las 222 sanas")
    ok(round(base["mediana"], 2) == 69.64, "la mediana sana es 69,64 °C")
    ok(round(base["mad"], 3) == 4.035, "el MAD sano es 4,035 °C")
    ok(round(base["umbral"], 2) == 87.59, "el umbral es 87,59 °C")

    alertas_ = deriva.alertas(filas, base)
    ok(alertas_["marcadas"] == 18, "se marcan 18 alertas")
    ok(alertas_["averias"] == 18, "coinciden con las 18 averías")
    ok(alertas_["averias_marcadas"] == 18, "las 18 averías quedan marcadas")
    ok(alertas_["falsos_positivos"] == 0, "0 falsos positivos sobre las 222 sanas")

    ventanas = deriva.ventanas(filas, base)
    ok(len(ventanas) == 20, "hay 20 turnos de 12 horas")
    ok(ventanas[0]["alertas"] == 0, "el primer turno no alerta")
    ok(ventanas[12]["alertas"] == 6, "el turno 12 tiene 6 alertas")
    ok(ventanas[13]["alertas"] == 12, "el turno 13 tiene 12 alertas")
    ok(ventanas[13]["maximo"] == 94.13, "el máximo del turno 13 es 94,13 °C")

    try:
        deriva.z_robusto(70.0, {"mediana": 70.0, "mad": 0.0})
        ok(False, "un MAD 0 debería rechazarse")
    except ValueError:
        ok(True, "un MAD 0 se rechaza (no hay escala)")
    ok(round(deriva.z_robusto(70.0, base), 2) < 1, "una lectura normal tiene z robusto menor que 1")

    codigo = (AQUI / "deriva.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
