# P27 · Energía: de la lectura del sensor a la alerta de deriva

Paquete descargable de **Data School** para el proyecto P27. Incluye las lecturas de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python deriva.py
python verificar.py
```

`deriva.py` aprende el rango normal con la parte sana (mediana y MAD), fija un umbral robusto de 3σ,
marca las alertas y las resume por turnos de 12 horas. `verificar.py` sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/sensores-planta.csv`: **240 filas × 4 columnas** (una lectura por hora; temperatura,
  presión y estado `marcha/parada/averia`, con 18 lecturas de avería). Sintético y **CC0-1.0**; es el
  `sensores-planta` del catálogo de Data School.

## Salida esperada

```text
lecturas: 240 · sanas: 222 · mediana 69.64 · MAD 4.035
umbral: 87.59 °C (mediana + 3.0 × 1,4826 × MAD)
alertas: 18 · averías marcadas: 18/18 · falsos positivos: 0
turno 12 (12 lecturas): media 78.19 · máx 89.52 · alertas 6
turno 13 (12 lecturas): media 92.43 · máx 94.13 · alertas 12
límite: 240 horas sintéticas de un solo sensor; no sustituye al mantenimiento real.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Grano | `leer` exige 240 horas sin huecos y estados conocidos | ventanas y marcas de agua |
| 2 · Baseline sano | `baseline` usa mediana y MAD solo de marcha/parada | monitorización de drift |
| 3 · z robusto | `z_robusto` escala por 1,4826·MAD | outliers y detección |
| 4 · Alertas | `alertas` marca y cuenta falsos positivos | outliers y detección |
| 5 · Turnos | `ventanas` resume por bloques de 12 h | ventanas y marcas de agua |
| 6 · Publicar | `main` deja el umbral y el límite a la vista | monitorización de drift |

## Fallos típicos

- **`horas deben ser 0–239`**: falta una hora o está repetida; las ventanas se descuadran.
- **Umbral con media y desviación clásicas**: la avería contamina el baseline y la alerta no salta.
- **Muchos falsos positivos**: el umbral es demasiado bajo; el criterio exige 0 sobre la parte sana.
- **Mirar la lectura suelta y no el turno**: una alerta aislada no es una deriva.

## Límite

Son 240 horas sintéticas de un sensor. Enseñan a fijar un umbral y probar falsos positivos; no sustituyen
al mantenimiento real.
