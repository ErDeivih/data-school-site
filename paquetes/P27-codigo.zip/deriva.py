﻿"""P27 · Energía: de la lectura del sensor a la alerta de deriva.

Aprende el rango normal de temperatura a partir de la parte sana, fija un umbral robusto y avisa de las
lecturas que se salen. Comprueba los falsos positivos sobre la parte sana y resume por turnos. Sin
dependencias.
"""
from __future__ import annotations

import argparse
import csv
import statistics
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("hora", "temperatura", "presion", "estado")
ESTADOS = ("marcha", "parada", "averia")
Z_UMBRAL = 3.0
PESO_MAD = 1.4826
HORAS_TURNO = 12


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el grano: una lectura por hora y un estado conocido.
    # Por qué: una hora repetida o un estado nuevo invalida el baseline y las ventanas.
    # Salida esperada: 240 filas, horas 0–239 y tres estados.
    # Si falla: «columnas inesperadas», «hora repetida» o «estado desconocido».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 240:
        raise ValueError(f"se esperaban 240 lecturas, hay {len(filas)}")
    horas = [int(f["hora"]) for f in filas]
    if sorted(horas) != list(range(240)):
        raise ValueError("las horas deben ser 0–239 sin huecos ni repeticiones")
    if {f["estado"] for f in filas} - set(ESTADOS):
        raise ValueError("hay un estado desconocido")
    return filas


def baseline(filas: list[dict]) -> dict:
    # Paso 2 · Aprender el rango normal solo con la parte sana (marcha y parada).
    # Por qué: si el baseline incluyera la avería, la alerta se aprendería a sí misma.
    # Salida esperada: mediana y MAD de 222 lecturas sanas.
    # Si falla: no hay suficientes lecturas sanas.
    sanas = [float(f["temperatura"]) for f in filas if f["estado"] != "averia"]
    if len(sanas) < 50:
        raise ValueError("hacen falta al menos 50 lecturas sanas")
    mediana = statistics.median(sanas)
    mad = statistics.median(abs(x - mediana) for x in sanas)
    return {"n": len(sanas), "mediana": mediana, "mad": mad,
            "umbral": mediana + Z_UMBRAL * PESO_MAD * mad}


def z_robusto(valor: float, base: dict) -> float:
    # Paso 3 · Convertir una lectura en z robusto: (x − mediana) / (1,4826 · MAD).
    # Por qué: la media y la desviación clásicas se contaminan con la propia avería.
    # Salida esperada: una lectura sana queda cerca de 0; una de avería, muy por encima.
    # Si falla: el MAD es 0 (serie constante) y no hay escala.
    if base["mad"] == 0:
        raise ValueError("el MAD es 0: la serie sana es constante")
    return (valor - base["mediana"]) / (PESO_MAD * base["mad"])


def alertas(filas: list[dict], base: dict) -> dict:
    # Paso 4 · Marcar alertas y medir falsos positivos sobre la parte sana.
    # Por qué: una alerta que salta con el sensor sano no sirve; el criterio exige 0.
    # Salida esperada: 18 averías marcadas y 0 falsos positivos en 222 sanas.
    # Si falla: el umbral es demasiado bajo o el baseline está contaminado.
    averias = [f for f in filas if f["estado"] == "averia"]
    sanas = [f for f in filas if f["estado"] != "averia"]
    marcadas = [f for f in filas if z_robusto(float(f["temperatura"]), base) > Z_UMBRAL]
    falsos = [f for f in marcadas if f["estado"] != "averia"]
    return {"marcadas": len(marcadas), "averias": len(averias),
            "averias_marcadas": sum(1 for f in averias if f in marcadas),
            "falsos_positivos": len(falsos)}


def ventanas(filas: list[dict], base: dict) -> list[dict]:
    # Paso 5 · Resumir por turnos de 12 horas: media, máximo y si el turno alerta.
    # Por qué: la alerta se lee por turno, no por lectura suelta; así se ve la deriva.
    # Salida esperada: 20 turnos con su media y su recuento de alertas.
    # Si falla: las horas no cubren 0–239.
    grupos = defaultdict(list)
    for f in filas:
        grupos[int(f["hora"]) // HORAS_TURNO].append(f)
    tabla = []
    for turno in sorted(grupos):
        grupo = grupos[turno]
        temps = [float(f["temperatura"]) for f in grupo]
        alertas_turno = sum(1 for f in grupo if z_robusto(float(f["temperatura"]), base) > Z_UMBRAL)
        tabla.append({"turno": turno, "n": len(grupo), "media": round(statistics.mean(temps), 2),
                      "maximo": round(max(temps), 2), "alertas": alertas_turno})
    return tabla


def main() -> int:
    # Paso 6 · Publicar el umbral, las alertas y el límite de la serie.
    # Por qué: sin el umbral a la vista, una alerta no se puede revisar ni discutir.
    # Salida esperada: baseline, 18 alertas, 0 falsos positivos y tabla de turnos.
    # Si falla: revisa --csv o si el fichero es el del catálogo.
    parser = argparse.ArgumentParser(description="Alerta de deriva del sensor (P27)")
    parser.add_argument("--csv", default="datos-ejemplo/sensores-planta.csv")
    args = parser.parse_args()
    filas = leer(Path(args.csv))
    base = baseline(filas)
    alertas_ = alertas(filas, base)
    print(f"lecturas: {len(filas)} · sanas: {base['n']} · mediana {base['mediana']:.2f} · MAD {base['mad']:.3f}")
    print(f"umbral: {base['umbral']:.2f} °C (mediana + {Z_UMBRAL} × 1,4826 × MAD)")
    print(f"alertas: {alertas_['marcadas']} · averías marcadas: {alertas_['averias_marcadas']}/{alertas_['averias']} · falsos positivos: {alertas_['falsos_positivos']}")
    for turno in ventanas(filas, base):
        if turno["alertas"]:
            print(f"turno {turno['turno']:>2} ({turno['n']} lecturas): media {turno['media']:.2f} · máx {turno['maximo']:.2f} · alertas {turno['alertas']}")
    print("límite: 240 horas sintéticas de un solo sensor; no sustituye al mantenimiento real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
