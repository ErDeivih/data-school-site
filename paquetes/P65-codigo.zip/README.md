# P65 · Detectar regresiones antes de publicar un modelo

Paquete descargable de **Data School** para el proyecto P65. Incluye el CSV de ejemplo, el código
comentado paso a paso, el informe JSON y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es cómo se publica un modelo **sin romper la calidad**: entrenar dos
versiones sobre la misma partición reservada, comparar la precisión balanceada con un intervalo de
confianza por bootstrap y decidir con una tolerancia fijada **antes** de mirar el resultado. La
puerta aprueba, pide revisar o rechaza; no decide con una cifra suelta.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: regresión logística con descenso de gradiente implementada en el
  propio paquete. No hace falta `numpy` ni `scikit-learn`.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python gate.py --caso candidato
python verificar.py
```

Guardar el informe y probar los controles:

```bash
python gate.py --caso candidato --salida resultados/comparacion.json
python gate.py --caso identico     # 0 · aprueba
python gate.py --caso invertido    # 2 · rechaza
python gate.py --caso sin-id       # 3 · muestra incompleta
```

## Salida esperada

```text
caso: candidato · 59 clientes de prueba
precisión balanceada: referencia 0.651 · candidato 0.642 · diferencia -0.009
IC95 % de la diferencia: [-0.106, +0.082] · tolerancia 0.02
decisión: revisar (código de salida 1)
lectura: la puerta no mira una cifra suelta: exige el mismo test, la misma métrica y un intervalo;
si el intervalo cruza el umbral, pide revisar en vez de decidir por ruido.
límite: 200 clientes sintéticos y tres variables; no describe clientes reales ni sustituye a una
validación.
```

El informe completo está en `resultados/comparacion.json`; la salida de consola, en
`resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/clientes-churn.csv`: **200 filas × 5 columnas**. `id_cliente`, antigüedad, uso
  mensual, reclamaciones y baja (0/1); 200 clientes con id único.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `clientes-churn` del catálogo.
  No son clientes reales.
- `sha256` del fichero: `5290b89e3ecf746e378b01af2e73bb9e39a4297541e5ccbedae19bfc97a9839c`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida id, variables y clases | comparar sobre clientes distintos no es comparar |
| 2 · Partir | 70/30 estratificado con semilla fija | congelar la evaluación antes de entrenar |
| 3 · Entrenar | estandarización solo con entrenamiento + L2 | pipelines sin fuga de información |
| 4 · Predecir | misma partición para las dos versiones | comparación justa |
| 5 · Métrica | precisión balanceada por clase | el desbalanceo no premia ignorar la minoría |
| 6 · Bootstrap | IC95 % de la diferencia remuestreando por clase | decidir con incertidumbre |
| 7 · Puerta | aprobar / revisar / rechazar con tolerancia previa | publicar con un contrato |

## Las tres trampas que el código deja a la vista

1. **La partición no se toca entre versiones.** El código la congela con semilla 65 (141/59); si
   cada versión usa una partición distinta, la comparación mide la partición, no el modelo.
2. **Una diferencia de −0,009 no es una regresión demostrada.** El IC95 % va de −0,106 a +0,082:
   cruza el umbral, así que la puerta pide **revisar**, no aprobar ni rechazar por una cifra.
3. **El caso invertido se bloquea.** Con las predicciones dadas la vuelta, la diferencia es grande y
   negativa, y la puerta devuelve **rechazar** (código 2); el caso sin un id devuelve **error** (3)
   en vez de comparar muestras distintas.

## Fallos típicos

- **`ModuleNotFoundError: gate`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`**: el CSV no es el del catálogo.
- **`partición inesperada`**: se cambió la proporción o el CSV cambió de tamaño.
- **`El candidato no cubre la misma muestra`**: falta un cliente en las predicciones.
- **La decisión no cambia**: la tolerancia se fijó después de ver el intervalo (no es una puerta).
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P65-codigo/
├── gate.py                    # pasos 1–7: partición, modelo, bootstrap y decisión
├── verificar.py               # la puerta del proyecto: 23 comprobaciones
├── requirements.txt           # sin dependencias
├── datos-ejemplo/
│   └── clientes-churn.csv     # 200 × 5 · sintético, CC0-1.0
└── resultados/
    ├── comparacion.json       # informe reproducible de la comparación
    └── ejemplo-salida.txt     # la salida real de una ejecución
```

## Límite

Son 200 clientes sintéticos y tres variables: no describe clientes reales ni sustituye a una
validación con datos de producción. La regresión logística es deliberadamente simple para que el
paquete no dependa de librerías; el valor está en el **contrato de publicación** (misma partición,
misma métrica, intervalo y tolerancia previa), no en el modelo.
