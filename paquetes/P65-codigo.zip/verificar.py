#!/usr/bin/env python3
"""Puerta del proyecto P65 (detectar regresiones antes de publicar un modelo).

Comprueba partición congelada, métricas, intervalo bootstrap, las cuatro decisiones de la puerta y
la ausencia de red/claves. VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import gate

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "clientes-churn.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.3f} ≈ {esperado:.3f})")


def main() -> int:
    ids, x, y = gate.leer(CSV)
    ok(len(ids) == 200 and len(set(ids)) == 200, "el CSV tiene 200 clientes con id único")
    ok(len(x[0]) == 3 and set(y) == {0, 1}, "hay 3 variables y dos clases")

    entrenamiento, prueba = gate.partir(y)
    ok(len(entrenamiento) == 141 and len(prueba) == 59, "partición congelada 141/59")
    ok(all(y[i] in (0, 1) for i in prueba), "la prueba conserva las dos clases")
    ok(not set(entrenamiento) & set(prueba), "entrenamiento y prueba no se solapan")

    informe, codigo = gate.ejecutar("candidato", x, y, ids)
    ok(informe["clientes_evaluados"] == 59, "se evalúan los 59 clientes reservados")
    cerca(informe["precision_balanceada_referencia"], 0.651, 0.002, "precisión balanceada de referencia")
    cerca(informe["precision_balanceada_candidato"], 0.642, 0.002, "precisión balanceada del candidato")
    cerca(informe["diferencia"], -0.009, 0.002, "diferencia candidato − referencia")
    cerca(informe["intervalo_95"][0], -0.106, 0.004, "límite inferior del IC95 %")
    cerca(informe["intervalo_95"][1], 0.082, 0.004, "límite superior del IC95 %")
    ok(informe["decision"] == "revisar" and codigo == 1, "el candidato pide revisar (no decide por ruido)")

    identico, codigo_id = gate.ejecutar("identico", x, y, ids)
    ok(identico["diferencia"] == 0 and identico["decision"] == "aprobar" and codigo_id == 0,
       "el caso idéntico aprueba con diferencia 0")

    invertido, codigo_inv = gate.ejecutar("invertido", x, y, ids)
    ok(invertido["decision"] == "rechazar" and codigo_inv == 2, "el caso invertido bloquea la publicación")
    ok(invertido["diferencia"] < -0.30, "la diferencia del invertido es grande y negativa")

    try:
        gate.ejecutar("sin-id", x, y, ids)
        ok(False, "el caso sin-id debe lanzar un error")
    except ValueError as error:
        ok("no cubre la misma muestra" in str(error), "sin-id se detecta como muestra incompleta")

    informe_json = gate.json.dumps(informe, ensure_ascii=False, indent=1)
    for clave in ("precision_balanceada_referencia", "intervalo_95", "decision", "tolerancia"):
        ok(clave in informe_json, f"el informe JSON incluye {clave}")

    codigo_py = (AQUI / "gate.py").read_text(encoding="utf-8")
    ok("http://" not in codigo_py and "https://" not in codigo_py and "requests" not in codigo_py,
       "el código no hace peticiones de red")
    ok("sklearn" not in codigo_py and "numpy" not in codigo_py, "el código no necesita librerías externas")
    ok("api_key" not in codigo_py.lower() and "authorization" not in codigo_py.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
