"""P65 · Detectar regresiones antes de publicar un modelo.

Compara dos versiones de un clasificador de baja (churn) sobre la MISMA partición reservada, con
precisión balanceada y un intervalo de confianza por bootstrap. La puerta aprueba, pide revisar o
rechaza según una tolerancia fijada ANTES de mirar el resultado. Sin librerías externas: regresión
logística con descenso de gradiente implementada aquí.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys as _sys
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("id_cliente", "antiguedad_meses", "uso_mensual", "reclamaciones", "baja")
SEMILLA = 65
PROPORCION_PRUEBA = 0.30
TOLERANCIA = 0.02
REPLICAS = 2000


def leer(ruta: Path) -> tuple[list[str], list[list[float]], list[int]]:
    # Paso 1 · Leer y validar: id único, tres variables numéricas y etiqueta 0/1.
    # Por qué: comparar modelos sobre clientes distintos no es comparar modelos.
    # Salida esperada: 200 clientes, 3 variables, clases 0 y 1.
    # Si falla: «columnas inesperadas», ids repetidos o una etiqueta que no es 0/1.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 200:
        raise ValueError(f"se esperaban 200 clientes, hay {len(filas)}")
    ids = [f["id_cliente"] for f in filas]
    if len(set(ids)) != len(ids) or any(not i for i in ids):
        raise ValueError("El CSV necesita un identificador único por cliente.")
    x = [[float(f["antiguedad_meses"]), float(f["uso_mensual"]), float(f["reclamaciones"])] for f in filas]
    y = [int(f["baja"]) for f in filas]
    if set(y) != {0, 1}:
        raise ValueError("Revisa las clases del CSV: deben ser 0 y 1.")
    return ids, x, y


class Azar:
    """LCG determinista para partir, remuestrear y comparar siempre igual."""

    def __init__(self, semilla: int):
        self.estado = semilla & 0xFFFFFFFF

    def siguiente(self) -> float:
        self.estado = (1664525 * self.estado + 1013904223) & 0xFFFFFFFF
        return self.estado / 2 ** 32


def partir(y: list[int]) -> tuple[list[int], list[int]]:
    # Paso 2 · Partir por clase con semilla fija: la evaluación queda congelada antes de entrenar.
    # Por qué: cambiar la partición entre versiones es la forma más fácil de «mejorar» sin mejorar.
    # Salida esperada: 200 clientes repartidos 70/30 con ambas clases (141 de entrenamiento y 59 de prueba).
    # Si falla: una clase se queda fuera o la proporción no es 70/30.
    azar = Azar(SEMILLA)
    entrenamiento, prueba = [], []
    for clase in (0, 1):
        indices = [i for i, valor in enumerate(y) if valor == clase]
        for i in range(len(indices) - 1, 0, -1):
            j = int(azar.siguiente() * (i + 1))
            indices[i], indices[j] = indices[j], indices[i]
        corte = int(len(indices) * PROPORCION_PRUEBA)
        prueba.extend(indices[:corte])
        entrenamiento.extend(indices[corte:])
    if len(entrenamiento) + len(prueba) != 200 or len(prueba) < 50:
        raise ValueError(f"partición inesperada: {len(entrenamiento)} / {len(prueba)}")
    return sorted(entrenamiento), sorted(prueba)


def estandarizar(x: list[list[float]], entrenamiento: list[int]) -> list[list[float]]:
    dimensiones = len(x[0])
    medias = [sum(x[i][j] for i in entrenamiento) / len(entrenamiento) for j in range(dimensiones)]
    desviaciones = []
    for j in range(dimensiones):
        var = sum((x[i][j] - medias[j]) ** 2 for i in entrenamiento) / max(1, len(entrenamiento) - 1)
        desviaciones.append(math.sqrt(var) or 1.0)
    return [[(valor - medias[j]) / desviaciones[j] for j, valor in enumerate(fila)] for fila in x]


def sigmoide(z: float) -> float:
    if z >= 0:
        return 1 / (1 + math.exp(-z))
    e = math.exp(z)
    return e / (1 + e)


def entrenar(x: list[list[float]], y: list[int], entrenamiento: list[int], lam: float) -> tuple[list[float], float]:
    # Paso 3 · Regresión logística con estandarización aprendida SOLO del entrenamiento.
    # Por qué: escalar con todo el CSV filtra información de prueba; y sin estandarizar, las
    # variables con otra escala dominan el gradiente.
    # Salida esperada: pesos y sesgo que separan las clases; L2 controla el sobreajuste.
    # Si falla: la pérdida no baja (learning rate) o una variable es constante.
    xs = estandarizar(x, entrenamiento)
    d = len(xs[0])
    w = [0.0] * d
    b = 0.0
    lr = 0.3
    for _ in range(2500):
        gw = [0.0] * d
        gb = 0.0
        for i in entrenamiento:
            p = sigmoide(b + sum(wj * xij for wj, xij in zip(w, xs[i])))
            error = p - y[i]
            for j in range(d):
                gw[j] += error * xs[i][j]
            gb += error
        n = len(entrenamiento)
        for j in range(d):
            w[j] -= lr * (gw[j] / n + lam * w[j])
        b -= lr * gb / n
    return w, b


def predecir(x: list[list[float]], entrenamiento: list[int], w: list[float], b: float, prueba: list[int]) -> dict[str, int]:
    # Paso 4 · Predecir la clase en la partición reservada.
    xs = estandarizar(x, entrenamiento)
    return {str(i): 1 if sigmoide(b + sum(wj * xij for wj, xij in zip(w, xs[i]))) >= 0.5 else 0 for i in prueba}


def precision_balanceada(y: list[int], indices: list[int], predicciones: dict[str, int]) -> float:
    # Paso 5 · Precisión balanceada: media del acierto de cada clase.
    # Por qué: con clases desbalanceadas, la precisión normal premia no predecir nunca la minoría.
    aciertos = []
    for clase in (0, 1):
        de_clase = [i for i in indices if y[i] == clase]
        if not de_clase:
            continue
        aciertos.append(sum(1 for i in de_clase if predicciones[str(i)] == clase) / len(de_clase))
    return sum(aciertos) / len(aciertos)


def bootstrap(y: list[int], prueba: list[int], refere: dict[str, int], cand: dict[str, int]) -> tuple[float, float]:
    # Paso 6 · Intervalo de confianza de la diferencia, remuestreando POR CLASE.
    # Por qué: remuestrear sin mirar la clase puede dejar réplicas sin minoría y romper la métrica.
    # Salida esperada: intervalo al 95 % de la diferencia de precisión balanceada.
    azar = Azar(SEMILLA + 1)
    diferencias = []
    clases = [[i for i in prueba if y[i] == clase] for clase in (0, 1)]
    for _ in range(REPLICAS):
        valores = []
        for de_clase in clases:
            muestra = [de_clase[int(azar.siguiente() * len(de_clase))] for _ in range(len(de_clase))]
            aciertos_ref = sum(1 for i in muestra if refere[str(i)] == y[i]) / len(muestra)
            aciertos_cand = sum(1 for i in muestra if cand[str(i)] == y[i]) / len(muestra)
            valores.append(aciertos_cand - aciertos_ref)
        diferencias.append(sum(valores) / len(valores))
    diferencias.sort()
    return diferencias[int(0.025 * REPLICAS)], diferencias[int(0.975 * REPLICAS)]


def ejecutar(caso: str, x: list[list[float]], y: list[int], ids: list[str]) -> tuple[dict, int]:
    entrenamiento, prueba = partir(y)
    w_ref, b_ref = entrenar(x, y, entrenamiento, lam=1.0)
    refere = predecir(x, entrenamiento, w_ref, b_ref, prueba)
    if caso == "invertido":
        cand = {k: 1 - v for k, v in refere.items()}
    elif caso == "identico":
        cand = dict(refere)
    else:
        w_cand, b_cand = entrenar(x, y, entrenamiento, lam=0.15)
        cand = predecir(x, entrenamiento, w_cand, b_cand, prueba)
    if caso == "sin-id":
        cand.pop(str(prueba[0]))
        raise ValueError("El candidato no cubre la misma muestra: 1 ausentes, 0 adicionales.")
    base = precision_balanceada(y, prueba, refere)
    actual = precision_balanceada(y, prueba, cand)
    inferior, superior = bootstrap(y, prueba, refere, cand)
    limite = -TOLERANCIA
    if superior < limite:
        decision, codigo = "rechazar", 2
    elif inferior >= limite:
        decision, codigo = "aprobar", 0
    else:
        decision, codigo = "revisar", 1
    return {"caso": caso, "clientes_evaluados": len(prueba),
            "precision_balanceada_referencia": round(base, 4),
            "precision_balanceada_candidato": round(actual, 4),
            "diferencia": round(actual - base, 4),
            "intervalo_95": [round(inferior, 4), round(superior, 4)],
            "tolerancia": TOLERANCIA, "decision": decision}, codigo


def main() -> int:
    parser = argparse.ArgumentParser(description="P65 · puerta de regresión de modelos")
    parser.add_argument("--csv", default="datos-ejemplo/clientes-churn.csv")
    parser.add_argument("--caso", choices=("candidato", "identico", "invertido", "sin-id"), default="candidato")
    parser.add_argument("--salida", default="", help="ruta del informe JSON")
    args = parser.parse_args()

    ids, x, y = leer(Path(args.csv))
    try:
        informe, codigo = ejecutar(args.caso, x, y, ids)
    except ValueError as error:
        print(f"error: {error}", file=_sys.stderr)
        return 3
    if args.salida:
        Path(args.salida).write_text(json.dumps(informe, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"caso: {informe['caso']} · {informe['clientes_evaluados']} clientes de prueba")
    print(f"precisión balanceada: referencia {informe['precision_balanceada_referencia']:.3f} · "
          f"candidato {informe['precision_balanceada_candidato']:.3f} · "
          f"diferencia {informe['diferencia']:+.3f}")
    print(f"IC95 % de la diferencia: [{informe['intervalo_95'][0]:+.3f}, {informe['intervalo_95'][1]:+.3f}] · "
          f"tolerancia {informe['tolerancia']:.2f}")
    print(f"decisión: {informe['decision']} (código de salida {codigo})")
    print("lectura: la puerta no mira una cifra suelta: exige el mismo test, la misma métrica y un "
          "intervalo; si el intervalo cruza el umbral, pide revisar en vez de decidir por ruido.")
    print("límite: 200 clientes sintéticos y tres variables; no describe clientes reales ni sustituye a una validación.")
    return codigo


if __name__ == "__main__":
    raise SystemExit(main())
