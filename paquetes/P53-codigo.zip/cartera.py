#!/usr/bin/env python3
"""P53 · Dashboard de cartera: asignación, riesgo y benchmark — código ejecutable.

Construye la serie de riqueza de cinco acciones y un índice, define una cartera con pesos que suman 1,
mide volatilidad, drawdown y Sharpe, la compara con el benchmark y genera un panel HTML con la lectura
de qué activo aporta. Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal de datasets/csv/):
    datos-ejemplo/cartera-acciones.csv  (360 filas × 3 columnas)

Uso:
    python cartera.py            # calcula, escribe resultados/ y el panel
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
INDICE = "indice"
ACCIONES = ["accion-a", "accion-b", "accion-c", "accion-d", "accion-e"]
# Pesos equiponderados declarados. El CSV no trae pesos: se eligen y se justifican con este supuesto.
PESOS = {activo: 1 / len(ACCIONES) for activo in ACCIONES}
# Tasa libre de riesgo declarada: 0 % para el Sharpe. El CSV no trae tipos; el proyecto real puede
# tomar el tipo de FRED y se documenta en el README.
TASA_LIBRE_RIESGO = 0.0


# Paso 1 · Carga el panel y comprueba su forma
# Por qué: un panel con un mes o un activo que falta deja huecos en la matriz y la riqueza se calcula
#          sobre una serie rota; se comprueba antes de pivotar.
# Salida esperada: "panel: 360 filas · 60 meses · 6 activos"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_panel() -> pd.DataFrame:
    ruta = DATOS / "cartera-acciones.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta, parse_dates=["mes"])
    print(
        f"panel: {len(df)} filas · {df['mes'].nunique()} meses · {df['activo'].nunique()} activos"
    )
    return df


# Paso 2 · Pivota a una matriz 60 × 6 y comprueba que no quedan huecos
# Por qué: con una fila por mes y activo, operar exige la matriz ancha; un hueco convertido en 0
#          inventaría un mes de retorno nulo y falsearía la volatilidad.
# Salida esperada: "matriz: 60 meses × 6 activos · 0 huecos"
# Si falla: huecos > 0 → falta una combinación (mes, activo) en el CSV.
def pivotar(panel: pd.DataFrame) -> dict:
    matriz = panel.pivot(index="mes", columns="activo", values="retorno").sort_index()
    huecos = int(matriz.isna().sum().sum())
    claves_duplicadas = int(panel.duplicated(["mes", "activo"]).sum())
    resultado = {"matriz": matriz, "huecos": huecos, "claves_duplicadas": claves_duplicadas}
    print(f"matriz: {matriz.shape[0]} meses × {matriz.shape[1]} activos · {huecos} huecos")
    return resultado


# Paso 3 · Construye la riqueza acumulada desde los retornos
# Por qué: el CSV no trae precios; la riqueza es el producto acumulado de (1 + retorno). Sumar retornos
#          mensuales no da el retorno total, y confundirlo es el error clásico de esta serie.
# Salida esperada: "riqueza: índice 1.391 · cartera 1.565 (retorno total 56.5 %)"
# Si falla: riqueza negativa o NaN → hay un retorno menor que −100 % o un hueco.
def construir_riqueza(matriz: pd.DataFrame) -> pd.DataFrame:
    riqueza = (1 + matriz).cumprod()
    print(
        f"riqueza: índice {riqueza[INDICE].iloc[-1]:.3f} · media de las 5 acciones "
        f"{riqueza[ACCIONES].mean(axis=1).iloc[-1]:.3f}"
    )
    return riqueza


# Paso 4 · Define los pesos y comprueba que suman 1
# Por qué: la suma de pesos es la comprobación automática del criterio de la ficha; si no suma 1, la
#          volatilidad y el Sharpe de la cartera no corresponden a ningún capital real.
# Salida esperada: "pesos: 5 activos · suma 1.0000"
# Si falla: la suma no es 1 → revisa el reparto, no lo normalices a escondidas.
def pesos_cartera() -> pd.DataFrame:
    tabla = pd.DataFrame({"activo": list(PESOS), "peso": list(PESOS.values())})
    suma = float(tabla["peso"].sum())
    print(f"pesos: {len(tabla)} activos · suma {suma:.4f}")
    return tabla


def serie_cartera(matriz: pd.DataFrame) -> pd.Series:
    """Retorno mensual de la cartera como media ponderada de los retornos de las cinco acciones."""
    return sum(matriz[activo] * peso for activo, peso in PESOS.items())


# Paso 5 · Mide volatilidad, drawdown y Sharpe sobre la riqueza
# Por qué: el drawdown se mide sobre la riqueza, no sobre la media de los retornos; y el Sharpe necesita
#          una tasa libre de riesgo declarada. Con datos mensuales, el drawdown es una cota.
# Salida esperada: "riesgo cartera: anualizado 10.1% · volatilidad 9.4% · drawdown 18.1% · Sharpe 1.07"
# Si falla: volatilidad 0 → la serie es constante; revisa la columna de retorno.
def metricas(serie: pd.Series, tasa_libre_riesgo: float = TASA_LIBRE_RIESGO) -> dict:
    riqueza = (1 + serie).cumprod()
    meses = len(serie)
    retorno_anualizado = float(riqueza.iloc[-1] ** (12 / meses) - 1)
    volatilidad_anual = float(serie.std() * np.sqrt(12))
    pico = riqueza.cummax()
    drawdown = 1 - riqueza / pico
    resultado = {
        "retorno_anualizado": retorno_anualizado,
        "volatilidad_anual": volatilidad_anual,
        "drawdown_maximo": float(drawdown.max()),
        "sharpe": (retorno_anualizado - tasa_libre_riesgo) / volatilidad_anual,
        "meses": meses,
        "riqueza_final": float(riqueza.iloc[-1]),
        "serie_riqueza": riqueza,
        "serie_drawdown": drawdown,
    }
    return resultado


# Paso 6 · Compara la cartera con el índice en la misma ventana
# Por qué: comparar con convenciones distintas no dice nada; se usan los mismos 60 meses y las mismas
#          fórmulas. Beta y alfa separan lo que explica el mercado de lo que es propio de la cartera.
# Salida esperada: "benchmark: cartera 56.5 % vs índice 39.1 % · beta 0.61 · alfa mensual 0.20 %"
# Si falla: ventanas de distinto tamaño → revisa la matriz pivotada.
def comparar_benchmark(matriz: pd.DataFrame, cartera: pd.Series) -> dict:
    indice = matriz[INDICE]
    beta = float(np.cov(cartera, indice, ddof=1)[0, 1] / np.var(indice, ddof=1))
    alfa_mensual = float(cartera.mean() - beta * indice.mean())
    metricas_cartera = metricas(cartera)
    metricas_indice = metricas(indice)
    resumen = {
        "beta": beta,
        "alfa_mensual": alfa_mensual,
        "alfa_anualizado": alfa_mensual * 12,
        "cartera": metricas_cartera,
        "indice": metricas_indice,
    }
    print(
        f"benchmark: cartera {metricas_cartera['retorno_anualizado']:.1%} vs índice "
        f"{metricas_indice['retorno_anualizado']:.1%} · beta {beta:.2f} · alfa mensual {alfa_mensual:.2%}"
    )
    return resumen


# Paso 7 · Calcula qué aporta cada activo
# Por qué: un panel de cartera tiene que responder «qué aporta»; la aportación combina el peso con el
#          retorno del activo y la correlación con el índice, sin presentarlo como predicción.
# Salida esperada: "aportación: accion-e lidera con 0.184 · correlación con el índice 0.42"
# Si falla: un activo sin correlación → revisa que el pivote tenga las seis columnas.
def aportacion_activos(matriz: pd.DataFrame) -> pd.DataFrame:
    indice = matriz[INDICE]
    filas = []
    for activo in ACCIONES:
        riqueza = (1 + matriz[activo]).cumprod()
        retorno_anualizado = float(riqueza.iloc[-1] ** (12 / len(matriz)) - 1)
        filas.append(
            {
                "activo": activo,
                "peso": PESOS[activo],
                "retorno_anualizado": retorno_anualizado,
                "aportacion": PESOS[activo] * retorno_anualizado,
                "correlacion_indice": float(np.corrcoef(matriz[activo], indice)[0, 1]),
            }
        )
    tabla = pd.DataFrame(filas).sort_values("aportacion", ascending=False).reset_index(drop=True)
    primero = tabla.iloc[0]
    print(
        f"aportación: {primero['activo']} lidera con {primero['aportacion']:.3f} · "
        f"correlación con el índice {primero['correlacion_indice']:.2f}"
    )
    return tabla


def panel_html(
    pesos: pd.DataFrame,
    aportacion: pd.DataFrame,
    comparacion: dict,
) -> str:
    """Devuelve el panel como HTML autocontenido; main() lo escribe y verificar.py lo comprueba."""
    cartera = comparacion["cartera"]
    indice = comparacion["indice"]
    filas_pesos = "".join(
        f"<tr><td>{fila['activo']}</td><td>{fila['peso']:.2f}</td></tr>" for _, fila in pesos.iterrows()
    )
    filas_aportacion = "".join(
        f"<tr><td>{fila['activo']}</td><td>{fila['peso']:.2f}</td><td>{fila['retorno_anualizado']:.1%}</td>"
        f"<td>{fila['aportacion']:.3f}</td><td>{fila['correlacion_indice']:.2f}</td></tr>"
        for _, fila in aportacion.iterrows()
    )
    return f"""<!doctype html>
<html lang="es"><head><meta charset="utf-8"><title>P53 · Panel de cartera</title>
<style>body{{font-family:system-ui,sans-serif;max-width:760px;margin:2rem auto;color:#1a202c}}
table{{border-collapse:collapse;width:100%;margin:.5rem 0 1.5rem}}
th,td{{border:1px solid #cbd5e0;padding:.3rem .5rem;text-align:left}}
th{{background:#edf2f7}}.aviso{{background:#fffbea;border-left:4px solid #d69e2e;padding:.6rem}}</style>
</head><body>
<h1>P53 · Dashboard de cartera</h1>
<h2>Asignación</h2><table><tr><th>Activo</th><th>Peso</th></tr>{filas_pesos}</table>
<p>Suma de pesos: {pesos['peso'].sum():.4f}</p>
<h2>Riesgo</h2><table>
<tr><th>Métrica</th><th>Cartera</th><th>Índice</th></tr>
<tr><td>Retorno anualizado</td><td>{cartera['retorno_anualizado']:.1%}</td><td>{indice['retorno_anualizado']:.1%}</td></tr>
<tr><td>Volatilidad anual</td><td>{cartera['volatilidad_anual']:.1%}</td><td>{indice['volatilidad_anual']:.1%}</td></tr>
<tr><td>Drawdown máximo</td><td>{cartera['drawdown_maximo']:.1%}</td><td>{indice['drawdown_maximo']:.1%}</td></tr>
<tr><td>Sharpe (tasa 0 % declarada)</td><td>{cartera['sharpe']:.2f}</td><td>{indice['sharpe']:.2f}</td></tr>
<tr><td>Beta frente al índice</td><td>{comparacion['beta']:.2f}</td><td>1.00</td></tr>
<tr><td>Alfa mensual</td><td>{comparacion['alfa_mensual']:.2%}</td><td>0.00 %</td></tr>
</table>
<h2>Aportación por activo</h2>
<table><tr><th>Activo</th><th>Peso</th><th>Retorno anual</th><th>Aportación</th><th>Correlación</th></tr>
{filas_aportacion}</table>
<h2>Lectura</h2><p>La cartera termina en {cartera['retorno_anualizado']:.1%} anual frente al {indice['retorno_anualizado']:.1%} del índice,
con más volatilidad ({cartera['volatilidad_anual']:.1%} frente a {indice['volatilidad_anual']:.1%}) y más drawdown
({cartera['drawdown_maximo']:.1%} frente a {indice['drawdown_maximo']:.1%}). El beta de {comparacion['beta']:.2f} indica que el
índice explica muy poco de la cartera en esta muestra: el alfa no es concluyente y no se presenta como habilidad.
Los pesos son equiponderados: un supuesto, no una recomendación.</p>
<p class="aviso"><strong>Límite:</strong> el panel es sintético (CC0-1.0, 60 meses) y no es una
recomendación de inversión. El drawdown mensual es una cota del real; el Sharpe usa una tasa libre de
riesgo del 0 % declarada.</p>
</body></html>
"""


def texto_lectura(pesos: pd.DataFrame, aportacion: pd.DataFrame, comparacion: dict) -> str:
    cartera, indice = comparacion["cartera"], comparacion["indice"]
    peor = aportacion.iloc[-1]
    mejor = aportacion.iloc[0]
    return "\n".join(
        [
            "# P53 · Lectura del panel de cartera",
            "",
            f"- Pesos: cinco acciones equiponderadas; suma {pesos['peso'].sum():.4f}.",
            f"- Cartera: {cartera['retorno_anualizado']:.1%} anual, volatilidad {cartera['volatilidad_anual']:.1%}, "
            f"drawdown máximo {cartera['drawdown_maximo']:.1%} y Sharpe {cartera['sharpe']:.2f}.",
            f"- Índice: {indice['retorno_anualizado']:.1%} anual, volatilidad {indice['volatilidad_anual']:.1%}, "
            f"drawdown máximo {indice['drawdown_maximo']:.1%}.",
            f"- Beta de la cartera frente al índice: {comparacion['beta']:.2f}; alfa mensual "
            f"{comparacion['alfa_mensual']:.2%} (estimación in-sample, no predicción). El beta tan bajo "
            "indica que el índice apenas explica la cartera en esta muestra: la comparación de alfa no "
            "es concluyente.",
            f"- Las dos series terminan en negativo ({cartera['retorno_anualizado']:.1%} y "
            f"{indice['retorno_anualizado']:.1%} anual): batir al índice aquí significa caer algo menos, "
            "no ganar dinero.",
            f"- Más aporta {mejor['activo']} ({mejor['aportacion']:.3f}); menos aporta {peor['activo']} "
            f"({peor['aportacion']:.3f}).",
            "- Límite: retornos sintéticos de un factor común más ruido; 60 meses no son una promesa y "
            "el drawdown mensual es una cota, no el máximo intradía.",
            "",
        ]
    )


def main() -> int:
    panel = cargar_panel()
    pivotado = pivotar(panel)
    matriz = pivotado["matriz"]
    construir_riqueza(matriz)
    pesos = pesos_cartera()
    cartera = serie_cartera(matriz)
    comparacion = comparar_benchmark(matriz, cartera)
    aportacion = aportacion_activos(matriz)
    RESULTADOS.mkdir(exist_ok=True)
    pesos.to_csv(RESULTADOS / "pesos.csv", index=False)
    aportacion.to_csv(RESULTADOS / "aportacion.csv", index=False)
    pd.DataFrame(
        [
            {"metrica": "retorno_anualizado", "cartera": comparacion["cartera"]["retorno_anualizado"], "indice": comparacion["indice"]["retorno_anualizado"]},
            {"metrica": "volatilidad_anual", "cartera": comparacion["cartera"]["volatilidad_anual"], "indice": comparacion["indice"]["volatilidad_anual"]},
            {"metrica": "drawdown_maximo", "cartera": comparacion["cartera"]["drawdown_maximo"], "indice": comparacion["indice"]["drawdown_maximo"]},
            {"metrica": "sharpe", "cartera": comparacion["cartera"]["sharpe"], "indice": comparacion["indice"]["sharpe"]},
        ]
    ).to_csv(RESULTADOS / "riesgo.csv", index=False)
    (RESULTADOS / "panel.html").write_text(panel_html(pesos, aportacion, comparacion), encoding="utf-8")
    (RESULTADOS / "lectura.md").write_text(texto_lectura(pesos, aportacion, comparacion), encoding="utf-8")
    print(f"escrito: {RESULTADOS / 'panel.html'} · lectura.md · pesos.csv · aportacion.csv · riesgo.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
