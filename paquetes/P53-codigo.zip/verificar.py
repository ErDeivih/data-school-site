#!/usr/bin/env python3
"""Puerta del proyecto P53 · dashboard de cartera: asignación, riesgo y benchmark.

Recalcula la matriz del panel, la riqueza, los pesos, la volatilidad, el drawdown, el Sharpe, el beta y
el alfa, y comprueba el panel HTML generado. No usa red y **no escribe ficheros**: solo calcula y saca
conclusiones por stdout.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import cartera

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P53 · dashboard de cartera ==")

    # Paso 1 · Comprueba el panel antes de pivotar
    # Por qué: 60 meses × 6 activos es la forma que promete el README; un hueco o una clave repetida
    #          rompe la riqueza y la comparación con el índice.
    # Salida esperada: "panel: 360 filas · 60 meses · 6 activos"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    panel = cartera.cargar_panel()
    pivotado = cartera.pivotar(panel)
    ok((len(panel), pivotado["matriz"].shape) == (360, (60, 6)), "panel: 360 filas · 60 meses · 6 activos")
    ok(pivotado["huecos"] == 0 and pivotado["claves_duplicadas"] == 0, "claves (mes, activo) únicas y sin huecos")
    matriz = pivotado["matriz"]
    ok(set(matriz.columns) == {cartera.INDICE, *cartera.ACCIONES}, f"activos: {sorted(matriz.columns)}")
    ok(bool(((matriz >= -1) & (matriz <= 1)).all().all()), "todos los retornos están en tanto por uno dentro de [−1, 1]")

    # Paso 2 · Recalcula la riqueza y comprueba que el retorno total es producto, no suma
    # Por qué: sumar retornos mensuales no da el retorno total; la riqueza se compone con prod(1 + r).
    # Salida esperada: "índice: riqueza 0.9352 · retorno total -6.48 %"
    # Si falla: riqueza negativa o distinta del producto → hay un retorno imposible.
    riqueza = cartera.construir_riqueza(matriz)
    ok(abs(riqueza[cartera.INDICE].iloc[-1] - 0.935217) < 1e-6, f"índice: riqueza final {riqueza[cartera.INDICE].iloc[-1]:.6f}")
    total_producto = float((1 + matriz[cartera.INDICE]).prod() - 1)
    total_suma = float(matriz[cartera.INDICE].sum())
    ok(abs((1 + total_producto) - riqueza[cartera.INDICE].iloc[-1]) < 1e-12, "la riqueza final es prod(1 + retorno)")
    ok(abs(total_producto - total_suma) > 1e-4, "el retorno total se compone (producto), no se suma")

    # Paso 3 · Comprueba los pesos
    # Por qué: la suma de pesos es el criterio de terminado del catálogo; se exige exactamente 1.
    # Salida esperada: "pesos: 5 activos · suma 1.0000"
    # Si falla: la suma no es 1 → hay capital sin asignar o de más.
    pesos = cartera.pesos_cartera()
    ok(len(pesos) == 5 and abs(float(pesos["peso"].sum()) - 1.0) < 1e-12, f"la suma de pesos es {pesos['peso'].sum():.4f}")
    ok(bool(np.allclose(pesos["peso"].to_numpy(), 0.2)), "los cinco pesos son equiponderados (0,2 cada uno)")

    # Paso 4 · Recalcula la serie de la cartera y sus métricas de riesgo
    # Por qué: volatilidad, drawdown y Sharpe son afirmaciones; se reconstruyen desde la matriz y la
    #          riqueza, y el drawdown se mide sobre la riqueza.
    # Salida esperada: "cartera: -0.89 % anual · vol 8.38 % · drawdown 19.18 % · Sharpe -0.11"
    # Si falla: drawdown distinto → se calculó sobre retornos y no sobre riqueza.
    serie = cartera.serie_cartera(matriz)
    recalculada = sum(matriz[activo] * peso for activo, peso in cartera.PESOS.items())
    ok(bool(np.allclose(serie.to_numpy(), recalculada.to_numpy())), "la cartera es la media ponderada de los retornos")
    metricas_cartera = cartera.metricas(serie)
    ok(
        abs(metricas_cartera["retorno_anualizado"] + 0.008896) < 1e-6
        and abs(metricas_cartera["volatilidad_anual"] - 0.083829) < 1e-6,
        f"cartera: {metricas_cartera['retorno_anualizado']:.2%} anual · volatilidad {metricas_cartera['volatilidad_anual']:.2%}",
    )
    riqueza_cartera = (1 + serie).cumprod()
    drawdown_recalculado = float((1 - riqueza_cartera / riqueza_cartera.cummax()).max())
    ok(
        abs(metricas_cartera["drawdown_maximo"] - drawdown_recalculado) < 1e-12
        and abs(metricas_cartera["drawdown_maximo"] - 0.191789) < 1e-6,
        f"drawdown máximo sobre la riqueza: {metricas_cartera['drawdown_maximo']:.2%}",
    )
    ok(abs(metricas_cartera["sharpe"] + 0.106122) < 1e-6, f"Sharpe con tasa 0 % declarada: {metricas_cartera['sharpe']:.2f}")
    ok(cartera.TASA_LIBRE_RIESGO == 0.0, "la tasa libre de riesgo del Sharpe está declarada (0 %)")

    # Paso 5 · Recalcula la comparación con el índice, el beta y el alfa
    # Por qué: la comparación solo vale con la misma ventana y la misma convención; beta y alfa se
    #          reconstruyen desde la covarianza para no publicar un número sin fórmula.
    # Salida esperada: "comparación: índice -1.33 % · beta 0.02 · alfa mensual -0.04 %"
    # Si falla: beta distinto → la covarianza se calculó con otra serie o con otra frecuencia.
    comparacion = cartera.comparar_benchmark(matriz, serie)
    ok(
        abs(comparacion["indice"]["retorno_anualizado"] + 0.013306) < 1e-6
        and abs(comparacion["indice"]["volatilidad_anual"] - 0.066633) < 1e-6,
        f"índice: {comparacion['indice']['retorno_anualizado']:.2%} anual · volatilidad {comparacion['indice']['volatilidad_anual']:.2%}",
    )
    beta_recalculado = float(np.cov(serie, matriz[cartera.INDICE], ddof=1)[0, 1] / np.var(matriz[cartera.INDICE], ddof=1))
    ok(
        abs(comparacion["beta"] - beta_recalculado) < 1e-12 and abs(comparacion["beta"] - 0.016356) < 1e-6,
        f"beta frente al índice: {comparacion['beta']:.4f}",
    )
    alfa_recalculado = float(serie.mean() - comparacion["beta"] * matriz[cartera.INDICE].mean())
    ok(abs(comparacion["alfa_mensual"] - alfa_recalculado) < 1e-12, f"alfa mensual: {comparacion['alfa_mensual']:.4%}")
    ok(comparacion["cartera"]["meses"] == comparacion["indice"]["meses"] == 60, "cartera e índice se comparan con los mismos 60 meses")

    # Paso 6 · Comprueba la aportación por activo y el panel generado
    # Por qué: el panel debe mostrar asignación, riesgo, benchmark y lectura; si falta una pieza, el
    #          entregable no cumple el criterio del catálogo.
    # Salida esperada: "panel: asignación, riesgo, benchmark y lectura presentes"
    # Si falla: falta una sección del HTML o la aportación no suma cinco activos.
    aportacion = cartera.aportacion_activos(matriz)
    ok(len(aportacion) == 5, f"aportación: {len(aportacion)} activos")
    ok(
        aportacion.iloc[0]["activo"] == "accion-e" and abs(aportacion.iloc[0]["aportacion"] - 0.018580) < 1e-5,
        f"más aporta {aportacion.iloc[0]['activo']}: {aportacion.iloc[0]['aportacion']:.4f}",
    )
    ok(
        bool(((aportacion["correlacion_indice"] >= -1) & (aportacion["correlacion_indice"] <= 1)).all()),
        "las correlaciones con el índice están en [−1, 1]",
    )
    html = cartera.panel_html(pesos, aportacion, comparacion)
    ok(
        all(texto in html for texto in ("Asignación", "Riesgo", "Aportación", "Lectura", "Límite")),
        "el panel tiene asignación, riesgo, aportación, lectura y límite",
    )
    ok("Suma de pesos: 1.0000" in html and "19.2%" in html, "el panel enseña la suma de pesos y el drawdown de la cartera")
    lectura = cartera.texto_lectura(pesos, aportacion, comparacion)
    ok("no es una recomendación" in lectura or "no una recomendación" in html, "el panel no se presenta como recomendación")
    ok("Límite" in lectura and "beta tan bajo" in lectura, "la lectura declara el límite y el beta bajo")

    # Paso 7 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (cartera.RAIZ / "cartera.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
