# P53 · Dashboard de cartera: asignación, riesgo y benchmark — código ejecutable

Construye la serie de riqueza de cinco acciones y un índice, define una cartera equiponderada, mide
volatilidad, drawdown y Sharpe, la compara con el benchmark y genera un **panel HTML** con la asignación,
el riesgo, la aportación de cada activo y la lectura. Es el código que acompaña a la ficha
`../../fichas-ideas/p53-dashboard-de-cartera.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** (BSD-3-Clause) y **numpy >= 1.26** (BSD-3-Clause). El panel es HTML estático: no
  necesita Streamlit ni servidor.
- Windows, Linux o macOS: sin red.

## Instalación

```powershell
cd proyectos/p53-dashboard-de-cartera/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python cartera.py
```

Recorre los pasos, imprime una línea por paso y escribe en `resultados/` los ficheros `pesos.csv`,
`aportacion.csv`, `riesgo.csv`, `lectura.md` y `panel.html`. El panel se abre en el navegador sin
servidor (`start resultados/panel.html` en Windows). Los generados no viajan en el ZIP: solo
`ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: 360 filas · 60 meses · 6 activos sin huecos, la
riqueza como producto acumulado (índice 0,9352), los cinco pesos que suman exactamente 1, la volatilidad
anual (8,38 %), el drawdown máximo sobre la riqueza (19,18 %), el Sharpe con tasa 0 % declarada
(−0,11), el beta frente al índice (0,02), el alfa mensual (−0,04 %) y las cinco secciones del panel.
Termina en `RESULTADO: VERDE` (0) o `RESULTADO: ROJO` (1). No usa red. La salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/cartera-acciones.csv`: **360 filas × 3 columnas** (`mes`, `activo`, `retorno`).
  60 meses × 6 activos (`indice`, `accion-a`…`accion-e`). `retorno` está en **tanto por uno**; no hay
  columna de precios: la riqueza se construye como `prod(1 + retorno)`.
- **Sintético, determinista y CC0-1.0**: copia literal de `datasets/csv/`, con
  `sha256:62ccc9a7355a27559024f7e4b725792d2be58a379fad4b4740a8a6fd25eacd51`; tamaño y columnas en
  `datasets.json`.
- El CSV **no trae** pesos, precios, inflación, tipos, dividendos, comisiones ni capital inicial: los
  pesos y la tasa libre de riesgo son supuestos declarados.

## Fuente real y licencia

- **Precios reales:** `alpha-vantage` (<https://www.alphavantage.co/query>), clave gratuita, EULA de uso
  personal y no comercial; su FAQ da peticiones ilimitadas a proyectos open source o educativos
  verificados. Sustituye al CSV para repetir el panel con activos reales.
- **Tasa libre de riesgo:** `fred` (<https://api.stlouisfed.org/fred/>), clave gratuita; los términos de
  uso no alteran los derechos de las series, que pueden ser de terceros: respeta las condiciones de cada
  serie. Aquí el Sharpe usa una tasa 0 % **declarada** para poder ejecutar sin red.
- Dependencias: pandas BSD-3-Clause, numpy BSD-3-Clause.

## Supuestos declarados

- **Pesos equiponderados** (0,2 por acción, suma 1). El CSV no trae pesos; el reparto es una decisión
  escrita, no un resultado.
- **Tasa libre de riesgo 0 %** para el Sharpe. El CSV no trae tipos; el proyecto real puede tomar el
  tipo de FRED y se documenta en el README.
- **Anualización mensual:** retorno compuesto `(1 + r)^12 − 1` y volatilidad `σ_mensual × √12`. Se
  declara en cada tabla.
- **Drawdown sobre la riqueza acumulada**; con datos mensuales es una **cota** de la caída real.
- **Beta y alfa in-sample** contra el índice, con 60 meses: estimación, no predicción. En esta muestra
  el índice apenas correlaciona con las acciones, así que el beta es bajo y el alfa no es concluyente.
- **Datos sintéticos**: no sirven para conclusiones de inversión y el panel lo dice.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y pivotar | Panel largo a matriz ancha sin huecos | `Reformar tablas: ancho y largo` |
| 2 · Riqueza acumulada | Componer retornos en vez de sumarlos | `Retornos logarítmicos` |
| 3 · Pesos de la cartera | Asignación que suma 1 y por qué se justifica | `Construcción de carteras` |
| 4 · Drawdown | Caída máxima sobre la riqueza, no sobre la media | `Máximo drawdown` |
| 5 · Sharpe | Exceso de retorno por unidad de riesgo con tasa declarada | `Ratio de Sharpe` |
| 6 · Benchmark | Beta, alfa y comparación con el índice | `Alpha y beta` |
| 7 · Panel | Contar asignación, riesgo y límite sin engañar | `Dashboards` |

## Estructura

```text
codigo/
├── cartera.py             # panel, riqueza, pesos, riesgo, benchmark y HTML
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas y numpy
├── datos-ejemplo/         # cartera-acciones.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **Pesos que no suman 1:** dejar capital sin asignar invalida la volatilidad y el Sharpe; el validador
  lo comprueba y falla.
- **Anualizar mal:** multiplicar el retorno medio mensual por 12 en vez de componer, o sumar retornos
  mensuales como si fueran aditivos.
- **Drawdown sobre retornos:** la caída máxima se mide sobre la riqueza acumulada, no sobre la serie de
  retornos ni sobre la media.
- **Sharpe sin tasa:** sin declarar la tasa libre de riesgo el número no es defendible; aquí es 0 % y se
  dice.
- **Beta de un índice que no explica nada:** con correlaciones bajas el beta sale cerca de 0 y el alfa
  no es concluyente; presentarlo como habilidad sería inventar.
- **`ModuleNotFoundError: pandas`**: instala las dependencias con el mismo Python que ejecuta el script.
