#!/usr/bin/env python3
"""Puerta del proyecto P39 · analítica de producto: embudo y cohortes.

Recalcula los recuentos del CSV, la tabla de usuarios, el embudo por pasos con usuarios únicos, las
cohortes de semana y la lectura de la caída. No usa red y **no escribe ficheros**.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import embudo

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P39 · embudo y cohortes ==")

    # Paso 1 · Comprueba el grano y los recuentos del origen
    # Por qué: el embudo se mide con usuarios; si el CSV no tiene 2000 eventos de 500 usuarios, el
    #          denominador no es el que promete el README.
    # Salida esperada: "datos: 2000 filas · 500 usuarios · 4 eventos por usuario"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    df = embudo.cargar_eventos()
    datos = embudo.validar_eventos(df)
    ok((datos["filas"], datos["columnas"], datos["usuarios"]) == (2000, 6, 500), "datos: 2000 filas · 6 columnas · 500 usuarios")
    ok(datos["eventos_por_usuario"] == {4: 500}, f"4 eventos por usuario: {datos['eventos_por_usuario']}")
    ok(datos["claves_duplicadas"] == 0, "la clave (usuario_id, fecha) es única")

    # Paso 2 · Comprueba los recuentos de eventos y de canal
    # Por qué: son las cifras medidas de la ficha; si no coinciden, el fichero no es el esperado.
    # Salida esperada: "eventos: visita 851 · registro 462 · abandono 322 · activacion 291 · compra 74"
    # Si falla: algún recuento distinto → revisa que el CSV sea el de eventos-app.
    ok(
        datos["eventos"] == {"visita": 851, "registro": 462, "abandono": 322, "activacion": 291, "compra": 74},
        f"eventos: {datos['eventos']}",
    )
    ok(
        datos["canales_eventos"] == {"organico": 952, "pago": 788, "referido": 260},
        f"eventos por canal: {datos['canales_eventos']}",
    )
    ok(datos["fechas"] == 32 and datos["desde"] == "2026-01-02" and datos["hasta"] == "2026-02-02",
       f"calendario: {datos['fechas']} días · {datos['desde']} a {datos['hasta']}")

    # Paso 3 · Comprueba la tabla de usuarios
    # Por qué: es la unidad del embudo; 500 filas con sus pasos y su canal, sin duplicar usuarios.
    # Salida esperada: "usuarios: 500 · 74 compras · 148 pro"
    # Si falla: el número de filas no es 500 → la agregación está contando eventos.
    usuarios = embudo.construir_usuarios(df)
    ok(len(usuarios) == 500 and usuarios["usuario_id"].is_unique, "tabla de usuarios: 500 filas, una por usuario")
    ok(int(usuarios["compra"].sum()) == 74, f"compras por usuario: {int(usuarios['compra'].sum())}")
    ok(int((usuarios["plan"] == "pro").sum()) == 148, f"usuarios pro: {int((usuarios['plan'] == 'pro').sum())}")
    canales = usuarios["canal"].value_counts()
    ok((int(canales["organico"]), int(canales["pago"]), int(canales["referido"])) == (238, 197, 65),
       f"usuarios por canal: {canales.to_dict()}")

    # Paso 4 · Recalcula el embudo global con usuarios únicos
    # Por qué: el criterio exige que la conversión cuadre con el recuento del CSV; se recalcula paso a paso.
    # Salida esperada: "embudo: visita 500 · registro 462 · activacion 291 · compra 74 (14.8 %)"
    # Si falla: el primer paso no es 500 → se están contando eventos.
    tabla_embudo = embudo.embudo(usuarios)
    valores = dict(zip(tabla_embudo["paso"], tabla_embudo["usuarios"]))
    ok(valores == {"visita": 500, "registro": 462, "activacion": 291, "compra": 74}, f"embudo: {valores}")
    ok(abs(float(tabla_embudo.iloc[-1]["conversion_sobre_base"]) - 0.148) < 1e-12, f"conversión final: {tabla_embudo.iloc[-1]['conversion_sobre_base']:.1%}")
    ok(abs(float(tabla_embudo.iloc[1]["tasa_sobre_paso_anterior"]) - 462 / 500) < 1e-12,
       "la tasa de cada paso usa el paso anterior como denominador")

    # Paso 5 · Recalcula el embudo por canal
    # Por qué: las cohortes de canal son la tabla que alimenta la lectura; sus totales deben sumar 500.
    # Salida esperada: "organico 238→220→156→53 · pago 197→179→90→9 · referido 65→63→45→12"
    # Si falla: alguna cohorte con otro tamaño → el canal no se asignó por usuario.
    por_canal = embudo.embudo_por_canal(usuarios)
    filas = por_canal.set_index("canal")
    ok(int(por_canal["usuarios"].sum()) == 500, "las tres cohortes suman 500 usuarios")
    ok(
        (int(filas.loc["organico", "registro"]), int(filas.loc["organico", "activacion"]), int(filas.loc["organico", "compra"])) == (220, 156, 53)
        and (int(filas.loc["pago", "registro"]), int(filas.loc["pago", "activacion"]), int(filas.loc["pago", "compra"])) == (179, 90, 9)
        and (int(filas.loc["referido", "registro"]), int(filas.loc["referido", "activacion"]), int(filas.loc["referido", "compra"])) == (63, 45, 12),
        "embudo por canal: 238/220/156/53 · 197/179/90/9 · 65/63/45/12",
    )
    ok(
        abs(float(filas.loc["organico", "conversion"]) - 53 / 238) < 1e-12
        and abs(float(filas.loc["pago", "conversion"]) - 9 / 197) < 1e-12,
        "conversión por cohorte: orgánico 22,3 % · pago 4,6 %",
    )

    # Paso 6 · Comprueba las cohortes por semana
    # Por qué: la cohorte sale de la fecha de primera actividad; con 32 días solo puede haber dos semanas.
    # Salida esperada: "cohortes: semanas 1 y 2 · n 151 y 349"
    # Si falla: más de dos semanas o n que no suma 500 → la fecha de cohorte está mal.
    tabla_cohortes = embudo.cohortes(usuarios)
    ok(len(tabla_cohortes) == 2 and list(tabla_cohortes["semana"]) == [1, 2], "dos cohortes de semana (1 y 2)")
    ok(list(tabla_cohortes["n"]) == [151, 349] and int(tabla_cohortes["n"].sum()) == 500,
       f"tamaños de cohorte: {list(tabla_cohortes['n'])}")
    ok(int(tabla_cohortes["compra"].sum()) == 74, "las compras de las cohortes suman 74")
    ok(
        abs(float(tabla_cohortes["tasa_compra"].iloc[0]) - tabla_cohortes["compra"].iloc[0] / 151) < 1e-12,
        "la tasa de compra de cada cohorte usa su n como denominador",
    )

    # Paso 7 · Comprueba la lectura de la caída
    # Por qué: el entregable no son cuatro números; el panel debe señalar el paso crítico y no confundir
    #          una etiqueta de evento con una baja.
    # Salida esperada: "lectura: activación es el paso crítico en las 3 cohortes"
    # Si falla: el paso crítico no es el mismo en las tres → revisa el cálculo de caídas.
    lectura = embudo.leer_caida(por_canal)
    ok(lectura["paso_critico"] == "activacion", f"paso crítico: {lectura['paso_critico']}")
    ok(set(lectura["criticos"].values()) == {"activacion"}, f"crítico en cada cohorte: {lectura['criticos']}")
    panel = embudo.texto_panel(tabla_embudo, por_canal, tabla_cohortes, lectura)
    ok(
        "usuarios únicos" in panel and "no una tendencia" in panel and "no una baja" in panel,
        "el panel declara el denominador, la foto de cohortes y que `abandono` no es una baja",
    )
    ok("Límite" in panel and "sintéticos" in panel, "el panel declara el límite de los datos")

    # Paso 8 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (embudo.RAIZ / "embudo.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
