# P39 · Analítica de producto: embudo y cohortes — código ejecutable

Construye el embudo de visita a compra **con usuarios únicos** y denominador declarado, la tabla de
usuarios con sus pasos y las cohortes por semana de primera actividad, y cierra con una lectura de dónde
se cae la gente. Es el código que acompaña a la ficha
`../../fichas-portfolio/p39-embudo-y-cohortes.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** (BSD-3-Clause).
- Windows, Linux o macOS: sin red ni servicios externos.

## Instalación

```powershell
cd proyectos/p39-embudo-y-cohortes/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python embudo.py
```

Recorre los pasos, imprime una línea por paso y escribe en `resultados/` los ficheros `usuarios.csv`,
`embudo.csv`, `embudo-por-canal.csv`, `cohortes.csv` y `panel.md`. Los generados no viajan en el ZIP:
solo `ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: 2000 filas y 6 columnas, 500 usuarios con 4 eventos
cada uno, la clave `(usuario_id, fecha)` única, los recuentos de eventos (visita 851, registro 462,
abandono 322, activación 291, compra 74), la tabla de 500 usuarios con 74 compras y 148 `pro`, el embudo
500 → 462 → 291 → 74 (14,8 %), las tres cohortes de canal (238/197/65) y las dos cohortes de semana
(151/349). Termina en `RESULTADO: VERDE` (0) o `RESULTADO: ROJO` (1). No usa red. La salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/eventos-app.csv`: **2000 filas × 6 columnas** (`usuario_id`, `fecha`, `evento`, `canal`,
  `minutos_sesion`, `plan`); 500 usuarios × 4 eventos, fechas 2026-01-02 a 2026-02-02.
- **Sintético, determinista y CC0-1.0**: copia literal del CSV servido por el portal en
  `aprender/web/datos/datasets/eventos-app.csv` (no está en `datasets/csv/` del repositorio), con
  `sha256:f926f5f961c5a338c4479bfbab9398de8986f57d77fd8becada41bee4c054460`.
- El CSV **no trae** sesión, campaña, dispositivo, importe de compra ni fecha de baja real. `abandono`
  es una etiqueta de evento, no una baja.

## Fuente real y licencia

- **No hay API**: la ficha declara `api: []`; el embudo y las cohortes se hacen solo con el CSV local.
- Datos sintéticos CC0-1.0, sin usuarios reales ni producto detrás. Dependencia: pandas BSD-3-Clause.

## Supuestos declarados

- **Denominador:** 500 usuarios en el embudo global y el n de cada cohorte en el embudo por canal;
  declarado antes de calcular.
- **Cohorte:** semana ISO de la fecha de primera actividad. Con 32 días de calendario solo hay dos
  semanas (151 y 349 usuarios): la retención es una foto, no una tendencia.
- **Canal:** lo asigna el generador al crear el usuario; no es una intervención de producto.
- **Paso crítico:** la mayor caída **antes de la compra** es el paso a activación en las tres cohortes;
  la conversión final a compra se informa aparte.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Declarar el grano | Qué es una fila y qué identifica al usuario | `Calidad de datos` |
| 2 · Valida recuentos | Categorías y totales que cuadran con el origen | `Agrupaciones y joins` |
| 3 · Tabla de usuarios | Una fila por usuario, sin duplicar al unir | `Pandas: agrupaciones y joins` |
| 4 · Embudo | Métrica con denominador declarado | `Métricas de producto` |
| 5 · Cohortes | Agrupar por fecha de primera actividad | `Métricas de producto` |
| 6 · Lectura y panel | Decir dónde se cae sin confundir etiqueta con baja | `Visualización honesta` |

## Estructura

```text
codigo/
├── embudo.py              # grano, tabla de usuarios, embudo, cohortes y panel
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas
├── datos-ejemplo/         # eventos-app.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **Contar eventos como usuarios:** `visita` aparece 851 veces; el embudo se mide con usuarios únicos.
- **Denominadores a la carta:** elegir 500 o el n de la cohorte según el resultado; se declara antes.
- **`abandono` como baja:** es una etiqueta de evento; el usuario conserva sus cuatro filas.
- **Duplicar al unir:** cruzar eventos con usuarios sin agregar antes multiplica cada usuario por cuatro.
- **Una cohorte de 32 días:** presentar la retención como tendencia es leer de más.
- **`ModuleNotFoundError: pandas`**: instala las dependencias con el mismo Python que ejecuta el script.
