#!/usr/bin/env python3
"""P39 · Analítica de producto: embudo y cohortes — código ejecutable.

Construye el embudo de visita a compra con usuarios únicos, la tabla de usuarios con sus pasos y las
cohortes por semana de primera actividad. Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal del portal):
    datos-ejemplo/eventos-app.csv  (2000 filas × 6 columnas)

Uso:
    python embudo.py             # calcula y escribe resultados/
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
# Orden del embudo: cada paso se cuenta con usuarios únicos, no con eventos.
PASOS = ["visita", "registro", "activacion", "compra"]
CANALES = ["organico", "pago", "referido"]


# Paso 1 · Carga los eventos y declara el grano
# Por qué: una fila es un evento, no un usuario; sin declarar el grano, el embudo se calcula con filas y
#          `visita` (851 filas) infla todos los pasos.
# Salida esperada: "eventos: 2000 filas · 6 columnas · 500 usuarios · 4 eventos por usuario"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_eventos() -> pd.DataFrame:
    ruta = DATOS / "eventos-app.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta, parse_dates=["fecha"])
    df = df.sort_values(["usuario_id", "fecha"]).reset_index(drop=True)
    print(
        f"eventos: {len(df)} filas · {df.shape[1]} columnas · {df['usuario_id'].nunique()} usuarios · "
        f"{df.groupby('usuario_id').size().mode().iloc[0]} eventos por usuario"
    )
    return df


# Paso 2 · Valida la clave, las categorías y los recuentos medidos
# Por qué: si la clave (usuario_id, fecha) se repite o las categorías no son las esperadas, la tabla de
#          usuarios agrega mal y el embudo deja de cuadrar con el origen.
# Salida esperada: "validación: 0 claves duplicadas · visita 851 · registro 462 · compra 74"
# Si falla: un recuento distinto → el CSV no es el que dice la ficha.
def validar_eventos(df: pd.DataFrame) -> dict:
    resumen = {
        "filas": len(df),
        "columnas": int(df.shape[1]),
        "usuarios": int(df["usuario_id"].nunique()),
        "eventos_por_usuario": {int(k): int(v) for k, v in df.groupby("usuario_id").size().value_counts().items()},
        "claves_duplicadas": int(df.duplicated(["usuario_id", "fecha"]).sum()),
        "eventos": {k: int(v) for k, v in df["evento"].value_counts().items()},
        "canales_eventos": {k: int(v) for k, v in df["canal"].value_counts().items()},
        "fechas": int(df["fecha"].nunique()),
        "desde": df["fecha"].min().date().isoformat(),
        "hasta": df["fecha"].max().date().isoformat(),
    }
    print(
        f"validación: {resumen['claves_duplicadas']} claves duplicadas · "
        f"visita {resumen['eventos'].get('visita', 0)} · registro {resumen['eventos'].get('registro', 0)} · "
        f"compra {resumen['eventos'].get('compra', 0)}"
    )
    return resumen


# Paso 3 · Construye la tabla de usuarios, una fila por usuario
# Por qué: el embudo y las cohortes necesitan al usuario como unidad; si se unen eventos con usuarios sin
#          agregar antes, cada usuario aparece cuatro veces y todo se infla.
# Salida esperada: "usuarios: 500 filas · 74 compras · 148 pro · canal 238/197/65"
# Si falla: algún usuario sin evento de visita → revisa el grano; hoy los 500 tienen visita.
def construir_usuarios(df: pd.DataFrame) -> pd.DataFrame:
    usuarios = df.groupby("usuario_id").agg(
        canal=("canal", "first"),
        plan=("plan", "first"),
        primera_actividad=("fecha", "min"),
    )
    for paso in PASOS[1:]:
        usuarios[paso] = usuarios.index.isin(df.loc[df["evento"] == paso, "usuario_id"].to_numpy())
    usuarios["visita"] = True
    usuarios = usuarios.reset_index()
    usuarios["semana"] = usuarios["primera_actividad"].dt.isocalendar().week.astype(int)
    canales = usuarios["canal"].value_counts()
    print(
        f"usuarios: {len(usuarios)} filas · {int(usuarios['compra'].sum())} compras · "
        f"{int((usuarios['plan'] == 'pro').sum())} pro · canal "
        + "/".join(str(int(canales.get(c, 0))) for c in CANALES)
    )
    return usuarios


# Paso 4 · Calcula el embudo con usuarios únicos y denominador declarado
# Por qué: cada paso se mide sobre el mismo denominador (los 500 usuarios) y la tasa de conversión sale
#          de ahí; cambiar el denominador según el paso es el error que hace incomparable el embudo.
# Salida esperada: "embudo: visita 500 · registro 462 · activacion 291 · compra 74 (14.8 %)"
# Si falla: el primer paso no es 500 → hay usuarios duplicados o falta un evento.
def embudo(usuarios: pd.DataFrame) -> pd.DataFrame:
    base = len(usuarios)
    filas = []
    anterior = base
    for paso in PASOS:
        usuarios_paso = int(usuarios[paso].sum())
        filas.append(
            {
                "paso": paso,
                "usuarios": usuarios_paso,
                "tasa_sobre_paso_anterior": usuarios_paso / anterior,
                "conversion_sobre_base": usuarios_paso / base,
            }
        )
        anterior = usuarios_paso
    tabla = pd.DataFrame(filas)
    ultimo = tabla.iloc[-1]
    print(
        "embudo: " + " · ".join(f"{fila.paso} {fila.usuarios}" for fila in tabla.itertuples())
        + f" ({ultimo.conversion_sobre_base:.1%})"
    )
    return tabla


# Paso 5 · Abre el embudo por cohorte de canal
# Por qué: el canal lo asigna el generador al crear el usuario, no es una intervención; sirve para
#          practicar la comparación entre cohortes, y así se declara en el panel.
# Salida esperada: "canal organico: 238 → 220 → 156 → 53 (22.3 %)"
# Si falla: la suma de cohortes no es 500 → hay usuarios sin canal o un canal nuevo.
def embudo_por_canal(usuarios: pd.DataFrame) -> pd.DataFrame:
    filas = []
    for canal in CANALES:
        grupo = usuarios[usuarios["canal"] == canal]
        fila = {"canal": canal, "usuarios": len(grupo)}
        for paso in PASOS:
            fila[paso] = int(grupo[paso].sum())
        fila["conversion"] = fila["compra"] / fila["usuarios"]
        filas.append(fila)
    tabla = pd.DataFrame(filas)
    for fila in tabla.itertuples():
        print(
            f"canal {fila.canal}: {fila.usuarios} → {fila.registro} → {fila.activacion} → "
            f"{fila.compra} ({fila.conversion:.1%})"
        )
    return tabla


# Paso 6 · Agrupa por semana de primera actividad
# Por qué: la cohorte sale de una fecha declarada (la primera actividad del usuario); con 32 días de
#          calendario solo hay dos semanas y tamaños pequeños, así que la retención es una foto.
# Salida esperada: "cohortes: semanas 1 y 2 · n 151 y 349"
# Si falla: más de dos semanas → la fecha de primera actividad no cae donde dice la ficha.
def cohortes(usuarios: pd.DataFrame) -> pd.DataFrame:
    tabla = (
        usuarios.groupby("semana")
        .agg(n=("usuario_id", "size"), activacion=("activacion", "sum"), compra=("compra", "sum"))
        .reset_index()
    )
    tabla["tasa_activacion"] = tabla["activacion"] / tabla["n"]
    tabla["tasa_compra"] = tabla["compra"] / tabla["n"]
    print(
        "cohortes: semanas " + " y ".join(str(int(s)) for s in tabla["semana"])
        + " · n " + " y ".join(str(int(n)) for n in tabla["n"])
    )
    return tabla


# Paso 7 · Lee la caída: qué paso pierde más gente y qué no se puede concluir
# Por qué: cuatro números sin lectura no son el entregable; se busca la mayor caída relativa antes de la
#          compra y se dice que `abandono` es una etiqueta, no una baja con fecha.
# Salida esperada: "lectura: el paso crítico es activación en las 3 cohortes"
# Si falla: ninguna caída → el embudo no tiene pasos decrecientes.
def leer_caida(por_canal: pd.DataFrame) -> dict:
    criticos = {}
    for fila in por_canal.itertuples():
        caidas = {
            "registro": 1 - fila.registro / fila.usuarios,
            "activacion": 1 - fila.activacion / fila.registro,
            "compra": 1 - fila.compra / fila.activacion,
        }
        # Antes de la compra, el cuello de botella es el paso de activación; la compra es el salto más
        # selectivo y se informa aparte, porque es la conversión final y no un paso del embudo.
        antes_de_comprar = {k: v for k, v in caidas.items() if k != "compra"}
        criticos[fila.canal] = max(antes_de_comprar, key=antes_de_comprar.get)
    paso_critico = max(set(criticos.values()), key=list(criticos.values()).count)
    print(f"lectura: el paso crítico es {paso_critico} en {len(criticos)} cohortes")
    return {"criticos": criticos, "paso_critico": paso_critico}


def tabla_markdown(df: pd.DataFrame, decimales: int = 1) -> str:
    """Tabla markdown sin tabulate: cabecera, separador y filas formateadas."""
    cabecera = "| " + " | ".join(df.columns) + " |"
    separador = "| " + " | ".join("---" for _ in df.columns) + " |"
    filas = []
    for _, fila in df.iterrows():
        celdas = []
        for valor in fila:
            if isinstance(valor, float):
                celdas.append(f"{valor:.{decimales}f}")
            else:
                celdas.append(str(valor))
        filas.append("| " + " | ".join(celdas) + " |")
    return "\n".join([cabecera, separador, *filas])


def texto_panel(
    embudo_global: pd.DataFrame,
    por_canal: pd.DataFrame,
    tabla_cohortes: pd.DataFrame,
    lectura: dict,
) -> str:
    lineas = [
        "# P39 · Panel de embudo y cohortes",
        "",
        "## Grano y denominador",
        "Una fila del CSV es un evento; el embudo se cuenta con **usuarios únicos** y el denominador es",
        "siempre 500 (o el n de la cohorte, declarado antes de calcular). `visita` aparece 851 veces,",
        "pero son 500 usuarios: contar filas inflaría todos los pasos.",
        "",
        "## Embudo global",
        tabla_markdown(embudo_global, decimales=3),
        "",
        "## Embudo por cohorte de canal",
        tabla_markdown(por_canal, decimales=3),
        "",
        "## Cohortes por semana de primera actividad",
        tabla_markdown(tabla_cohortes, decimales=3),
        "Con 32 días de calendario y primeras actividades entre el 2 y el 11 de enero, solo hay dos",
        "semanas de cohorte: la retención es una foto, no una tendencia.",
        "",
        "## Lectura de la caída",
        f"- Paso crítico antes de la compra: **{lectura['paso_critico']}** en las tres cohortes "
        f"({', '.join(f'{c}: {p}' for c, p in lectura['criticos'].items())}).",
        "- La conversión final a compra también se separa por canal: el orgánico convierte 22,3 %, el",
        "  referido 18,5 % y el pago 4,6 %. Son cohortes asignadas por el generador, no una intervención",
        "  de producto: el panel practica el método, no mide un experimento.",
        "- `abandono` es una etiqueta de evento, no una baja con fecha: el usuario conserva sus cuatro filas.",
        "",
        "## Límite",
        "Datos sintéticos, CC0-1.0, con 500 usuarios y cuatro eventos por usuario: no hay log completo, ni",
        "sesiones, ni importe de compra. Las cohortes son dos semanas pequeñas y el canal no es aleatorio;",
        "no se puede concluir causalidad ni extrapolar a un producto real.",
        "",
    ]
    return "\n".join(lineas)


def main() -> int:
    df = cargar_eventos()
    validar_eventos(df)
    usuarios = construir_usuarios(df)
    embudo_global = embudo(usuarios)
    por_canal = embudo_por_canal(usuarios)
    tabla_cohortes = cohortes(usuarios)
    lectura = leer_caida(por_canal)
    RESULTADOS.mkdir(exist_ok=True)
    usuarios.to_csv(RESULTADOS / "usuarios.csv", index=False)
    embudo_global.to_csv(RESULTADOS / "embudo.csv", index=False)
    por_canal.to_csv(RESULTADOS / "embudo-por-canal.csv", index=False)
    tabla_cohortes.to_csv(RESULTADOS / "cohortes.csv", index=False)
    (RESULTADOS / "panel.md").write_text(
        texto_panel(embudo_global, por_canal, tabla_cohortes, lectura), encoding="utf-8"
    )
    print(f"escrito: {RESULTADOS / 'panel.md'} · usuarios.csv · embudo.csv · cohortes.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
