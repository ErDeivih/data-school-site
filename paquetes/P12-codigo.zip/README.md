# P12 · Un panel de carrera con una sola pregunta

Paquete descargable de **Data School** para el proyecto P12. Incluye el CSV de ejemplo, el código
comentado paso a paso, un **panel HTML** de una pantalla y un verificador. No necesita conexión ni
dependencias.

La pregunta del proyecto es una sola: **¿qué stint rinde mejor y cuánto cuesta de verdad la
parada?** El código deriva los stints de la parada (el CSV no los trae), aparta la vuelta de boxes,
agrega por stint y escribe un panel con la pregunta, los KPIs, la tabla, la fuente, la fecha y el
límite. Eso es lo que convierte un gráfico en un panel demostrable.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice. El panel se genera con HTML propio.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python panel.py
python verificar.py
```

Para guardar el panel y abrirlo en el navegador:

```bash
python panel.py --html resultados/panel.html
start resultados/panel.html        # Windows
# xdg-open resultados/panel.html   # Linux
```

Desde la carpeta del paquete (el CSV se busca en `datos-ejemplo/`):

```bash
cd P12-codigo
python panel.py --csv datos-ejemplo/telemetria-f1.csv --html resultados/panel.html
```

## Salida esperada

```text
datos: 180 vueltas · 174 de ritmo + 6 de parada
stints: 12 · stints más rápido: monza/A despues (83.529 s)
antes 89.515 s · después 88.577 s · diferencia -0.939 s
coste medio de la parada: 22.369 s
panel: escrito en resultados/panel.html
fuente: telemetria-f1 (catálogo Data School) · 3 carreras × 2 pilotos × 30 vueltas · fecha 2026-11-10
límite: 3 carreras sintéticas y una sola parada por piloto: el panel describe este CSV, no una
temporada real; la parada y el neumático van juntos y no se separan.
```

El panel completo está en `resultados/panel.html`; la salida de consola, en
`resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/telemetria-f1.csv`: **180 filas × 10 columnas**. 3 carreras (`bahrein`, `monza`,
  `suzuka`) × 2 pilotos × 30 vueltas; compuesto, edad del neumático, tres sectores, tiempo de vuelta
  y marca de parada. Clave `(carrera, piloto, vuelta)` única.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `telemetria-f1` del catálogo.
  No son datos reales de ningún equipo ni circuito.
- `sha256` del fichero: `c232e767dc95184fddeb329f6a7c4c72ccb13423a2961bea717cd464150c2c3b`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida grano y 30 vueltas por piloto | grano de una tabla de telemetría |
| 2 · Stints | deriva antes/después de la parada y aparta la vuelta de boxes | del dato crudo a la unidad de análisis |
| 3 · Degradación | pendiente de tiempo frente a edad del neumático | una métrica que no es una media |
| 4 · Agregar | media, mediana, p90, dispersión y degradación por stint | KPIs que no se tapan entre sí |
| 5 · Coste de parada | vuelta de boxes − media de las 3 anteriores | comparar contra la referencia correcta |
| 6 · Panel | pregunta, KPIs, tabla, fuente, fecha y límite en una pantalla | storytelling con datos y trazabilidad |

## Las tres trampas que el código deja a la vista

1. **La vuelta de boxes no es ritmo.** Dura ~22,4 s más; si entra en la media, el «después» sale
   artificialmente lento. El código la aparta y calcula su coste por separado (media 22,369 s).
2. **El CSV no trae la columna «stint».** Se deriva de la parada: pretender que el dato viene dado
   es el primer autoengaño de un panel. Aquí se deriva y se comprueba (12 stints, 174 vueltas).
3. **Un panel sin fuente ni límite no es demostrable.** El panel imprime la pregunta, la fuente, la
   fecha y el límite; sin esos cuatro, es un adorno que no se puede discutir.

## Fallos típicos

- **`ModuleNotFoundError: panel`**: ejecuta desde la carpeta del paquete.
- **`FileNotFoundError`**: `--csv` es relativo al directorio actual.
- **`se esperaba una parada`**: falta la marca `parada=1` o hay dos paradas en un stint.
- **Panel sin barras**: el CSV no tiene variedad de tiempos (todas las vueltas iguales).
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P12-codigo/
├── panel.py                   # pasos 1–6: stints, KPIs y panel HTML
├── verificar.py               # la puerta del proyecto: 25 comprobaciones
├── requirements.txt           # sin dependencias
├── datos-ejemplo/
│   └── telemetria-f1.csv      # 180 × 10 · sintético, CC0-1.0
└── resultados/
    ├── panel.html             # panel de una pantalla listo para abrir
    └── ejemplo-salida.txt     # la salida real de una ejecución
```

## Límite

Son 3 carreras sintéticas y una sola parada por piloto: el panel describe **este CSV**, no una
temporada real. La parada y el neumático nuevo van juntos, así que no se puede separar «lo que costó
la parada» de «lo que ganó el neumático»; el panel lo dice en lugar de fingir que lo sabe.
