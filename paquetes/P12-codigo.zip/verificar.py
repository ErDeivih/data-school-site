#!/usr/bin/env python3
"""Puerta del proyecto P12 (panel de carrera con una sola pregunta).

Comprueba grano, stints, KPIs, coste de la parada, que el panel cabe y cita fuente/fecha/límite, y
que el código no usa red ni claves. VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import panel

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "telemetria-f1.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.3f} ≈ {esperado:.3f})")


def main() -> int:
    filas = panel.leer(CSV)
    ok(len(filas) == 180, "el CSV tiene 180 vueltas")
    ok(len({(f["carrera"], f["piloto"]) for f in filas}) == 6, "hay 6 pares carrera/piloto")
    ok(all(sum(1 for f in filas if (f["carrera"], f["piloto"]) == (c, p)) == 30
           for c, p in {(f["carrera"], f["piloto"]) for f in filas}), "cada par tiene 30 vueltas")

    ritmo, paradas = panel.stints(filas)
    ok(len(ritmo) == 174, "quedan 174 vueltas de ritmo")
    ok(len(paradas) == 6, "se apartan 6 vueltas de parada")
    ok(len({(f["carrera"], f["piloto"], f["stint"]) for f in ritmo}) == 12, "hay 12 stints (antes/después)")

    agregado = panel.agregar(ritmo)
    ok(len(agregado) == 12, "la tabla de KPIs tiene 12 filas")
    ok(all(s["vueltas"] >= 8 for s in agregado), "ningún stint tiene menos de 8 vueltas")
    best = min(agregado, key=lambda x: x["media"])
    ok((best["carrera"], best["piloto"], best["stint"]) == ("monza", "A", "despues"),
       "el stint más rápido es monza/A después")
    cerca(best["media"], 83.529, 0.005, "su media es 83,529 s")
    ok(all(s["degradacion"] > 0 for s in agregado), "todos los stints degradan (pendiente positiva)")

    perdidas = panel.coste_paradas(ritmo, paradas)
    ok(len(perdidas) == 6, "hay 6 costes de parada")
    cerca(panel.media([p["perdida"] for p in perdidas]), 22.369, 0.01, "coste medio de la parada")
    ok(all(21.5 < p["perdida"] < 23.5 for p in perdidas), "los 6 costes están entre 21,5 y 23,5 s")

    documento = panel.panel(agregado, perdidas)
    ok(len(documento) > 3000, "el panel es HTML completo (más de 3 KB)")
    ok(panel.PREGUNTA in documento, "el panel lleva la pregunta")
    ok(panel.FUENTE in documento, "el panel cita la fuente")
    ok(panel.FECHA in documento, "el panel lleva fecha")
    ok(panel.LIMITE in documento, "el panel declara su límite")
    ok(documento.count("<tr>") == 13, "la tabla del panel tiene 12 filas + cabecera")
    ok("83.529" in documento, "el KPI del mejor stint aparece en el panel")
    ok("22.4" in documento, "el coste medio de la parada aparece en el panel")
    ok("http" not in documento.lower(), "el panel no carga recursos externos")

    codigo = (AQUI / "panel.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
