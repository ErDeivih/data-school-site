"""P12 · Un panel de carrera con una sola pregunta.

Elige UNA pregunta que la telemetría pueda responder, agrega por stint (antes y después de la
parada), calcula el coste de la parada y deja un panel de una pantalla con su fuente, su fecha y
su límite. El panel es HTML: se puede abrir, imprimir o publicar tal cual.

Sin dependencias externas: solo la biblioteca estándar. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import html
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("carrera", "piloto", "vuelta", "compuesto", "edad_neumatico",
            "sector1_s", "sector2_s", "sector3_s", "tiempo_vuelta_s", "parada")
PREGUNTA = "¿Qué stint rinde mejor y cuánto cuesta de verdad la parada?"
FUENTE = "telemetria-f1 (catálogo Data School) · 3 carreras × 2 pilotos × 30 vueltas"
FECHA = "2026-11-10"
LIMITE = ("3 carreras sintéticas y una sola parada por piloto: el panel describe este CSV, "
          "no una temporada real; la parada y el neumático van juntos y no se separan.")


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar el grano: una fila por carrera, piloto y vuelta.
    # Por qué: si una vuelta se repite o falta un piloto, el agregado por stint miente.
    # Salida esperada: 180 filas × 10 columnas, 6 pares carrera/piloto con 30 vueltas.
    # Si falla: «columnas inesperadas» o «cada par debe tener 30 vueltas».
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 180:
        raise ValueError(f"se esperaban 180 filas, hay {len(filas)}")
    for fila in filas:
        for columna in ("vuelta", "edad_neumatico", "sector1_s", "sector2_s", "sector3_s", "tiempo_vuelta_s"):
            float(fila[columna])
    grupos = defaultdict(list)
    for fila in filas:
        grupos[(fila["carrera"], fila["piloto"])].append(fila)
    if len(grupos) != 6 or any(len(g) != 30 for g in grupos.values()):
        raise ValueError("cada par carrera/piloto debe tener 30 vueltas")
    return filas


def stints(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    # Paso 2 · Derivar el stint de cada vuelta y apartar la vuelta de boxes.
    # Por qué: el CSV no trae «stint»; se deriva de la parada. La vuelta de la parada dura ~22 s
    # más y no es ritmo: se guarda aparte para calcular cuánto cuesta la parada.
    # Salida esperada: 174 vueltas de ritmo (114 antes + 60 después) y 6 vueltas de parada, en 12 stints.
    # Si falla: un piloto no tiene parada o tiene dos.
    ritmo, paradas = [], []
    for (carrera, piloto), grupo in grupos_ordenados(filas).items():
        marcas = [f for f in grupo if f["parada"] == "1"]
        if len(marcas) != 1:
            raise ValueError(f"{carrera}/{piloto}: se esperaba una parada, hay {len(marcas)}")
        vuelta_parada = int(marcas[0]["vuelta"])
        for fila in grupo:
            if fila["parada"] == "1":
                paradas.append({**fila, "carrera": carrera, "piloto": piloto})
                continue
            copia = dict(fila)
            copia["stint"] = "antes" if int(fila["vuelta"]) < vuelta_parada else "despues"
            ritmo.append(copia)
    if len(ritmo) != 174 or len(paradas) != 6:
        raise ValueError(f"se esperaban 174 vueltas de ritmo y 6 paradas; hay {len(ritmo)} y {len(paradas)}")
    return ritmo, paradas


def grupos_ordenados(filas: list[dict]) -> dict:
    grupos = defaultdict(list)
    for fila in filas:
        grupos[(fila["carrera"], fila["piloto"])].append(fila)
    for grupo in grupos.values():
        grupo.sort(key=lambda f: int(f["vuelta"]))
    return dict(grupos)


def media(valores: list[float]) -> float:
    return sum(valores) / len(valores)


def mediana(valores: list[float]) -> float:
    orden = sorted(valores)
    n = len(orden)
    return orden[n // 2] if n % 2 else (orden[n // 2 - 1] + orden[n // 2]) / 2


def percentil(valores: list[float], p: float) -> float:
    orden = sorted(valores)
    if not orden:
        return 0.0
    pos = (len(orden) - 1) * p
    bajo, alto = math.floor(pos), math.ceil(pos)
    return orden[bajo] + (orden[alto] - orden[bajo]) * (pos - bajo)


def pendiente(puntos: list[tuple[float, float]]) -> float:
    # Paso 3 · Pendiente de tiempo de vuelta frente a edad del neumático (OLS simple).
    # Por qué: es la degradación del stint en segundos por vuelta de neumático.
    # Salida esperada: un número positivo (cuanto más viejo el neumático, más lento).
    n = len(puntos)
    mx = sum(p[0] for p in puntos) / n
    my = sum(p[1] for p in puntos) / n
    sxx = sum((p[0] - mx) ** 2 for p in puntos)
    if not sxx:
        return 0.0
    return sum((p[0] - mx) * (p[1] - my) for p in puntos) / sxx


def agregar(ritmo: list[dict]) -> list[dict]:
    # Paso 4 · Una fila por stint con sus KPIs: ritmo medio, mediana, p90, dispersión y degradación.
    # Por qué: una media sola esconde la consistencia; el panel necesita varias cifras por stint.
    # Salida esperada: 12 stints (3 carreras × 2 pilotos × antes/después).
    por_stint = defaultdict(list)
    for fila in ritmo:
        por_stint[(fila["carrera"], fila["piloto"], fila["stint"])].append(fila)
    salida = []
    for (carrera, piloto, stint), vueltas in sorted(por_stint.items()):
        tiempos = [float(f["tiempo_vuelta_s"]) for f in vueltas]
        puntos = [(float(f["edad_neumatico"]), float(f["tiempo_vuelta_s"])) for f in vueltas]
        salida.append({
            "carrera": carrera, "piloto": piloto, "stint": stint,
            "vueltas": len(tiempos), "media": media(tiempos), "mediana": mediana(tiempos),
            "p90": percentil(tiempos, 0.9), "desviacion": math.sqrt(sum((t - media(tiempos)) ** 2 for t in tiempos) / len(tiempos)),
            "degradacion": pendiente(puntos),
            "mejor": min(tiempos),
        })
    return salida


def coste_paradas(ritmo: list[dict], paradas: list[dict]) -> list[dict]:
    # Paso 5 · Coste de la parada = vuelta de boxes − ritmo esperado sin parar.
    # Por qué: la vuelta de la parada no se compara con la media del stint entero, sino con las
    # tres vueltas anteriores (mismo neumático y combustible similar).
    # Salida esperada: 6 pérdidas de unos 22 s cada una.
    # Si falla: no hay tres vueltas antes de la parada para dar una referencia.
    por_par = defaultdict(dict)
    for fila in ritmo:
        por_par[(fila["carrera"], fila["piloto"])].setdefault("ritmo", []).append(fila)
    for fila in paradas:
        por_par[(fila["carrera"], fila["piloto"])]["parada"] = fila
    salida = []
    for (carrera, piloto), datos in sorted(por_par.items()):
        referencia = [float(f["tiempo_vuelta_s"]) for f in datos["ritmo"] if f["stint"] == "antes"][-3:]
        if len(referencia) != 3:
            raise ValueError(f"{carrera}/{piloto}: faltan vueltas de referencia antes de la parada")
        perdida = float(datos["parada"]["tiempo_vuelta_s"]) - media(referencia)
        salida.append({"carrera": carrera, "piloto": piloto, "perdida": perdida})
    return salida


def panel(agregado: list[dict], perdidas: list[dict]) -> str:
    # Paso 6 · Componer el panel de una pantalla: pregunta, KPIs, tabla, fuente, fecha y límite.
    # Por qué: un panel sin pregunta es un adorno; sin fuente y sin límite, no es demostrable.
    # Salida esperada: HTML autocontenido con las cifras y la procedencia.
    mejor = min(agregado, key=lambda x: x["media"])
    antes = [s["media"] for s in agregado if s["stint"] == "antes"]
    despues = [s["media"] for s in agregado if s["stint"] == "despues"]
    diferencia = media(despues) - media(antes)
    perdida_media = media([p["perdida"] for p in perdidas])
    maximo = max(s["p90"] for s in agregado)
    filas = "".join(
        f"<tr><td>{html.escape(s['carrera'])}</td><td>{html.escape(s['piloto'])}</td>"
        f"<td>{html.escape(s['stint'])}</td><td>{s['vueltas']}</td>"
        f"<td>{s['media']:.3f}</td><td>{s['mediana']:.3f}</td><td>{s['p90']:.3f}</td>"
        f"<td>{s['degradacion']:+.3f}</td></tr>"
        for s in agregado
    )
    # Barras horizontales de ritmo medio, sin librerías: se ve el orden de un vistazo.
    barras = "".join(
        f'<div class="barra"><span>{html.escape(s["carrera"])} {html.escape(s["piloto"])} {html.escape(s["stint"])}</span>'
        f'<i style="width:{(s["media"] / maximo) * 100:.1f}%"></i><b>{s["media"]:.3f} s</b></div>'
        for s in agregado
    )
    return f"""<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><title>{html.escape(PREGUNTA)}</title>
<style>body{{font-family:system-ui,sans-serif;max-width:900px;margin:24px auto;padding:0 16px;color:#111}}
h1{{font-size:24px;line-height:1.2}}.kpis{{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0}}
.kpi{{flex:1 1 180px;border:1px solid #bbb;border-radius:10px;padding:10px}}
.kpi b{{display:block;font-size:24px}}.kpi span{{font-size:12px;color:#555}}
table{{border-collapse:collapse;width:100%;font-size:13px;margin:12px 0}}
th,td{{border-bottom:1px solid #ddd;padding:6px;text-align:left}}
.barra{{display:flex;align-items:center;gap:8px;font-size:12px;margin:4px 0}}
.barra i{{background:#1f6f54;height:10px;border-radius:4px}}.barra span{{width:210px}}.barra b{{white-space:nowrap;margin-left:8px;min-width:74px}}
.fuente{{font-size:12px;color:#555;border-top:1px solid #ddd;padding-top:10px;margin-top:18px}}</style>
</head><body>
<h1>{html.escape(PREGUNTA)}</h1>
<p>Pregunta única: comparar el ritmo de cada stint de la carrera, no «todo lo que se puede medir».</p>
<div class="kpis">
  <div class="kpi"><b>{html.escape(mejor['carrera'])} · {html.escape(mejor['piloto'])}</b><span>stint más rápido ({html.escape(mejor['stint'])}): {mejor['media']:.3f} s de media</span></div>
  <div class="kpi"><b>{diferencia:+.3f} s</b><span>después − antes (media de los stints)</span></div>
  <div class="kpi"><b>{perdida_media:.1f} s</b><span>coste medio de la parada en pista</span></div>
</div>
{barras}
<table><caption>KPIs por stint (vuelta de boxes excluida del ritmo)</caption>
<thead><tr><th>Carrera</th><th>Piloto</th><th>Stint</th><th>Vueltas</th><th>Media (s)</th><th>Mediana (s)</th><th>P90 (s)</th><th>Degradación (s/vuelta)</th></tr></thead>
<tbody>{filas}</tbody></table>
<p class="fuente">Fuente: {html.escape(FUENTE)} · Fecha: {html.escape(FECHA)}.<br>Límite: {html.escape(LIMITE)}</p>
</body></html>"""


def main() -> int:
    parser = argparse.ArgumentParser(description="P12 · panel de carrera con una sola pregunta")
    parser.add_argument("--csv", default="datos-ejemplo/telemetria-f1.csv")
    parser.add_argument("--html", default="", help="ruta donde escribir el panel HTML")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    ritmo, paradas = stints(filas)
    agregado = agregar(ritmo)
    perdidas = coste_paradas(ritmo, paradas)
    documento = panel(agregado, perdidas)
    if args.html:
        Path(args.html).write_text(documento, encoding="utf-8")

    mejor = min(agregado, key=lambda x: x["media"])
    antes = media([s["media"] for s in agregado if s["stint"] == "antes"])
    despues = media([s["media"] for s in agregado if s["stint"] == "despues"])
    print(f"datos: {len(filas)} vueltas · {len(ritmo)} de ritmo + {len(paradas)} de parada")
    print(f"stints: {len(agregado)} · stints más rápido: {mejor['carrera']}/{mejor['piloto']} {mejor['stint']} ({mejor['media']:.3f} s)")
    print(f"antes {antes:.3f} s · después {despues:.3f} s · diferencia {despues - antes:+.3f} s")
    print(f"coste medio de la parada: {media([p['perdida'] for p in perdidas]):.3f} s")
    print("panel: " + ("escrito en " + args.html if args.html else "generado en memoria; usa --html salida.html para guardarlo"))
    print(f"fuente: {FUENTE} · fecha {FECHA}")
    print(f"límite: {LIMITE}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
