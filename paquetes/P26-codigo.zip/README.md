# P26 · Precios diarios: volatilidad, saltos y caída máxima

Paquete descargable de **Data School** para el proyecto P26. Incluye la serie de precios, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python volatilidad.py
python volatilidad.py --sigmas 2
python verificar.py
```

`volatilidad.py` imprime el rango de cierres, la volatilidad anualizada, el retorno medio, el peor y el
mejor día, la caída máxima y los saltos por encima del umbral (`--sigmas`, 3 por defecto). `verificar.py`
sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/precios-accion.csv`: **250 filas × 6 columnas** (un precio diario de apertura, cierre,
  máximo, mínimo y volumen, de enero a septiembre de 2026). Sintético y **CC0-1.0**; es el
  `precios-accion` del catálogo de Data School.

## Salida esperada

```text
filas: 250 · retornos: 249 · cierres: 85.66–102.89
volatilidad anualizada: 18.483% (sqrt(252))
retorno medio diario: -0.03101% · peor: -1.98% · mejor: 2.02%
caída máxima: -16.75%
saltos > 3.0σ: 0
límite: precios sintéticos de 250 días; no es una serie real ni una predicción.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Contrato del CSV | `leer` valida fechas únicas, precios positivos y máximo/mínimo | outliers y detección |
| 2 · Retornos logarítmicos | `retornos` pasa de precios a ln(P_t/P_{t-1}) | volatilidad realizada |
| 3 · Volatilidad anual | `volatilidad_anual` escala por sqrt(252) | volatilidad realizada |
| 4 · Caída máxima | `caida_maxima` mide el peor momento desde un máximo | máximo drawdown |
| 5 · Saltos | `saltos` cuenta retornos fuera de 3σ | outliers y detección |
| 6 · Publicar | `main` resume y declara el límite | volatilidad realizada |

## Fallos típicos

- **`precios no positivos`**: un cero o un signo mal puesto rompe el logaritmo.
- **`máximo/mínimo no acotan apertura y cierre`**: el CSV viene de otra fuente o está corrupto.
- **Volatilidad anualizada sin `sqrt(252)`**: se queda en diaria y no se puede comparar con un año.
- **Saltos contados con umbral 1σ**: casi todo parece anómalo; el umbral es parte de la decisión.

## Límite

Los precios son sintéticos y cubren 250 días. Enseñan a medir riesgo; no son una serie real ni una
predicción.
