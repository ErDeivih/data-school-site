﻿#!/usr/bin/env python3
"""Puerta del proyecto P26 (volatilidad, saltos y caída máxima).

Comprueba contrato del CSV, retornos, volatilidad anualizada, caída máxima, saltos y ausencia de red.
Sin escribir en disco. Termina en RESULTADO: VERDE (0) o ROJO (1).
"""
from __future__ import annotations

import statistics
from pathlib import Path
# La consola de Windows puede estar en cp1252: se fuerza UTF-8 para los signos y acentos.
import sys as _sys
for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

import volatilidad

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "precios-accion.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = volatilidad.leer(CSV)
    ok(len(filas) == 250, "el CSV tiene 250 filas")
    ok(len(filas[0]) == 6, "el CSV trae las 6 columnas del contrato")
    ok(len({f["fecha"] for f in filas}) == 250, "las 250 fechas son únicas")
    ok(all(float(f["cierre"]) > 0 for f in filas), "todos los cierres son positivos")

    rets = volatilidad.retornos(filas)
    ok(len(rets) == 249, "250 precios dan 249 retornos")
    ok(round(volatilidad.volatilidad_anual(rets), 5) == 0.18483, "la volatilidad anualizada es 18,483 %")
    ok(round(volatilidad.caida_maxima(filas), 5) == -0.16746, "la caída máxima es −16,746 %")
    ok(round(statistics.mean(rets), 5) == -0.00031, "el retorno medio diario es −0,031 %")
    ok(round(min(rets), 5) == -0.01981, "el peor día cae −1,981 %")
    ok(round(max(rets), 5) == 0.02019, "el mejor día sube +2,019 %")
    ok(volatilidad.saltos(rets) == [], "no hay saltos por encima de 3σ")
    ok(volatilidad.saltos(rets, 1.0) != [], "con umbral 1σ sí aparecen saltos (el umbral importa)")

    cierres = [float(f["cierre"]) for f in filas]
    ok(round(min(cierres), 2) == 85.66, "el cierre mínimo es 85,66")
    ok(round(max(cierres), 2) == 102.89, "el cierre máximo es 102,89")

    # El contrato tiene que rechazar de verdad: precio negativo y máximo que no acota.
    malas = [
        {"fecha": "2026-01-01", "apertura": "100", "cierre": "-1", "maximo": "101", "minimo": "99", "volumen": "1"},
        {"fecha": "2026-01-02", "apertura": "100", "cierre": "101", "maximo": "100", "minimo": "99", "volumen": "1"},
    ]
    for i, fila in enumerate(malas, start=1):
        try:
            volatilidad.validar_fila(fila, i)
            ok(False, f"el contrato debería rechazar la fila mala {i}")
        except ValueError:
            ok(True, f"el contrato rechaza la fila mala {i}")

    codigo = (AQUI / "volatilidad.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
