"""P26 · Precios diarios: volatilidad, saltos y caída máxima.

Convierte una serie de precios de cierre en las medidas de riesgo que se piden en un informe: retornos
logarítmicos, volatilidad anualizada, caída máxima y saltos anómalos. Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import math
import statistics
import sys as _sys
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("fecha", "apertura", "cierre", "maximo", "minimo", "volumen")
DIAS_ANIO = 252


def validar_fila(fila: dict, numero: int) -> None:
    # Paso 1b · Aplicar el contrato de una fila. Se expone aparte para poder probar los rechazos.
    apertura, cierre = float(fila["apertura"]), float(fila["cierre"])
    maximo, minimo = float(fila["maximo"]), float(fila["minimo"])
    if min(apertura, cierre, maximo, minimo) <= 0:
        raise ValueError(f"fila {numero}: precios no positivos")
    if not (minimo <= min(apertura, cierre) and maximo >= max(apertura, cierre)):
        raise ValueError(f"fila {numero}: máximo/mínimo no acotan apertura y cierre")


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar el CSV diario: fechas únicas, precios positivos y máximo/mínimo coherentes.
    # Por qué: un precio negativo o un máximo por debajo del cierre rompe cualquier retorno.
    # Salida esperada: 250 filas con las 6 columnas del contrato.
    # Si falla: el mensaje dice qué fila incumple el contrato.
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if not filas:
        raise ValueError("el CSV está vacío")
    fechas = [f["fecha"] for f in filas]
    if len(fechas) != len(set(fechas)):
        raise ValueError("hay fechas repetidas")
    for i, fila in enumerate(filas, start=2):
        validar_fila(fila, i)
    return filas


def retornos(filas: list[dict]) -> list[float]:
    # Paso 2 · Pasar de precios a retornos logarítmicos: ln(P_t / P_{t-1}).
    # Por qué: los logaritmos se suman y son la base de la volatilidad anualizada.
    # Salida esperada: 249 retornos para 250 precios.
    # Si falla: falta un precio o hay un cero.
    cierres = [float(f["cierre"]) for f in filas]
    return [math.log(cierres[i] / cierres[i - 1]) for i in range(1, len(cierres))]


def volatilidad_anual(rets: list[float]) -> float:
    # Paso 3 · Anualizar: desviación típica diaria × sqrt(252).
    # Por qué: una volatilidad diaria no se compara con un año sin escalarla.
    # Salida esperada: 18,483 % anual.
    # Si falla: hay menos de dos retornos.
    return statistics.stdev(rets) * math.sqrt(DIAS_ANIO)


def caida_maxima(filas: list[dict]) -> float:
    # Paso 4 · Medir la peor caída desde un máximo del precio de cierre.
    # Por qué: es la pérdida que sufre quien entra en el peor momento.
    # Salida esperada: −16,746 %.
    # Si falla: la serie está vacía o tiene precios no positivos.
    cierres = [float(f["cierre"]) for f in filas]
    pico, peor = cierres[0], 0.0
    for precio in cierres:
        pico = max(pico, precio)
        peor = min(peor, precio / pico - 1)
    return peor


def saltos(rets: list[float], sigmas: float = 3.0) -> list[int]:
    # Paso 5 · Contar saltos: retornos que se alejan más de 3 desviaciones típicas.
    # Por qué: un salto no es ruido normal; hay que mirarlo antes de hablar de tendencia.
    # Salida esperada: 0 saltos en esta serie sintética.
    # Si falla: el umbral está mal o hay un retorno corrupto.
    desviacion = statistics.stdev(rets)
    return [i for i, r in enumerate(rets, start=2) if abs(r) > sigmas * desviacion]


def main() -> int:
    # Paso 6 · Publicar el resumen y declarar que la serie es sintética.
    # Por qué: sin ese límite, las cifras parecen una recomendación de inversión.
    # Salida esperada: 250 filas, 249 retornos, volatilidad 18,48 %, caída −16,75 %, 0 saltos.
    # Si falla: revisa --csv o si el fichero es el del catálogo.
    parser = argparse.ArgumentParser(description="Volatilidad, saltos y caída máxima (P26)")
    parser.add_argument("--csv", default="datos-ejemplo/precios-accion.csv")
    parser.add_argument("--sigmas", type=float, default=3.0)
    args = parser.parse_args()
    filas = leer(Path(args.csv))
    rets = retornos(filas)
    cierres = [float(f["cierre"]) for f in filas]
    print(f"filas: {len(filas)} · retornos: {len(rets)} · cierres: {min(cierres):.2f}–{max(cierres):.2f}")
    print(f"volatilidad anualizada: {volatilidad_anual(rets):.3%} (sqrt({DIAS_ANIO}))")
    print(f"retorno medio diario: {statistics.mean(rets):.5%} · peor: {min(rets):.2%} · mejor: {max(rets):.2%}")
    print(f"caída máxima: {caida_maxima(filas):.2%}")
    print(f"saltos > {args.sigmas}σ: {len(saltos(rets, args.sigmas))}")
    print("límite: precios sintéticos de 250 días; no es una serie real ni una predicción.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
