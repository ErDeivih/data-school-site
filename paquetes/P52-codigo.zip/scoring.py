#!/usr/bin/env python3
"""P52 · Riesgo de crédito: ratios, scoring y probabilidad de impago — código ejecutable.

Calcula los ratios de crédito, entrena un scoring logístico fuera de muestra, comprueba su calibración
frente a la frecuencia observada y elige el umbral por coste. Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal de datasets/csv/):
    datos-ejemplo/credito-empresas.csv  (300 filas × 8 columnas)

Uso:
    python scoring.py            # calcula y escribe resultados/
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
OBJETIVO = "impago"
VARIABLES = ["deuda_equity", "cobertura_intereses", "liquidez", "margen", "tamano"]
SEMILLA = 20261105
FRACCION_TEST = 0.30
# Coste de cada error, en unidades arbitrarias de negocio y declarado como supuesto. Un falso
# negativo (crédito impagado) cuesta diez veces más que un falso positivo (operación perdida).
COSTO_FALSO_NEGATIVO = 10.0
COSTO_FALSO_POSITIVO = 1.0
ITERACIONES = 6000
TASA_APRENDIZAJE = 0.5
REGULARIZACION = 0.01


# Paso 1 · Carga el CSV y comprueba su forma
# Por qué: la prevalencia y los rangos se declaran antes de modelar; si la clave se repite, hay empresas
#          duplicadas y la tasa de impago deja de ser la del fichero.
# Salida esperada: "credito: 300 filas · 8 columnas · 300 empresas · 27 impagos (9.0 %)"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_credito() -> pd.DataFrame:
    ruta = DATOS / "credito-empresas.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta)
    impagos = int(df[OBJETIVO].sum())
    print(
        f"credito: {len(df)} filas · {df.shape[1]} columnas · {df['empresa'].nunique()} empresas · "
        f"{impagos} impagos ({impagos / len(df):.1%})"
    )
    return df


# Paso 2 · Analiza la señal univariante y los rangos, con n por celda
# Por qué: con 9 % de impago, una línea base que diga «nunca impaga» acierta el 91 % y no detecta a
#          nadie; antes de modelar hay que ver la dirección de cada ratio y cuántos casos hay por tramo.
# Salida esperada: "señal: cuartil de más deuda 22.7 % de impago · cuartil de menos 2.7 %"
# Si falla: un tramo con 0 casos → no se saca tasa; se informa de n.
def analizar_datos(df: pd.DataFrame) -> dict:
    impagos = int(df[OBJETIVO].sum())
    cuartiles = pd.qcut(df["deuda_equity"], 4, labels=["q1", "q2", "q3", "q4"])
    por_cuartil = df.groupby(cuartiles, observed=True)[OBJETIVO].agg(["sum", "count"])
    resumen = {
        "filas": len(df),
        "columnas": int(df.shape[1]),
        "empresas": int(df["empresa"].nunique()),
        "claves_duplicadas": int(df.duplicated(["empresa"]).sum()),
        "impagos": impagos,
        "prevalencia": impagos / len(df),
        "nulos": int(df.isna().sum().sum()),
        "rangos": {
            "deuda_equity": (float(df["deuda_equity"].min()), float(df["deuda_equity"].max())),
            "cobertura_intereses": (float(df["cobertura_intereses"].min()), float(df["cobertura_intereses"].max())),
            "liquidez": (float(df["liquidez"].min()), float(df["liquidez"].max())),
            "margen": (float(df["margen"].min()), float(df["margen"].max())),
            "tamano": (float(df["tamano"].min()), float(df["tamano"].max())),
        },
        "anyo": {int(k): int(v) for k, v in df["anyo"].value_counts().sort_index().items()},
        "cuartiles": {
            "q4_mas_deuda": (int(por_cuartil.loc["q4", "sum"]), int(por_cuartil.loc["q4", "count"])),
            "q1_menos_deuda": (int(por_cuartil.loc["q1", "sum"]), int(por_cuartil.loc["q1", "count"])),
        },
    }
    q4_imp, q4_n = resumen["cuartiles"]["q4_mas_deuda"]
    q1_imp, q1_n = resumen["cuartiles"]["q1_menos_deuda"]
    print(
        f"señal: cuartil de más deuda {q4_imp / q4_n:.1%} de impago · cuartil de menos {q1_imp / q1_n:.1%}"
    )
    return resumen


# Paso 3 · Estandariza y parte la muestra fuera de muestra
# Por qué: la partición se fija con semilla y se declara; el objetivo (`impago`) no entra como variable
#          de entrada, o el modelo aprendería la respuesta. Las escalas se ajustan solo con train.
# Salida esperada: "partición: 210 train · 90 test · 19 impagos en test"
# Si falla: una clase ausente en test → la partición es demasiado pequeña o el objetivo está mal.
def partir_y_estandarizar(df: pd.DataFrame) -> dict:
    generador = np.random.default_rng(SEMILLA)
    y = df[OBJETIVO].to_numpy(dtype=int)
    # Partición estratificada: con 27 positivos, un corte aleatorio simple puede dejar el test con muy
    # pocos impagos y un AUC inestable. Se reparte la misma proporción en train y test.
    positivos = np.where(y == 1)[0]
    negativos = np.where(y == 0)[0]
    generador.shuffle(positivos)
    generador.shuffle(negativos)
    test_idx = np.sort(
        np.concatenate(
            [
                positivos[: int(round(len(positivos) * FRACCION_TEST))],
                negativos[: int(round(len(negativos) * FRACCION_TEST))],
            ]
        )
    )
    train_idx = np.sort(np.setdiff1d(np.arange(len(df)), test_idx))
    X = df[VARIABLES].to_numpy(dtype=float)
    media = X[train_idx].mean(axis=0)
    desviacion = X[train_idx].std(axis=0)
    desviacion[desviacion == 0] = 1.0
    X_estandar = (X - media) / desviacion
    X_estandar = np.column_stack([np.ones(len(df)), X_estandar])
    resultado = {
        "train": train_idx,
        "test": test_idx,
        "X": X_estandar,
        "y": y,
        "media": media,
        "desviacion": desviacion,
        "features": list(VARIABLES),
        "positivos_test": int(y[test_idx].sum()),
    }
    print(
        f"partición: {len(train_idx)} train · {len(test_idx)} test · "
        f"{int(y[test_idx].sum())} impagos en test"
    )
    return resultado


# Paso 4 · Entrena el scoring logístico por descenso de gradiente
# Por qué: se implementa a mano para que se vea la función de pérdida y la regularización; con 27
#          positivos, un modelo con muchas variables sobreajusta y por eso son solo cinco ratios.
# Salida esperada: "scoring: 6 parámetros · pérdida final 0.1372"
# Si falla: probabilidades fuera de [0,1] → el sigmoide o el signo del gradiente están mal.
def _sigmoide(z: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-z))


def entrenar_scoring(particion: dict) -> dict:
    X, y = particion["X"], particion["y"]
    X_train, y_train = X[particion["train"]], y[particion["train"]]
    pesos = np.zeros(X_train.shape[1])
    perdida = np.inf
    for _ in range(ITERACIONES):
        probabilidad = _sigmoide(X_train @ pesos)
        perdida = float(
            -np.mean(y_train * np.log(probabilidad + 1e-12) + (1 - y_train) * np.log(1 - probabilidad + 1e-12))
        )
        gradiente = X_train.T @ (probabilidad - y_train) / len(y_train)
        gradiente[1:] += REGULARIZACION * pesos[1:]
        pesos -= TASA_APRENDIZAJE * gradiente
    probabilidades = _sigmoide(X @ pesos)
    resultado = {"pesos": pesos, "perdida": perdida, "probabilidades": probabilidades}
    print(f"scoring: {len(pesos)} parámetros · pérdida final {perdida:.4f}")
    return resultado


# Paso 5 · Calibra por tramos y mide el Brier
# Por qué: una probabilidad no es una etiqueta; se compara la probabilidad declarada con la frecuencia
#          observada en cada tramo, con su n, y se mide el Brier frente a la línea base.
# Salida esperada: "calibración: 4 tramos · Brier 0.0712 (base 0.0834)"
# Si falla: un tramo con n=0 → se descarta y se informa; no se inventan frecuencias.
def calibrar(probabilidades: np.ndarray, y: np.ndarray) -> tuple[pd.DataFrame, dict]:
    bordes = np.array([0.0, 0.05, 0.10, 0.20, 0.40, 1.0])
    tramo = pd.cut(probabilidades, bordes, include_lowest=True, right=False)
    tabla = (
        pd.DataFrame({"probabilidad": probabilidades, "impago": y, "tramo": tramo})
        .groupby("tramo", observed=True)
        .agg(n=("impago", "size"), prob_media=("probabilidad", "mean"), frecuencia=("impago", "mean"))
        .reset_index()
    )
    tabla["tramo"] = tabla["tramo"].astype(str)
    brier = float(np.mean((probabilidades - y) ** 2))
    base = float(np.mean((y.mean() - y) ** 2))
    resumen = {"brier": brier, "brier_base": base, "tramos": int(len(tabla)), "n_total": int(tabla["n"].sum())}
    print(f"calibración: {len(tabla)} tramos · Brier {brier:.4f} (base {base:.4f})")
    return tabla, resumen


# Paso 6 · Elige el umbral por coste esperado
# Por qué: el 0,5 por defecto no significa nada; con un coste declarado para cada error se barre el
#          umbral y se elige el de menor coste, mostrando también el coste del corte clásico.
# Salida esperada: "umbral: 0.23 · coste 46 · coste en 0.5 103"
# Si falla: el barrido no cubre 0,5 o los costes no son positivos → revisa los supuestos de negocio.
def elegir_umbral(probabilidades: np.ndarray, y: np.ndarray, coste_fn: float, coste_fp: float) -> tuple[pd.DataFrame, dict]:
    umbrales = np.round(np.arange(0.01, 0.991, 0.01), 2)
    filas = []
    for umbral in umbrales:
        predicho = (probabilidades >= umbral).astype(int)
        falso_negativo = int(((predicho == 0) & (y == 1)).sum())
        falso_positivo = int(((predicho == 1) & (y == 0)).sum())
        filas.append(
            {
                "umbral": float(umbral),
                "falsos_negativos": falso_negativo,
                "falsos_positivos": falso_positivo,
                "coste": falso_negativo * coste_fn + falso_positivo * coste_fp,
            }
        )
    tabla = pd.DataFrame(filas)
    mejor = tabla.loc[tabla["coste"].idxmin()]
    corte_05 = tabla.loc[np.isclose(tabla["umbral"], 0.5)].iloc[0]
    elegido = float(mejor["umbral"])
    predicho = (probabilidades >= elegido).astype(int)
    resumen = {
        "umbral": elegido,
        "coste": float(mejor["coste"]),
        "coste_05": float(corte_05["coste"]),
        "verdaderos_positivos": int(((predicho == 1) & (y == 1)).sum()),
        "falsos_positivos": int(((predicho == 1) & (y == 0)).sum()),
        "falsos_negativos": int(((predicho == 0) & (y == 1)).sum()),
        "verdaderos_negativos": int(((predicho == 0) & (y == 0)).sum()),
        "coste_fn": coste_fn,
        "coste_fp": coste_fp,
    }
    print(f"umbral: {elegido:.2f} · coste {resumen['coste']:.0f} · coste en 0.5 {resumen['coste_05']:.0f}")
    return tabla, resumen


# Paso 7 · Mide AUC fuera de muestra
# Por qué: la exactitud engaña con 9 % de impago; el AUC mide si el scoring ordena a los buenos por
#          delante de los malos, y se calcula por rangos sin dependencias extra.
# Salida esperada: "AUC fuera de muestra: 0.8421"
# Si falla: AUC ≈ 0,5 → el modelo no ordena mejor que el azar.
def auc(y: np.ndarray, probabilidades: np.ndarray) -> float:
    orden = np.argsort(probabilidades)
    rangos = np.empty(len(probabilidades), dtype=float)
    rangos[orden] = np.arange(1, len(probabilidades) + 1)
    positivos = int(y.sum())
    negativos = int(len(y) - positivos)
    if positivos == 0 or negativos == 0:
        return float("nan")
    return float((rangos[y == 1].sum() - positivos * (positivos + 1) / 2) / (positivos * negativos))


def texto_informe(datos: dict, calibracion: dict, umbral: dict, auc_test: float) -> str:
    lineas = [
        "# P52 · Riesgo de crédito: ratios, scoring y probabilidad de impago",
        "",
        f"Muestra: {datos['filas']} empresas de práctica (CC0-1.0) con {datos['impagos']} impagos "
        f"({datos['prevalencia']:.1%}). Una línea base que diga «nunca impaga» acierta el "
        f"{1 - datos['prevalencia']:.1%} y no detecta a nadie.",
        "",
        "## Ratios y señal",
        f"- Deuda/equity: {datos['rangos']['deuda_equity'][0]:.2f}–{datos['rangos']['deuda_equity'][1]:.2f}.",
        f"- Cobertura de intereses: {datos['rangos']['cobertura_intereses'][0]:.2f}–"
        f"{datos['rangos']['cobertura_intereses'][1]:.2f} veces.",
        f"- Liquidez: {datos['rangos']['liquidez'][0]:.2f}–{datos['rangos']['liquidez'][1]:.2f}.",
        f"- Margen: {datos['rangos']['margen'][0]:.1f}–{datos['rangos']['margen'][1]:.1f} %.",
        f"- Tamaño: {datos['rangos']['tamano'][0]:.1f}–{datos['rangos']['tamano'][1]:.1f} M€ de ingresos.",
        f"- El cuartil de más deuda impaga {datos['cuartiles']['q4_mas_deuda'][0]}/"
        f"{datos['cuartiles']['q4_mas_deuda'][1]} y el de menos, {datos['cuartiles']['q1_menos_deuda'][0]}/"
        f"{datos['cuartiles']['q1_menos_deuda'][1]}.",
        "- `anyo` está en ciclo 2021–2025: no es una serie por empresa, así que la validación es aleatoria.",
        "",
        "## Scoring y calibración",
        f"- AUC fuera de muestra: {auc_test:.4f}.",
        f"- Brier del modelo {calibracion['brier']:.4f} frente a la línea base {calibracion['brier_base']:.4f}.",
        f"- Calibración por tramos con n; {calibracion['tramos']} tramos y "
        f"{datos['impagos']} positivos: la resolución es gruesa y se dice.",
        "",
        "## Umbral por coste",
        f"- Coste supuesto: falso negativo ×{umbral['coste_fn']:.0f} y falso positivo ×{umbral['coste_fp']:.0f}. "
        "Es un supuesto de negocio, no un dato del CSV.",
        f"- Umbral elegido {umbral['umbral']:.2f}: coste {umbral['coste']:.0f} frente a "
        f"{umbral['coste_05']:.0f} del corte 0,5.",
        f"- Matriz de confusión en test: {umbral['verdaderos_positivos']} VP, {umbral['falsos_positivos']} FP, "
        f"{umbral['falsos_negativos']} FN y {umbral['verdaderos_negativos']} VN.",
        "",
        "## Límite",
        "La muestra es de práctica y sintética: no es un sistema de concesión de crédito. Con 27 positivos",
        "la calibración es gruesa y los intervalos son anchos. El contraste real se haría con los estados",
        "financieros de la SEC (empresas de EE. UU.); no hay API gratuita verificable de impagos españoles.",
        "No se afirma causalidad ni se presenta el umbral como una recomendación.",
        "",
    ]
    return "\n".join(lineas)


def main() -> int:
    df = cargar_credito()
    datos = analizar_datos(df)
    particion = partir_y_estandarizar(df)
    modelo = entrenar_scoring(particion)
    test_idx = particion["test"]
    probabilidades_test = modelo["probabilidades"][test_idx]
    y_test = particion["y"][test_idx]
    tabla_calibracion, resumen_calibracion = calibrar(probabilidades_test, y_test)
    tabla_umbral, resumen_umbral = elegir_umbral(probabilidades_test, y_test, COSTO_FALSO_NEGATIVO, COSTO_FALSO_POSITIVO)
    auc_test = auc(y_test, probabilidades_test)
    RESULTADOS.mkdir(exist_ok=True)
    pd.DataFrame(
        {
            "empresa": df["empresa"],
            "impago": df[OBJETIVO],
            "probabilidad": modelo["probabilidades"],
            "particion": np.where(np.isin(np.arange(len(df)), test_idx), "test", "train"),
        }
    ).to_csv(RESULTADOS / "scoring.csv", index=False)
    tabla_calibracion.to_csv(RESULTADOS / "calibracion.csv", index=False)
    tabla_umbral.to_csv(RESULTADOS / "umbrales.csv", index=False)
    (RESULTADOS / "informe.md").write_text(
        texto_informe(datos, resumen_calibracion, resumen_umbral, auc_test), encoding="utf-8"
    )
    print(f"escrito: {RESULTADOS / 'scoring.csv'} · calibracion.csv · umbrales.csv · informe.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
