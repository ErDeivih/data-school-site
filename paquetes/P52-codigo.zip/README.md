# P52 · Riesgo de crédito: ratios, scoring y probabilidad de impago — código ejecutable

Convierte cinco ratios de crédito en una probabilidad de impago: entrena un scoring logístico fuera de
muestra, comprueba la calibración frente a la frecuencia observada y elige el umbral por coste esperado.
Es el código que acompaña a la ficha
`../../fichas-ideas/p52-riesgo-de-credito.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** (BSD-3-Clause) y **numpy >= 1.26** (BSD-3-Clause).
- Windows, Linux o macOS: sin red ni servicios externos.

## Instalación

```powershell
cd proyectos/p52-riesgo-de-credito/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python scoring.py
```

Recorre los pasos, imprime una línea por paso y escribe en `resultados/` los ficheros `scoring.csv`,
`calibracion.csv`, `umbrales.csv` e `informe.md`. Los generados no viajan en el ZIP: solo
`ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: 300 filas, 8 columnas, 27 impagos (9,0 %), los rangos
de los ratios, la señal por cuartiles de deuda (17/75 frente a 2/75), la partición estratificada 210/90
con 8 impagos en test, el scoring de 6 parámetros, el AUC fuera de muestra (0,7759), la calibración en 5
tramos con Brier 0,0705 frente a 0,0810 de la base, y el umbral por coste (0,08: coste 38 frente a 70
del corte 0,5). Termina en `RESULTADO: VERDE` (0) o `RESULTADO: ROJO` (1). No usa red. La salida real
está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/credito-empresas.csv`: **300 filas × 8 columnas** (`empresa`, `anyo`, `deuda_equity`,
  `cobertura_intereses`, `liquidez`, `margen`, `tamano`, `impago`). Cada empresa aparece una vez;
  `anyo` está en ciclo 2021–2025 y **no forma una serie temporal por empresa**.
- **Sintético, determinista y CC0-1.0**: copia literal de `datasets/csv/`, con
  `sha256:9a9ceb45d6d077d1916ff3f34a3db8e70cfd2be77baa62f704d52e9c8eec4926`; tamaño y columnas en
  `datasets-nuevos-2026-11-05.json`.
- El CSV **no trae** sector, país, rating, colateral, historial de impagos, importe de la deuda ni
  fechas: no se puede comparar por industria ni construir una PD de cartera real.

## Fuente real y licencia

- **Contraste real:** `sec-edgar` (<https://data.sec.gov/api/xbrl/>), sin clave; contenido del Gobierno
  de EE. UU. reutilizable citando a la SEC. Los mismos ratios se aplicarían a los estados de empresas de
  EE. UU., y el informe lo documenta como trabajo aparte.
- **No hay** API gratuita verificable de impagos españoles en el catálogo; no se finge una.
- Dependencias: pandas BSD-3-Clause, numpy BSD-3-Clause.

## Supuestos declarados

- **Coste de los errores:** falso negativo (crédito impagado) ×10 y falso positivo (operación perdida)
  ×1. Es un supuesto de negocio, no un dato del CSV; cambiarlo cambia el umbral.
- **Partición:** 30 % test estratificado con semilla 20261105; con 27 positivos, la validación es
  aleatoria y no temporal, porque `anyo` no es una serie por empresa.
- **Modelo:** regresión logística con cinco ratios estandarizados con la media y desviación de train;
  `impago` no entra como variable y no se añaden más variables para no sobreajustar 27 positivos.
- **Calibración:** tramos fijos con n a la vista; con 27 positivos la resolución es gruesa y se dice.
- **Sin causalidad:** el scoring ordena, no demuestra que un ratio cause el impago.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y prevalencia | Clase minoritaria y línea base honesta | `Desbalanceo de clases` |
| 2 · Ratios y cuartiles | Unidades y señal univariante con n | `Datos de mercado y acciones corporativas` |
| 3 · Partición fuera de muestra | Train/test reproducible y sin fuga | `Train, validación y test` |
| 4 · Scoring logístico | Función de pérdida, sigmoide y regularización | `GLM y regresión logística` |
| 5 · Calibración y Brier | Probabilidad frente a frecuencia observada | `Calibración` |
| 6 · Umbral por coste | Elegir el corte por coste, no por 0,5 | `Umbrales y coste` |
| 7 · Matriz de confusión | Leer VP, FP, FN y VN con 9 % de impago | `Matriz de confusión` |

## Estructura

```text
codigo/
├── scoring.py             # ratios, partición, logística, calibración, umbral e informe
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas y numpy
├── datos-ejemplo/         # credito-empresas.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **Mirar solo la exactitud:** con 9 % de impago, acertar el 91 % es no detectar a nadie; usa AUC,
  precisión y recall.
- **Umbral fijo 0,5:** sin costes declarados ese corte no significa nada; el barrido lo demuestra.
- **Diez tramos de calibración:** 27 positivos no llenan diez bins; pocos tramos y con n.
- **`anyo` como serie temporal:** no hay panel por empresa; una validación por años sería inventada.
- **Fuga del objetivo:** incluir `impago` entre las variables hace que el modelo parezca perfecto.
- **`ModuleNotFoundError: pandas`**: instala las dependencias con el mismo Python que ejecuta el script.
