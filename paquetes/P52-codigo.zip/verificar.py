#!/usr/bin/env python3
"""Puerta del proyecto P52 · riesgo de crédito: ratios, scoring y probabilidad de impago.

Recalcula la prevalencia y los rangos, la señal por cuartiles, la partición fuera de muestra, el scoring
logístico, la calibración por tramos, el AUC y el umbral por coste. No usa red y **no escribe
ficheros**: solo calcula y saca conclusiones por stdout.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import scoring

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P52 · riesgo de crédito y scoring ==")

    # Paso 1 · Comprueba la muestra y la prevalencia antes de modelar
    # Por qué: con 9 % de impago, la exactitud engaña; la prevalencia se declara y se comprueba primero.
    # Salida esperada: "datos: 300 filas · 8 columnas · 27 impagos (9.0 %)"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    df = scoring.cargar_credito()
    datos = scoring.analizar_datos(df)
    ok((datos["filas"], datos["columnas"], datos["empresas"]) == (300, 8, 300), "datos: 300 filas · 8 columnas · 300 empresas")
    ok(datos["claves_duplicadas"] == 0 and datos["nulos"] == 0, "empresa única y sin nulos")
    ok(
        datos["impagos"] == 27 and abs(datos["prevalencia"] - 0.09) < 1e-12,
        f"prevalencia: {datos['impagos']}/300 = {datos['prevalencia']:.1%}",
    )

    # Paso 2 · Comprueba rangos, señal por cuartiles y que `anyo` no es una serie
    # Por qué: los rangos fijan las unidades y los cuartiles muestran la dirección de la señal; el año
    #          en ciclo impide una validación temporal y se declara.
    # Salida esperada: "rangos: 0.15–3.73 · cobertura 0.80–11.78 · cuartiles 17/75 y 2/75"
    # Si falla: un rango distinto → el CSV no es el original.
    ok(
        abs(datos["rangos"]["deuda_equity"][0] - 0.15) < 1e-9 and abs(datos["rangos"]["deuda_equity"][1] - 3.73) < 1e-9,
        f"deuda/equity: {datos['rangos']['deuda_equity']}",
    )
    ok(
        abs(datos["rangos"]["cobertura_intereses"][0] - 0.80) < 1e-9
        and abs(datos["rangos"]["cobertura_intereses"][1] - 11.78) < 1e-9,
        f"cobertura: {datos['rangos']['cobertura_intereses']}",
    )
    ok(datos["cuartiles"]["q4_mas_deuda"] == (17, 75) and datos["cuartiles"]["q1_menos_deuda"] == (2, 75),
       f"cuartiles de deuda: {datos['cuartiles']}")
    ok(
        datos["anyo"] == {2021: 60, 2022: 60, 2023: 60, 2024: 60, 2025: 60},
        f"anyo en ciclo 2021–2025 (60 por año): {datos['anyo']}",
    )

    # Paso 3 · Comprueba la partición estratificada y que no hay fuga del objetivo
    # Por qué: `impago` no puede ser una variable de entrada y la partición debe ser reproducible con
    #          semilla; con 27 positivos el test necesita positivos suficientes para medir algo.
    # Salida esperada: "partición: 210 train · 90 test · 8 impagos en test"
    # Si falla: las dos particiones se solapan o suman distinto de 300.
    particion = scoring.partir_y_estandarizar(df)
    train, test = particion["train"], particion["test"]
    ok(len(train) + len(test) == 300 and len(np.intersect1d(train, test)) == 0, "partición disjunta y completa: 210 + 90 = 300")
    ok((len(train), len(test)) == (210, 90), f"tamaños: {len(train)} train · {len(test)} test")
    ok(particion["positivos_test"] == 8, f"impagos en test: {particion['positivos_test']}")
    ok("impago" not in particion["features"], "el objetivo no entra como variable de entrada")

    # Paso 4 · Entrena el scoring y comprueba que ordena mejor que el azar
    # Por qué: el AUC fuera de muestra mide la ordenación; un modelo que no supera el azar no sirve.
    # Salida esperada: "AUC fuera de muestra: 0.7759"
    # Si falla: AUC ≈ 0,5 → el scoring no distingue impagos de buenos.
    modelo = scoring.entrenar_scoring(particion)
    probabilidades = modelo["probabilidades"]
    ok(bool(((probabilidades >= 0) & (probabilidades <= 1)).all()), "las probabilidades están en [0, 1]")
    y_test = particion["y"][test]
    probabilidades_test = probabilidades[test]
    auc_test = scoring.auc(y_test, probabilidades_test)
    ok(abs(auc_test - 0.7759146341463414) < 1e-9 and auc_test > 0.6, f"AUC fuera de muestra: {auc_test:.4f}")

    # Paso 5 · Comprueba la calibración por tramos y el Brier
    # Por qué: una probabilidad no es una etiqueta; se compara con la frecuencia observada en cada
    #          tramo, con su n, y se mide el Brier frente a la línea base.
    # Salida esperada: "calibración: 5 tramos · Brier 0.0705 (base 0.0810)"
    # Si falla: los tramos no cubren el test o el Brier del modelo no mejora la base.
    tabla_calibracion, calibracion = scoring.calibrar(probabilidades_test, y_test)
    ok(calibracion["tramos"] == 5 and calibracion["n_total"] == 90, f"calibración: {calibracion['tramos']} tramos con n total {calibracion['n_total']}")
    ok(calibracion["brier"] < calibracion["brier_base"], f"Brier {calibracion['brier']:.4f} < base {calibracion['brier_base']:.4f}")
    frecuencia_manual = float(tabla_calibracion["n"].mul(tabla_calibracion["frecuencia"]).sum() / tabla_calibracion["n"].sum())
    ok(abs(frecuencia_manual - y_test.mean()) < 1e-9, "la frecuencia de los tramos reconstruye la del test")
    ok(bool((tabla_calibracion["n"] > 0).all()), "cada tramo informa de su n y ninguno está vacío")

    # Paso 6 · Comprueba el umbral por coste y la matriz de confusión
    # Por qué: el umbral se elige por coste declarado, no por 0,5; el coste debe poder recalcularse.
    # Salida esperada: "umbral: 0.08 · coste 38 · coste en 0.5 70"
    # Si falla: el coste del umbral elegido es mayor que el del corte 0,5 → el barrido está mal.
    tabla_umbral, umbral = scoring.elegir_umbral(probabilidades_test, y_test, scoring.COSTO_FALSO_NEGATIVO, scoring.COSTO_FALSO_POSITIVO)
    ok(abs(umbral["umbral"] - 0.08) < 1e-9, f"umbral elegido: {umbral['umbral']:.2f}")
    ok(
        abs(umbral["coste"] - (umbral["falsos_negativos"] * 10 + umbral["falsos_positivos"] * 1)) < 1e-9
        and umbral["coste"] <= umbral["coste_05"],
        f"coste {umbral['coste']:.0f} ≤ coste en 0,5 {umbral['coste_05']:.0f}",
    )
    confusion = umbral["verdaderos_positivos"] + umbral["falsos_positivos"] + umbral["falsos_negativos"] + umbral["verdaderos_negativos"]
    ok(confusion == len(test), f"la matriz de confusión suma el test: {confusion} = {len(test)}")
    ok(umbral["falsos_negativos"] == 1 and umbral["falsos_positivos"] == 28, "confusión en test: 7 VP · 28 FP · 1 FN · 54 VN")

    # Paso 7 · Comprueba que el informe declara el límite y el coste
    # Por qué: sin coste, umbral y límite, el scoring parece una decisión de crédito cuando es práctica.
    # Salida esperada: "el informe declara 27 positivos, coste, SEC y límite"
    # Si falla: el informe presenta el modelo como un sistema real o no menciona el contraste.
    informe = scoring.texto_informe(datos, calibracion, umbral, auc_test)
    ok("27" in informe and "coste" in informe.lower(), "el informe declara los 27 positivos y el coste")
    ok("SEC" in informe and "Límite" in informe and "sintética" in informe, "el informe declara el contraste real y el límite")
    ok("no es un sistema de concesión de crédito" in informe, "el informe no presenta el scoring como un sistema real")

    # Paso 8 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (scoring.RAIZ / "scoring.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
