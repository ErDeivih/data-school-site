# P71 · Sensores: la deriva que avisa

Paquete descargable de **Data School** para el proyecto P71. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es si una alerta de sensor puede avisar **antes** de la avería. Con 120
horas de referencia y 120 de vigilancia, el código marca las horas fuera de ±3σ: encuentra **18
alertas**, la primera en la hora **150**… la misma en la que empieza la avería. El resultado honesto
es que **este CSV no permite aviso temprano**: la alerta detecta el cambio, no lo anticipa.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python deriva.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P71-codigo
python deriva.py --csv datos-ejemplo/sensores-planta.csv
```

## Salida esperada

```text
datos: 240 horas · referencia 0–119 · vigilancia 120–239
referencia: temperatura 71.07 ± 4.01 · presión 4.00 ± 0.28
alertas |z| ≥ 3: 18 horas
primera alerta: hora 150 · temperatura (z +4.30)
averías declaradas: 18 · primera a la hora 150
la alerta llega con la avería, no antes: este CSV no permite aviso temprano
lectura: la alerta no adivina la avería; detecta que el sensor se sale de su rango normal.
límite: 240 horas sintéticas de un solo sensor; no hay estacionalidad, mantenimiento ni falsos
positivos de varios equipos.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/sensores-planta.csv`: **240 filas × 4 columnas**. Hora, temperatura, presión y
  estado (parada, marcha, avería); 18 horas de avería.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `sensores-planta` del catálogo.
- `sha256`: `151ed407852ef5ae874afeb18302fa9300a58f090f1302c876422f30732617aa`.

## Qué enseña

| Paso | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida 240 horas en orden y estados | una hora repetida rompe la serie |
| 2 · Referencia | media y desviación de las 120 primeras horas | la alerta se define contra lo normal |
| 3 · Alertas | z-score de cada hora de vigilancia | un umbral explícito, no una impresión |
| 4 · Lectura | compara la primera alerta con la avería | detectar no es anticipar |

## Las trampas que deja a la vista

1. **Un umbral sin referencia no significa nada.** ±3σ se calcula con las primeras 120 horas; si se
   usara todo el CSV, la avería contaminaría la referencia y la alerta desaparecería.
2. **Detectar no es anticipar.** La primera alerta coincide con la primera avería (0 h de ventaja);
   el paquete lo dice en lugar de vender «mantenimiento predictivo».
3. **Dos variables, una alerta.** Se dispara con temperatura **o** presión, pero se registra cuál;
   sin esa distinción no se sabe qué revisar.

## Fallos típicos

- **`ModuleNotFoundError: deriva`**: ejecuta desde la carpeta del paquete.
- **`las horas no van de 0 a 239 en orden`**: el CSV está desordenado o le falta una hora.
- **`constante en la referencia`**: la serie no tiene variación y el z-score no está definido.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P71-codigo/
├── deriva.py                  # referencia, z-scores y alertas
├── verificar.py               # 15 comprobaciones
├── requirements.txt
├── datos-ejemplo/sensores-planta.csv
└── resultados/ejemplo-salida.txt
```

## Límite

240 horas sintéticas de un solo sensor; no hay estacionalidad, mantenimiento, varios equipos ni
falsos positivos. El paquete enseña a definir y leer una alerta, y a decir cuándo **no** permite
anticiparse.
