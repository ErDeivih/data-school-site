#!/usr/bin/env python3
"""Puerta del proyecto P71 (sensores: la deriva que avisa).

Comprueba referencia, alertas, relación con la avería y ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import deriva

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "sensores-planta.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.2f} ≈ {esperado:.2f})")


def main() -> int:
    filas = deriva.leer(CSV)
    ok(len(filas) == 240, "el CSV tiene 240 horas")
    ok([int(f["hora"]) for f in filas] == list(range(240)), "las horas van de 0 a 239")
    ok(sum(1 for f in filas if f["estado"] == "averia") == 18, "hay 18 horas de avería")

    base = deriva.referencia(filas)
    cerca(base["temperatura"][0], 71.07, 0.05, "temperatura media de referencia")
    cerca(base["temperatura"][1], 4.01, 0.05, "desviación de temperatura de referencia")
    cerca(base["presion"][0], 4.00, 0.01, "presión media de referencia")
    cerca(base["presion"][1], 0.28, 0.01, "desviación de presión de referencia")

    avisos = deriva.alertas(filas, base)
    ok(len(avisos) == 18, "se marcan 18 horas fuera de ±3σ")
    ok(avisos[0]["hora"] == 150, "la primera alerta es la hora 150")
    ok(avisos[0]["variable"] == "temperatura", "la primera alerta viene de la temperatura")
    cerca(avisos[0]["z"], 4.30, 0.05, "z de la primera alerta")
    averias = [int(f["hora"]) for f in filas if f["estado"] == "averia"]
    ok(averias[0] == 150, "la primera avería es la hora 150")
    ok(averias[0] - avisos[0]["hora"] == 0, "con este CSV no hay ventaja: alerta y avería coinciden")

    codigo = (AQUI / "deriva.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
