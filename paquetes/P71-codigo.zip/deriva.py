"""P71 · Sensores: la deriva que avisa.

Compara 120 horas de referencia con las 120 siguientes, calcula z-scores de temperatura y presión y
marca las horas que se salen de ±3σ: la alerta llega antes de la avería. Sin librerías.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("hora", "temperatura", "presion", "estado")
CORTE = 120
UMBRAL = 3.0


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: 240 horas, estado conocido y valores numéricos.
    # Por qué: una hora repetida o un estado nuevo rompe la línea temporal de la alerta.
    # Salida esperada: 240 filas (120 de referencia + 120 de vigilancia).
    # Si falla: «columnas inesperadas», horas fuera de 0..239 o estado desconocido.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 240:
        raise ValueError(f"se esperaban 240 horas, hay {len(filas)}")
    if [int(f["hora"]) for f in filas] != list(range(240)):
        raise ValueError("las horas no van de 0 a 239 en orden")
    for fila in filas:
        if fila["estado"] not in ("parada", "marcha", "averia"):
            raise ValueError(f"estado desconocido: {fila['estado']}")
        float(fila["temperatura"]); float(fila["presion"])
    return filas


def referencia(filas: list[dict]) -> dict:
    # Paso 2 · Media y desviación de las primeras 120 horas, por variable.
    # Por qué: la alerta se define contra el comportamiento normal, no contra un umbral inventado.
    # Salida esperada: media y desviación de temperatura y presión.
    # Si falla: la referencia no tiene desviación (serie constante).
    base = filas[:CORTE]
    salida = {}
    for columna in ("temperatura", "presion"):
        valores = [float(f[columna]) for f in base]
        media = sum(valores) / len(valores)
        sd = math.sqrt(sum((v - media) ** 2 for v in valores) / (len(valores) - 1))
        if sd == 0:
            raise ValueError(f"{columna} constante en la referencia")
        salida[columna] = (media, sd)
    return salida


def alertas(filas: list[dict], base: dict) -> list[dict]:
    # Paso 3 · z-score en las 120 horas de vigilancia; alerta si temperatura o presión superan ±3σ.
    # Por qué: una sola variable puede fallar; la alerta se dispara con cualquiera de las dos.
    # Salida esperada: lista de horas con su variable, z y estado.
    salida = []
    for fila in filas[CORTE:]:
        for columna in ("temperatura", "presion"):
            media, sd = base[columna]
            z = (float(fila[columna]) - media) / sd
            if abs(z) >= UMBRAL:
                salida.append({"hora": int(fila["hora"]), "variable": columna,
                               "z": z, "estado": fila["estado"]})
                break
    return salida


def main() -> int:
    parser = argparse.ArgumentParser(description="P71 · deriva de sensores y alerta temprana")
    parser.add_argument("--csv", default="datos-ejemplo/sensores-planta.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    base = referencia(filas)
    avisos = alertas(filas, base)
    averias = [f for f in filas if f["estado"] == "averia"]
    primera_averia = int(averias[0]["hora"]) if averias else None
    primera_alerta = avisos[0]["hora"] if avisos else None
    print(f"datos: {len(filas)} horas · referencia 0–119 · vigilancia 120–239")
    print(f"referencia: temperatura {base['temperatura'][0]:.2f} ± {base['temperatura'][1]:.2f} · "
          f"presión {base['presion'][0]:.2f} ± {base['presion'][1]:.2f}")
    print(f"alertas |z| ≥ {UMBRAL:.0f}: {len(avisos)} horas")
    if avisos:
        print(f"primera alerta: hora {primera_alerta} · {avisos[0]['variable']} (z {avisos[0]['z']:+.2f})")
    print(f"averías declaradas: {len(averias)} · primera a la hora {primera_averia}")
    if primera_alerta is not None and primera_averia is not None:
        ventaja = primera_averia - primera_alerta
        print(f"ventaja de la alerta: {ventaja} h antes de la primera avería" if ventaja > 0
              else "la alerta llega con la avería, no antes: este CSV no permite aviso temprano")
    print("lectura: la alerta no adivina la avería; detecta que el sensor se sale de su rango normal.")
    print("límite: 240 horas sintéticas de un solo sensor; no hay estacionalidad, mantenimiento ni "
          "falsos positivos de varios equipos.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
