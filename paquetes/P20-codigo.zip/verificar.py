#!/usr/bin/env python3
"""Puerta del proyecto P20 (ingesta y modelo en estrella del fútbol).

Comprueba de verdad el resultado: grano del origen (y su trampa), dimensiones, hecho, integridad
referencial, cuadre de totales entre origen y hecho, clasificación construida desde el hecho, los
CSV escritos y la reproducibilidad byte a byte. Sin red.

VERDE (código 0) solo si todo pasa; ROJO (código 1) si algo falla.
"""
from __future__ import annotations

import csv
import hashlib
import json
import sys as _sys
import tempfile
from pathlib import Path

import estrella

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "futbol-partidos.csv"
VERSION = "1.0.0"
MANIFIESTO = AQUI / "paquete.json"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def leer_csv(ruta: Path) -> list[dict]:
    with ruta.open(encoding="utf-8", newline="") as archivo:
        return list(csv.DictReader(archivo))


def hash_fichero(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def main() -> int:
    # Paso 0 · La ficha, el manifiesto del ZIP y el verificador declaran la misma versión.
    ok(MANIFIESTO.is_file(), "el paquete incluye su manifiesto paquete.json")
    if MANIFIESTO.is_file():
        manifiesto = json.loads(MANIFIESTO.read_text(encoding="utf-8-sig"))
        ok(manifiesto.get("id") == "P20" and manifiesto.get("version") == VERSION,
           f"la ficha, el manifiesto y el verificador comparten la versión {VERSION}")

    # Paso 1 · Grano del origen: una fila por partido, no por gol.
    filas = estrella.leer(CSV)
    ok(len(filas) == 380, "el origen tiene 380 filas")
    ok(len(filas[0]) == 12, "el origen tiene 12 columnas")
    auditoria = estrella.auditar_origen(filas)
    ok(len(auditoria["equipos"]) == 20, "hay 20 equipos")
    ok(len(auditoria["jornadas"]) == 38, "hay 38 jornadas")
    ok(set(auditoria["partidos_por_jornada"].values()) == {10}, "cada jornada tiene 10 partidos")
    ok(auditoria["claves_jornada_local"] == 380, "la clave (jornada, local) es única en las 380 filas")

    # Paso 2 · La trampa del grano: (local, visitante) NO identifica un partido.
    ok(len(auditoria["pares_local_visitante"]) == 20, "solo hay 20 emparejamientos (local, visitante) distintos")
    ok(set(auditoria["repeticiones_par"]) == {19}, "cada emparejamiento se repite 19 veces")
    ok(auditoria["nulos"] == 0, "el origen no tiene celdas vacías")
    ok(auditoria["resultados_coherentes"] == 380, "el resultado 1/X/2 cuadra con los goles en las 380 filas")

    # Paso 3 · Dimensiones: equipo y jornada, con clave sustituta.
    dim_equipo, dim_jornada = estrella.construir_dimensiones(filas)
    ok(len(dim_equipo) == 20, "dim_equipo tiene 20 filas")
    ok({d["id_equipo"] for d in dim_equipo} == {str(i) for i in range(1, 21)},
       "dim_equipo tiene claves sustitutas 1..20")
    ok({d["equipo"] for d in dim_equipo} == set(auditoria["equipos"]), "dim_equipo conserva los 20 nombres")
    ok(len(dim_jornada) == 38, "dim_jornada tiene 38 filas")
    ok({d["jornada"] for d in dim_jornada} == {str(j) for j in range(1, 39)},
       "dim_jornada cubre las jornadas 1..38")
    ok(sum(1 for d in dim_jornada if d["tramo"] == "primera-vuelta") == 19 and
       sum(1 for d in dim_jornada if d["tramo"] == "segunda-vuelta") == 19,
       "dim_jornada reparte 19 + 19 jornadas en dos tramos derivados")
    ok(all(d["partidos"] == "10" for d in dim_jornada), "dim_jornada declara 10 partidos por jornada")

    # Paso 4 · Hecho: una fila por partido, con claves ajenas y medidas.
    hecho = estrella.construir_hecho(filas, dim_equipo)
    ok(len(hecho) == 380, "el hecho tiene 380 filas, una por partido")
    ok(len({h["id_partido"] for h in hecho}) == 380, "id_partido es único")
    ok({h["id_partido"] for h in hecho} == {str(i) for i in range(1, 381)},
       "id_partido va de 1 a 380")
    ok(all(h["id_equipo_local"] in {d["id_equipo"] for d in dim_equipo} for h in hecho),
       "todas las claves de equipo local existen en dim_equipo")
    ok(all(h["id_jornada"] in {d["id_jornada"] for d in dim_jornada} for h in hecho),
       "todas las claves de jornada existen en dim_jornada")

    # Paso 5 · Integridad y grano del hecho.
    integridad = estrella.comprobar_integridad(dim_equipo, dim_jornada, hecho)
    ok(integridad["huerfanas"] == 0, "el hecho no tiene claves huérfanas")
    ok(integridad["grano_local"] == 380 and integridad["grano_visitante"] == 380,
       "el grano del hecho es un partido: 380 claves (jornada, local) y 380 (jornada, visitante)")
    ok(set(integridad["apariciones"].values()) == {38}, "cada equipo aparece 38 veces en el hecho")

    # Paso 6 · Cuadre de totales entre el origen y el hecho: 0 diferencias.
    cuadre = estrella.cuadrar(filas, hecho)
    ok(cuadre["diferencias"]["partidos"] == 0, "el número de partidos cuadra (380)")
    ok(cuadre["origen"]["goles"] == 717 and cuadre["hecho"]["goles"] == 717, "los goles cuadran: 717")
    ok(cuadre["origen"]["goles_local"] == 419 and cuadre["origen"]["goles_visitante"] == 298,
       "los goles se reparten 419 locales y 298 visitantes")
    ok(cuadre["origen"]["tiros"] == 6172 and cuadre["hecho"]["tiros"] == 6172, "los tiros cuadran: 6172")
    ok(cuadre["origen"]["xg"] == 687.23 and cuadre["hecho"]["xg"] == 687.23, "el xG cuadra: 687,23")
    ok(cuadre["origen"]["amarillas"] == 1219 and cuadre["hecho"]["amarillas"] == 1219,
       "las tarjetas cuadran: 1219")
    ok(cuadre["origen"]["posesion"] == 20551 and cuadre["hecho"]["posesion"] == 20551,
       "la posesión cuadra: 20551")
    ok(sum(cuadre["diferencias"].values()) == 0, "el cuadre no tiene ninguna diferencia")

    # Paso 7 · Clasificación construida DESDE el hecho, no desde el origen.
    tabla = estrella.clasificacion(hecho, dim_equipo)
    ok(len(tabla) == 20, "la clasificación tiene 20 equipos")
    ok(all(fila["partidos"] == 38 for fila in tabla), "todos los equipos han jugado 38 partidos")
    ok(sum(fila["puntos"] for fila in tabla) == 1026,
       "la suma de puntos es 1026 = 3·266 + 2·114")
    ok(sum(fila["pg"] for fila in tabla) == 266 and sum(fila["pp"] for fila in tabla) == 266,
       "victorias y derrotas cuadran: 266 y 266")
    ok(sum(fila["gf"] for fila in tabla) == 717 and sum(fila["gc"] for fila in tabla) == 717,
       "goles a favor y en contra cuadran: 717 y 717")
    ok(tabla[0]["equipo"] == "equipo-03" and tabla[0]["puntos"] == 94,
       "el líder es equipo-03 con 94 puntos")
    ok(tabla[-1]["equipo"] == "equipo-18" and tabla[-1]["puntos"] == 16,
       "el colista es equipo-18 con 16 puntos")

    # Paso 8 · Los CSV escritos: se releen del disco y se comprueba su forma y su contenido.
    with tempfile.TemporaryDirectory(prefix="p20-") as temporal:
        destino = Path(temporal) / "estrella"
        escritos = estrella.escribir(destino, dim_equipo, dim_jornada, hecho)
        ok(len(escritos) == 3, "la ingesta escribe tres ficheros")
        dim_e = leer_csv(destino / "dim_equipo.csv")
        dim_j = leer_csv(destino / "dim_jornada.csv")
        fact = leer_csv(destino / "hecho_partido.csv")
        ok(len(dim_e) == 20 and len(dim_j) == 38 and len(fact) == 380,
           "los CSV releídos tienen 20, 38 y 380 filas")
        ok(list(dim_e[0]) == ["id_equipo", "equipo"], "la cabecera de dim_equipo es la prometida")
        ok(list(dim_j[0]) == ["id_jornada", "jornada", "tramo", "partidos"],
           "la cabecera de dim_jornada es la prometida")
        ok("id_partido" in fact[0] and "id_equipo_local" in fact[0] and "xg_local" in fact[0],
           "el hecho lleva id de partido, claves y medidas")
        ok(sum(int(f["goles_local"]) + int(f["goles_visitante"]) for f in fact) == 717,
           "los goles releídos del hecho suman 717")

        # Paso 9 · Reproducibilidad: dos ingestas dan los mismos bytes.
        segundo = Path(temporal) / "estrella-2"
        estrella.escribir(segundo, dim_equipo, dim_jornada, hecho)
        ok(all(hash_fichero(destino / nombre) == hash_fichero(segundo / nombre)
               for nombre in ("dim_equipo.csv", "dim_jornada.csv", "hecho_partido.csv")),
           "la ingesta es reproducible: los tres CSV salen idénticos byte a byte")

    # Paso 10 · El código no toca la red ni lleva claves.
    codigo = (AQUI / "estrella.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"P20 · versión {VERSION}")
    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
