"""P20 · Fútbol: ingesta y modelo en estrella.

Convierte una tabla plana de partidos en un modelo en estrella: una tabla de hechos con grano de
partido y dos dimensiones (equipo y jornada), con claves sustitutas. Después comprueba lo que de
verdad importa: que el grano sea «un partido», que no haya claves huérfanas y que los totales del
origen y del hecho cuadren. Sin dependencias externas y sin red: biblioteca estándar de Python.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from collections import Counter
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = (
    "jornada", "local", "visitante", "goles_local", "goles_visitante",
    "tiros_local", "tiros_visitante", "xg_local", "xg_visitante",
    "posesion_local", "amarillas", "resultado",
)
COLUMNAS_DIM_EQUIPO = ("id_equipo", "equipo")
COLUMNAS_DIM_JORNADA = ("id_jornada", "jornada", "tramo", "partidos")
COLUMNAS_HECHO = (
    "id_partido", "id_jornada", "id_equipo_local", "id_equipo_visitante",
    "goles_local", "goles_visitante", "tiros_local", "tiros_visitante",
    "xg_local", "xg_visitante", "posesion_local", "amarillas", "resultado",
)
CORTE_TRAMO = 19
SALIDA_POR_DEFECTO = Path("resultados") / "estrella"


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer el CSV del origen y comprobar la forma antes de transformar nada.
    # Por qué: si el grano o los tipos no son los prometidos, el modelo en estrella hereda el error.
    # Salida esperada: 380 filas × 12 columnas, 20 equipos y 38 jornadas.
    # Si falla: «columnas inesperadas», «goles no enteros» o «resultado distinto de 1/X/2».
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 380:
        raise ValueError(f"se esperaban 380 partidos, hay {len(filas)}")
    for fila in filas:
        if fila["resultado"] not in {"1", "X", "2"}:
            raise ValueError(f"resultado inesperado: {fila['resultado']}")
        for columna in ("goles_local", "goles_visitante", "tiros_local", "tiros_visitante",
                        "posesion_local", "amarillas"):
            int(fila[columna])
    return filas


def auditar_origen(filas: list[dict]) -> dict:
    # Paso 2 · Auditar el grano del origen: ¿qué combinación de columnas identifica un partido?
    # Por qué: (local, visitante) parece la clave obvia y NO lo es en este CSV: se repite 19 veces.
    # Salida esperada: (jornada, local) único en 380 filas; (local, visitante) solo 20 pares, cada uno 19 veces.
    # Si falla: el CSV no es el del catálogo; revisa que no falte la columna jornada.
    equipos = sorted({f["local"] for f in filas} | {f["visitante"] for f in filas})
    jornadas = sorted({int(f["jornada"]) for f in filas})
    partidos_por_jornada = Counter(int(f["jornada"]) for f in filas)
    pares = Counter((f["local"], f["visitante"]) for f in filas)
    nulos = sum(1 for f in filas for valor in f.values() if valor is None or valor.strip() == "")
    coherentes = sum(
        1 for f in filas
        if f["resultado"] == ("1" if int(f["goles_local"]) > int(f["goles_visitante"])
                              else "X" if int(f["goles_local"]) == int(f["goles_visitante"]) else "2")
    )
    return {
        "equipos": equipos,
        "jornadas": jornadas,
        "partidos_por_jornada": partidos_por_jornada,
        "pares_local_visitante": pares,
        "repeticiones_par": sorted(set(pares.values())),
        "claves_jornada_local": len({(f["jornada"], f["local"]) for f in filas}),
        "nulos": nulos,
        "resultados_coherentes": coherentes,
    }


def construir_dimensiones(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    # Paso 3 · Construir las dimensiones con clave sustituta (un entero corto, no el texto del nombre).
    # Por qué: la clave sustituta no cambia si el equipo se renombra y ocupa menos en el hecho.
    # Salida esperada: 20 equipos con id 1..20 y 38 jornadas repartidas en dos tramos de 19.
    # Si falla: un nombre de equipo aparece con dos formas («equipo-01» y «equipo-1») y salen 21 filas.
    equipos = sorted({f["local"] for f in filas} | {f["visitante"] for f in filas})
    jornadas = sorted({int(f["jornada"]) for f in filas})
    partidos_por_jornada = Counter(int(f["jornada"]) for f in filas)
    dim_equipo = [{"id_equipo": str(i), "equipo": equipo} for i, equipo in enumerate(equipos, start=1)]
    dim_jornada = [
        {
            "id_jornada": str(jornada),
            "jornada": str(jornada),
            # Atributo derivado, no dato del origen: el CSV no trae fechas ni fases.
            "tramo": "primera-vuelta" if jornada <= CORTE_TRAMO else "segunda-vuelta",
            "partidos": str(partidos_por_jornada[jornada]),
        }
        for jornada in jornadas
    ]
    return dim_equipo, dim_jornada


def construir_hecho(filas: list[dict], dim_equipo: list[dict]) -> list[dict]:
    # Paso 4 · Construir el hecho: una fila por partido, con las claves ajenas y las medidas.
    # Por qué: el hecho guarda lo que se mide; el contexto (equipo, jornada) vive en las dimensiones.
    # Salida esperada: 380 filas con id_partido 1..380 y 13 columnas.
    # Si falla: un equipo del hecho no está en dim_equipo; la integridad referencial lo denunciará.
    clave = {d["equipo"]: d["id_equipo"] for d in dim_equipo}
    hecho = []
    for i, fila in enumerate(filas, start=1):
        hecho.append({
            "id_partido": str(i),
            "id_jornada": str(int(fila["jornada"])),
            "id_equipo_local": clave[fila["local"]],
            "id_equipo_visitante": clave[fila["visitante"]],
            "goles_local": fila["goles_local"],
            "goles_visitante": fila["goles_visitante"],
            "tiros_local": fila["tiros_local"],
            "tiros_visitante": fila["tiros_visitante"],
            "xg_local": fila["xg_local"],
            "xg_visitante": fila["xg_visitante"],
            "posesion_local": fila["posesion_local"],
            "amarillas": fila["amarillas"],
            "resultado": fila["resultado"],
        })
    return hecho


def escribir(destino: Path, dim_equipo: list[dict], dim_jornada: list[dict],
              hecho: list[dict]) -> list[Path]:
    # Paso 5 · Escribir la estrella en CSV, una tabla por fichero y siempre con la misma cabecera.
    # Por qué: la ingesta tiene que dejar un artefacto que otro pueda leer sin ejecutar el código.
    # Salida esperada: dim_equipo.csv (20), dim_jornada.csv (38) y hecho_partido.csv (380).
    # Si falla: «PermissionError» porque un CSV está abierto en otro programa; ciérralo y repite.
    destino = Path(destino)
    destino.mkdir(parents=True, exist_ok=True)
    salidas = []
    for nombre, columnas, datos in (
        ("dim_equipo.csv", COLUMNAS_DIM_EQUIPO, dim_equipo),
        ("dim_jornada.csv", COLUMNAS_DIM_JORNADA, dim_jornada),
        ("hecho_partido.csv", COLUMNAS_HECHO, hecho),
    ):
        ruta = destino / nombre
        with ruta.open("w", encoding="utf-8", newline="") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=columnas)
            escritor.writeheader()
            escritor.writerows(datos)
        salidas.append(ruta)
    return salidas


def comprobar_integridad(dim_equipo: list[dict], dim_jornada: list[dict], hecho: list[dict]) -> dict:
    # Paso 6 · Integridad referencial y grano del hecho.
    # Por qué: un hecho con una clave que no existe en la dimensión es un partido que nadie puede leer.
    # Salida esperada: 0 huérfanas, 380 claves (jornada, local) y 380 (jornada, visitante).
    # Si falla: hay un id de equipo o de jornada que no está en su dimensión.
    ids_equipo = {d["id_equipo"] for d in dim_equipo}
    ids_jornada = {d["id_jornada"] for d in dim_jornada}
    huerfanas = sum(1 for h in hecho if h["id_equipo_local"] not in ids_equipo
                    or h["id_equipo_visitante"] not in ids_equipo or h["id_jornada"] not in ids_jornada)
    apariciones = Counter()
    for h in hecho:
        apariciones[h["id_equipo_local"]] += 1
        apariciones[h["id_equipo_visitante"]] += 1
    return {
        "huerfanas": huerfanas,
        "grano_local": len({(h["id_jornada"], h["id_equipo_local"]) for h in hecho}),
        "grano_visitante": len({(h["id_jornada"], h["id_equipo_visitante"]) for h in hecho}),
        "partidos_por_jornada": Counter(h["id_jornada"] for h in hecho),
        "apariciones": apariciones,
    }


def cuadrar(origen: list[dict], hecho: list[dict]) -> dict:
    # Paso 7 · Cuadrar los totales del origen con los del hecho, medida a medida.
    # Por qué: si el hecho pierde filas o redondea distinto, la suma deja de cuadrar y el panel miente.
    # Salida esperada: goles 717, tiros 6172, xG 687,23, tarjetas 1219, posesión 20551 y 0 diferencias.
    # Si falla: alguna diferencia es distinta de 0; busca la fila que se ha quedado por el camino.

    def sumas(filas: list[dict], local: str, visitante: str, con_decimales: bool = False) -> dict:
        def suma(filas_: list[dict], columna: str) -> float:
            if con_decimales:
                return round(sum(float(f[columna]) for f in filas_), 2)
            return sum(int(f[columna]) for f in filas_)
        return {
            "partidos": len(filas),
            "goles_local": suma(filas, local),
            "goles_visitante": suma(filas, visitante),
            "goles": suma(filas, local) + suma(filas, visitante),
        }

    origen_simple = sumas(origen, "goles_local", "goles_visitante")
    hecho_simple = sumas(hecho, "goles_local", "goles_visitante")
    origen_simple.update({
        "tiros": sum(int(f["tiros_local"]) + int(f["tiros_visitante"]) for f in origen),
        "xg": round(sum(float(f["xg_local"]) + float(f["xg_visitante"]) for f in origen), 2),
        "amarillas": sum(int(f["amarillas"]) for f in origen),
        "posesion": sum(int(f["posesion_local"]) for f in origen),
    })
    hecho_simple.update({
        "tiros": sum(int(f["tiros_local"]) + int(f["tiros_visitante"]) for f in hecho),
        "xg": round(sum(float(f["xg_local"]) + float(f["xg_visitante"]) for f in hecho), 2),
        "amarillas": sum(int(f["amarillas"]) for f in hecho),
        "posesion": sum(int(f["posesion_local"]) for f in hecho),
    })
    diferencias = {
        clave: (0 if origen_simple[clave] == hecho_simple[clave] else 1)
        for clave in origen_simple
    }
    return {"origen": origen_simple, "hecho": hecho_simple, "diferencias": diferencias}


def clasificacion(hecho: list[dict], dim_equipo: list[dict]) -> list[dict]:
    # Paso 8 · Construir la clasificación DESDE el hecho (no desde el origen): es la prueba del cuadre.
    # Por qué: si la tabla sale del hecho y cuadra con el origen, el modelo no ha perdido ni inventado nada.
    # Salida esperada: 20 equipos, 38 partidos cada uno, 1026 puntos en total.
    # Si falla: un equipo juega 37 partidos; falta una fila en el hecho o una clave está mal.
    nombre = {d["id_equipo"]: d["equipo"] for d in dim_equipo}
    acumulado = {d["id_equipo"]: {"partidos": 0, "puntos": 0, "gf": 0, "gc": 0,
                                  "pg": 0, "pe": 0, "pp": 0} for d in dim_equipo}
    for h in hecho:
        local, visitante = h["id_equipo_local"], h["id_equipo_visitante"]
        goles_local, goles_visitante = int(h["goles_local"]), int(h["goles_visitante"])
        for equipo, goles_favor, goles_contra in (
            (local, goles_local, goles_visitante),
            (visitante, goles_visitante, goles_local),
        ):
            fila = acumulado[equipo]
            fila["partidos"] += 1
            fila["gf"] += goles_favor
            fila["gc"] += goles_contra
        if goles_local > goles_visitante:
            acumulado[local]["puntos"] += 3
            acumulado[local]["pg"] += 1
            acumulado[visitante]["pp"] += 1
        elif goles_local < goles_visitante:
            acumulado[visitante]["puntos"] += 3
            acumulado[visitante]["pg"] += 1
            acumulado[local]["pp"] += 1
        else:
            for equipo in (local, visitante):
                acumulado[equipo]["puntos"] += 1
                acumulado[equipo]["pe"] += 1
    tabla = [{"id_equipo": clave, "equipo": nombre[clave], **valores}
             for clave, valores in acumulado.items()]
    tabla.sort(key=lambda f: (-f["puntos"], -(f["gf"] - f["gc"]), -f["gf"], f["equipo"]))
    return tabla


def limpiar(destino: Path) -> None:
    """Borra los CSV generados y deja la carpeta como se descargó."""
    import shutil
    if Path(destino).exists():
        shutil.rmtree(destino)


def main() -> int:
    # Paso 9 · Publicar el resultado y dejar los CSV de la estrella escritos.
    # Por qué: el entregable es el modelo en estrella que cuadra, no solo la consola.
    # Salida esperada: los recuentos, el cuadre, la clasificación y las tres rutas escritas.
    # Si falla: revisa --csv; el código se ejecuta desde la carpeta del paquete.
    parser = argparse.ArgumentParser(description="Ingesta y modelo en estrella del fútbol (P20)")
    parser.add_argument("accion", nargs="?", choices=["limpiar"], help="limpiar: borra los CSV generados")
    parser.add_argument("--csv", default="datos-ejemplo/futbol-partidos.csv")
    parser.add_argument("--salida", default=str(SALIDA_POR_DEFECTO))
    args = parser.parse_args()

    if args.accion == "limpiar":
        limpiar(Path(args.salida))
        print(f"limpiado: {args.salida}")
        return 0

    filas = leer(Path(args.csv))
    auditoria = auditar_origen(filas)
    dim_equipo, dim_jornada = construir_dimensiones(filas)
    hecho = construir_hecho(filas, dim_equipo)
    integridad = comprobar_integridad(dim_equipo, dim_jornada, hecho)
    cuadre = cuadrar(filas, hecho)
    tabla = clasificacion(hecho, dim_equipo)
    salidas = escribir(Path(args.salida), dim_equipo, dim_jornada, hecho)

    pares = auditoria["pares_local_visitante"]
    repeticiones = auditoria["repeticiones_par"]
    print(f"origen: {len(filas)} filas × {len(COLUMNAS)} columnas · {len(auditoria['equipos'])} equipos · "
          f"{len(auditoria['jornadas'])} jornadas")
    print(f"grano: (jornada, local) único en {auditoria['claves_jornada_local']} filas · "
          f"trampa: (local, visitante) solo {len(pares)} pares, repetidos {repeticiones[0]} veces cada uno")
    print(f"nulos: {auditoria['nulos']} · resultado coherente con los goles: "
          f"{auditoria['resultados_coherentes']}/{len(filas)}")
    print(f"dim_equipo: {len(dim_equipo)} filas · dim_jornada: {len(dim_jornada)} filas · "
          f"hecho: {len(hecho)} filas")
    print(f"integridad: {integridad['huerfanas']} claves huérfanas · grano del hecho: "
          f"{integridad['grano_local']} claves (jornada, local) y {integridad['grano_visitante']} "
          f"(jornada, visitante)")
    print(f"cuadre origen → hecho: {sum(cuadre['diferencias'].values())} diferencias · "
          f"goles {cuadre['hecho']['goles']} · tiros {cuadre['hecho']['tiros']} · "
          f"xG {cuadre['hecho']['xg']:.2f} · amarillas {cuadre['hecho']['amarillas']} · "
          f"posesión {cuadre['hecho']['posesion']}")
    print(f"clasificación desde el hecho: {len(tabla)} equipos × {tabla[0]['partidos']} partidos · "
          f"puntos {sum(f['puntos'] for f in tabla)} = 3·{sum(f['pg'] for f in tabla)} + "
          f"2·{sum(f['pe'] for f in tabla) // 2} · GF {sum(f['gf'] for f in tabla)} = "
          f"GC {sum(f['gc'] for f in tabla)}")
    print(f"líder: {tabla[0]['equipo']} {tabla[0]['puntos']} puntos · "
          f"colista: {tabla[-1]['equipo']} {tabla[-1]['puntos']} puntos")
    print("escrito: " + ", ".join(str(ruta).replace("\\", "/") for ruta in salidas))
    print("límite: 20 emparejamientos repetidos 19 veces (no es un calendario real); el CSV no trae fechas.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
