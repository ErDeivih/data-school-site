# P20 · Fútbol: ingesta y modelo en estrella

Paquete descargable de **Data School** para el proyecto P20. Incluye la tabla de partidos de ejemplo,
el código comentado paso a paso y un verificador. No necesita el repositorio, ni conexión, ni
dependencias.

La pregunta del proyecto: una tabla plana de 380 partidos, ¿cómo se convierte en un **modelo en
estrella** que se pueda consultar sin perder ni inventar nada? El código construye una tabla de hechos
con grano de partido y dos dimensiones (equipo y jornada), con claves sustitutas, y después demuestra
lo que de verdad importa: que el grano es «un partido» (y no «un gol» ni «un emparejamiento»), que no
hay claves huérfanas y que los totales del origen y del hecho cuadran a cero diferencias.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: `requirements.txt` solo lo dice. Todo va con la biblioteca
  estándar de Python; no hace falta pandas, ni DuckDB, ni SQLite.
- Windows, Linux o macOS. No hace falta red.

## Instalación

```bash
python -m pip install -r requirements.txt
```

No instala nada: el fichero existe para que el comando funcione igual que en el resto de paquetes.

## Ejecutar

```bash
python estrella.py
python verificar.py
```

`estrella.py` lee el CSV del origen, audita el grano, construye las dimensiones y el hecho, comprueba
la integridad referencial, cuadra los totales, construye la clasificación desde el hecho y deja los
tres CSV de la estrella en `resultados/estrella/`. `verificar.py` comprueba el resultado de verdad y
sale 0 si todo cuadra.

Para volver a dejar la carpeta como se descargó (borra los CSV generados):

```bash
python estrella.py limpiar
```

## Salida esperada

```text
origen: 380 filas × 12 columnas · 20 equipos · 38 jornadas
grano: (jornada, local) único en 380 filas · trampa: (local, visitante) solo 20 pares, repetidos 19 veces cada uno
nulos: 0 · resultado coherente con los goles: 380/380
dim_equipo: 20 filas · dim_jornada: 38 filas · hecho: 380 filas
integridad: 0 claves huérfanas · grano del hecho: 380 claves (jornada, local) y 380 (jornada, visitante)
cuadre origen → hecho: 0 diferencias · goles 717 · tiros 6172 · xG 687.23 · amarillas 1219 · posesión 20551
clasificación desde el hecho: 20 equipos × 38 partidos · puntos 1026 = 3·266 + 2·114 · GF 717 = GC 717
líder: equipo-03 94 puntos · colista: equipo-18 16 puntos
escrito: resultados/estrella/dim_equipo.csv, resultados/estrella/dim_jornada.csv, resultados/estrella/hecho_partido.csv
límite: 20 emparejamientos repetidos 19 veces (no es un calendario real); el CSV no trae fechas.
```

La estrella que queda escrita:

```text
resultados/estrella/
├── dim_equipo.csv      # 20 filas · id_equipo, equipo
├── dim_jornada.csv     # 38 filas · id_jornada, jornada, tramo, partidos
└── hecho_partido.csv   # 380 filas · id_partido, claves y medidas (goles, tiros, xG, posesión…)
```

## Datos

- `datos-ejemplo/futbol-partidos.csv`: **380 filas × 12 columnas** (38 jornadas × 10 partidos). 20
  equipos; goles, tiros, xG, posesión y tarjetas por partido, con el resultado 1/X/2.
- **Sintético, determinista y CC0-1.0**: es una copia literal del CSV `futbol-partidos` del catálogo
  del portal, generado con semilla fija `20261104`. No es ninguna liga real y los equipos no existen.
- `sha256` del fichero: `5cbc8977b6c9d4f7ae66bfcc7642c93a6655faf7b6e6524a6d40480e2e66a12e`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.
- La fuente real que el catálogo asocia es **StatsBomb Open Data** (eventos liberados para
  investigación, con atribución); su repositorio no declara licencia SPDX, así que aquí **no** se
  descarga ni se redistribuye. El CSV sintético basta para el ejercicio.

## Lo que este CSV tiene de especial (y es justo lo que se aprende)

1. **El grano no es el que parece.** `(local, visitante)` parece identificar un partido, pero en este
   CSV solo hay **20 emparejamientos distintos, cada uno repetido 19 veces**. La clave real del grano
   es `(jornada, local)` (o `(jornada, visitante)`), única en las 380 filas. Si se modela el hecho por
   «emparejamiento», se pierden 19 de cada 20 partidos.
2. **La dimensión de jornada no trae fechas.** El CSV no tiene fecha; `dim_jornada` lleva la jornada y
   un atributo **derivado y declarado** (`primera-vuelta` / `segunda-vuelta`, 19 + 19). No se inventan
   fechas: se dice que no están.
3. **El cuadre es la prueba.** La clasificación se construye **desde el hecho**, no desde el origen: si
   suma 1026 puntos, 266 victorias y 717 goles a favor y en contra, el hecho no ha perdido ni
   duplicado partidos. Los totales origen → hecho dan **0 diferencias**.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida columnas, tipos y resultado 1/X/2 | contrato de datos |
| 2 · Auditar el grano | busca la clave que identifica un partido | grano y clave |
| 3 · Dimensiones | `dim_equipo` y `dim_jornada` con clave sustituta | hechos y dimensiones |
| 4 · Hecho | una fila por partido con claves ajenas y medidas | modelado dimensional |
| 5 · Escribir | tres CSV con cabecera fija | entrega reproducible |
| 6 · Integridad | 0 huérfanas y grano único | integridad referencial |
| 7 · Cuadrar | origen y hecho, medida a medida | cuadre de totales |
| 8 · Clasificación | tabla construida desde el hecho | consulta que valida el modelo |
| 9 · Publicar | recuentos, cuadre, clasificación y límites | comunicación honesta |

## Fallos típicos

- **`ModuleNotFoundError: estrella`**: ejecuta desde la carpeta del paquete, no desde su padre.
- **`FileNotFoundError`**: el comando se ha lanzado desde otra carpeta; `--csv` apunta a
  `datos-ejemplo/futbol-partidos.csv` y la ruta es relativa al directorio actual.
- **`columnas inesperadas`**: el CSV no es el del catálogo o se ha abierto con otro separador.
- **El hecho tiene 20 filas en vez de 380**: has modelado un emparejamiento en vez de un partido; el
  grano incluye la jornada.
- **La clasificación no suma 1026 puntos**: falta una fila o una clave de equipo está mal; el cuadre
  del paso 7 lo detecta antes.
- **La suma de xG no cuadra por 0,01**: se ha redondeado cada fila por separado; aquí se redondea la
  suma total a dos decimales.
- **`PermissionError` al escribir**: un CSV de `resultados/estrella/` está abierto en otro programa;
  ciérralo y repite.

## Estructura

```text
P20-codigo/
├── estrella.py                 # pasos 1–9: grano, dimensiones, hecho, cuadre y clasificación
├── verificar.py                # la puerta del proyecto: 49 comprobaciones, sin red
├── requirements.txt            # sin dependencias
├── datos-ejemplo/
│   └── futbol-partidos.csv     # 380 × 12 · sintético, CC0-1.0
└── resultados/
    └── ejemplo-salida.txt      # la salida real de una ejecución
```

Los CSV de `resultados/estrella/` **no viajan en el paquete**: se generan al ejecutar `estrella.py` y
se borran con `python estrella.py limpiar`.

## Límite

Son 380 partidos sintéticos con 20 emparejamientos repetidos 19 veces: sirve para aprender a declarar
el grano, separar dimensiones y cuadrar un hecho, **no** para analizar una liga real. El CSV no trae
fechas, estadios, árbitros ni plantillas, así que las dimensiones son deliberadamente delgadas; no se
rellenan con datos inventados. La clasificación que sale es una comprobación del modelo, no un
resultado deportivo.
