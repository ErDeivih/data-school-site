﻿#!/usr/bin/env python3
"""Puerta del proyecto P33 (etapas, perfil y tiempo).

Comprueba grano, contrato, muestra por perfil, s/km, tamaño del efecto y totales. Sin escribir en disco.
VERDE (0) o ROJO (1).
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import ciclismo

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "etapas-ciclismo.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = ciclismo.leer(CSV)
    ok(len(filas) == 420, "el CSV tiene 420 filas")
    ok(len({f["etapa"] for f in filas}) == 21, "hay 21 etapas")
    ok(all(sum(1 for f in filas if f["etapa"] == e) == 20 for e in {f["etapa"] for f in filas}), "cada etapa tiene 20 corredores")
    ok(len({f["corredor"] for f in filas}) == 20, "hay 20 corredores")
    ok(len({f["equipo"] for f in filas}) == 5, "hay 5 equipos")

    perfil = ciclismo.por_perfil(filas)
    ok(perfil["llano"]["n"] == 140, "llano aporta 140 puntos")
    ok(perfil["media"]["n"] == 140, "media montaña aporta 140 puntos")
    ok(perfil["montana"]["n"] == 140, "montaña aporta 140 puntos")
    ok(perfil["llano"]["media"] == 2.76545, "llano: 2,76545 s/km")
    ok(perfil["media"]["media"] == 3.04978, "media: 3,04978 s/km")
    ok(perfil["montana"]["media"] == 3.41736, "montaña: 3,41736 s/km")
    ok(perfil["llano"]["media"] < perfil["media"]["media"] < perfil["montana"]["media"],
       "el tiempo por kilómetro crece con el perfil")

    ok(round(ciclismo.tamano_efecto(filas), 5) == 2.54563, "la d de Cohen montaña-llano es 2,54563")
    tabla = ciclismo.tabla_etapas(filas)
    ok(len(tabla) == 21, "la tabla de etapas tiene 21 filas")
    ok(all(t["n"] == 20 for t in tabla), "cada etapa declara sus 20 corredores")
    ok(sum(t["distancia_km"] for t in tabla) == 3361, "la distancia total es 3.361 km")
    ok(sum(t["desnivel_m"] for t in tabla) == 57227, "el desnivel total es 57.227 m")
    ok(len({t["perfil"] for t in tabla}) == 3, "las etapas cubren los tres perfiles")

    malas = [
        {"etapa": "1", "fecha": "2026-01-01", "perfil": "pista", "distancia_km": "100", "desnivel_m": "10", "corredor": "c", "equipo": "e", "tiempo_s": "300", "posicion": "1"},
        {"etapa": "1", "fecha": "2026-01-01", "perfil": "llano", "distancia_km": "100", "desnivel_m": "10", "corredor": "c", "equipo": "e", "tiempo_s": "-5", "posicion": "1"},
        {"etapa": "1", "fecha": "2026-01-01", "perfil": "llano", "distancia_km": "100", "desnivel_m": "10", "corredor": "c", "equipo": "e", "tiempo_s": "300", "posicion": "99"},
    ]
    for i, fila in enumerate(malas, start=1):
        try:
            ciclismo.validar_fila(fila, i)
            ok(False, f"el contrato debería rechazar la fila mala {i}")
        except ValueError:
            ok(True, f"el contrato rechaza la fila mala {i}")

    codigo = (AQUI / "ciclismo.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
