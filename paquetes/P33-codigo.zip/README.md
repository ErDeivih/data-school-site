# P33 · Ciclismo: etapas, perfil y tiempo

Paquete descargable de **Data School** para el proyecto P33. Incluye las etapas de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python ciclismo.py
python verificar.py
```

`ciclismo.py` ordena las 21 etapas, comprueba la muestra de cada perfil y compara el tiempo por kilómetro
entre llano, media montaña y montaña, con la d de Cohen. `verificar.py` sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/etapas-ciclismo.csv`: **420 filas × 9 columnas** (21 etapas × 20 corredores; tres
  perfiles, 20 corredores y 5 equipos). Sintético y **CC0-1.0**; es el `etapas-ciclismo` del catálogo de
  Data School.

## Salida esperada

```text
etapas: 21 · corredores: 20 · equipos: 5
distancia total: 3361 km · desnivel: 57227 m
llano    n=140 · 2.765 s/km (sd 0.206)
media    n=140 · 3.050 s/km (sd 0.216)
montana  n=140 · 3.417 s/km (sd 0.298)
tamaño del efecto montaña frente a llano: d = 2.55
límite: 20 corredores por etapa y datos sintéticos; no describe una vuelta real.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Contrato de fila | `validar_fila` comprueba perfil, tiempo y posición | diseños factoriales e interacciones |
| 2 · Grano y distancias | `leer` exige 21 etapas de 20 y una distancia por etapa | diseños factoriales e interacciones |
| 3 · Por perfil | `por_perfil` da n, media y desviación | ANOVA |
| 4 · Tamaño del efecto | `tamano_efecto` calcula la d de Cohen montaña-llano | tamaño del efecto |
| 5 · Tabla de etapas | `tabla_etapas` publica una fila por etapa | ANOVA |
| 6 · Publicar y acotar | `main` declara la muestra y el límite | tamaño del efecto |

## Fallos típicos

- **`perfil desconocido`**: se ha añadido `pista` o `contrarreloj` sin declararlo en el contrato.
- **`distancia o desnivel no son únicos`**: la misma etapa tiene filas con distinta distancia.
- **`posiciones incompletas o repetidas`**: falta un corredor o hay dos con la misma posición.
- **Comparar tiempos brutos entre etapas**: hay que normalizar por kilómetro; si no, la etapa larga pesa más.

## Límite

Son 20 corredores por etapa y datos sintéticos. Enseñan a comparar perfiles y declarar la muestra; no
describen una vuelta real.
