"""P33 · Ciclismo: etapas, perfil y tiempo.

Ordena las etapas, comprueba la muestra por perfil y compara el tiempo por kilómetro entre llano, media
montaña y montaña, con el tamaño del efecto. Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import math
import statistics
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("etapa", "fecha", "perfil", "distancia_km", "desnivel_m", "corredor", "equipo", "tiempo_s", "posicion")
PERFILES = ("llano", "media", "montana")
ETAPAS = 21
CORREDORES_POR_ETAPA = 20


def validar_fila(fila: dict, numero: int) -> None:
    # Paso 1 · Contrato de una fila: perfil permitido, tiempo positivo y posición válida.
    # Por qué: una etapa con posiciones repetidas o un tiempo negativo rompe la comparación.
    # Salida esperada: las 420 filas del catálogo pasan.
    # Si falla: dice la fila y la regla incumplida.
    if fila["perfil"] not in PERFILES:
        raise ValueError(f"fila {numero}: perfil desconocido {fila['perfil']}")
    if float(fila["tiempo_s"]) <= 0:
        raise ValueError(f"fila {numero}: tiempo no positivo")
    if not 1 <= int(fila["posicion"]) <= CORREDORES_POR_ETAPA:
        raise ValueError(f"fila {numero}: posición fuera de rango")


def leer(ruta: Path) -> list[dict]:
    # Paso 2 · Leer y comprobar el grano: 21 etapas de 20 corredores, con la misma distancia por etapa.
    # Por qué: comparar tiempos sin normalizar por distancia mezcla etapas de 120 y 220 km.
    # Salida esperada: 420 filas, 21 etapas y 20 corredores por etapa.
    # Si falla: «etapa incompleta» o «distancia distinta en la misma etapa».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if not filas:
        raise ValueError("el CSV está vacío")
    for i, fila in enumerate(filas, start=2):
        validar_fila(fila, i)
    por_etapa = defaultdict(list)
    for fila in filas:
        por_etapa[int(fila["etapa"])].append(fila)
    if len(por_etapa) != ETAPAS or any(len(v) != CORREDORES_POR_ETAPA for v in por_etapa.values()):
        raise ValueError(f"se esperaban {ETAPAS} etapas de {CORREDORES_POR_ETAPA} corredores")
    for etapa, grupo in por_etapa.items():
        distancias = {f["distancia_km"] for f in grupo}
        desniveles = {f["desnivel_m"] for f in grupo}
        if len(distancias) != 1 or len(desniveles) != 1:
            raise ValueError(f"etapa {etapa}: distancia o desnivel no son únicos")
        if {int(f["posicion"]) for f in grupo} != set(range(1, CORREDORES_POR_ETAPA + 1)):
            raise ValueError(f"etapa {etapa}: posiciones incompletas o repetidas")
    return filas


def por_perfil(filas: list[dict]) -> dict:
    # Paso 3 · Comparar el tiempo por kilómetro entre perfiles, con su muestra y su dispersión.
    # Por qué: la media sola no dice si la diferencia es grande o es ruido.
    # Salida esperada: 140 puntos por perfil y 2,765 / 3,050 / 3,417 s/km.
    # Si falla: hay un perfil con menos muestra de la declarada.
    salida = {}
    for perfil in PERFILES:
        valores = [float(f["tiempo_s"]) / float(f["distancia_km"]) for f in filas if f["perfil"] == perfil]
        salida[perfil] = {
            "n": len(valores),
            "media": round(statistics.mean(valores), 5),
            "desviacion": round(statistics.stdev(valores), 5),
        }
    return salida


def tamano_efecto(filas: list[dict]) -> float:
    # Paso 4 · Calcular la d de Cohen entre montaña y llano.
    # Por qué: «va más lento» no dice cuánto; la d lo pone en unidades de dispersión.
    # Salida esperada: d ≈ 2,55 (efecto grande).
    # Si falla: falta muestra en alguno de los dos perfiles.
    montana = [float(f["tiempo_s"]) / float(f["distancia_km"]) for f in filas if f["perfil"] == "montana"]
    llano = [float(f["tiempo_s"]) / float(f["distancia_km"]) for f in filas if f["perfil"] == "llano"]
    var = ((len(montana) - 1) * statistics.variance(montana) + (len(llano) - 1) * statistics.variance(llano)) / (len(montana) + len(llano) - 2)
    return (statistics.mean(montana) - statistics.mean(llano)) / math.sqrt(var)


def tabla_etapas(filas: list[dict]) -> list[dict]:
    # Paso 5 · Publicar una fila por etapa con su perfil, distancia, desnivel y tiempo medio.
    # Por qué: el informe necesita ver de dónde sale cada comparación.
    # Salida esperada: 21 etapas ordenadas por número.
    # Si falla: el número de etapa no es numérico.
    grupos = defaultdict(list)
    for fila in filas:
        grupos[int(fila["etapa"])].append(fila)
    tabla = []
    for etapa in sorted(grupos):
        grupo = grupos[etapa]
        tabla.append({
            "etapa": etapa,
            "perfil": grupo[0]["perfil"],
            "distancia_km": int(grupo[0]["distancia_km"]),
            "desnivel_m": int(grupo[0]["desnivel_m"]),
            "n": len(grupo),
            "tiempo_medio_s": round(statistics.mean(float(f["tiempo_s"]) for f in grupo), 2),
        })
    return tabla


def main() -> int:
    # Paso 6 · Publicar la comparación con la muestra y el límite declarados.
    # Por qué: 20 corredores por etapa no representan el pelotón profesional; hay que decirlo.
    # Salida esperada: 21 etapas, 3 perfiles con su n y la d de Cohen.
    # Si falla: revisa --csv o si el fichero es el del catálogo.
    parser = argparse.ArgumentParser(description="Etapas, perfil y tiempo (P33)")
    parser.add_argument("--csv", default="datos-ejemplo/etapas-ciclismo.csv")
    args = parser.parse_args()
    filas = leer(Path(args.csv))
    tabla = tabla_etapas(filas)
    print(f"etapas: {len(tabla)} · corredores: {len({f['corredor'] for f in filas})} · equipos: {len({f['equipo'] for f in filas})}")
    print(f"distancia total: {sum(t['distancia_km'] for t in tabla)} km · desnivel: {sum(t['desnivel_m'] for t in tabla)} m")
    for perfil, datos in por_perfil(filas).items():
        print(f"{perfil:<8} n={datos['n']:>3} · {datos['media']:.3f} s/km (sd {datos['desviacion']:.3f})")
    print(f"tamaño del efecto montaña frente a llano: d = {tamano_efecto(filas):.2f}")
    print("límite: 20 corredores por etapa y datos sintéticos; no describe una vuelta real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
