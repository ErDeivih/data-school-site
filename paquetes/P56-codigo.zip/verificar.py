#!/usr/bin/env python3
"""Puerta del proyecto P56 · backtest de media móvil con costes, Sharpe y lookahead.

Recalcula la señal con ventanas declaradas, aplica comisión y slippage por cambio de posición, calcula
el Sharpe neto y demuestra con el prefijo de la serie que no hay datos futuros. No usa red y **no
escribe ficheros**.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import backtest

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P56 · backtest de media móvil ==")

    # Paso 1 · Valida los precios antes de construir la señal
    # Por qué: una clave repetida o un precio incoherente convierten el backtest en ruido con formato.
    # Salida esperada: "datos: 4000 filas · 8 empresas · 500 sesiones · 0 violaciones"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    df = backtest.cargar_precios()
    validacion = backtest.validar_precios(df)
    ok(
        (validacion["filas"], validacion["empresas"], validacion["sesiones"]) == (4000, 8, 500),
        f"datos: {validacion['filas']} filas · {validacion['empresas']} empresas · {validacion['sesiones']} sesiones",
    )
    ok(validacion["claves_duplicadas"] == 0 and validacion["violaciones"] == 0,
       f"clave única y precios coherentes: {validacion['violaciones']} violaciones")

    # Paso 2 · Comprueba que la posición usa la señal del periodo anterior
    # Por qué: si la posición del retorno de t usa la señal de t, el backtest ve el cierre que está
    #          intentando predecir; la comprobación es directa con el shift.
    # Salida esperada: "señal: 20/60 · EMP-A 10 cambios · posición = señal de t−1"
    # Si falla: hay filas donde la posición no es la señal anterior → lookahead de una sesión.
    datos = backtest.calcular_senales(df)
    posiciones = set(datos["posicion"].unique())
    ok(posiciones == {0, 1}, f"las posiciones son binarias: {sorted(posiciones)}")
    esperado = datos.groupby("empresa")["senal"].shift(1).fillna(0).astype(int)
    ok(bool((datos["posicion"].to_numpy() == esperado.to_numpy()).all()),
       "la posición del retorno de t es la señal de t−1 (sin ver el cierre de t)")
    cambios = int((datos[datos["empresa"] == backtest.EMPRESA_BASE]["posicion"].diff().abs() > 0).sum())
    ok(cambios == 10, f"cambios de posición de EMP-A: {cambios}")

    # Paso 3 · Comprueba que los costes se aplican en cada operación
    # Por qué: comisión y slippage son supuestos declarados; se descuentan en cada cambio de posición y
    #          el neto tiene que quedar por debajo del bruto.
    # Salida esperada: "EMP-A: coste 1.50 % · neto 17.6 % < bruto 19.4 %"
    # Si falla: coste acumulado 0 con operaciones > 0 → no se aplicó el cambio de posición.
    datos = backtest.aplicar_costes(datos)
    coste_manual = (backtest.COMISION + backtest.SLIPPAGE) * datos.groupby("empresa")["posicion"].diff().abs().fillna(0)
    ok(bool(np.allclose(datos["coste"].to_numpy(), coste_manual.to_numpy())),
       f"coste = ({backtest.COMISION:.2%} + {backtest.SLIPPAGE:.2%}) × |Δposición| en cada fila")
    tabla = backtest.resumir_backtest(datos)
    fila = tabla.set_index("empresa").loc[backtest.EMPRESA_BASE]
    ok(
        abs(fila["retorno_bruto"] - 0.194256) < 1e-6 and abs(fila["retorno_neto"] - 0.176425) < 1e-6
        and abs(fila["coste_acumulado"] - 0.0150) < 1e-9,
        f"EMP-A: bruto {fila['retorno_bruto']:+.2%} · neto {fila['retorno_neto']:+.2%} · coste {fila['coste_acumulado']:.2%}",
    )
    ok(bool((tabla["retorno_neto"] < tabla["retorno_bruto"]).all()), "en las 8 empresas el neto es menor que el bruto")

    # Paso 4 · Recalcula el Sharpe con la tasa declarada
    # Por qué: el Sharpe es la métrica que la ficha exige con su unidad; se reconstruye desde el exceso
    #          diario y la anualización √252.
    # Salida esperada: "Sharpe EMP-A: 0.7053 con tasa 2,0 % y 500 sesiones"
    # Si falla: la desviación es 0 → la estrategia nunca cambió de posición.
    serie = datos[datos["empresa"] == backtest.EMPRESA_BASE]
    exceso = serie["retorno_neto"] - backtest.TASA_LIBRE_RIESGO / backtest.SESIONES_ANIO
    sharpe_manual = float(exceso.mean() / exceso.std() * np.sqrt(backtest.SESIONES_ANIO))
    ok(abs(fila["sharpe"] - sharpe_manual) < 1e-12 and abs(sharpe_manual - 0.705275) < 1e-5,
       f"Sharpe EMP-A: {fila['sharpe']:.4f} con tasa {backtest.TASA_LIBRE_RIESGO:.1%}")
    ok(backtest.TASA_LIBRE_RIESGO == 0.02 and backtest.SESIONES_ANIO == 252,
       "tasa libre de riesgo y convención de anualización declaradas")

    # Paso 5 · Ejecuta la prueba de lookahead
    # Por qué: el criterio del catálogo exige que el recuento de señales con datos futuros salga 0.
    # Salida esperada: "lookahead: 0 señales con datos futuros (176 comprobaciones)"
    # Si falla: recuento > 0 → la señal usa el cierre de la misma sesión o posteriores.
    lookahead = backtest.probar_lookahead(datos)
    ok(lookahead["senales_con_futuro"] == 0, f"señales con datos futuros: {lookahead['senales_con_futuro']}")
    ok(lookahead["comprobaciones"] == 176, f"comprobaciones de lookahead: {lookahead['comprobaciones']}")

    # Paso 6 · Recalcula la lectura por episodios comunes
    # Por qué: parte del retorno es del mercado; el backtest debe leerse dentro y fuera de los tramos.
    # Salida esperada: "caida-larga -2.63 % · caida-corta -1.77 % · rebote +12.40 %"
    # Si falla: un episodio sin filas → el índice de sesión no se construyó por empresa.
    episodios = backtest.analizar_episodios(datos)
    valores = dict(zip(episodios["episodio"], episodios["retorno_neto_medio_dentro"]))
    ok(
        abs(valores["caida-larga"] + 0.026343) < 1e-5
        and abs(valores["caida-corta"] + 0.017678) < 1e-5
        and abs(valores["rebote"] - 0.123995) < 1e-5,
        f"episodios: {valores}",
    )
    ok(valores["caida-larga"] < 0 < valores["rebote"], "la caída larga pierde y el rebote gana: el tramo es común")

    # Paso 7 · Comprueba que el informe declara costes, lookahead y límite
    # Por qué: un backtest sin costes ni prueba de futuro no es defendible, y el informe es el entregable.
    # Salida esperada: "el informe declara comisión, slippage, tasa, lookahead 0 y límite"
    # Si falla: falta la prueba o el límite de las 500 sesiones.
    informe = backtest.texto_informe(tabla, lookahead, episodios)
    ok(
        f"Comisión {backtest.COMISION:.2%}" in informe and f"slippage {backtest.SLIPPAGE:.2%}" in informe
        and f"Tasa libre de riesgo {backtest.TASA_LIBRE_RIESGO:.1%}" in informe,
        "el informe declara comisión, slippage y tasa libre de riesgo",
    )
    ok("con datos futuros: **0**" in informe and "Límite" in informe and "sintéticos" in informe,
       "el informe enseña el 0 de lookahead y el límite de la muestra")
    ok("Alpha Vantage" in informe, "el informe separa el CSV sintético del dato real de Alpha Vantage")

    # Paso 8 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (backtest.RAIZ / "backtest.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
