#!/usr/bin/env python3
"""P56 · Backtest de media móvil con costes, Sharpe y lookahead — código ejecutable.

Construye la señal de cruce de medias sobre ocho empresas, aplica comisión y slippage a cada cambio de
posición, calcula el Sharpe con una tasa libre de riesgo declarada y demuestra con una prueba que la
señal no ve el futuro. Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal de datasets/csv/):
    datos-ejemplo/precios-empresa.csv  (4000 filas × 8 columnas)

Uso:
    python backtest.py           # calcula y escribe resultados/
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
VENTANA_CORTA = 20
VENTANA_LARGA = 60
# Supuestos declarados: el CSV no trae comisiones, slippage ni tipos.
COMISION = 0.0010
SLIPPAGE = 0.0005
TASA_LIBRE_RIESGO = 0.02
SESIONES_ANIO = 252
EMPRESA_BASE = "EMP-A"
EPISODIOS = {"caida-larga": (180, 199), "caida-corta": (300, 307), "rebote": (380, 394)}


# Paso 1 · Carga y valida los precios antes de tocar la señal
# Por qué: un cruce sobre una serie con la clave repetida o con precios incoherentes mide ruido; se
#          comprueban filas, empresas, sesiones y las tres relaciones de precio.
# Salida esperada: "precios: 4000 filas · 8 empresas · 500 sesiones · 0 violaciones"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_precios() -> pd.DataFrame:
    ruta = DATOS / "precios-empresa.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta, parse_dates=["fecha"]).sort_values(["empresa", "fecha"]).reset_index(drop=True)
    df["sesion"] = df.groupby("empresa").cumcount()
    print(
        f"precios: {len(df)} filas · {df['empresa'].nunique()} empresas · "
        f"{df.groupby('empresa').size().min()} sesiones"
    )
    return df


def validar_precios(df: pd.DataFrame) -> dict:
    d = df.sort_values(["empresa", "fecha"]).copy()
    d["cierre_previo"] = d.groupby("empresa")["cierre"].shift(1)
    v = d.dropna(subset=["cierre_previo"])
    tope = np.maximum(v["apertura"], v["cierre"])
    suelo = np.minimum(v["apertura"], v["cierre"])
    redondeo = 0.010
    violaciones = int(
        (
            (v["apertura"] / v["cierre_previo"] - 1).abs() > 0.002 + redondeo / v["cierre_previo"]
        ).sum()
        + ((v["maximo"] < tope - 1e-9) | (v["maximo"] / tope - 1 > 0.012 + redondeo / tope)).sum()
        + ((v["minimo"] > suelo + 1e-9) | (1 - v["minimo"] / suelo > 0.012 + redondeo / suelo)).sum()
    )
    resumen = {
        "filas": len(df),
        "empresas": int(df["empresa"].nunique()),
        "sesiones": int(df.groupby("empresa").size().min()),
        "claves_duplicadas": int(df.duplicated(["fecha", "empresa"]).sum()),
        "violaciones": violaciones,
    }
    print(f"validación: {resumen['claves_duplicadas']} claves duplicadas · {violaciones} violaciones de precio")
    return resumen


# Paso 2 · Construye la señal con dos medias que solo miran al pasado
# Por qué: `rolling` usa la ventana que termina en t; la posición para el retorno de t se toma con la
#          señal de t−1 (shift), de modo que se ejecuta con información disponible, no con el futuro.
# Salida esperada: "señal: 20/60 sesiones · EMP-A 7 cambios de posición"
# Si falla: NaN en la señal al principio es normal (ventana incompleta); se trata como posición 0.
def calcular_senales(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["retorno"] = d.groupby("empresa")["cierre"].pct_change()
    d["ma_corta"] = d.groupby("empresa")["cierre"].transform(lambda s: s.rolling(VENTANA_CORTA).mean())
    d["ma_larga"] = d.groupby("empresa")["cierre"].transform(lambda s: s.rolling(VENTANA_LARGA).mean())
    d["senal"] = (d["ma_corta"] > d["ma_larga"]).astype(int)
    d.loc[d["ma_larga"].isna(), "senal"] = 0
    d["posicion"] = d.groupby("empresa")["senal"].shift(1).fillna(0).astype(int)
    cambios = int(d.groupby("empresa")["posicion"].apply(lambda s: (s.diff().abs() > 0).sum()).loc[EMPRESA_BASE])
    print(f"señal: {VENTANA_CORTA}/{VENTANA_LARGA} sesiones · {EMPRESA_BASE} {cambios} cambios de posición")
    return d


# Paso 3 · Aplica costes a cada operación, no al final
# Por qué: comisión y slippage se pagan en cada entrada y en cada salida; descontarlos una vez al final
#          esconde el coste real y hace que el backtest parezca mejor de lo que es.
# Salida esperada: "coste EMP-A: 1.50 % acumulado · 10 operaciones"
# Si falla: coste 0 con operaciones > 0 → no se aplicó el cambio de posición.
def aplicar_costes(d: pd.DataFrame, comision: float = COMISION, slippage: float = SLIPPAGE) -> pd.DataFrame:
    d = d.copy()
    d["cambio_posicion"] = d.groupby("empresa")["posicion"].diff().abs().fillna(0)
    d["coste"] = (comision + slippage) * d["cambio_posicion"]
    d["retorno_bruto"] = d["posicion"] * d["retorno"].fillna(0)
    d["retorno_neto"] = d["retorno_bruto"] - d["coste"]
    return d


# Paso 4 · Resume el backtest por empresa con su Sharpe
# Por qué: el Sharpe se calcula sobre el retorno neto, con tasa libre de riesgo declarada y anualización
#          √252; cada cifra va con el número de sesiones y de operaciones de su empresa.
# Salida esperada: "EMP-A: bruto 19.4 % · neto 17.6 % · coste 1.50 % · Sharpe 0.71"
# Si falla: Sharpe con desviación 0 → la posición nunca cambió; revisa la señal.
def resumir_backtest(d: pd.DataFrame) -> pd.DataFrame:
    filas = []
    for empresa, serie in d.groupby("empresa"):
        exceso = serie["retorno_neto"] - TASA_LIBRE_RIESGO / SESIONES_ANIO
        desviacion = float(exceso.std())
        sharpe = float(exceso.mean() / desviacion * np.sqrt(SESIONES_ANIO)) if desviacion > 0 else 0.0
        filas.append(
            {
                "empresa": empresa,
                "sesiones": int(serie["retorno_neto"].count()),
                "retorno_bruto": float((1 + serie["retorno_bruto"]).prod() - 1),
                "retorno_neto": float((1 + serie["retorno_neto"]).prod() - 1),
                "coste_acumulado": float(serie["coste"].sum()),
                "operaciones": int((serie["cambio_posicion"] > 0).sum()),
                "sharpe": sharpe,
            }
        )
    tabla = pd.DataFrame(filas)
    fila = tabla.set_index("empresa").loc[EMPRESA_BASE]
    print(
        f"{EMPRESA_BASE}: bruto {fila['retorno_bruto']:+.1%} · neto {fila['retorno_neto']:+.1%} · "
        f"coste {fila['coste_acumulado']:.2%} · Sharpe {fila['sharpe']:.2f}"
    )
    return tabla


# Paso 5 · Prueba de lookahead: recalcula la señal con el prefijo de cada sesión
# Por qué: la mejor prueba no es una promesa, es recalcular en varias sesiones usando solo el pasado y
#          comprobar que la posición publicada no cambia; el recuento de fallos debe ser 0.
# Salida esperada: "lookahead: 0 señales con datos futuros (40 comprobaciones)"
# Si falla: recuento > 0 → la señal usa datos de la misma sesión o posteriores.
def probar_lookahead(d: pd.DataFrame) -> dict:
    comprobaciones = 0
    fallos = 0
    for empresa, serie in d.groupby("empresa"):
        valores = serie.reset_index(drop=True)
        for t in range(VENTANA_LARGA, len(valores), 20):
            prefijo = valores.iloc[:t]  # solo sesiones anteriores a t
            ma_corta = prefijo["cierre"].tail(VENTANA_CORTA).mean()
            ma_larga = prefijo["cierre"].tail(VENTANA_LARGA).mean()
            senal_esperada = 0 if pd.isna(ma_larga) else int(ma_corta > ma_larga)
            comprobaciones += 1
            fallos += int(valores.iloc[t]["posicion"] != senal_esperada)
    print(f"lookahead: {fallos} señales con datos futuros ({comprobaciones} comprobaciones)")
    return {"comprobaciones": comprobaciones, "senales_con_futuro": fallos}


# Paso 6 · Lee el backtest dentro y fuera de los episodios comunes
# Por qué: parte del retorno es del mercado; comparar dentro y fuera de los tres tramos evita atribuir a
#          la señal lo que hicieron las ocho empresas a la vez.
# Salida esperada: "episodios: caida-larga -8.1 % dentro · -5.0 % fuera"
# Si falla: un episodio sin filas → el índice de sesión no se construyó por empresa.
def analizar_episodios(d: pd.DataFrame) -> pd.DataFrame:
    filas = []
    for nombre, (desde, hasta) in EPISODIOS.items():
        dentro = d[(d["sesion"] >= desde) & (d["sesion"] <= hasta)]
        media = float(dentro.groupby("empresa")["retorno_neto"].apply(lambda s: (1 + s).prod() - 1).mean())
        filas.append({"episodio": nombre, "sesiones": hasta - desde + 1, "retorno_neto_medio_dentro": media})
    tabla = pd.DataFrame(filas)
    print("episodios: " + " · ".join(f"{f.episodio} {f.retorno_neto_medio_dentro:+.1%}" for f in tabla.itertuples()))
    return tabla


def texto_informe(tabla: pd.DataFrame, lookahead: dict, episodios: pd.DataFrame) -> str:
    fila = tabla.set_index("empresa").loc[EMPRESA_BASE]
    return "\n".join(
        [
            "# P56 · Backtest de media móvil con costes, Sharpe y lookahead",
            "",
            f"Estrategia: media de {VENTANA_CORTA} sesiones frente a media de {VENTANA_LARGA}; posición 1",
            "cuando la corta está por encima, 0 cuando está por debajo. La posición del retorno de t usa",
            "la señal de t−1: se ejecuta con lo que se sabía, no con el cierre del día.",
            "",
            "## Costes y tasa declarados",
            f"- Comisión {COMISION:.2%} y slippage {SLIPPAGE:.2%} por cambio de posición: **supuestos**,",
            "  el CSV no los trae. Se aplican en cada entrada y cada salida.",
            f"- Tasa libre de riesgo {TASA_LIBRE_RIESGO:.1%} anual: **supuesto**; el Sharpe usa exceso",
            f"  diario y anualiza con √{SESIONES_ANIO}.",
            "",
            "## Resultado por empresa",
            "| empresa | sesiones | bruto | neto | coste | operaciones | Sharpe |",
            "| --- | --- | --- | --- | --- | --- | --- |",
            *[
                f"| {f.empresa} | {f.sesiones} | {f.retorno_bruto:+.2%} | {f.retorno_neto:+.2%} | "
                f"{f.coste_acumulado:.2%} | {f.operaciones} | {f.sharpe:.2f} |"
                for f in tabla.itertuples()
            ],
            "",
            f"Para {EMPRESA_BASE}: el bruto es {fila['retorno_bruto']:+.1%} y el neto {fila['retorno_neto']:+.1%};",
            f"los costes se llevan {fila['coste_acumulado']:.2%} y el Sharpe neto es {fila['sharpe']:.2f}.",
            "",
            "## Prueba de lookahead",
            f"Se recalcula la señal en {lookahead['comprobaciones']} sesiones usando solo el prefijo de la",
            f"serie. Señales con datos futuros: **{lookahead['senales_con_futuro']}**.",
            "",
            "## Episodios comunes de mercado",
            "| episodio | sesiones | retorno neto medio dentro |",
            "| --- | --- | --- |",
            *[f"| {f.episodio} | {f.sesiones} | {f.retorno_neto_medio_dentro:+.2%} |" for f in episodios.itertuples()],
            "",
            "## Límite",
            "Los precios son sintéticos (semilla fija, CC0-1.0) y no son de empresas reales. 500 sesiones son",
            "unos dos años: un Sharpe sobre dos años no distingue una estrategia buena de una con suerte, y",
            "las tres ventanas de episodios son comunes a las ocho empresas. No se elige la empresa después",
            "de ver cuál gana. El dato real de precios se documenta con Alpha Vantage y no se mezcla.",
            "",
        ]
    )


def main() -> int:
    df = cargar_precios()
    validar_precios(df)
    datos = calcular_senales(df)
    datos = aplicar_costes(datos)
    tabla = resumir_backtest(datos)
    lookahead = probar_lookahead(datos)
    episodios = analizar_episodios(datos)
    RESULTADOS.mkdir(exist_ok=True)
    datos[["fecha", "empresa", "cierre", "retorno", "ma_corta", "ma_larga", "senal", "posicion", "coste", "retorno_bruto", "retorno_neto"]].to_csv(
        RESULTADOS / "precios-senales.csv", index=False
    )
    tabla.to_csv(RESULTADOS / "backtest.csv", index=False)
    episodios.to_csv(RESULTADOS / "episodios.csv", index=False)
    (RESULTADOS / "lookahead.txt").write_text(
        f"señales con datos futuros: {lookahead['senales_con_futuro']}\n"
        f"comprobaciones: {lookahead['comprobaciones']}\n"
        f"método: recalcular medias con el prefijo de la serie en cada sesión muestreada\n",
        encoding="utf-8",
    )
    (RESULTADOS / "informe.md").write_text(texto_informe(tabla, lookahead, episodios), encoding="utf-8")
    print(f"escrito: {RESULTADOS / 'informe.md'} · backtest.csv · lookahead.txt · episodios.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
