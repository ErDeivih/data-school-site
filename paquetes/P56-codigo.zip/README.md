# P56 · Backtest de media móvil con costes, Sharpe y lookahead — código ejecutable

Construye la señal de cruce de dos medias sobre ocho empresas, aplica comisión y slippage en cada cambio
de posición, calcula el Sharpe neto con tasa libre de riesgo declarada y demuestra con el prefijo de la
serie que no hay datos futuros. Es el código que acompaña a la ficha
`../../fichas-ideas/p56-backtest-de-media-movil.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** y **numpy >= 1.26** (ambas BSD-3-Clause).
- Windows, Linux o macOS: sin red ni servicios externos.

## Instalación

```powershell
cd proyectos/p56-backtest-de-media-movil/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python backtest.py
```

Recorre los pasos, imprime una línea por paso y escribe en `resultados/` los ficheros `backtest.csv`,
`lookahead.txt`, `episodios.csv`, `precios-senales.csv` e `informe.md`. Los generados no viajan en el
ZIP: solo `ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: 4000 filas y 8 empresas de 500 sesiones, 0 violaciones
de precio, la posición del retorno de t tomada con la señal de t−1, los costes aplicados a cada cambio
(EMP-A: 1,50 % acumulado en 10 operaciones), el resultado bruto y neto (19,43 % y 17,64 %), el Sharpe de
0,7053 con tasa 2 %, el lookahead con **0 señales con datos futuros** en 176 comprobaciones y los tres
episodios comunes. Termina en `RESULTADO: VERDE` (0) o `RESULTADO: ROJO` (1). No usa red. La salida real
está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/precios-empresa.csv`: **4000 filas × 8 columnas**, 8 empresas × 500 sesiones laborables
  del 2025-01-02 al 2026-12-02.
- **Sintético, determinista y CC0-1.0**: copia literal de `datasets/csv/`, con
  `sha256:2b01812744dbdc70bd17d2bff85bb4f061c5560993a8fe0c9519eb8af4895e20`; tamaño y columnas en
  `datasets-nuevos-2026-11-05.json`.
- El CSV **no trae** comisiones, slippage, tipos de interés ni índice de mercado: se declaran como
  supuestos. Una fila es una sesión.

## Fuente real y licencia

- **Precios reales:** `alpha-vantage` (<https://www.alphavantage.co/query>), clave gratuita, EULA de uso
  personal y no comercial; su FAQ da peticiones ilimitadas a proyectos educativos u open source
  verificados. No se mezcla con el CSV sin decirlo.
- Datos sintéticos CC0-1.0. Dependencias: pandas y numpy BSD-3-Clause.

## Supuestos declarados

- **Comisión 0,10 % y slippage 0,05 %** por cambio de posición, aplicados en cada entrada y salida.
- **Tasa libre de riesgo 2,0 % anual** para el Sharpe; exceso diario y anualización √252.
- **Señal:** media de 20 sesiones frente a media de 60; la posición de t usa la señal de t−1.
- **Empresa de referencia:** EMP-A para las cifras destacadas; la tabla trae las ocho con la misma
  ventana y las mismas ventanas de medias (no se elige la empresa después de ver cuál gana).
- **Episodios:** sesiones 180–199, 300–307 y 380–394, comunes a las ocho empresas.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Validar precios | Clave única y coherencia de precios | `Calidad de datos` |
| 2 · Señal de cruce | Indicadores con ventanas y sin futuro | `Indicadores técnicos` |
| 3 · Costes por operación | Comisión y slippage reales | `Slippage y comisiones` |
| 4 · Sharpe neto | Exceso por unidad de riesgo con tasa | `Ratio de Sharpe` |
| 5 · Prueba de lookahead | Demostrar que la señal no ve el futuro | `Sesgo de mirar al futuro` |
| 6 · Episodios comunes | Mercado y estrategia, separados | `Regímenes de mercado` |

## Estructura

```text
codigo/
├── backtest.py            # señal, costes, Sharpe, lookahead, episodios e informe
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas y numpy
├── datos-ejemplo/         # precios-empresa.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **Costes a cero:** un backtest sin comisión ni slippage sobre 500 sesiones no es defendible.
- **Lookahead de una sesión:** usar el cierre de t para decidir en t; la posición va con la señal de t−1.
- **Elegir la empresa después:** comparar las ocho con la misma ventana y declarar la de referencia.
- **Sharpe sin tasa:** el CSV no trae tipos; la tasa va escrita y con la anualización declarada.
- **Confundir mercado con estrategia:** los tres episodios son comunes; hay que leer dentro y fuera.
- **`ModuleNotFoundError: pandas`**: instala las dependencias con el mismo Python que ejecuta el script.
