#!/usr/bin/env python3
"""Adaptador simulado de la API de embeddings de Hugging Face Hub (sin red).

El proyecto no descarga nada: este módulo lee una **respuesta capturada** guardada en
`datos-ejemplo/fixtures/huggingface-embeddings.json`, con la forma que tendría la respuesta de un modelo
de embeddings (`modelo`, `licencia`, `dim` y un vector por texto de ejemplo). Los vectores del fixture
están **truncados a 16 dimensiones** para que el fichero sea legible: no son la salida real del modelo.

Con red y sin clave, el modo real pediría los vectores al Hub (`all-MiniLM-L6-v2`, apache-2.0); esta
entrega no incluye esa llamada y el proyecto usa embeddings locales calculados por hashing.
"""
from __future__ import annotations

import json
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
FIXTURE = RAIZ / "datos-ejemplo" / "fixtures" / "huggingface-embeddings.json"


class ErrorDeFixture(RuntimeError):
    """El fixture no existe, no tiene la forma declarada o no cubre el texto pedido."""


class AdaptadorHub:
    """Cliente simulado: la misma interfaz que un cliente del Hub, pero leyendo el fixture local."""

    def __init__(self, ruta: Path = FIXTURE):
        # Paso 1 · Carga el fixture y valida el modelo, la licencia y la dimensión
        # Por qué: la licencia la declara cada ítem del Hub; si el fixture no dice cuál es, el adaptador
        #          no puede usarse en una entrega que después se comparte.
        # Salida esperada: "adaptador: all-MiniLM-L6-v2 · apache-2.0 · 16 dimensiones · 3 textos"
        # Si falla: ErrorDeFixture → falta datos-ejemplo/fixtures/huggingface-embeddings.json.
        ruta = Path(ruta)
        if not ruta.exists():
            raise ErrorDeFixture(f"no existe el fixture {ruta}")
        datos = json.loads(ruta.read_text(encoding="utf-8"))
        for campo in ("modelo", "licencia", "dim", "capturado", "textos"):
            if campo not in datos:
                raise ErrorDeFixture(f"el fixture no trae «{campo}»")
        if datos["licencia"] != "apache-2.0":
            raise ErrorDeFixture(f"licencia inesperada en el fixture: {datos['licencia']!r}")
        if int(datos["dim"]) <= 0 or not datos["textos"]:
            raise ErrorDeFixture("el fixture no trae dimensión o textos")
        self.datos = datos
        self._por_texto = {item["texto"]: list(item["vector"]) for item in datos["textos"]}

    def modelo(self) -> dict:
        return {"modelo": self.datos["modelo"], "licencia": self.datos["licencia"],
                "dim": int(self.datos["dim"]), "capturado": self.datos["capturado"]}

    def embedding(self, texto: str) -> list:
        # Paso 2 · Devuelve el vector capturado o falla con un mensaje explícito
        # Por qué: sin red no hay llamada real; inventar un vector para un texto desconocido ocultaría que
        #          se está usando otro modo. La entrega usa los embeddings locales para el corpus completo.
        # Salida esperada: una lista de 16 floats para los textos del fixture
        # Si falla: ErrorDeFixture → el texto no está en el fixture; el proyecto debe usar embeddings_hash.
        if texto not in self._por_texto:
            raise ErrorDeFixture("texto sin fixture: sin red no se llama al modelo; usa los embeddings locales del proyecto")
        return list(self._por_texto[texto])

    def tamano_fixture(self) -> int:
        return len(self._por_texto)


if __name__ == "__main__":
    adaptador = AdaptadorHub()
    info = adaptador.modelo()
    print(f"adaptador: {info['modelo']} · {info['licencia']} · {info['dim']} dimensiones · {adaptador.tamano_fixture()} textos")
