#!/usr/bin/env python3
"""Puerta del proyecto P43 (NLP clásico: de bolsa de palabras a embeddings).

Comprueba el resultado de verdad, sin escribir en disco y sin red: estructura y recuentos del CSV,
auditoría de duplicados de plantilla, partición sin fuga, TF-IDF y embeddings con la misma partición,
métricas fuera de muestra contra la línea base, matriz de confusión recalculada, adaptador simulado del
Hub y código offline. Termina en RESULTADO: VERDE (código 0) o ROJO (código 1).

Uso:
    python verificar.py

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import sys

sys.dont_write_bytecode = True  # la puerta no escribe nada: ni resultados ni caché de bytecode

from pathlib import Path

import adaptador
import nlp

fallos: list = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P43 · NLP clasico: de bolsa de palabras a embeddings ==")

    # Paso 1 · Comprueba los parámetros declarados y la estructura del CSV
    # Por qué: la semilla y la dimensión deciden la partición y los vectores; si no son las declaradas, el
    #          resto del informe no se puede reproducir.
    # Salida esperada: "OK parámetros: semilla 20261109 · test 0.30 · embeddings 64".
    # Si falla: RuntimeError de cargar_parametros → falta datos-ejemplo/parametros.json.
    parametros = nlp.cargar_parametros()
    ok(
        (int(parametros["semilla"]), float(parametros["test_frac"]), int(parametros["dim_embeddings"])) == (20261109, 0.3, 64),
        f"parámetros: semilla {int(parametros['semilla'])} · test {float(parametros['test_frac']):.2f} · embeddings {int(parametros['dim_embeddings'])} dimensiones",
    )
    corpus = nlp.cargar_corpus()
    ok(len(corpus["filas"]) == 600 and len(nlp.COLUMNAS) == 5 and len(set(corpus["ids"])) == 600,
       f"corpus: {len(corpus['filas'])} filas · {len(nlp.COLUMNAS)} columnas · {len(set(corpus['ids']))} ids unicos")

    # Paso 2 · Comprueba etiquetas, canales, longitudes y la auditoría de duplicados
    # Por qué: la fuga de plantilla es la trampa del dataset; si el recuento de textos únicos no es 367, la
    #          partición por texto no está protegiendo nada.
    # Salida esperada: "OK etiquetas: positiva 241 · negativa 188 · neutra 171" y "OK auditoría: 367 únicos, 177 primeras frases".
    # Si falla: el CSV no es el del catálogo o se regeneró con otra semilla.
    auditoria = nlp.auditar(corpus)
    ok(
        auditoria["etiquetas"] == {"negativa": 188, "neutra": 171, "positiva": 241},
        "etiquetas: " + " · ".join(f"{clase} {auditoria['etiquetas'][clase]}" for clase in nlp.ETIQUETAS),
    )
    ok(
        auditoria["canales"] == {"app": 195, "tienda": 199, "web": 206},
        "canales: " + " · ".join(f"{canal} {auditoria['canales'][canal]}" for canal in nlp.CANALES),
    )
    ok(
        auditoria["longitud_min"] == 8 and auditoria["longitud_max"] == 14
        and all(int(fila["longitud_palabras"]) == len(fila["texto"].split()) for fila in corpus["filas"]),
        f"longitudes: {auditoria['longitud_min']}-{auditoria['longitud_max']} palabras y longitud_palabras cuadra con el texto",
    )
    ok(
        (auditoria["textos_unicos"], auditoria["textos_repetidos"], auditoria["primeras_frases_unicas"], auditoria["vocabulario"]) == (367, 233, 177, 110),
        f"auditoría: {auditoria['textos_unicos']} textos únicos ({auditoria['textos_repetidos']} repetidos) · {auditoria['primeras_frases_unicas']} primeras frases únicas · {auditoria['vocabulario']} palabras tal cual",
    )

    # Paso 3 · Comprueba que la partición agrupa por texto y es reproducible
    # Por qué: un split por fila repartiría copias de la misma reseña entre train y test; la prueba es que
    #          ningún texto completo esté en los dos lados y que la partición se repita.
    # Salida esperada: "OK partición: train y test sin textos compartidos" y "OK reproducibilidad: misma partición".
    # Si falla: hay textos compartidos → la partición no agrupa por texto o el barajado no usa la semilla.
    asignacion = nlp.partir_sin_fuga(corpus, float(parametros["test_frac"]), int(parametros["semilla"]))
    train = [fila for fila in asignacion if fila["particion"] == "train"]
    test = [fila for fila in asignacion if fila["particion"] == "test"]
    claves_train = {fila["clave"] for fila in train}
    claves_test = {fila["clave"] for fila in test}
    ok(
        len(train) + len(test) == 600 and not (claves_train & claves_test) and len(train) > 100 and len(test) > 50,
        f"partición: train {len(train)} filas · test {len(test)} filas · textos compartidos {len(claves_train & claves_test)}",
    )
    repetida = nlp.partir_sin_fuga(corpus, float(parametros["test_frac"]), int(parametros["semilla"]))
    ok(repetida == asignacion, "reproducibilidad: la misma semilla devuelve la misma partición")

    # Paso 4 · Ejecuta los dos modelos y comprueba las métricas fuera de muestra
    # Por qué: comparar exige la misma partición y la misma línea base; y el acierto alto es una propiedad
    #          de las plantillas, así que se mide contra la clase mayoritaria y se declara.
    # Salida esperada: las líneas de la corrida y los OK de TF-IDF, embeddings y línea base.
    # Si falla: un modelo no supera la línea base → la limpieza o la partición están mal.
    resultados = nlp.ejecutar(parametros)
    ok(
        resultados["met_tfidf"]["acierto"] > resultados["acierto_base"],
        f"tfidf: acierto {resultados['met_tfidf']['acierto']:.3f} > línea base {resultados['acierto_base']:.3f}",
    )
    ok(
        resultados["met_emb"]["acierto"] > resultados["acierto_base"],
        f"embeddings: acierto {resultados['met_emb']['acierto']:.3f} > línea base {resultados['acierto_base']:.3f}",
    )
    ok(resultados["met_tfidf"]["acierto"] >= 0.9 and resultados["met_emb"]["acierto"] >= 0.8,
       "aciertos: los dos modelos quedan por encima de los umbrales declarados (0,90 y 0,80)")
    ok(
        resultados["acierto_base"] == sum(1 for e in resultados["etiquetas_test"] if e == resultados["mayoritaria"]) / len(resultados["etiquetas_test"]),
        f"línea base: {resultados['acierto_base']:.3f} calculada sobre el test con la clase mayoritaria ({resultados['mayoritaria']})",
    )

    # Paso 5 · Recalcula las métricas desde las predicciones y comprueba las matrices
    # Por qué: una tabla de métricas no se cree; se recalcula con las predicciones guardadas.
    # Salida esperada: "OK métricas TF-IDF recalculadas" y matrices que suman el test.
    # Si falla: las métricas reportadas no coinciden con las predicciones → hay una tabla inventada.
    for nombre, pred, met in (("TF-IDF", resultados["pred_tfidf"], resultados["met_tfidf"]),
                              ("embeddings", resultados["pred_emb"], resultados["met_emb"])):
        recalculadas = nlp.metricas(resultados["etiquetas_test"], pred, nlp.ETIQUETAS)
        ok(
            abs(recalculadas["acierto"] - met["acierto"]) < 1e-12
            and recalculadas["matriz"] == met["matriz"]
            and all(abs(recalculadas["por_clase"][c]["f1"] - met["por_clase"][c]["f1"]) < 1e-12 for c in nlp.ETIQUETAS),
            f"métricas {nombre}: recalculadas desde las predicciones y matriz que suma {sum(sum(f) for f in met['matriz'])} = {len(pred)} del test",
        )

    # Paso 6 · Comprueba el adaptador simulado del Hub y sus límites
    # Por qué: el adaptador no debe inventar vectores para textos fuera del fixture; se declara el modo y la
    #          licencia del ítem, que es lo que exige el Hub.
    # Salida esperada: "OK adaptador: all-MiniLM-L6-v2 · apache-2.0 · 16 dimensiones · 3 textos".
    # Si falla: ErrorDeFixture → falta datos-ejemplo/fixtures/huggingface-embeddings.json o cambió.
    cliente = adaptador.AdaptadorHub()
    info = cliente.modelo()
    ok(
        info["modelo"] == "all-MiniLM-L6-v2" and info["licencia"] == "apache-2.0" and info["dim"] == 16 and cliente.tamano_fixture() == 3,
        f"adaptador: {info['modelo']} · {info['licencia']} · {info['dim']} dimensiones · {cliente.tamano_fixture()} textos",
    )
    primero = cliente.datos["textos"][0]["texto"]
    ok(
        len(cliente.embedding(primero)) == 16 and cliente.embedding(primero) == cliente.embedding(primero),
        "adaptador: vector de 16 dimensiones y determinista para los textos del fixture",
    )
    try:
        cliente.embedding("texto que no está en el fixture")
        fallo_esperado = False
    except adaptador.ErrorDeFixture:
        fallo_esperado = True
    ok(fallo_esperado, "adaptador: un texto sin fixture lanza ErrorDeFixture (no inventa vectores sin red)")

    # Paso 7 · Comprueba que el código es offline y no lleva claves
    # Por qué: la entrega se comparte y la puerta se ejecuta sin red.
    # Salida esperada: "el código no hace peticiones de red" y "no contiene claves".
    # Si falla: aparece un http(s) o un patrón de token → quítalo antes de empaquetar.
    fuentes = [nlp.RAIZ / "nlp.py", nlp.RAIZ / "adaptador.py", nlp.DATOS / "fixtures" / "huggingface-embeddings.json"]
    texto = "\n".join(ruta.read_text(encoding="utf-8") for ruta in fuentes)
    ok("http://" not in texto and "https://" not in texto, "el código del proyecto no hace peticiones de red")
    ok(
        not any(patron in texto for patron in ("ghp_", "github_pat_", "Authorization:", "api_key", "hf_")),
        "el código del proyecto no contiene claves ni cabeceras de autorización",
    )

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
