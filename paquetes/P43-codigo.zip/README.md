# P43 · NLP clásico: de bolsa de palabras a embeddings — código ejecutable

Compara dos representaciones del texto —**TF-IDF** y **embeddings densos calculados en local**— con la
misma partición, la misma línea base y métricas fuera de muestra, sobre las 600 reseñas sintéticas del
CSV. Audita antes la trampa del dataset: 233 de los 600 textos están repetidos (367 únicos) y un split
por fila repartiría la misma reseña entre train y test. No usa red. Es el código que acompaña a la ficha
`../../fichas-portfolio/p43-nlp-clasico-a-embeddings.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: solo la biblioteca estándar (`csv`, `hashlib`, `math`, `random`).
- No hace falta red ni clave: los embeddings del corpus se calculan en local por hashing y el modelo
  descargado del Hub se representa con un **fixture capturado** y un adaptador simulado.

## Instalación

```powershell
cd proyectos/p43-nlp-clasico-a-embeddings/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` no instala nada: el proyecto es de biblioteca estándar.

## Orden de ejecución

```powershell
python nlp.py --comprobar   # solo valida el CSV y muestra el resumen del corpus
python nlp.py               # audita, parte, entrena TF-IDF y embeddings y guarda resultados/
python adaptador.py         # comprueba el fixture del Hub: modelo, licencia, dimensión y textos
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta es **solo stdout** (no escribe en disco) y no usa red. Comprueba **19 cosas**: 600 filas × 5
columnas con 600 ids únicos, etiquetas (positiva 241, negativa 188, neutra 171), canales (web 206, tienda
199, app 195), longitudes de 8 a 14 palabras y `longitud_palabras` cuadrando con el texto, la auditoría de
duplicados (367 textos únicos, 233 repetidos, 177 primeras frases únicas, 110 palabras tal cual), que la
partición agrupa por texto y no comparte ninguna reseña entre train y test, que TF-IDF y embeddings usan
la **misma** partición, que los dos superan la línea base, que las métricas se recalculan desde las
predicciones, el adaptador simulado del Hub y que el código no hace red ni lleva claves. Termina en
`RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). La salida real es la de
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt), con **19 comprobaciones** en verde:

- **Partición:** train 418 filas · test 182 filas · **textos compartidos 0** (agrupando por texto).
- **TF-IDF:** vocabulario de 107 términos limpios · acierto **1,000** · macro F1 **1,000**.
- **Embeddings:** 64 dimensiones (hashing local, semilla 7) · acierto **0,951** · macro F1 **0,957**.
- **Línea base:** acierto **0,451** en el test (clase mayoritaria `positiva`); sobre el corpus completo la
  clase mayoritaria es el 40,2 % (241/600), que es la cifra de la ficha.

El acierto casi perfecto de TF-IDF **no** demuestra comprensión del lenguaje: las plantillas del
generador hacen que cada etiqueta tenga su propio repertorio de frases y cierres. El informe lo dice y la
comparación se juzga contra la línea base y con la matriz de confusión por clase.

## Datos y procedencia

- `datos-ejemplo/resenas-texto.csv`: **600 filas × 5 columnas** (`id`, `texto`, `etiqueta`,
  `longitud_palabras`, `canal`). Sintético, semilla 20261109 y **CC0-1.0**. Copia literal del catálogo del
  portal (`aprender/web/datos/datasets/resenas-texto.csv`), no presente en `datasets/csv/` de este
  repositorio; sha256 `30f40f0d7ea897cf2ec849ada0e383d8391685113ed92ffab5a6dd1935ee990c`.
- `datos-ejemplo/parametros.json`: semilla de partición 20261109, 30 % de test, `min_df` 1, 64
  dimensiones de embeddings y semilla 7 para el hashing.
- `datos-ejemplo/fixtures/huggingface-embeddings.json`: **respuesta simulada** con la forma de la API del
  Hub (modelo `all-MiniLM-L6-v2`, licencia `apache-2.0`, `dim` 16 y 3 textos con sus vectores
  **truncados** para que el fichero se lea). No se ha descargado nada; no viaja ningún modelo.
- `resultados/`: `comparacion.csv`, `matriz-tfidf.csv`, `matriz-embeddings.csv` y `metricas.json`, que se
  regeneran con `python nlp.py`.

## Qué es real y qué es simulado

- **Real:** el CSV es el del catálogo del portal (CC0-1.0, sha256 comprobado) y las métricas salen del
  código ejecutado. El modelo de embeddings citado existe y declara apache-2.0.
- **Simulado:** la llamada al Hub. El adaptador lee un fixture con 3 vectores truncados y, para cualquier
  otro texto, lanza `ErrorDeFixture` en vez de inventar un vector. El proyecto completo usa embeddings
  locales por hashing, declarados como tales.
- **Sin red:** `verificar.py` no abre sockets ni lee variables de entorno con claves; no hay ninguna clave
  en el repositorio (el modo real usaría la variable de entorno del cliente, nunca el código).

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · CSV y validación | Contrato de columnas y recuentos antes de modelar | `Contratos de datos` |
| 2 · Auditoría de duplicados | Plantillas repetidas y por qué inflan la métrica | `Fuga de datos` |
| 3 · Partición agrupada | Partir por texto, no por fila, para no filtrar el test | `Fuga de datos` |
| 4 · TF-IDF | Vocabulario e idf calculados solo con el train | `Índices y búsqueda en texto` |
| 5 · Embeddings por hashing | Vector denso local, reproducible y declarado | `Embeddings` |
| 6 · Centroides y coseno | Clasificar por similitud y medir el parecido | `Producto punto y similitud` |
| 7 · Evaluación fuera de muestra | Acierto, línea base y macro F1 no bastan sin la matriz | `Métricas de clasificación` |
| 8 · Matriz de confusión | Mirar clase a clase, sobre todo la neutra | `Matriz de confusión` |

## Estructura

```text
codigo/
├── nlp.py                  # carga, auditoría, partición, TF-IDF, embeddings, métricas y CSV
├── adaptador.py            # cliente simulado del Hub que lee el fixture (sin red)
├── datos-ejemplo/          # resenas-texto.csv (CC0-1.0), parametros.json y fixtures/
├── verificar.py            # la puerta del proyecto (solo stdout, sin red)
└── resultados/             # ejemplo-salida.txt y las tablas generadas
```

## Fallos típicos

- **Fuga por duplicados:** partir por fila reparte copias del mismo texto entre train y test; la partición
  agrupa por texto limpio y la puerta comprueba que la intersección es vacía.
- **`longitud_palabras` como feature:** es una función del texto; el modelo solo usa el texto limpio.
- **Vocabulario construido con todo el corpus:** el idf se calcula solo con el train; si se hace con todo,
  la métrica deja de ser fuera de muestra.
- **Creerse el 100 %:** el acierto casi perfecto viene de las plantillas del generador, no de entender
  reseñas; el README y la ficha lo dicen.
- **Línea base ausente:** sin la clase mayoritaria (40,2 % del corpus / 45,1 % del test) un 0,95 no se
  puede juzgar.
- **Embeddings sin declarar el origen:** aquí son hashing local de 64 dimensiones, no un modelo del Hub;
  el fixture solo demuestra la forma de la respuesta.
- **Adaptador que inventa vectores:** para un texto sin fixture debe fallar; si devolviera ruido, el modo
  «simulado» se confundiría con el real.
- **`FileNotFoundError` del CSV:** falta `datos-ejemplo/resenas-texto.csv`; el ZIP lo trae y el sha256 está
  en este README.
