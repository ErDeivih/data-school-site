#!/usr/bin/env python3
"""P43 · NLP clásico: de bolsa de palabras a embeddings.

Proyecto completo de la ficha P43. Carga las 600 reseñas sintéticas del CSV, audita los duplicados de
plantilla, parte el corpus agrupando por texto (sin fuga), entrena dos representaciones —TF-IDF y
embeddings densos calculados en local por hashing— y las compara fuera de muestra contra la línea base de
clase mayoritaria, con matriz de confusión y métricas por clase. No usa red.

    python nlp.py            # audita, parte, entrena los dos modelos y guarda resultados/
    python nlp.py --comprobar # solo valida el CSV y muestra el resumen del corpus

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"

COLUMNAS = ["id", "texto", "etiqueta", "longitud_palabras", "canal"]
ETIQUETAS = ("negativa", "neutra", "positiva")
CANALES = ("app", "tienda", "web")
PUNTUACION = str.maketrans("", "", ".,;:!?«»\"'()[]{}¿¡")


def cargar_parametros() -> dict:
    # Paso 1 · Lee la semilla, la proporción de test y la dimensión de los embeddings
    # Por qué: la partición y la dimensión no se eligen después de ver el acierto; quedan declaradas en
    #          un JSON y la puerta comprueba que se usan.
    # Salida esperada: "parametros: semilla 20261109 · test 0.30 · embeddings 64 dimensiones"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o restaura datos-ejemplo/parametros.json.
    ruta = DATOS / "parametros.json"
    parametros = json.loads(ruta.read_text(encoding="utf-8"))
    obligatorias = ("semilla", "test_frac", "min_df", "dim_embeddings", "modelo_embeddings", "semilla_embeddings")
    faltan = [clave for clave in obligatorias if clave not in parametros]
    if faltan:
        raise RuntimeError(f"faltan claves en {ruta.name}: {', '.join(faltan)}")
    if not 0.1 <= float(parametros["test_frac"]) <= 0.5:
        raise RuntimeError("«test_frac» tiene que estar entre 0,1 y 0,5")
    return parametros


def limpiar(texto: str) -> str:
    """Minúsculas, sin puntuación y con espacios simples: la limpieza se declara en el README."""
    minusculas = texto.lower().translate(PUNTUACION)
    return re.sub(r"\s+", " ", minusculas).strip()


def cargar_corpus() -> dict:
    # Paso 2 · Carga el CSV y valida la estructura antes de modelar nada
    # Por qué: con 600 filas y 5 columnas, un id repetido o una etiqueta fuera del contrato invalidaría
    #          el split y las métricas; se comprueba antes de partir.
    # Salida esperada: "corpus: 600 filas · 5 columnas · ids unicos 600"
    # Si falla: RuntimeError → el CSV no está en datos-ejemplo/ o cambió de forma.
    ruta = DATOS / "resenas-texto.csv"
    with ruta.open(encoding="utf-8", newline="") as f:
        lector = csv.DictReader(f)
        columnas = lector.fieldnames or []
        filas = [fila for fila in lector if fila]
    if columnas != COLUMNAS:
        raise RuntimeError(f"columnas del CSV: {columnas} (se esperaban {COLUMNAS})")
    if len(filas) != 600:
        raise RuntimeError(f"filas del CSV: {len(filas)} (se esperaban 600)")
    ids = [fila["id"] for fila in filas]
    if len(set(ids)) != len(ids):
        raise RuntimeError("hay ids repetidos en el CSV")
    for fila in filas:
        if fila["etiqueta"] not in ETIQUETAS:
            raise RuntimeError(f"etiqueta desconocida: {fila['etiqueta']!r}")
        if fila["canal"] not in CANALES:
            raise RuntimeError(f"canal desconocido: {fila['canal']!r}")
        if int(fila["longitud_palabras"]) != len(fila["texto"].split()):
            raise RuntimeError(f"longitud_palabras no cuadra con el texto en {fila['id']}")
    return {
        "filas": filas,
        "ids": ids,
        "textos": [fila["texto"] for fila in filas],
        "etiquetas": [fila["etiqueta"] for fila in filas],
        "canales": [fila["canal"] for fila in filas],
        "longitudes": [int(fila["longitud_palabras"]) for fila in filas],
    }


def auditar(corpus: dict) -> dict:
    # Paso 3 · Audita duplicados de plantilla y vocabulario antes de partir
    # Por qué: el corpus se generó con plantillas; 233 textos están repetidos y un split por fila
    #          repartiría la misma reseña entre train y test, inflando el acierto.
    # Salida esperada: "textos unicos: 367 (233 repetidos) · primeras frases unicas 177 · vocabulario 108"
    # Si falla: no falla con el CSV del catálogo; si el recuento cambia, el CSV no es el declarado.
    textos = corpus["textos"]
    limpios = [limpiar(texto) for texto in textos]
    unicos = set(limpios)
    primeras = set(texto.split(".")[0].strip().lower() for texto in textos)
    vocabulario = set(palabra for texto in textos for palabra in texto.lower().split())
    return {
        "etiquetas": {etiqueta: corpus["etiquetas"].count(etiqueta) for etiqueta in ETIQUETAS},
        "canales": {canal: corpus["canales"].count(canal) for canal in CANALES},
        "textos_unicos": len(unicos),
        "textos_repetidos": len(textos) - len(unicos),
        "primeras_frases_unicas": len(primeras),
        "vocabulario": len(vocabulario),
        "longitud_min": min(corpus["longitudes"]),
        "longitud_max": max(corpus["longitudes"]),
        "longitud_media": sum(corpus["longitudes"]) / len(corpus["longitudes"]),
    }


def partir_sin_fuga(corpus: dict, test_frac: float, semilla: int) -> list:
    # Paso 4 · Parte el corpus agrupando por texto completo, no por fila
    # Por qué: todos los duplicados de una misma reseña caen en el mismo lado; así ninguna reseña
    #          completa está a la vez en entrenamiento y en prueba.
    # Salida esperada: "particion: train 420 filas · test 180 filas · textos compartidos 0"
    # Si falla: RuntimeError → la proporción deja un lado vacío.
    grupos = {}
    for indice, texto in enumerate(corpus["textos"]):
        grupos.setdefault(limpiar(texto), []).append(indice)
    claves = sorted(grupos)
    random.Random(semilla).shuffle(claves)
    n_test = round(len(claves) * test_frac)
    if n_test <= 0 or n_test >= len(claves):
        raise RuntimeError("la proporción de test deja la partición vacía")
    en_test = set(claves[:n_test])
    asignacion = []
    for indice, texto in enumerate(corpus["textos"]):
        clave = limpiar(texto)
        asignacion.append({"indice": indice, "particion": "test" if clave in en_test else "train", "clave": clave})
    return asignacion


def coseno_denso(a: list, b: list) -> float:
    producto = sum(x * y for x, y in zip(a, b))
    norma_a = math.sqrt(sum(x * x for x in a))
    norma_b = math.sqrt(sum(y * y for y in b))
    if norma_a == 0.0 or norma_b == 0.0:
        return 0.0
    return producto / (norma_a * norma_b)


def coseno_disperso(a: dict, b: dict) -> float:
    comunes = set(a) & set(b)
    producto = sum(a[clave] * b[clave] for clave in comunes)
    norma_a = math.sqrt(sum(valor * valor for valor in a.values()))
    norma_b = math.sqrt(sum(valor * valor for valor in b.values()))
    if norma_a == 0.0 or norma_b == 0.0:
        return 0.0
    return producto / (norma_a * norma_b)


def entrenar_tfidf(textos_train: list, min_df: int) -> dict:
    # Paso 5 · Bolsa de palabras: vocabulario e idf calculados solo con el entrenamiento
    # Por qué: si el vocabulario se construye con todo el corpus, el test influye en el modelo y la
    #          métrica deja de ser fuera de muestra.
    # Salida esperada: "tfidf: vocabulario 108 terminos"
    # Si falla: RuntimeError → el entrenamiento se quedó sin términos.
    documentos = [limpiar(texto).split() for texto in textos_train]
    frecuencia_documental = {}
    for palabras in documentos:
        for palabra in set(palabras):
            frecuencia_documental[palabra] = frecuencia_documental.get(palabra, 0) + 1
    vocabulario = sorted(palabra for palabra, df in frecuencia_documental.items() if df >= min_df)
    if not vocabulario:
        raise RuntimeError("el vocabulario de entrenamiento está vacío")
    total = len(documentos)
    idf = {palabra: math.log((1.0 + total) / (1.0 + frecuencia_documental[palabra])) + 1.0 for palabra in vocabulario}
    return {"vocabulario": vocabulario, "idf": idf}


def vector_tfidf(texto: str, modelo: dict) -> dict:
    palabras = limpiar(texto).split()
    cuenta = {}
    for palabra in palabras:
        if palabra in modelo["idf"]:
            cuenta[palabra] = cuenta.get(palabra, 0) + 1
    return {palabra: (1.0 + math.log(cantidad)) * modelo["idf"][palabra] for palabra, cantidad in cuenta.items()}


def centroides_dispersos(vectores: list, etiquetas: list, clases: tuple) -> dict:
    centroides = {}
    for clase in clases:
        acumulado = {}
        n = 0
        for vector, etiqueta in zip(vectores, etiquetas):
            if etiqueta != clase:
                continue
            n += 1
            for palabra, valor in vector.items():
                acumulado[palabra] = acumulado.get(palabra, 0.0) + valor
        centroides[clase] = {palabra: valor / n for palabra, valor in acumulado.items()} if n else {}
    return centroides


def embeddings_hash(texto: str, dim: int, semilla: int) -> list:
    # Paso 6 · Embeddings densos calculados en local por hashing de palabras y bigramas
    # Por qué: sin red no hay modelo descargado; este vector es una representación densa declarada como
    #          local (no es el modelo del Hub) y la puerta comprueba que es determinista.
    # Salida esperada: "embeddings: dimension 64 · 600 vectores"
    # Si falla: ZeroDivisionError → dim 0; revisa «dim_embeddings» en el JSON.
    palabras = limpiar(texto).split()
    caracteristicas = palabras + [f"{a}_{b}" for a, b in zip(palabras, palabras[1:])]
    vector = [0.0] * dim
    for caracteristica in caracteristicas:
        resumen = hashlib.sha256(f"{semilla}:{caracteristica}".encode("utf-8")).hexdigest()
        cubo = int(resumen[:8], 16) % dim
        signo = 1.0 if int(resumen[8:10], 16) % 2 == 0 else -1.0
        vector[cubo] += signo
    norma = math.sqrt(sum(valor * valor for valor in vector))
    return [valor / norma for valor in vector] if norma else vector


def centroides_densos(vectores: list, etiquetas: list, clases: tuple) -> dict:
    centroides = {}
    for clase in clases:
        acumulado = [0.0] * len(vectores[0])
        n = 0
        for vector, etiqueta in zip(vectores, etiquetas):
            if etiqueta != clase:
                continue
            n += 1
            for i, valor in enumerate(vector):
                acumulado[i] += valor
        if n:
            centroides[clase] = [valor / n for valor in acumulado]
    return centroides


def predecir(vectores: list, centroides: dict, coseno) -> list:
    predicciones = []
    for vector in vectores:
        mejor_clase, mejor = None, -2.0
        for clase in sorted(centroides):
            similitud = coseno(vector, centroides[clase])
            if similitud > mejor:
                mejor, mejor_clase = similitud, clase
        predicciones.append(mejor_clase)
    return predicciones


def matriz_confusion(real: list, predicho: list, clases: tuple) -> list:
    indice = {clase: i for i, clase in enumerate(clases)}
    matriz = [[0] * len(clases) for _ in clases]
    for verdad, prediccion in zip(real, predicho):
        matriz[indice[verdad]][indice[prediccion]] += 1
    return matriz


def metricas(real: list, predicho: list, clases: tuple) -> dict:
    aciertos = sum(1 for verdad, prediccion in zip(real, predicho) if verdad == prediccion)
    exactitud = aciertos / len(real)
    matriz = matriz_confusion(real, predicho, clases)
    por_clase = {}
    for i, clase in enumerate(clases):
        verdaderos_positivos = matriz[i][i]
        predichos = sum(matriz[fila][i] for fila in range(len(clases)))
        reales = sum(matriz[i])
        precision = verdaderos_positivos / predichos if predichos else 0.0
        recall = verdaderos_positivos / reales if reales else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        por_clase[clase] = {"precision": precision, "recall": recall, "f1": f1, "soporte": reales}
    macros = {
        "precision": sum(valor["precision"] for valor in por_clase.values()) / len(clases),
        "recall": sum(valor["recall"] for valor in por_clase.values()) / len(clases),
        "f1": sum(valor["f1"] for valor in por_clase.values()) / len(clases),
    }
    return {"acierto": exactitud, "macro": macros, "por_clase": por_clase, "matriz": matriz}


def ejecutar(parametros: dict) -> dict:
    """Carga, audita, parte, entrena los dos modelos y devuelve todo lo que la puerta necesita."""
    corpus = cargar_corpus()
    auditoria = auditar(corpus)
    asignacion = partir_sin_fuga(corpus, float(parametros["test_frac"]), int(parametros["semilla"]))
    indices_train = [fila["indice"] for fila in asignacion if fila["particion"] == "train"]
    indices_test = [fila["indice"] for fila in asignacion if fila["particion"] == "test"]
    claves_train = {asignacion[i]["clave"] for i in indices_train}
    claves_test = {asignacion[i]["clave"] for i in indices_test}

    # Paso 7 · Entrena TF-IDF y embeddings con la MISMA partición y evalúa fuera de muestra
    # Por qué: comparar dos modelos con splits distintos no compara nada; la partición es una sola.
    # Salida esperada: "tfidf: acierto 0.99 · embeddings: acierto 0.97 · linea base 0.40"
    # Si falla: el acierto no supera la línea base → revisa la limpieza o la partición.
    textos_train = [corpus["textos"][i] for i in indices_train]
    textos_test = [corpus["textos"][i] for i in indices_test]
    etiquetas_train = [corpus["etiquetas"][i] for i in indices_train]
    etiquetas_test = [corpus["etiquetas"][i] for i in indices_test]

    modelo_tfidf = entrenar_tfidf(textos_train, int(parametros["min_df"]))
    vectores_tfidf = [vector_tfidf(texto, modelo_tfidf) for texto in textos_train]
    centroides_tfidf = centroides_dispersos(vectores_tfidf, etiquetas_train, ETIQUETAS)
    pred_tfidf = predecir([vector_tfidf(texto, modelo_tfidf) for texto in textos_test], centroides_tfidf, coseno_disperso)
    met_tfidf = metricas(etiquetas_test, pred_tfidf, ETIQUETAS)

    dim = int(parametros["dim_embeddings"])
    semilla_emb = int(parametros["semilla_embeddings"])
    vectores_emb = [embeddings_hash(texto, dim, semilla_emb) for texto in textos_train]
    centroides_emb = centroides_densos(vectores_emb, etiquetas_train, ETIQUETAS)
    pred_emb = predecir([embeddings_hash(texto, dim, semilla_emb) for texto in textos_test], centroides_emb, coseno_denso)
    met_emb = metricas(etiquetas_test, pred_emb, ETIQUETAS)

    mayoritaria = max(ETIQUETAS, key=lambda clase: auditoria["etiquetas"][clase])
    acierto_base = sum(1 for etiqueta in etiquetas_test if etiqueta == mayoritaria) / len(etiquetas_test)

    print(f"corpus: {len(corpus['filas'])} filas · {len(COLUMNAS)} columnas · ids unicos {len(set(corpus['ids']))}")
    print(
        "etiquetas: "
        + " · ".join(f"{clase} {auditoria['etiquetas'][clase]}" for clase in ETIQUETAS)
        + f" · linea base {acierto_base:.3f} ({mayoritaria})"
    )
    print("canales: " + " · ".join(f"{canal} {auditoria['canales'][canal]}" for canal in CANALES))
    print(
        f"textos unicos: {auditoria['textos_unicos']} ({auditoria['textos_repetidos']} repetidos)"
        f" · primeras frases unicas {auditoria['primeras_frases_unicas']}"
        f" · vocabulario {auditoria['vocabulario']} (tal cual) / {len(modelo_tfidf['vocabulario'])} limpio"
    )
    print(
        f"longitudes: {auditoria['longitud_min']}-{auditoria['longitud_max']} palabras"
        f" · media {auditoria['longitud_media']:.1f}"
    )
    print(
        f"particion: train {len(indices_train)} filas · test {len(indices_test)} filas"
        f" · textos compartidos {len(claves_train & claves_test)}"
    )
    print(
        f"tfidf: vocabulario {len(modelo_tfidf['vocabulario'])} terminos"
        f" · acierto {met_tfidf['acierto']:.3f} · macro F1 {met_tfidf['macro']['f1']:.3f}"
    )
    print(
        f"embeddings: dimension {dim} ({parametros['modelo_embeddings']})"
        f" · acierto {met_emb['acierto']:.3f} · macro F1 {met_emb['macro']['f1']:.3f}"
    )
    print(f"linea base: acierto {acierto_base:.3f} (clase mayoritaria {mayoritaria})")
    return {
        "corpus": corpus,
        "auditoria": auditoria,
        "asignacion": asignacion,
        "modelo_tfidf": modelo_tfidf,
        "met_tfidf": met_tfidf,
        "met_emb": met_emb,
        "pred_tfidf": pred_tfidf,
        "pred_emb": pred_emb,
        "etiquetas_test": etiquetas_test,
        "acierto_base": acierto_base,
        "mayoritaria": mayoritaria,
        "dim": dim,
        "claves_train": claves_train,
        "claves_test": claves_test,
    }


def guardar(resultados: dict, parametros: dict) -> None:
    # Paso 8 · Guarda la comparación, las matrices de confusión y las métricas
    # Por qué: una tabla que no se puede recalcular no demuestra nada; se guardan predicciones y matriz
    #          para que la puerta recomponga los números.
    # Salida esperada: "resultados: comparacion.csv, matriz-tfidf.csv, matriz-embeddings.csv, metricas.json"
    # Si falla: PermissionError → resultados/ no es escribible; ejecuta desde codigo/.
    RESULTADOS.mkdir(parents=True, exist_ok=True)
    with (RESULTADOS / "comparacion.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["modelo", "acierto", "macro_precision", "macro_recall", "macro_f1"])
        escritor.writerow(["tfidf", f"{resultados['met_tfidf']['acierto']:.6f}", f"{resultados['met_tfidf']['macro']['precision']:.6f}",
                           f"{resultados['met_tfidf']['macro']['recall']:.6f}", f"{resultados['met_tfidf']['macro']['f1']:.6f}"])
        escritor.writerow(["embeddings", f"{resultados['met_emb']['acierto']:.6f}", f"{resultados['met_emb']['macro']['precision']:.6f}",
                           f"{resultados['met_emb']['macro']['recall']:.6f}", f"{resultados['met_emb']['macro']['f1']:.6f}"])
        escritor.writerow(["linea_base", f"{resultados['acierto_base']:.6f}", "", "", ""])
    for nombre, met in (("matriz-tfidf.csv", resultados["met_tfidf"]), ("matriz-embeddings.csv", resultados["met_emb"])):
        with (RESULTADOS / nombre).open("w", encoding="utf-8", newline="") as f:
            escritor = csv.writer(f)
            escritor.writerow(["real\\predicho"] + list(ETIQUETAS))
            for clase, fila in zip(ETIQUETAS, met["matriz"]):
                escritor.writerow([clase] + fila)
    metricas_json = {
        "tfidf": resultados["met_tfidf"],
        "embeddings": resultados["met_emb"],
        "linea_base": {"acierto": resultados["acierto_base"], "clase_mayoritaria": resultados["mayoritaria"]},
        "particion": {"train": sum(1 for f in resultados["asignacion"] if f["particion"] == "train"),
                       "test": sum(1 for f in resultados["asignacion"] if f["particion"] == "test")},
    }
    (RESULTADOS / "metricas.json").write_text(json.dumps(metricas_json, ensure_ascii=False, indent=2), encoding="utf-8")
    print("resultados: comparacion.csv, matriz-tfidf.csv, matriz-embeddings.csv, metricas.json")


def main(argv: list) -> int:
    try:
        parametros = cargar_parametros()
        if "--comprobar" in argv:
            corpus = cargar_corpus()
            auditoria = auditar(corpus)
            print(f"corpus: {len(corpus['filas'])} filas · textos unicos {auditoria['textos_unicos']}")
            print("etiquetas: " + " · ".join(f"{c} {auditoria['etiquetas'][c]}" for c in ETIQUETAS))
            return 0
        print("== P43 · NLP clasico: de bolsa de palabras a embeddings ==")
        resultados = ejecutar(parametros)
        guardar(resultados, parametros)
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
