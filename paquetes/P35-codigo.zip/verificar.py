#!/usr/bin/env python3
"""Puerta del proyecto P35 (NumPy de verdad: vectorizar un análisis).

Comprueba el resultado de verdad, sin escribir nada y sin red: el CSV es el del catálogo (sha256), el
grano es 180 días y 3 tiendas, el bucle y el array dan los mismos totales al céntimo, la máscara de
broadcasting tiene forma (3, 180) con 60 filas por tienda, la medición repite y publica un veredicto,
y el cálculo no depende de aleatoriedad.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import inspect
import sys

import numpy as np

import numpy_de_verdad as p

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P35 · NumPy de verdad ==")

    # Paso 1 · Comprueba el dato de ejemplo y el grano
    # Por qué: si el CSV no es el del catálogo o el grano no es una fila por día y tienda, los totales
    #          de después no se comparan con la ficha.
    # Salida esperada: "datos: 180 filas × 4 columnas · 3 tiendas × 60 filas · 180 fechas únicas"
    # Si falla: FileNotFoundError → falta datos-ejemplo/ventas-mensuales.csv (el ZIP lo trae).
    datos = p.cargar()
    ok(len(datos["fechas"]) == 180 and len(datos["unidades"]) == 180,
       f"CSV: {len(datos['fechas'])} filas")
    ok(p.sha256(p.DATOS) == "afa71a0b0ae0189e863247ff5a25f4ebe1836742ac7686f929d6a42565ecf7f6",
       "el sha256 del CSV de ejemplo es el de la copia del catálogo")
    ok(len(set(datos["fechas"])) == 180, "fechas únicas: 180")
    ok(all(datos["tiendas"].count(tienda) == 60 for tienda in p.TIENDAS),
       "cada tienda aparece 60 veces")

    # Paso 2 · Comprueba que la versión con bucle es de verdad un bucle de Python
    # Por qué: la comparación solo vale si una versión no usa la herramienta de la otra; se mira el
    #          código fuente de la función, no una promesa del README.
    # Salida esperada: "el bucle no usa NumPy"
    # Si falla: aparece `np.` dentro de _bucle → la comparación de versiones no demuestra nada.
    fuente_bucle = inspect.getsource(p._bucle)
    ok("np." not in fuente_bucle and "import numpy" not in fuente_bucle,
       "el bucle no usa NumPy para sumar")

    # Paso 3 · Comprueba los totales de las dos versiones y su igualdad al céntimo
    # Por qué: el criterio de la ficha es que los totales cuadren; se recalcula y se comparan en
    #          céntimos, no con igualdad exacta de floats.
    # Salida esperada: "bucle 14295 unidades / 192292.08 EUR · vectorizado los mismos"
    # Si falla: total distinto de 14295 → la columna sumada no es la correcta.
    bucle = p.totales_bucle(datos)
    vector = p.totales_vectorizado(datos)
    ok(bucle["unidades"] == 14295 and bucle["centimos"] == 19229208,
       f"bucle: {bucle['unidades']} unidades y {bucle['centimos'] / 100:.2f} EUR")
    ok(vector["unidades"] == 14295 and vector["centimos"] == 19229208,
       f"vectorizado: {vector['unidades']} unidades y {vector['centimos'] / 100:.2f} EUR")
    comparacion = p.comparar(bucle, vector)
    ok(comparacion["diferencia_total_cent"] == 0, "total al céntimo: diferencia 0")
    ok(all(valor == 0 for valor in comparacion["diferencias"].values()),
       "por tienda al céntimo: diferencia 0 en las tres")
    ok([bucle["por_tienda"][t]["unidades"] for t in p.TIENDAS] == [4892, 4651, 4752],
       "unidades por tienda: centro 4892 · norte 4651 · sur 4752")
    ok([bucle["por_tienda"][t]["centimos"] for t in p.TIENDAS] == [6527956, 6280388, 6420864],
       "céntimos por tienda: 6527956 · 6280388 · 6420864")

    # Paso 4 · Comprueba la máscara de broadcasting
    # Por qué: la ficha pide una máscara de forma (3, 180) construida por broadcasting; si la forma
    #          es otra, el total por tienda se calcula de otra manera.
    # Salida esperada: "máscara (3, 180) con 60 filas por tienda"
    # Si falla: forma distinta → revisa los reshape (3, 1) y (1, 180).
    mascara = vector["mascara"]
    ok(mascara.shape == (3, 180), f"máscara: forma {mascara.shape}")
    ok(bool((mascara.sum(axis=1) == 60).all()), "60 filas por tienda en la máscara")
    fuente_vector = inspect.getsource(p._vector)
    ok("mascara" in fuente_vector and ".dot(" in fuente_vector,
       "el vectorizado usa la máscara y el producto matricial")
    ok("range(" not in fuente_vector, "el vectorizado no recorre filas por índice")

    # Paso 5 · Comprueba la medición: repeticiones, mediana y veredicto
    # Por qué: una sola cifra es una anécdota; la ficha exige repeticiones, calentamiento, mediana y
    #          una lectura de si la diferencia es real.
    # Salida esperada: "medición: bucle … µs · vectorizado … µs con 1000 repeticiones"
    # Si falla: medianas de 0 µs → el cronómetro no envuelve el cálculo.
    medicion = p.medir(datos)
    ok(medicion["bucle"]["veces"] == 1000 and medicion["vectorizado"]["veces"] == 1000,
       "medición con 1000 repeticiones por versión")
    ok(medicion["bucle"]["mediana_us"] > 0 and medicion["vectorizado"]["mediana_us"] > 0,
       "las dos medianas son mayores que 0 µs")
    ok(medicion["bucle"]["dispersion_us"] >= 0 and medicion["vectorizado"]["dispersion_us"] >= 0,
       "las dos dispersiones son no negativas")
    ok(isinstance(medicion["concluyente"], bool), "la medición publica un veredicto explícito")

    # Paso 6 · Comprueba que el cálculo es determinista
    # Por qué: si el resultado cambia entre ejecuciones, los totales no son un dato del fichero.
    # Salida esperada: "dos cargas y dos cálculos dan lo mismo"
    # Si falla: valores distintos → hay aleatoriedad o estado global en el cálculo.
    bucle2 = p._bucle(p.cargar())
    ok(bucle2 == bucle, "dos ejecuciones del bucle dan el mismo resultado")
    vector2 = p._vector(datos)
    ok(bool(np.array_equal(vector2["mascara"], mascara)) and vector2["unidades"] == vector["unidades"],
       "dos ejecuciones del vectorizado dan la misma máscara y el mismo total")

    # Paso 7 · Comprueba que el código es offline y no lleva secretos
    # Por qué: la puerta se ejecuta sin red y la carpeta se comparte; una descarga escondida rompería
    #          la promesa del README.
    # Salida esperada: "código offline, sin claves"
    # Si falla: aparece una llamada de red o un token en el código.
    texto = (p.RAIZ / "numpy_de_verdad.py").read_text(encoding="utf-8")
    ok(not any(x in texto for x in ("import requests", "import urllib", "import socket",
                                    "urlopen(", "requests.get")),
       "el código no hace peticiones de red")
    ok(not any(x in texto for x in ("ghp_", "github_pat_", "Authorization:")),
       "el código no contiene claves ni cabeceras de autorización")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
