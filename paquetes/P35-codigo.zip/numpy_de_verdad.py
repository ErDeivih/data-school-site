#!/usr/bin/env python3
"""P35 · NumPy de verdad: vectorizar un análisis.

Código ejecutable del proyecto P35 (ruta datos, nivel básico). Calcula los totales de ventas de dos
formas —un bucle de Python y arrays de NumPy con broadcasting—, demuestra que dan el mismo resultado
al céntimo y mide las dos versiones con repeticiones, calentamiento y mediana.

Uso:
    python numpy_de_verdad.py            # pipeline completo; escribe las tablas en resultados/
    python numpy_de_verdad.py limpiar    # borra las tablas generadas

Datos: datos-ejemplo/ventas-mensuales.csv (180 filas × 4 columnas, CC0-1.0; procedencia en el README).
Sin red: solo la biblioteca estándar y numpy.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import statistics
import sys
import time
from pathlib import Path

import numpy as np

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo" / "ventas-mensuales.csv"
RESULTADOS = RAIZ / "resultados"

TIENDAS = ["centro", "norte", "sur"]
COLUMNAS = ["fecha", "tienda", "unidades", "ingresos"]
REPETICIONES = 1000
CALENTAMIENTO = 50
GENERADOS = ["totales.csv", "tiempos.csv", "broadcasting.md"]


def exigir(condicion: bool, mensaje: str) -> None:
    """Aborta con un mensaje legible; el pipeline devuelve 1 y no deja resultados a medias."""
    if not condicion:
        raise RuntimeError(mensaje)


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def cargar() -> dict:
    # Paso 1 · Carga el CSV y comprueba el grano antes de calcular nada
    # Por qué: el nombre «mensuales» engaña; una fila es un día de una tienda, y si el recuento o las
    #          tiendas no cuadran, los totales de después no comparan nada.
    # Salida esperada: "datos: 180 filas × 4 columnas · 3 tiendas × 60 filas · 180 fechas únicas"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o recupera el CSV de datos-ejemplo/.
    exigir(DATOS.exists(), f"no existe el dato de ejemplo: {DATOS}")
    with DATOS.open(encoding="utf-8", newline="") as fichero:
        lector = csv.DictReader(fichero)
        exigir(lector.fieldnames == COLUMNAS, f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    exigir(len(filas) == 180, f"se esperaban 180 filas y hay {len(filas)}")
    fechas = [fila["fecha"] for fila in filas]
    tiendas = [fila["tienda"] for fila in filas]
    unidades = [int(fila["unidades"]) for fila in filas]
    ingresos = [float(fila["ingresos"]) for fila in filas]
    exigir(len(set(fechas)) == 180, "las fechas no son únicas")
    for tienda in TIENDAS:
        exigir(tiendas.count(tienda) == 60, f"la tienda {tienda} no tiene 60 filas")
    exigir(set(tiendas) == set(TIENDAS), f"tiendas inesperadas: {sorted(set(tiendas))}")
    print(f"datos: {len(filas)} filas × {len(COLUMNAS)} columnas · "
          f"{len(TIENDAS)} tiendas × 60 filas · {len(set(fechas))} fechas únicas · "
          f"sha256 {sha256(DATOS)[:8]}…")
    return {"fechas": fechas, "tiendas": tiendas, "unidades": unidades, "ingresos": ingresos}


def _bucle(datos: dict) -> dict:
    """Cálculo de referencia sin NumPy ni pandas: suma recorriendo filas."""
    unidades = 0
    centimos = 0
    por_tienda = {tienda: {"unidades": 0, "centimos": 0} for tienda in TIENDAS}
    for i, tienda in enumerate(datos["tiendas"]):
        unidades += datos["unidades"][i]
        cents = round(datos["ingresos"][i] * 100)
        centimos += cents
        por_tienda[tienda]["unidades"] += datos["unidades"][i]
        por_tienda[tienda]["centimos"] += cents
    return {"unidades": unidades, "centimos": centimos, "por_tienda": por_tienda}


def totales_bucle(datos: dict) -> dict:
    # Paso 2 · Calcula los totales con un bucle de Python, sin NumPy
    # Por qué: es la versión de referencia; si se suma con una herramienta y la comprobación se
    #          hace con la misma, no se demuestra nada.
    # Salida esperada: "bucle: 14295 unidades · 192292.08 EUR · por tienda centro, norte y sur"
    # Si falla: total distinto de 14295 → no se está sumando la columna correcta.
    resultado = _bucle(datos)
    print(f"bucle: {resultado['unidades']} unidades · {resultado['centimos'] / 100:.2f} EUR · "
          "por tienda " + ", ".join(f"{t} {resultado['por_tienda'][t]['unidades']}" for t in TIENDAS))
    return resultado


def _vector(datos: dict) -> dict:
    """Cálculo con arrays y máscara de broadcasting, sin recorrer filas."""
    etiquetas = np.array(datos["tiendas"], dtype=object)
    unidades = np.array(datos["unidades"], dtype=np.int64)
    centimos = np.rint(np.array(datos["ingresos"], dtype=float) * 100).astype(np.int64)
    mascara = np.array(TIENDAS, dtype=object).reshape(3, 1) == etiquetas.reshape(1, 180)
    por_unidades = mascara.dot(unidades)
    por_centimos = mascara.dot(centimos)
    por_tienda = {}
    for k, tienda in enumerate(TIENDAS):
        por_tienda[tienda] = {"unidades": int(por_unidades[k]), "centimos": int(por_centimos[k])}
    return {"unidades": int(unidades.sum()), "centimos": int(centimos.sum()),
            "por_tienda": por_tienda, "mascara": mascara}


def totales_vectorizado(datos: dict) -> dict:
    # Paso 3 · Calcula lo mismo con arrays y una máscara de broadcasting (3, 180)
    # Por qué: multiplicar dos arrays de la misma longitud no enseña broadcasting; comparar la lista
    #          de tiendas en forma (3, 1) con las etiquetas en forma (1, 180) sí: la máscara resultante
    #          suma por tienda sin recorrer filas.
    # Salida esperada: "vectorizado: 14295 unidades · 192292.08 EUR · máscara (3, 180) con 60 por tienda"
    # Si falla: ValueError de formas → revisa el reshape (3, 1) y (1, 180).
    resultado = _vector(datos)
    mascara = resultado["mascara"]
    print(f"vectorizado: {resultado['unidades']} unidades · {resultado['centimos'] / 100:.2f} EUR · "
          f"máscara {mascara.shape} con {int(mascara.sum(axis=1).max())} por tienda")
    return resultado


def comparar(bucle: dict, vector: dict) -> dict:
    # Paso 4 · Compara las dos versiones al céntimo, no con igualdad de floats
    # Por qué: el orden de la suma mueve los últimos decimales de un float; la comprobación se hace en
    #          céntimos y solo entonces la diferencia es cero de verdad.
    # Salida esperada: "comparación: 0 céntimos de diferencia en el total y en las tres tiendas"
    # Si falla: diferencia distinta de 0 → una de las dos versiones no está sumando lo mismo.
    diferencia_total = abs(bucle["centimos"] - vector["centimos"])
    diferencias = {tienda: abs(bucle["por_tienda"][tienda]["centimos"]
                               - vector["por_tienda"][tienda]["centimos"]) for tienda in TIENDAS}
    exigir(diferencia_total == 0, f"los totales difieren en {diferencia_total} céntimos")
    exigir(all(valor == 0 for valor in diferencias.values()), f"difieren por tienda: {diferencias}")
    print(f"comparación: {diferencia_total} céntimos de diferencia en el total y en las tres tiendas")
    return {"diferencia_total_cent": diferencia_total, "diferencias": diferencias}


def medir(datos: dict, veces: int = REPETICIONES) -> dict:
    # Paso 5 · Mide las dos versiones en igualdad de condiciones
    # Por qué: con 180 filas, una sola ejecución mide el ruido de la máquina; se calienta, se repite
    #          mil veces y se publica la mediana con su dispersión. Se cronometra el cálculo, no el
    #          print: medir la impresión mediría la consola.
    # Salida esperada: "medición: bucle 20.0 µs (dispersión 1.0 µs) con 1000 repeticiones"
    # Si falla: tiempo de 0 µs → el cronómetro no envuelve la llamada; revisa perf_counter.
    resultados = {}
    for nombre, funcion in (("bucle", _bucle), ("vectorizado", _vector)):
        for _ in range(CALENTAMIENTO):
            funcion(datos)
        tiempos = []
        for _ in range(veces):
            inicio = time.perf_counter()
            funcion(datos)
            tiempos.append((time.perf_counter() - inicio) * 1_000_000)
        tiempos.sort()
        mediana = statistics.median(tiempos)
        dispersion = (tiempos[int(len(tiempos) * 0.75)] - tiempos[int(len(tiempos) * 0.25)]) / 2
        resultados[nombre] = {"mediana_us": mediana, "dispersion_us": dispersion, "veces": veces}
        print(f"medición: {nombre} {mediana:.1f} µs (dispersión {dispersion:.2f} µs) "
              f"con {veces} repeticiones")
    bucle, vector = resultados["bucle"], resultados["vectorizado"]
    separados = (bucle["mediana_us"] - bucle["dispersion_us"]
                 > vector["mediana_us"] + vector["dispersion_us"])
    resultados["concluyente"] = separados
    if separados:
        print(f"veredicto: la diferencia es concluyente; el bucle tarda "
              f"{bucle['mediana_us'] / vector['mediana_us']:.1f} veces lo que el array")
    else:
        print("veredicto: la diferencia cae dentro del ruido de la medición y no se anuncia ventaja")
    return resultados


def explicar_broadcasting(vector: dict) -> None:
    # Paso 6 · Deja escrito por qué encajan las formas, con el ejemplo del propio proyecto
    # Por qué: broadcasting significa alinear formas sin copiar; la máscara (3, 180) se forma al
    #          comparar (3, 1) con (1, 180), y cada fila suma las 60 filas de su tienda.
    # Salida esperada: "broadcasting: (3,1) contra (1,180) da (3, 180); 60 filas por tienda sin bucle"
    # Si falla: las formas no encajan → imprime shape de la máscara antes de operar.
    mascara = vector["mascara"]
    exigir(mascara.shape == (3, 180), f"la máscara tiene forma {mascara.shape}")
    exigir(int(mascara.sum(axis=1).min()) == 60, "alguna tienda no tiene 60 filas en la máscara")
    texto = (
        "# Broadcasting en este proyecto\n\n"
        "- Formas que se comparan: `(3, 1)` (la lista de tiendas) contra `(1, 180)` (las etiquetas).\n"
        "- Resultado: una máscara booleana `(3, 180)`; no hay copia de los datos originales, solo de la\n"
        "  máscara, que es lo que se usa para sumar.\n"
        "- Cada fila de la máscara tiene 60 `True` (una tienda aparece una vez cada tres días).\n"
        "- `mascara[k].dot(unidades)` suma unidades por tienda sin recorrer filas.\n"
        "- Si las formas fueran `(3, 180)` contra `(3, 180)` se compararían elementos, no tiendas.\n"
    )
    RESULTADOS.mkdir(exist_ok=True)
    (RESULTADOS / "broadcasting.md").write_text(texto, encoding="utf-8")
    print(f"broadcasting: (3,1) contra (1,180) da {mascara.shape}; 60 filas por tienda sin bucle")


def escribir(bucle: dict, vector: dict, comparacion: dict, medicion: dict) -> None:
    # Paso 7 · Escribe los totales y los tiempos en CSV
    # Por qué: cada cifra del README sale de estos ficheros; sin ellos la medición no se reproduce.
    # Salida esperada: "resultados: totales.csv, tiempos.csv, broadcasting.md"
    # Si falla: PermissionError → revisa permisos de resultados/.
    RESULTADOS.mkdir(exist_ok=True)
    with (RESULTADOS / "totales.csv").open("w", encoding="utf-8", newline="") as fichero:
        escritor = csv.writer(fichero)
        escritor.writerow(["version", "unidades", "ingresos_eur", "diferencia_cent"])
        escritor.writerow(["bucle", bucle["unidades"], f"{bucle['centimos'] / 100:.2f}",
                           comparacion["diferencia_total_cent"]])
        escritor.writerow(["vectorizado", vector["unidades"], f"{vector['centimos'] / 100:.2f}",
                           comparacion["diferencia_total_cent"]])
        for tienda in TIENDAS:
            escritor.writerow([f"tienda:{tienda}", bucle["por_tienda"][tienda]["unidades"],
                               f"{bucle['por_tienda'][tienda]['centimos'] / 100:.2f}",
                               comparacion["diferencias"][tienda]])
    with (RESULTADOS / "tiempos.csv").open("w", encoding="utf-8", newline="") as fichero:
        escritor = csv.writer(fichero)
        escritor.writerow(["version", "repeticiones", "mediana_us", "dispersion_us"])
        for nombre in ("bucle", "vectorizado"):
            datos = medicion[nombre]
            escritor.writerow([nombre, datos["veces"], f"{datos['mediana_us']:.2f}",
                               f"{datos['dispersion_us']:.2f}"])
    print("resultados: totales.csv, tiempos.csv, broadcasting.md")


def limpiar() -> None:
    # Paso 8 · Borra las tablas generadas y deja la carpeta como descargada
    # Por qué: el ZIP no lleva resultados derivados; se regeneran con `python numpy_de_verdad.py`.
    # Salida esperada: "limpiar: resultados/ generados borrados"
    # Si falla: PermissionError → cierra el programa que tenga abierto un CSV de resultados/.
    for nombre in GENERADOS:
        (RESULTADOS / nombre).unlink(missing_ok=True)
    print("limpiar: resultados/ generados borrados")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="NumPy de verdad: vectorizar un análisis (P35)")
    parser.add_argument("accion", nargs="?", default="todo", choices=["todo", "limpiar"])
    args = parser.parse_args(argv)
    if args.accion == "limpiar":
        limpiar()
        return 0
    try:
        datos = cargar()
        bucle = totales_bucle(datos)
        vector = totales_vectorizado(datos)
        comparacion = comparar(bucle, vector)
        medicion = medir(datos)
        explicar_broadcasting(vector)
        escribir(bucle, vector, comparacion, medicion)
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con resultados a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
