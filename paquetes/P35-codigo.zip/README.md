# P35 · NumPy de verdad: vectorizar un análisis — código ejecutable

El proyecto completo sobre el CSV sintético de 180 días de ventas: calcula los totales con un **bucle
de Python** y con **arrays de NumPy y broadcasting**, demuestra que las dos versiones coinciden al
céntimo y mide ambas con calentamiento, 1.000 repeticiones y mediana. Es el código que acompaña a la
ficha `../../fichas-portfolio/p35-numpy-de-verdad.md`.

El resultado que enseña el proyecto: los dos caminos dan **14.295 unidades y 192.292,08 €** (diferencia
0 céntimos), el total por tienda sale de una máscara de forma **(3, 180)** construida por broadcasting
sin recorrer filas, y en la medición de ejemplo el bucle tarda **77,3 µs** frente a **39,9 µs** del
array (≈1,9 veces), con la dispersión publicada para poder dudar de la cifra.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **numpy** (probado con 2.5.2). Se instala en un comando.
- Windows, Linux o macOS. No hace falta red: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p35-numpy-de-verdad/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide `numpy`, licencia BSD-3-Clause.

## Orden de ejecución

```powershell
python numpy_de_verdad.py          # carga, bucle, vectorizado, comparación, medición y tablas
python numpy_de_verdad.py limpiar  # borra las tablas generadas y deja la carpeta como se descargó
```

La salida esperada de una ejecución (los tiempos varían con la máquina):

```text
datos: 180 filas × 4 columnas · 3 tiendas × 60 filas · 180 fechas únicas · sha256 afa71a0b…
bucle: 14295 unidades · 192292.08 EUR · por tienda centro 4892, norte 4651, sur 4752
vectorizado: 14295 unidades · 192292.08 EUR · máscara (3, 180) con 60 por tienda
comparación: 0 céntimos de diferencia en el total y en las tres tiendas
medición: bucle 77.3 µs (dispersión 12.75 µs) con 1000 repeticiones
medición: vectorizado 39.9 µs (dispersión 1.60 µs) con 1000 repeticiones
veredicto: la diferencia es concluyente; el bucle tarda 1.9 veces lo que el array
broadcasting: (3,1) contra (1,180) da (3, 180); 60 filas por tienda sin bucle
resultados: totales.csv, tiempos.csv, broadcasting.md
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta no mira que los ficheros existan: recalcula los totales, comprueba que el bucle no usa NumPy
(leyendo el código fuente de la función), que las dos versiones coinciden al céntimo y por tienda, que
la máscara tiene forma (3, 180) con 60 filas por tienda, que la medición repite 1.000 veces y deja
mediana, dispersión y veredicto, y que el cálculo es determinista. No usa red y no escribe nada.
Termina en `RESULTADO: VERDE` (código 0) con **23 comprobaciones**; la salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- [`datos-ejemplo/ventas-mensuales.csv`](datos-ejemplo/ventas-mensuales.csv): **180 filas × 4 columnas**
  (`fecha`, `tienda`, `unidades`, `ingresos`). Una fila es un día de una tienda; 180 días consecutivos
  del 2026-01-01 al 2026-06-29; 3 tiendas en rotación con 60 filas cada una.
- sha256 del fichero:
  `afa71a0b0ae0189e863247ff5a25f4ebe1836742ac7686f929d6a42565ecf7f6`. Es copia literal de
  `datasets/csv/ventas-mensuales.csv` del repositorio (manifiesto `datasets/datasets.json`, ficha en
  `datasets/FICHAS.md`), sintético, semilla fija y licencia **CC0-1.0**.

Basta con ese CSV: el proyecto se ejecuta sin descargar nada. Para usar datos propios, se copian en
`datos-ejemplo/` con las mismas columnas o se edita la constante `DATOS` de `numpy_de_verdad.py`.

## Fuente real y licencia

- El catálogo no asigna API (`api: []`): el trabajo se hace **solo con el CSV local**.
- Los datos son sintéticos y no dicen nada de ninguna tienda real; sirven para medir el método.
- numpy: licencia BSD-3-Clause.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y declarar el grano | Leer columnas y comprobar recuentos antes de calcular | NumPy: fundamentos |
| 2 · Calcular con un bucle | La versión de referencia y su coste por fila | Complejidad asintótica |
| 3 · Vectorizar con broadcasting | Máscara (3, 180) sin recorrer filas | NumPy: broadcasting |
| 4 · Comparar al céntimo | Igualdad con tolerancia, no `==` de floats | Precisión y error numérico |
| 5 · Medir con repeticiones | Calentamiento, mediana, dispersión y veredicto | Rendimiento y perfilado |
| 6 · Explicar broadcasting | Qué formas encajan y por qué no hay copia | Vectorización |
| 7 · Escribir resultados | Dejar las tablas que reproducen el informe | Pandas: fundamentos |
| 8 · Verificador offline | Comprobar con tolerancias y sin red | Testing con pytest |

## Estructura

```text
codigo/
├── numpy_de_verdad.py    # pipeline: carga, bucle, vectorizado, comparación y medición
├── verificar.py          # la puerta del proyecto (23 comprobaciones, sin red, sin escribir)
├── requirements.txt      # numpy
├── datos-ejemplo/
│   └── ventas-mensuales.csv   # 180 × 4 · CC0-1.0
└── resultados/
    └── ejemplo-salida.txt
```

Las tablas que escribe `python numpy_de_verdad.py` (`totales.csv`, `tiempos.csv`,
`broadcasting.md`) no viajan en el ZIP: se regeneran.

## Fallos típicos

- **`ModuleNotFoundError: numpy`**: instala con `python -m pip install -r requirements.txt` con el
  mismo intérprete que lanza el pipeline.
- **Medir una sola vez**: el cronómetro de una ejecución mide el ruido de la máquina; el pipeline
  calienta, repite 1.000 veces y publica mediana y dispersión.
- **Cronometrar la consola**: dentro del bucle medido no hay `print`; se cronometra el cálculo, no la
  impresión.
- **Comparar floats con `==`**: la comparación va en céntimos (`round(x * 100)`), porque el orden de la
  suma mueve los últimos decimales.
- **Máscara transpuesta**: `(3, 180)` contra `(180, 3)` suma otra cosa; la puerta comprueba la forma y
  las 60 filas por tienda.
- **Creerse el nombre «mensuales»**: es una serie diaria; junio está incompleto (llega al día 29) y no
  se compara con meses enteros.
