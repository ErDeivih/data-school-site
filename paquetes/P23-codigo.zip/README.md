# P23 · Fútbol: el modelo de fuerzas de la liga

Paquete descargable de **Data School** para el proyecto P23. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es si se puede resumir una liga con dos números por equipo —**ataque y
defensa**— y usarlos para predecir. El código estima esas fuerzas con los goles de las primeras 27
jornadas, calcula goles y puntos esperados con Poisson y valida contra la tabla real de las 11
jornadas que el modelo no vio: **MAE 4,52 puntos** y **Spearman 0,598** entre tabla esperada y real.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice. Todo con la biblioteca estándar.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python fuerzas.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P23-codigo
python fuerzas.py --csv datos-ejemplo/futbol-partidos.csv
```

## Salida esperada

```text
datos: 380 partidos · ajuste 270 (jornadas 1–27) · prueba 110
liga: 1.115 goles local · 0.811 visitante
fuerzas (ataque · defensa):
  equipo-01: 1.740 · 0.603
  …
validación fuera de muestra: MAE 4.52 puntos · Spearman 0.598
tabla esperada vs real (top 5):
  equipo-03: real 25 · esperado 28.4 · error +3.4
  equipo-08: real 22 · esperado 19.0 · error -3.0
  equipo-10: real 22 · esperado 19.5 · error -2.5
  equipo-06: real 20 · esperado 22.2 · error +2.2
  equipo-02: real 19 · esperado 24.4 · error +5.4
lectura: las fuerzas estimadas con 27 jornadas ordenan la tabla de las 11 siguientes; el error se
mide en puntos, no en «parece que acierta».
límite: liga sintética con 20 equipos y 38 jornadas; no hay lesiones, fichajes ni calendario real.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/futbol-partidos.csv`: **380 filas × 12 columnas**. 38 jornadas, 20 equipos, un
  partido por fila con goles, tiros, xG, posesión, amarillas y resultado.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `futbol-partidos` del catálogo.
  No son datos reales de ninguna liga.
- `sha256` del fichero: `5cbc8977b6c9d4f7ae66bfcc7642c93a6655faf7b6e6524a6d40480e2e66a12e`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida 380 partidos y 20 equipos | el equipo fantasma rompe la tabla |
| 2 · Dividir | ajuste 1–27, prueba 28–38 | validación temporal |
| 3 · Fuerzas | goles por partido relativos a la media, normalizados | ataque y defensa comparables |
| 4 · Goles esperados | media de la liga × ataque × defensa rival | el modelo de fuerzas |
| 5 · Puntos | matriz Poisson 0..8: victoria/empate/derrota | de goles a puntos |
| 6 · Validar | tabla esperada vs real fuera de muestra | MAE y Spearman, no impresiones |

## Las tres trampas que el código deja a la vista

1. **Sumar goles sin normalizar engaña.** Un equipo con más partidos parece más fuerte; las fuerzas
   se dividen por la media de la liga y se normalizan a media 1 (ataque y defensa).
2. **Un marcador esperado no es una tabla.** Hay que convertir los goles en probabilidades de
   victoria/empate y de ahí en puntos; el código lo hace con la matriz Poisson.
3. **La tabla de fuerzas sin validación es una descripción.** El código mide el error en las
   jornadas que no vio: MAE 4,52 puntos y Spearman 0,598, no «los de arriba ganan».

## Fallos típicos

- **`ModuleNotFoundError: fuerzas`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`**: el CSV no es el del catálogo.
- **`se esperaban 20 equipos`**: un nombre de equipo cambió y aparece uno fantasma.
- **`partición inesperada`**: se cambió el corte de jornadas sin actualizar el código.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P23-codigo/
├── fuerzas.py                  # pasos 1–6: fuerzas, goles esperados, puntos y validación
├── verificar.py                # la puerta del proyecto: 20 comprobaciones
├── requirements.txt            # sin dependencias
├── datos-ejemplo/
│   └── futbol-partidos.csv     # 380 × 12 · sintético, CC0-1.0
└── resultados/
    └── ejemplo-salida.txt      # la salida real de una ejecución
```

## Límite

Liga sintética de 20 equipos y 38 jornadas: no hay lesiones, fichajes, calendario real ni
localizaciones. El modelo supone que las fuerzas son constantes durante la temporada y que los
goles siguen Poisson; ambas cosas son simplificaciones que el propio código declara.
