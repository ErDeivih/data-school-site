"""P23 · Fútbol: el modelo de fuerzas de la liga.

Estima la fuerza de ataque y de defensa de cada equipo con los goles de las primeras 27 jornadas,
convierte esas fuerzas en goles esperados con Poisson y comprueba la tabla esperada contra la real
en las 11 jornadas que el modelo NO vio. Sin librerías: solo la estándar.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("jornada", "local", "visitante", "goles_local", "goles_visitante",
            "tiros_local", "tiros_visitante", "xg_local", "xg_visitante",
            "posesion_local", "amarillas", "resultado")
CORTE = 27
MAX_GOLES = 8


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: 380 partidos, 20 equipos, goles no negativos.
    # Por qué: el modelo suma goles por equipo; un equipo mal escrito crea un equipo fantasma.
    # Salida esperada: 380 partidos y exactamente 20 equipos.
    # Si falla: «columnas inesperadas», un equipo repetido con otro nombre o goles negativos.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 380:
        raise ValueError(f"se esperaban 380 partidos, hay {len(filas)}")
    for fila in filas:
        if int(fila["goles_local"]) < 0 or int(fila["goles_visitante"]) < 0:
            raise ValueError("goles negativos")
        if not fila["local"] or not fila["visitante"] or fila["local"] == fila["visitante"]:
            raise ValueError(f"partido inválido en jornada {fila['jornada']}")
    equipos = {f["local"] for f in filas} | {f["visitante"] for f in filas}
    if len(equipos) != 20:
        raise ValueError(f"se esperaban 20 equipos, hay {len(equipos)}")
    return filas


def dividir(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    # Paso 2 · Ajuste con las primeras 27 jornadas; prueba con las 11 siguientes.
    # Por qué: validar en el futuro es el único corte que se parece a predecir de verdad.
    # Salida esperada: 270 partidos de ajuste y 110 de prueba.
    ajuste = [f for f in filas if int(f["jornada"]) <= CORTE]
    prueba = [f for f in filas if int(f["jornada"]) > CORTE]
    if len(ajuste) != 270 or len(prueba) != 110:
        raise ValueError(f"partición inesperada: {len(ajuste)} / {len(prueba)}")
    return ajuste, prueba


def fuerzas(ajuste: list[dict]) -> dict:
    # Paso 3 · Fuerza de ataque y defensa: goles por partido relativos a la media de la liga.
    # Por qué: sin normalizar, un equipo con más partidos parece más fuerte; y el ataque solo
    # significa algo comparado con lo que concede el rival.
    # Salida esperada: 20 equipos con ataque y defensa, medias normalizadas a 1.
    # Si falla: un equipo sin partidos o una media de liga 0.
    goles_local = sum(int(f["goles_local"]) for f in ajuste) / len(ajuste)
    goles_visitante = sum(int(f["goles_visitante"]) for f in ajuste) / len(ajuste)
    partidos = defaultdict(int)
    favor = defaultdict(int)
    contra = defaultdict(int)
    for fila in ajuste:
        local, visitante = fila["local"], fila["visitante"]
        gl, gv = int(fila["goles_local"]), int(fila["goles_visitante"])
        partidos[local] += 1; partidos[visitante] += 1
        favor[local] += gl; contra[local] += gv
        favor[visitante] += gv; contra[visitante] += gl
    equipos = sorted(partidos)
    if any(partidos[e] == 0 for e in equipos):
        raise ValueError("hay un equipo sin partidos")
    media_favor = sum(favor.values()) / sum(partidos.values())
    media_contra = sum(contra.values()) / sum(partidos.values())
    if media_favor == 0 or media_contra == 0:
        raise ValueError("la liga no tiene goles")
    ataque = {e: (favor[e] / partidos[e]) / media_favor for e in equipos}
    defensa = {e: (contra[e] / partidos[e]) / media_contra for e in equipos}
    # Normalizar a media 1 (la media muestral no tiene por qué ser exactamente 1).
    ma = sum(ataque.values()) / len(equipos)
    md = sum(defensa.values()) / len(equipos)
    ataque = {e: v / ma for e, v in ataque.items()}
    defensa = {e: v / md for e, v in defensa.items()}
    return {"equipos": equipos, "ataque": ataque, "defensa": defensa,
            "goles_local": goles_local, "goles_visitante": goles_visitante}


def poisson(lam: float, k: int) -> float:
    return math.exp(-lam) * lam ** k / math.factorial(k)


def marcador_esperado(modelo: dict, local: str, visitante: str) -> tuple[float, float]:
    # Paso 4 · Goles esperados del partido: media de la liga × ataque × defensa del rival.
    # Por qué: es el corazón del modelo de fuerzas; el resto (probabilidades) sale de aquí.
    # Salida esperada: dos lambdas positivas y razonables (0,3–3 goles).
    lam_local = modelo["goles_local"] * modelo["ataque"][local] * modelo["defensa"][visitante]
    lam_visitante = modelo["goles_visitante"] * modelo["ataque"][visitante] * modelo["defensa"][local]
    if lam_local <= 0 or lam_visitante <= 0:
        raise ValueError("goles esperados no positivos")
    return lam_local, lam_visitante


def puntos_esperados(lam_local: float, lam_visitante: float) -> tuple[float, float]:
    # Paso 5 · Puntos esperados de cada equipo con la matriz Poisson 0..8.
    # Por qué: un marcador esperado no es una tabla; hay que convertir victoria/empate en puntos.
    # Salida esperada: dos valores entre 0 y 3.
    local = [poisson(lam_local, k) for k in range(MAX_GOLES + 1)]
    visitante = [poisson(lam_visitante, k) for k in range(MAX_GOLES + 1)]
    p_local = p_empate = p_visitante = 0.0
    for i, pi in enumerate(local):
        for j, pj in enumerate(visitante):
            p = pi * pj
            if i > j:
                p_local += p
            elif i == j:
                p_empate += p
            else:
                p_visitante += p
    total = p_local + p_empate + p_visitante
    return (3 * p_local + p_empate) / total, (3 * p_visitante + p_empate) / total


def validar(modelo: dict, prueba: list[dict]) -> dict:
    # Paso 6 · Tabla esperada vs real en las jornadas no vistas.
    # Por qué: una tabla de fuerzas sin validación fuera de muestra es solo una descripción.
    # Salida esperada: 20 equipos, MAE de puntos y correlación de Spearman entre tablas.
    # Si falla: falta un equipo en la prueba.
    real = defaultdict(float)
    esperado = defaultdict(float)
    for fila in prueba:
        lam_local, lam_visitante = marcador_esperado(modelo, fila["local"], fila["visitante"])
        pl, pv = puntos_esperados(lam_local, lam_visitante)
        gl, gv = int(fila["goles_local"]), int(fila["goles_visitante"])
        real[fila["local"]] += 3 if gl > gv else 1 if gl == gv else 0
        real[fila["visitante"]] += 3 if gv > gl else 1 if gl == gv else 0
        esperado[fila["local"]] += pl
        esperado[fila["visitante"]] += pv
    equipos = sorted(real)
    if len(equipos) != 20 or set(equipos) != set(modelo["equipos"]):
        raise ValueError("la prueba no cubre los 20 equipos")
    mae = sum(abs(esperado[e] - real[e]) for e in equipos) / len(equipos)
    # Spearman = correlación de Pearson entre los rangos.
    def rangos(valores: dict) -> dict:
        orden = sorted(valores, key=lambda e: valores[e], reverse=True)
        return {e: i + 1 for i, e in enumerate(orden)}
    r_real, r_esp = rangos(real), rangos(esperado)
    n = len(equipos)
    media_r = (n + 1) / 2
    cov = sum((r_real[e] - media_r) * (r_esp[e] - media_r) for e in equipos)
    var = sum((r_real[e] - media_r) ** 2 for e in equipos) * sum((r_esp[e] - media_r) ** 2 for e in equipos)
    spearman = cov / math.sqrt(var) if var else 0.0
    tabla = [{"equipo": e, "real": real[e], "esperado": esperado[e], "error": esperado[e] - real[e]}
             for e in sorted(equipos, key=lambda e: real[e], reverse=True)]
    return {"mae": mae, "spearman": spearman, "tabla": tabla}


def main() -> int:
    parser = argparse.ArgumentParser(description="P23 · fuerzas de ataque y defensa con Poisson")
    parser.add_argument("--csv", default="datos-ejemplo/futbol-partidos.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    ajuste, prueba = dividir(filas)
    modelo = fuerzas(ajuste)
    validacion = validar(modelo, prueba)

    print(f"datos: {len(filas)} partidos · ajuste {len(ajuste)} (jornadas 1–{CORTE}) · prueba {len(prueba)}")
    print(f"liga: {modelo['goles_local']:.3f} goles local · {modelo['goles_visitante']:.3f} visitante")
    print("fuerzas (ataque · defensa):")
    for equipo in modelo["equipos"]:
        print(f"  {equipo}: {modelo['ataque'][equipo]:.3f} · {modelo['defensa'][equipo]:.3f}")
    print(f"validación fuera de muestra: MAE {validacion['mae']:.2f} puntos · Spearman {validacion['spearman']:.3f}")
    print("tabla esperada vs real (top 5):")
    for fila in validacion["tabla"][:5]:
        print(f"  {fila['equipo']}: real {fila['real']:.0f} · esperado {fila['esperado']:.1f} · error {fila['error']:+.1f}")
    print("lectura: las fuerzas estimadas con 27 jornadas ordenan la tabla de las 11 siguientes; "
          "el error se mide en puntos, no en «parece que acierta».")
    print("límite: liga sintética con 20 equipos y 38 jornadas; no hay lesiones, fichajes ni calendario real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
