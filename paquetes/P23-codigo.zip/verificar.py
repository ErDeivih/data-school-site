#!/usr/bin/env python3
"""Puerta del proyecto P23 (fútbol: el modelo de fuerzas de la liga).

Comprueba equipos, fuerzas, goles esperados, validación fuera de muestra y ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import fuerzas as modelo

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "futbol-partidos.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = modelo.leer(CSV)
    ok(len(filas) == 380 and len({f["jornada"] for f in filas}) == 38, "380 partidos en 38 jornadas")
    equipos = {f["local"] for f in filas} | {f["visitante"] for f in filas}
    ok(len(equipos) == 20, "hay 20 equipos")

    ajuste, prueba = modelo.dividir(filas)
    ok(len(ajuste) == 270 and len(prueba) == 110, "partición temporal 270/110")
    ok(max(int(f["jornada"]) for f in ajuste) <= 27 < min(int(f["jornada"]) for f in prueba),
       "la validación usa jornadas que el modelo no vio")

    m = modelo.fuerzas(ajuste)
    ok(len(m["equipos"]) == 20 and set(m["equipos"]) == equipos, "las fuerzas cubren los 20 equipos")
    ok(all(v > 0 for v in m["ataque"].values()) and all(v > 0 for v in m["defensa"].values()),
       "ataque y defensa son positivos")
    cerca(sum(m["ataque"].values()) / 20, 1.0, 0.001, "la media de ataque está normalizada a 1")
    cerca(sum(m["defensa"].values()) / 20, 1.0, 0.001, "la media de defensa está normalizada a 1")
    cerca(m["goles_local"], 1.1148, 0.002, "goles medios del local en el ajuste")
    cerca(m["goles_visitante"], 0.8111, 0.002, "goles medios del visitante en el ajuste")

    fila = prueba[0]
    lam_local, lam_visitante = modelo.marcador_esperado(m, fila["local"], fila["visitante"])
    ok(0 < lam_local < 4 and 0 < lam_visitante < 4, "los goles esperados son razonables")
    pl, pv = modelo.puntos_esperados(lam_local, lam_visitante)
    ok(0 <= pl <= 3 and 0 <= pv <= 3, "los puntos esperados están entre 0 y 3")

    v = modelo.validar(m, prueba)
    ok(len(v["tabla"]) == 20, "la tabla esperada tiene 20 equipos")
    ok(0 <= v["mae"] <= 8, "el error medio de puntos es razonable")
    cerca(v["mae"], 4.52, 0.15, "MAE fuera de muestra")
    cerca(v["spearman"], 0.598, 0.02, "correlación de Spearman entre tabla real y esperada")
    ok(sum(1 for f in v["tabla"] if f["esperado"] > 0) == 20, "todos los equipos tienen puntos esperados")
    ok(all(-15 <= f["error"] <= 15 for f in v["tabla"]), "ningún error individual se dispara")

    codigo = (AQUI / "fuerzas.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
