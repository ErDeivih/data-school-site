# P45 · RAG sobre el propio temario — código ejecutable

Construye un RAG completo sobre los 120 documentos sintéticos: **trocea** con un criterio declarado,
**indexa** cada fragmento con su documento de origen y su tema, **recupera** por similitud de vectores
tf-idf locales y **responde citando el fragmento**. Cierra con una batería de 12 preguntas —9 con
respuesta en el corpus y 3 sin respuesta— que mide aciertos, citas correctas y falsos «no sé». No usa
red. Es el código que acompaña a la ficha
`../../fichas-portfolio/p45-rag-sobre-el-temario.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: solo la biblioteca estándar (`csv`, `json`, `math`, `re`).
- No hace falta red ni clave: el índice usa vectores **tf-idf locales** y el modelo de embeddings del Hub
  se representa con un **fixture capturado**.

## Instalación

```powershell
cd proyectos/p45-rag-sobre-el-temario/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` no instala nada: el proyecto es de biblioteca estándar.

## Orden de ejecución

```powershell
python rag.py --comprobar   # solo valida el CSV y muestra el resumen del corpus
python rag.py               # trocea, indexa, responde la batería y guarda resultados/
python adaptador.py         # comprueba el fixture del Hub: modelo, licencia y documentos
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta es **solo stdout** (no escribe en disco) y no usa red. Comprueba **22 cosas**: 120 filas × 5
columnas con 120 ids únicos, 6 temas × 20 documentos, niveles (básico 42, intermedio 42, avanzado 36),
30 títulos únicos, 115 textos únicos y textos de 23–74 palabras, el criterio de troceado (unidad,
máximo y solapamiento) sin fragmentos que se pasen, el índice con documento, tema y vector reproducible,
que la batería tiene 9 contestables y 3 sin respuesta, que **9/9 contestables** citan el tema esperado y
la palabra clave, que **3/3 sin respuesta** responden «no está en el corpus», que no hay falsos «no sé»,
que las citas apuntan a documentos del índice, que los recuentos se recalculan, el adaptador simulado del
Hub y que el código no hace red ni lleva claves. Termina en `RESULTADO: VERDE` (código 0) o `RESULTADO:
ROJO` (código 1). La salida real es la de
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt), con **22 comprobaciones** en verde:

- **Corpus:** 120 filas · 5 columnas · 6 temas × 20 documentos · 30 títulos únicos · 115 textos únicos ·
  23–74 palabras.
- **Troceado:** 1 fragmento por documento · máximo 80 palabras · solapamiento 0 · 120 fragmentos.
- **Índice:** 120 fragmentos con documento, tema y vector tf-idf · 897 términos de vocabulario.
- **Batería:** 9 contestables y 3 sin respuesta · **aciertos 9/9** · **no contestables 3/3** · 9 citas
  correctas · 0 falsos «no sé».

## Datos y procedencia

- `datos-ejemplo/documentos-corpus.csv`: **120 filas × 5 columnas** (`id`, `titulo`, `texto`, `tema`,
  `nivel`). Sintético, semilla 20261113 y **CC0-1.0**. Copia literal del catálogo del portal
  (`aprender/web/datos/datasets/documentos-corpus.csv`), no presente en `datasets/csv/`; sha256
  `8e353108fa59ccb2623502842551732868f583de7f234d9f56f422ddde837c10`.
- `datos-ejemplo/parametros.json`: semilla 20261113, top_k 3, máximo 80 palabras por fragmento y umbral
  de similitud 0,05 (un umbral por debajo del cual la respuesta es «no está en el corpus»).
- `datos-ejemplo/preguntas.json`: la **batería completa** escrita antes de mirar resultados: 9 preguntas
  con tema esperado y palabra clave, y 3 sin respuesta en el corpus (la capital de Francia, el Quijote y
  el BCE). Se guarda entera, no solo los aciertos.
- `datos-ejemplo/fixtures/huggingface-embeddings.json`: **respuesta simulada** del Hub con el modelo
  `all-MiniLM-L6-v2` (licencia `apache-2.0`), dimensión declarada 16 y 3 documentos con sus vectores
  **truncados** para que el fichero se lea. No se ha descargado nada.
- `resultados/`: `fragmentos.csv`, `indice.json`, `preguntas.csv` y `evaluacion.json`, regenerados con
  `python rag.py`.

## Qué es real y qué es simulado

- **Real:** el CSV del catálogo (sha256 comprobado), el troceado, el índice, la recuperación, las
  respuestas y la evaluación los calcula el código ejecutado. El modelo de embeddings citado existe y
  declara apache-2.0.
- **Simulado:** la llamada al Hub. El adaptador lee un fixture con 3 vectores truncados y, para cualquier
  otro texto, lanza `ErrorDeFixture` en vez de inventar un vector. El índice real usa vectores tf-idf
  locales, declarados como tales.
- **Sin red:** `verificar.py` no abre sockets ni lee claves; no hay ninguna clave en el repositorio.
- **Límite del juguete:** 120 documentos sintéticos **no son el temario real** del portal (el temario son
  459 fichas de `contenido/`); cualquier conclusión sobre «el sistema funciona» tiene este tamaño detrás.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Corpus y recuentos | Validar el corpus antes de indexar | `Chunking y embeddings` |
| 2 · Troceado declarado | Unidad, tamaño máximo y solapamiento | `Chunking y embeddings` |
| 3 · Índice con origen | Fragmento, documento y tema inseparables | `Arquitectura de un RAG` |
| 4 · Recuperación vectorial | Similitud de coseno y top-k | `Índices y búsqueda en texto` |
| 5 · Responder citando | La cita es la prueba de la respuesta | `Evaluación de RAG` |
| 6 · «No está en el corpus» | Umbral y preguntas sin respuesta | `Evaluación de RAG` |
| 7 · Batería completa | Aciertos, citas y falsos «no sé» | `Métricas de ranking` |
| 8 · Adaptador del Hub | Licencia por ítem y modo sin red | `APIs y peticiones HTTP` |

## Estructura

```text
codigo/
├── rag.py                  # corpus, troceado, índice tf-idf, búsqueda, respuesta y evaluación
├── adaptador.py            # cliente simulado del Hub que lee el fixture (sin red)
├── datos-ejemplo/          # documentos-corpus.csv (CC0-1.0), parametros.json, preguntas.json y fixtures/
├── verificar.py            # la puerta del proyecto (solo stdout, sin red)
└── resultados/             # ejemplo-salida.txt y los artefactos generados
```

## Fallos típicos

- **Trocear sin criterio:** partir por frases documentos de 23–74 palabras deja fragmentos sin contexto;
  aquí se declara un fragmento por documento con su máximo y solapamiento.
- **Título como identificador:** solo hay 30 títulos para 120 documentos; la cita usa el `id`, no el título.
- **Respuesta sin cita:** una respuesta que suena bien no se puede evaluar; cada respuesta cita el
  documento y el fragmento recuperado.
- **«No sé» que no existe:** si todas las preguntas tienen respuesta, no se prueba el caso importante; la
  batería incluye 3 preguntas que no están en el corpus.
- **Evaluación a la carta:** la batería se escribe antes de mirar resultados y se entrega entera, con
  aciertos, fallos y no contestables.
- **Umbral elegido después:** el umbral de similitud está en `parametros.json`; cambiarlo para que las
  respuestas salgan bien invalidaría la batería.
- **Creer que el corpus es el temario:** es un sustituto sintético; las respuestas no valen sobre las
  fichas reales de `contenido/`.
- **Adaptador que inventa vectores:** para un texto sin fixture debe fallar; el índice usa tf-idf local y
  se declara.
