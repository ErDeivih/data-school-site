#!/usr/bin/env python3
"""P45 · RAG sobre el propio temario.

Proyecto completo de la ficha P45. Carga los 120 documentos del CSV, los trocea con un criterio declarado
(un fragmento por documento, porque tienen 23–74 palabras), construye un índice vectorial local con el
`id` y el tema de cada fragmento, recupera los k más cercanos a una pregunta y responde **citando el
fragmento**. Cierra con una batería de preguntas —con respuesta y sin respuesta en el corpus— y mide
aciertos, citas correctas y falsos «no sé». No usa red.

    python rag.py             # construye el índice, evalúa la batería y guarda resultados/
    python rag.py --comprobar # solo valida el CSV y muestra el resumen del corpus

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import json
import math
import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
COLUMNAS = ["id", "titulo", "texto", "tema", "nivel"]
TEMAS = ("datos", "energia", "f1", "finanzas", "futbol", "salud")
NIVELES = ("avanzado", "básico", "intermedio")
SIN_RESPUESTA = "no está en el corpus"
PUNTUACION = str.maketrans("", "", ".,;:!?«»\"'()[]{}¿¡")
# Palabras de función que no distinguen un documento de otro: se declaran y se quitan del vector.
PALABRAS_VACIAS = frozenset(
    "de la el los las un una unos unas y o e que en con por para al del se su sus es son esta este estos estas "
    "como mas pero sin sobre entre cuando donde muy ya hay ser esta estan fue han ha ni tan".split()
)


def cargar_parametros() -> dict:
    # Paso 1 · Lee el top-k, el umbral y el límite de palabras por fragmento
    # Por qué: el troceado, el umbral y el k se fijan antes de mirar los aciertos; si se ajustan después,
    #          la evaluación deja de valer como prueba.
    # Salida esperada: "parámetros: top_k 3 · umbral 0.08 · fragmento <= 80 palabras"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o restaura datos-ejemplo/parametros.json.
    ruta = DATOS / "parametros.json"
    parametros = json.loads(ruta.read_text(encoding="utf-8"))
    obligatorias = ("semilla", "top_k", "max_palabras_fragmento", "umbral_similitud")
    faltan = [clave for clave in obligatorias if clave not in parametros]
    if faltan:
        raise RuntimeError(f"faltan claves en {ruta.name}: {', '.join(faltan)}")
    return parametros


def cargar_corpus() -> dict:
    # Paso 2 · Carga y valida el corpus: 120 filas, 6 temas × 20 documentos, niveles y únicos
    # Por qué: el índice se apoya en el id y el tema; si un id se repite o falta un tema, la cita no se
    #          puede auditar.
    # Salida esperada: "corpus: 120 filas · 5 columnas · ids unicos 120"
    # Si falla: RuntimeError → falta datos-ejemplo/documentos-corpus.csv o cambió de forma.
    ruta = DATOS / "documentos-corpus.csv"
    with ruta.open(encoding="utf-8", newline="") as f:
        lector = csv.DictReader(f)
        columnas = lector.fieldnames or []
        filas = [fila for fila in lector if fila]
    if columnas != COLUMNAS:
        raise RuntimeError(f"columnas del CSV: {columnas} (se esperaban {COLUMNAS})")
    if len(filas) != 120:
        raise RuntimeError(f"filas del CSV: {len(filas)} (se esperaban 120)")
    if len({fila["id"] for fila in filas}) != 120:
        raise RuntimeError("hay ids repetidos en el CSV")
    for fila in filas:
        if fila["tema"] not in TEMAS or fila["nivel"] not in NIVELES:
            raise RuntimeError(f"tema o nivel desconocido en {fila['id']}")
    return {"filas": filas, "ids": [f["id"] for f in filas]}


def auditar(corpus: dict) -> dict:
    temas = {tema: sum(1 for fila in corpus["filas"] if fila["tema"] == tema) for tema in TEMAS}
    niveles = {nivel: sum(1 for fila in corpus["filas"] if fila["nivel"] == nivel) for nivel in NIVELES}
    palabras = [len(fila["texto"].split()) for fila in corpus["filas"]]
    return {
        "temas": temas,
        "niveles": niveles,
        "titulos_unicos": len({fila["titulo"] for fila in corpus["filas"]}),
        "textos_unicos": len({fila["texto"] for fila in corpus["filas"]}),
        "palabras_min": min(palabras),
        "palabras_max": max(palabras),
    }


def trocear(corpus: dict, max_palabras: int) -> dict:
    # Paso 3 · Trocea con un criterio declarado: un fragmento por documento, sin solapamiento
    # Por qué: los documentos tienen 23–74 palabras, así que partir por frases dejaría fragmentos sin
    #          contexto; el criterio se escribe y se comprueba que ningún fragmento supera el máximo.
    # Salida esperada: "troceado: 1 fragmento por documento · maximo 80 palabras · solapamiento 0 · 120 fragmentos"
    # Si falla: RuntimeError → hay un documento que no cabe y la regla no lo dice.
    fragmentos = []
    for fila in corpus["filas"]:
        palabras = fila["texto"].split()
        if len(palabras) > max_palabras:
            raise RuntimeError(f"{fila['id']} tiene {len(palabras)} palabras y supera el máximo declarado {max_palabras}")
        fragmentos.append(
            {
                "fragmento_id": f"F{fila['id']}",
                "documento": fila["id"],
                "tema": fila["tema"],
                "titulo": fila["titulo"],
                "nivel": fila["nivel"],
                "texto": fila["texto"],
                "palabras": len(palabras),
            }
        )
    return {
        "criterio": {
            "unidad": "documento",
            "max_palabras": max_palabras,
            "solapamiento": 0,
            "por_que": "documentos de 23-74 palabras: un fragmento por documento conserva el contexto y no corta frases",
        },
        "fragmentos": fragmentos,
    }


def limpiar(texto: str) -> str:
    return re.sub(r"\s+", " ", texto.lower().translate(PUNTUACION)).strip()


def caracteristicas(texto: str) -> list:
    """Palabras con contenido y bigramas de palabras con contenido: lo que se vectoriza."""
    palabras = [palabra for palabra in limpiar(texto).split() if palabra not in PALABRAS_VACIAS and len(palabra) > 1]
    return palabras + [f"{a}_{b}" for a, b in zip(palabras, palabras[1:])]


def construir_modelo(fragmentos: list) -> dict:
    # Paso 4 · Vocabulario e idf calculados con el corpus: pesa lo que distingue, no lo común
    # Por qué: una bolsa de palabras sin idf haría que «datos» o «precio» pesaran igual que una palabra
    #          exclusiva de un tema, y la recuperación devolvería fragmentos por casualidad.
    # Salida esperada: "indice: 120 fragmentos · vocabulario N terminos"
    # Si falla: RuntimeError → el corpus no tiene características tras quitar palabras vacías.
    frecuencia_documental = {}
    for fragmento in fragmentos:
        for caracteristica in set(caracteristicas(fragmento["texto"])):
            frecuencia_documental[caracteristica] = frecuencia_documental.get(caracteristica, 0) + 1
    if not frecuencia_documental:
        raise RuntimeError("el vocabulario del corpus está vacío")
    total = len(fragmentos)
    idf = {clave: math.log((1.0 + total) / (1.0 + valor)) + 1.0 for clave, valor in frecuencia_documental.items()}
    return {"idf": idf, "total": total, "vocabulario": len(idf)}


def vectorizar(texto: str, modelo: dict) -> dict:
    """Vector tf-idf disperso: término -> tf * idf; el coseno lo normaliza al comparar."""
    cuenta = {}
    for caracteristica in caracteristicas(texto):
        if caracteristica in modelo["idf"]:
            cuenta[caracteristica] = cuenta.get(caracteristica, 0) + 1
    return {clave: (1.0 + math.log(cantidad)) * modelo["idf"][clave] for clave, cantidad in cuenta.items()}


def coseno_disperso(a: dict, b: dict) -> float:
    comunes = set(a) & set(b)
    producto = sum(a[clave] * b[clave] for clave in comunes)
    norma_a = math.sqrt(sum(valor * valor for valor in a.values()))
    norma_b = math.sqrt(sum(valor * valor for valor in b.values()))
    if norma_a == 0.0 or norma_b == 0.0:
        return 0.0
    return producto / (norma_a * norma_b)


def construir_indice(fragmentos: list, modelo: dict) -> list:
    # Paso 5 · Indexa cada fragmento con su vector, su documento de origen y su tema
    # Por qué: sin las tres cosas no se puede citar ni auditar la recuperación; el índice es la pieza que
    #          reutiliza el agente de P46.
    # Salida esperada: "indice: 120 fragmentos · vocabulario N terminos · semilla 20261113"
    # Si falla: KeyError → un fragmento no trae documento o tema.
    return [{**fragmento, "vector": vectorizar(fragmento["texto"], modelo)} for fragmento in fragmentos]


def buscar(indice: list, pregunta: str, modelo: dict, k: int) -> list:
    # Paso 6 · Recupera los k fragmentos más cercanos por similitud de coseno
    # Por qué: la búsqueda devuelve el id además del texto; una respuesta sin cita no se puede evaluar.
    # Salida esperada: una lista con fragmento, documento, tema y similitud, ordenada de mayor a menor
    # Si falla: ValueError → k <= 0 o índice vacío.
    if not indice or k <= 0:
        raise ValueError("hace falta un índice no vacío y k > 0")
    vector_pregunta = vectorizar(pregunta, modelo)
    puntuados = [{**fragmento, "similitud": coseno_disperso(vector_pregunta, fragmento["vector"])} for fragmento in indice]
    puntuados.sort(key=lambda fila: (-fila["similitud"], fila["documento"]))
    return puntuados[:k]


def responder(indice: list, pregunta: str, parametros: dict, modelo: dict, umbral: float = None) -> dict:
    # Paso 7 · Responde citando el fragmento recuperado o dice que no está en el corpus
    # Por qué: el RAG no inventa; si la mejor similitud no supera el umbral declarado, la respuesta correcta
    #          es «no está en el corpus», y esa respuesta se cuenta aparte.
    # Salida esperada: "¿...? -> DOC003 (datos) 0.31" o "-> no está en el corpus"
    # Si falla: KeyError → el resultado de la búsqueda no trae documento o tema.
    umbral = float(parametros["umbral_similitud"]) if umbral is None else umbral
    recuperados = buscar(indice, pregunta, modelo, int(parametros["top_k"]))
    mejor = recuperados[0]
    if mejor["similitud"] < umbral:
        return {"pregunta": pregunta, "respuesta": SIN_RESPUESTA, "documento": None, "tema": None,
                "similitud": mejor["similitud"], "recuperados": [fila["documento"] for fila in recuperados]}
    return {
        "pregunta": pregunta,
        "respuesta": f"Según {mejor['documento']} ({mejor['tema']}): «{mejor['texto']}»",
        "documento": mejor["documento"],
        "tema": mejor["tema"],
        "similitud": mejor["similitud"],
        "recuperados": [fila["documento"] for fila in recuperados],
    }


def cargar_preguntas() -> list:
    # La batería se escribe antes de mirar los resultados y se guarda en datos-ejemplo/preguntas.json.
    ruta = DATOS / "preguntas.json"
    datos = json.loads(ruta.read_text(encoding="utf-8"))
    return datos["preguntas"]


def evaluar(indice: list, preguntas: list, parametros: dict, modelo: dict) -> dict:
    # Paso 8 · Evalúa la batería completa: aciertos, citas correctas y no contestables
    # Por qué: se cuentan los fallos y los «no sé» falsos, no solo los aciertos; una batería con solo
    #          preguntas fáciles no prueba nada.
    # Salida esperada: "bateria: 9 contestables y 3 sin respuesta · aciertos 9/9 · no contestables 3/3"
    # Si falla: una pregunta contestable no cita el tema esperado o una sin respuesta no dice «no está».
    filas = []
    documentos = {fragmento["documento"] for fragmento in indice}
    for pregunta in preguntas:
        resultado = responder(indice, pregunta["pregunta"], parametros, modelo)
        if pregunta["contestable"]:
            acierto = (
                resultado["documento"] is not None
                and resultado["tema"] == pregunta["tema_esperado"]
                and pregunta["palabra_clave"].lower() in resultado["respuesta"].lower()
            )
        else:
            acierto = resultado["respuesta"] == SIN_RESPUESTA
        filas.append({**pregunta, **resultado, "acierto": bool(acierto),
                      "cita_en_indice": resultado["documento"] in documentos})
    contestables = [fila for fila in filas if fila["contestable"]]
    no_contestables = [fila for fila in filas if not fila["contestable"]]
    return {
        "filas": filas,
        "contestables": len(contestables),
        "no_contestables": len(no_contestables),
        "aciertos": sum(1 for fila in contestables if fila["acierto"]),
        "aciertos_no_contestables": sum(1 for fila in no_contestables if fila["acierto"]),
        "citas_correctas": sum(1 for fila in filas if fila["cita_en_indice"]),
        "falsos_no_se": sum(1 for fila in contestables if fila["respuesta"] == SIN_RESPUESTA),
    }


def ejecutar(parametros: dict) -> dict:
    """Carga, trocea, indexa, responde la batería e imprime el resumen que la puerta necesita."""
    corpus = cargar_corpus()
    auditoria = auditar(corpus)
    troceado = trocear(corpus, int(parametros["max_palabras_fragmento"]))
    modelo = construir_modelo(troceado["fragmentos"])
    indice = construir_indice(troceado["fragmentos"], modelo)
    preguntas = cargar_preguntas()
    evaluacion = evaluar(indice, preguntas, parametros, modelo)

    print(f"corpus: {len(corpus['filas'])} filas · {len(COLUMNAS)} columnas · ids unicos {len(set(corpus['ids']))}")
    print("temas: " + " · ".join(f"{tema} {auditoria['temas'][tema]}" for tema in TEMAS))
    print("niveles: " + " · ".join(f"{nivel} {auditoria['niveles'][nivel]}" for nivel in NIVELES))
    print(
        f"titulos unicos {auditoria['titulos_unicos']} · textos unicos {auditoria['textos_unicos']}"
        f" · palabras {auditoria['palabras_min']}-{auditoria['palabras_max']}"
    )
    print(
        f"troceado: 1 fragmento por documento · maximo {troceado['criterio']['max_palabras']} palabras"
        f" · solapamiento {troceado['criterio']['solapamiento']} · {len(troceado['fragmentos'])} fragmentos"
    )
    print(f"indice: {len(indice)} fragmentos · vocabulario {modelo['vocabulario']} terminos · vectores tf-idf locales")
    print(
        f"bateria: {evaluacion['contestables']} contestables y {evaluacion['no_contestables']} sin respuesta"
        f" · aciertos {evaluacion['aciertos']}/{evaluacion['contestables']}"
        f" · no contestables {evaluacion['aciertos_no_contestables']}/{evaluacion['no_contestables']}"
        f" · citas correctas {evaluacion['citas_correctas']}"
    )
    for fila in evaluacion["filas"][:4]:
        destino = fila["documento"] if fila["documento"] else "no esta en el corpus"
        print(f"  {fila['pregunta']} -> {destino} (similitud {fila['similitud']:.3f})")
    return {
        "corpus": corpus,
        "auditoria": auditoria,
        "troceado": troceado,
        "modelo": modelo,
        "indice": indice,
        "preguntas": preguntas,
        "evaluacion": evaluacion,
        "parametros": parametros,
    }


def guardar(resultados: dict, parametros: dict) -> None:
    # Paso 9 · Guarda fragmentos, índice serializado, preguntas y evaluación
    # Por qué: el índice con su origen y la batería completa son los artefactos que permiten auditar el
    #          RAG; una respuesta sin el fragmento citado no se puede comprobar.
    # Salida esperada: "resultados: fragmentos.csv, indice.json, preguntas.csv, evaluacion.json"
    # Si falla: PermissionError → resultados/ no es escribible; ejecuta desde codigo/.
    RESULTADOS.mkdir(parents=True, exist_ok=True)
    with (RESULTADOS / "fragmentos.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["fragmento", "documento", "tema", "titulo", "nivel", "palabras"])
        for fragmento in resultados["troceado"]["fragmentos"]:
            escritor.writerow([fragmento["fragmento_id"], fragmento["documento"], fragmento["tema"],
                               fragmento["titulo"], fragmento["nivel"], fragmento["palabras"]])
    indice_json = {
        "criterio": resultados["troceado"]["criterio"],
        "vocabulario": resultados["modelo"]["vocabulario"],
        "fragmentos": [
            {clave: valor for clave, valor in fragmento.items() if clave != "vector"}
            for fragmento in resultados["indice"]
        ],
    }
    (RESULTADOS / "indice.json").write_text(json.dumps(indice_json, ensure_ascii=False, indent=2), encoding="utf-8")
    with (RESULTADOS / "preguntas.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["pregunta", "contestable", "documento_citado", "tema_citado", "similitud", "acierto", "respuesta"])
        for fila in resultados["evaluacion"]["filas"]:
            escritor.writerow([fila["pregunta"], fila["contestable"], fila["documento"] or "",
                               fila["tema"] or "", f"{fila['similitud']:.6f}", fila["acierto"], fila["respuesta"]])
    resumen = {clave: valor for clave, valor in resultados["evaluacion"].items() if clave != "filas"}
    (RESULTADOS / "evaluacion.json").write_text(json.dumps(resumen, ensure_ascii=False, indent=2), encoding="utf-8")
    print("resultados: fragmentos.csv, indice.json, preguntas.csv, evaluacion.json")


def main(argv: list) -> int:
    try:
        parametros = cargar_parametros()
        if "--comprobar" in argv:
            corpus = cargar_corpus()
            auditoria = auditar(corpus)
            print(f"corpus: {len(corpus['filas'])} filas · temas " + " · ".join(f"{t} {auditoria['temas'][t]}" for t in TEMAS))
            return 0
        print("== P45 · RAG sobre el temario (corpus sintetico, no es el temario real) ==")
        resultados = ejecutar(parametros)
        guardar(resultados, parametros)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
