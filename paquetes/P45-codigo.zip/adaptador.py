#!/usr/bin/env python3
"""Adaptador simulado de la API de embeddings de Hugging Face Hub (sin red).

El proyecto no descarga ningún modelo: lee una **respuesta capturada** de `datos-ejemplo/fixtures/`
con la forma de la respuesta del Hub (`modelo`, `licencia`, `dim` y un vector por documento de ejemplo).
Los vectores del fixture están **truncados a 16 dimensiones** para que el fichero se lea: no son la
salida real del modelo.

Con red y sin clave, el modo real pediría los vectores del modelo `all-MiniLM-L6-v2` (apache-2.0); esta
entrega no incluye esa llamada: el índice del RAG usa vectores tf-idf locales.
"""
from __future__ import annotations

import json
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
FIXTURE = RAIZ / "datos-ejemplo" / "fixtures" / "huggingface-embeddings.json"


class ErrorDeFixture(RuntimeError):
    """El fixture no existe, no tiene la forma declarada o no cubre el texto pedido."""


class AdaptadorHub:
    """Cliente simulado del Hub: misma interfaz, datos del fixture local."""

    def __init__(self, ruta: Path = FIXTURE):
        # Paso 1 · Carga el fixture y comprueba modelo, licencia y dimensión
        # Por qué: la licencia la declara cada ítem del Hub; sin ella el adaptador no se puede usar en una
        #          entrega que se comparte.
        # Salida esperada: "adaptador: all-MiniLM-L6-v2 · apache-2.0 · 16 dimensiones · 3 documentos"
        # Si falla: ErrorDeFixture → falta datos-ejemplo/fixtures/huggingface-embeddings.json.
        ruta = Path(ruta)
        if not ruta.exists():
            raise ErrorDeFixture(f"no existe el fixture {ruta}")
        datos = json.loads(ruta.read_text(encoding="utf-8"))
        for campo in ("modelo", "licencia", "dim", "capturado", "documentos"):
            if campo not in datos:
                raise ErrorDeFixture(f"el fixture no trae «{campo}»")
        if datos["licencia"] != "apache-2.0":
            raise ErrorDeFixture(f"licencia inesperada en el fixture: {datos['licencia']!r}")
        self.datos = datos
        self._por_texto = {item["texto"]: list(item["vector"]) for item in datos["documentos"]}

    def modelo(self) -> dict:
        return {"modelo": self.datos["modelo"], "licencia": self.datos["licencia"],
                "dim": int(self.datos["dim"]), "capturado": self.datos["capturado"]}

    def embedding(self, texto: str) -> list:
        # Paso 2 · Devuelve el vector capturado o falla con un mensaje explícito
        # Por qué: sin red no hay llamada real; inventar un vector ocultaría que se está en otro modo.
        # Salida esperada: una lista de 16 floats para los textos del fixture
        # Si falla: ErrorDeFixture → el texto no está en el fixture; el índice usa tf-idf local.
        if texto not in self._por_texto:
            raise ErrorDeFixture("texto sin fixture: sin red no se llama al modelo; el índice usa vectores tf-idf locales")
        return list(self._por_texto[texto])

    def tamano_fixture(self) -> int:
        return len(self._por_texto)


if __name__ == "__main__":
    adaptador = AdaptadorHub()
    info = adaptador.modelo()
    print(f"adaptador: {info['modelo']} · {info['licencia']} · {info['dim']} dimensiones · {adaptador.tamano_fixture()} documentos")
