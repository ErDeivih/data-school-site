#!/usr/bin/env python3
"""Puerta del proyecto P45 (RAG sobre el propio temario).

Comprueba el resultado de verdad, sin escribir en disco y sin red: recuentos del corpus, criterio de
troceado, índice con documento de origen y tema, recuperación y respuestas que citan el fragmento,
batería completa con preguntas sin respuesta, adaptador simulado del Hub y código offline. Termina en
RESULTADO: VERDE (código 0) o ROJO (código 1).

Uso:
    python verificar.py

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import json
import sys

sys.dont_write_bytecode = True  # la puerta no escribe nada: ni resultados ni caché de bytecode

import adaptador
import rag

fallos: list = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P45 · RAG sobre el temario (corpus sintetico) ==")

    # Paso 1 · Comprueba los parámetros y los recuentos del corpus
    # Por qué: el troceado y el umbral se declaran antes de evaluar; los recuentos del CSV son el contrato
    #          de la ficha (120 filas, 20 documentos por tema, 115 textos únicos).
    # Salida esperada: "OK parámetros", "OK corpus", "OK temas" y "OK niveles".
    # Si falla: RuntimeError de cargar_corpus → falta datos-ejemplo/documentos-corpus.csv o cambió.
    parametros = rag.cargar_parametros()
    ok(
        (int(parametros["top_k"]), float(parametros["umbral_similitud"]), int(parametros["max_palabras_fragmento"])) == (3, 0.05, 80),
        f"parámetros: top_k {int(parametros['top_k'])} · umbral {float(parametros['umbral_similitud']):.2f} · fragmento <= {int(parametros['max_palabras_fragmento'])} palabras",
    )
    corpus = rag.cargar_corpus()
    auditoria = rag.auditar(corpus)
    ok(
        len(corpus["filas"]) == 120 and len(rag.COLUMNAS) == 5 and len(set(corpus["ids"])) == 120,
        f"corpus: {len(corpus['filas'])} filas · {len(rag.COLUMNAS)} columnas · {len(set(corpus['ids']))} ids unicos",
    )
    ok(
        all(auditoria["temas"][tema] == 20 for tema in rag.TEMAS) and sum(auditoria["temas"].values()) == 120,
        "temas: " + " · ".join(f"{tema} {auditoria['temas'][tema]}" for tema in rag.TEMAS),
    )
    ok(
        auditoria["niveles"] == {"avanzado": 36, "básico": 42, "intermedio": 42},
        "niveles: " + " · ".join(f"{nivel} {auditoria['niveles'][nivel]}" for nivel in rag.NIVELES),
    )
    ok(
        (auditoria["titulos_unicos"], auditoria["textos_unicos"], auditoria["palabras_min"], auditoria["palabras_max"]) == (30, 115, 23, 74),
        f"únicos y tamaño: {auditoria['titulos_unicos']} títulos, {auditoria['textos_unicos']} textos, {auditoria['palabras_min']}-{auditoria['palabras_max']} palabras",
    )

    # Paso 2 · Comprueba el troceado declarado y que cubre todos los documentos
    # Por qué: el criterio de troceado se escribe (unidad, máximo y solapamiento) y se comprueba que no
    #          parte frases ni deja documentos fuera del índice.
    # Salida esperada: "OK troceado: 120 fragmentos, uno por documento, sin solapamiento".
    # Si falla: RuntimeError de trocear → algún documento supera el máximo declarado.
    troceado = rag.trocear(corpus, int(parametros["max_palabras_fragmento"]))
    criterio = troceado["criterio"]
    documentos = {fragmento["documento"] for fragmento in troceado["fragmentos"]}
    ok(
        len(troceado["fragmentos"]) == 120 and len(documentos) == 120
        and criterio["unidad"] == "documento" and criterio["solapamiento"] == 0 and criterio["max_palabras"] == 80,
        f"troceado: {len(troceado['fragmentos'])} fragmentos · uno por documento · solapamiento {criterio['solapamiento']} · máximo {criterio['max_palabras']} palabras",
    )
    ok(
        all(fragmento["palabras"] <= int(parametros["max_palabras_fragmento"]) and fragmento["palabras"] >= 1 for fragmento in troceado["fragmentos"]),
        "troceado: ningún fragmento supera el máximo y ninguno está vacío (no se cortan frases a la mitad)",
    )

    # Paso 3 · Construye el índice y comprueba que guarda el origen y el tema
    # Por qué: sin `documento` y `tema` en el índice no se puede citar ni auditar la recuperación.
    # Salida esperada: "OK índice: 120 fragmentos con documento, tema y vector tf-idf".
    # Si falla: KeyError → el fragmento no trae documento o tema.
    modelo = rag.construir_modelo(troceado["fragmentos"])
    indice = rag.construir_indice(troceado["fragmentos"], modelo)
    ok(
        len(indice) == 120 and all(fila["documento"] and fila["tema"] and fila["vector"] for fila in indice),
        f"índice: {len(indice)} fragmentos con documento, tema y vector tf-idf ({modelo['vocabulario']} términos de vocabulario)",
    )
    ok(
        rag.construir_indice(troceado["fragmentos"], modelo) == indice,
        "índice: reproducible (reconstruirlo devuelve los mismos vectores)",
    )

    # Paso 4 · Ejecuta la batería y comprueba aciertos, citas y «no está»
    # Por qué: el RAG se juzga por su evaluación; se comprueban los aciertos con tema y palabra clave, las
    #          preguntas sin respuesta y los falsos «no sé», no solo el total.
    # Salida esperada: "OK batería: 9/9 contestables, 3/3 sin respuesta y citas correctas".
    # Si falla: alguna pregunta contestable no cita el tema esperado o una sin respuesta no dice «no está».
    resultados = rag.ejecutar(parametros)
    evaluacion = resultados["evaluacion"]
    ok(
        evaluacion["contestables"] == 9 and evaluacion["no_contestables"] == 3,
        f"batería: {evaluacion['contestables']} preguntas contestables y {evaluacion['no_contestables']} sin respuesta en el corpus",
    )
    ok(
        evaluacion["aciertos"] == evaluacion["contestables"],
        f"aciertos: {evaluacion['aciertos']}/{evaluacion['contestables']} preguntas contestables citan el tema esperado y la palabra clave",
    )
    ok(
        evaluacion["aciertos_no_contestables"] == evaluacion["no_contestables"],
        f"no contestables: {evaluacion['aciertos_no_contestables']}/{evaluacion['no_contestables']} responden «{rag.SIN_RESPUESTA}»",
    )
    ok(evaluacion["falsos_no_se"] == 0, f"falsos «no sé»: {evaluacion['falsos_no_se']} (ninguna pregunta contestable se queda sin respuesta)")
    ok(
        all(fila["documento"] in documentos for fila in evaluacion["filas"] if fila["documento"]),
        f"citas: las {evaluacion['citas_correctas']} citas apuntan a documentos que están en el índice",
    )
    for fila in evaluacion["filas"]:
        if fila["contestable"]:
            if not (fila["documento"] and fila["tema"] == fila["tema_esperado"] and fila["palabra_clave"].lower() in fila["respuesta"].lower()):
                ok(False, f"respuesta incompleta: {fila['pregunta'][:50]}")
                break
    else:
        ok(True, "respuestas: cada una cita su documento y contiene la palabra clave esperada")

    # Paso 5 · Recalcula la batería desde cero y compara los recuentos
    # Por qué: no se da por bueno el resumen del runner; la puerta vuelve a lanzar cada pregunta.
    # Salida esperada: "OK evaluación: recuentos recalculados coinciden".
    # Si falla: los recuentos reportados no salen de las respuestas → hay una tabla inventada.
    preguntas = rag.cargar_preguntas()
    recalculada = rag.evaluar(indice, preguntas, parametros, modelo)
    ok(
        (recalculada["aciertos"], recalculada["aciertos_no_contestables"], recalculada["citas_correctas"]) ==
        (evaluacion["aciertos"], evaluacion["aciertos_no_contestables"], evaluacion["citas_correctas"]),
        f"evaluación: recuentos recalculados ({recalculada['aciertos']}/{recalculada['contestables']} y {recalculada['aciertos_no_contestables']}/{recalculada['no_contestables']})",
    )
    ok(
        all(("tema_esperado" in fila and "palabra_clave" in fila) for fila in preguntas if fila["contestable"])
        and len(preguntas) == 12,
        f"batería completa: {len(preguntas)} preguntas con tema y palabra clave declarados en datos-ejemplo/preguntas.json",
    )

    # Paso 6 · Comprueba el adaptador simulado del Hub
    # Por qué: el índice real usa vectores locales; el adaptador demuestra la forma del modelo sin red y
    #          declara su licencia. Un texto sin fixture debe fallar, no inventar un vector.
    # Salida esperada: "OK adaptador: all-MiniLM-L6-v2 · apache-2.0 · 16 dimensiones · 3 documentos".
    # Si falla: ErrorDeFixture → falta datos-ejemplo/fixtures/huggingface-embeddings.json.
    cliente = adaptador.AdaptadorHub()
    info = cliente.modelo()
    ok(
        info["modelo"] == "all-MiniLM-L6-v2" and info["licencia"] == "apache-2.0" and info["dim"] == 16 and cliente.tamano_fixture() == 3,
        f"adaptador: {info['modelo']} · {info['licencia']} · {info['dim']} dimensiones · {cliente.tamano_fixture()} documentos",
    )
    primero = cliente.datos["documentos"][0]["texto"]
    ok(len(cliente.embedding(primero)) == 16 and cliente.embedding(primero) == cliente.embedding(primero),
       "adaptador: vector de 16 dimensiones y determinista para los documentos del fixture")
    try:
        cliente.embedding("texto que no está en el fixture")
        fallo_esperado = False
    except adaptador.ErrorDeFixture:
        fallo_esperado = True
    ok(fallo_esperado, "adaptador: un texto sin fixture lanza ErrorDeFixture (no inventa vectores sin red)")

    # Paso 7 · Comprueba que el código es offline y no lleva claves
    # Por qué: la entrega se comparte y la puerta se ejecuta sin red.
    # Salida esperada: "el código no hace peticiones de red" y "no contiene claves".
    # Si falla: aparece un http(s) o un patrón de token → quítalo antes de empaquetar.
    fuentes = [rag.RAIZ / "rag.py", rag.RAIZ / "adaptador.py", rag.DATOS / "fixtures" / "huggingface-embeddings.json"]
    texto = "\n".join(ruta.read_text(encoding="utf-8") for ruta in fuentes)
    ok("http://" not in texto and "https://" not in texto, "el código del proyecto no hace peticiones de red")
    ok(
        not any(patron in texto for patron in ("ghp_", "github_pat_", "Authorization:", "api_key", "hf_")),
        "el código del proyecto no contiene claves ni cabeceras de autorización",
    )

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
