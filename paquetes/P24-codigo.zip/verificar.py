﻿#!/usr/bin/env python3
"""Puerta del proyecto P24 (Elo validado con la jornada siguiente).

Comprueba calendario, ratings, pronósticos de la última jornada, Brier y log-loss frente a la línea base,
determinismo y ausencia de red. Sin escribir en disco. VERDE (0) o ROJO (1).
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import elo

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "futbol-partidos.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = elo.leer(CSV)
    ok(len(filas) == 380, "el CSV tiene 380 partidos")
    ok(len({f["jornada"] for f in filas}) == 38, "hay 38 jornadas")
    ok(len({f["local"] for f in filas} | {f["visitante"] for f in filas}) == 20, "hay 20 equipos")

    ratings, pronosticos = elo.recorrer(filas)
    ok(len(ratings) == 20, "el Elo cubre los 20 equipos")
    ok(abs(sum(ratings.values()) - 30000) < 0.5, "los ratings suman 30.000 (ELO_INICIAL × 20)")
    ok(ratings["equipo-02"] == 1620.83, "equipo-02 lidera con 1620,83")
    ok(ratings["equipo-03"] == 1609.28, "equipo-03 es segundo con 1609,28")
    ok(len(pronosticos) == 10, "hay 10 pronósticos para la jornada 38")
    ok(all(0.0 <= p["p_local"] <= 1.0 for p in pronosticos), "las probabilidades están en [0, 1]")
    ok(round(pronosticos[0]["p_local"], 3) == 0.658, "el primer pronóstico da 0,658 al local")
    ok(round(pronosticos[-1]["p_local"], 3) == 0.500, "el último pronóstico da 0,500 al local")

    base = sum(p["gano_local"] for p in pronosticos) / len(pronosticos)
    pron_base = [{"p_local": base, "gano_local": p["gano_local"]} for p in pronosticos]
    ok(round(base, 3) == 0.4, "la línea base es 0,4 (4 locales ganaron de 10)")
    ok(round(elo.brier(pronosticos), 5) == 0.23268, "el Brier del Elo es 0,23268")
    ok(round(elo.brier(pron_base), 5) == 0.24000, "el Brier de la base es 0,24000")
    ok(elo.brier(pronosticos) < elo.brier(pron_base), "el Elo mejora el Brier de la base")
    ok(round(elo.log_loss(pronosticos), 5) == 0.65665, "el log-loss del Elo es 0,65665")
    ok(round(elo.log_loss(pron_base), 5) == 0.67301, "el log-loss de la base es 0,67301")
    ok(elo.log_loss(pronosticos) < elo.log_loss(pron_base), "el Elo mejora el log-loss de la base")

    ok(round(elo.probabilidad_local(1500, 1500), 3) == 0.585, "1500 contra 1500 con campo da 0,585")
    ok(elo.probabilidad_local(1600, 1500) > elo.probabilidad_local(1500, 1500),
       "más Elo local sube la probabilidad de victoria")

    ratings2, pronosticos2 = elo.recorrer(filas)
    ok(ratings2 == ratings and [p["p_local"] for p in pronosticos2] == [p["p_local"] for p in pronosticos],
       "dos pasadas dan los mismos ratings y pronósticos")

    codigo = (AQUI / "elo.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
