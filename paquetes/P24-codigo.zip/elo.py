"""P24 · Deporte: un Elo que se valida con la jornada siguiente.

Construye un rating Elo partido a partido, con ventaja de campo, y lo valida sobre la última jornada:
compara su Brier y su log-loss con la línea base de «gana el local». Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("jornada", "local", "visitante", "goles_local", "goles_visitante",
            "tiros_local", "tiros_visitante", "xg_local", "xg_visitante",
            "posesion_local", "amarillas", "resultado")
K = 20.0
VENTAJA_CAMPO = 60.0
ELO_INICIAL = 1500.0
JORNADAS = 38
EQUIPOS = 20


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el calendario: 38 jornadas, 10 partidos cada una y 20 equipos.
    # Por qué: un Elo necesita orden cronológico y un rival por partido; si falta, no hay rating.
    # Salida esperada: 380 filas, 38 jornadas y 20 equipos.
    # Si falla: «columnas inesperadas», «jornada incompleta» o «equipo repetido».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != JORNADAS * 10:
        raise ValueError(f"se esperaban {JORNADAS * 10} partidos, hay {len(filas)}")
    por_jornada = defaultdict(list)
    equipos = set()
    for fila in filas:
        if fila["local"] == fila["visitante"]:
            raise ValueError("un equipo no puede jugar contra sí mismo")
        goles_local, goles_visitante = int(fila["goles_local"]), int(fila["goles_visitante"])
        esperado = "1" if goles_local > goles_visitante else ("2" if goles_local < goles_visitante else "X")
        if fila["resultado"] != esperado:
            raise ValueError(f"jornada {fila['jornada']}: resultado no cuadra con los goles")
        por_jornada[int(fila["jornada"])].append(fila)
        equipos.add(fila["local"])
        equipos.add(fila["visitante"])
    if set(por_jornada) != set(range(1, JORNADAS + 1)):
        raise ValueError("faltan jornadas")
    if any(len(partidos) != 10 for partidos in por_jornada.values()):
        raise ValueError("alguna jornada no tiene 10 partidos")
    if len(equipos) != EQUIPOS:
        raise ValueError(f"se esperaban {EQUIPOS} equipos, hay {len(equipos)}")
    return filas


def probabilidad_local(elo_local: float, elo_visitante: float) -> float:
    # Paso 2 · Convertir la diferencia de Elo (con campo) en probabilidad de victoria local.
    # Por qué: el Elo no es una probabilidad; hace falta la curva logística 1/(1+10^(-d/400)).
    # Salida esperada: 1500 contra 1500 con campo da 0,586.
    # Si falla: el signo de la diferencia está al revés.
    return 1.0 / (1.0 + 10 ** (-(elo_local + VENTAJA_CAMPO - elo_visitante) / 400.0))


def recorrer(filas: list[dict]) -> tuple[dict[str, float], list[dict]]:
    # Paso 3 · Recorrer los partidos en orden y actualizar los ratings.
    # Por qué: usar el rating final para predecir el pasado sería fuga de información.
    # Salida esperada: ratings tras 37 jornadas y 10 pronósticos para la 38.
    # Si falla: el orden de las filas no es el del calendario.
    elo = defaultdict(lambda: ELO_INICIAL)
    pronosticos = []
    for fila in filas:
        jornada = int(fila["jornada"])
        local, visitante = fila["local"], fila["visitante"]
        p_local = probabilidad_local(elo[local], elo[visitante])
        if jornada == JORNADAS:
            pronosticos.append({"local": local, "visitante": visitante, "p_local": p_local,
                                "gano_local": 1.0 if fila["resultado"] == "1" else 0.0})
            continue
        marcador = 1.0 if fila["resultado"] == "1" else (0.0 if fila["resultado"] == "2" else 0.5)
        delta = K * (marcador - p_local)
        elo[local] += delta
        elo[visitante] -= delta
    return {equipo: round(valor, 2) for equipo, valor in elo.items()}, pronosticos


def brier(pronosticos: list[dict]) -> float:
    # Paso 4 · Medir el error con Brier: media de (probabilidad − resultado)^2.
    # Por qué: una probabilidad se evalúa, no se «acierta»; el Brier penaliza la confianza falsa.
    # Salida esperada: Brier del Elo menor que el de la línea base.
    # Si falla: las probabilidades no están en [0, 1].
    return sum((p["p_local"] - p["gano_local"]) ** 2 for p in pronosticos) / len(pronosticos)


def log_loss(pronosticos: list[dict]) -> float:
    # Paso 5 · Medir el log-loss, que castiga mucho equivocarse con confianza.
    # Por qué: Brier y log-loss ordenan los modelos de forma distinta; conviene ver los dos.
    # Salida esperada: log-loss del Elo menor que el de la línea base.
    # Si falla: alguna probabilidad es 0 o 1 exacta.
    total = 0.0
    for p in pronosticos:
        q = min(max(p["p_local"], 1e-9), 1 - 1e-9)
        total += -(p["gano_local"] * math.log(q) + (1 - p["gano_local"]) * math.log(1 - q))
    return total / len(pronosticos)


def main() -> int:
    # Paso 6 · Publicar ratings y validación con la línea base a la vista.
    # Por qué: un Elo sin comparación no dice si aporta algo; la base es «siempre gana el local».
    # Salida esperada: top-5 de ratings, Brier y log-loss del Elo y de la base.
    # Si falla: revisa la ruta del CSV o el número de jornadas.
    parser = argparse.ArgumentParser(description="Elo validado con la jornada siguiente (P24)")
    parser.add_argument("--csv", default="datos-ejemplo/futbol-partidos.csv")
    args = parser.parse_args()
    filas = leer(Path(args.csv))
    elo, pronosticos = recorrer(filas)
    ordenados = sorted(elo.items(), key=lambda par: -par[1])[:5]
    base = sum(p["gano_local"] for p in pronosticos) / len(pronosticos)
    pron_base = [{"p_local": base, "gano_local": p["gano_local"]} for p in pronosticos]
    print(f"partidos: {len(filas)} · equipos: {len(elo)} · jornada de validación: {JORNADAS}")
    print("top-5 Elo: " + " · ".join(f"{equipo} {valor:.2f}" for equipo, valor in ordenados))
    print(f"Brier  · Elo: {brier(pronosticos):.5f} · base: {brier(pron_base):.5f}")
    print(f"log-loss · Elo: {log_loss(pronosticos):.5f} · base: {log_loss(pron_base):.5f}")
    print("pronósticos de la última jornada:")
    for p in pronosticos:
        print(f"  {p['local']} vs {p['visitante']}: local {p['p_local']:.3f} · {'ganó' if p['gano_local'] else 'no ganó'}")
    print("límite: resultados sintéticos de una liga; el Elo no incorpora bajas ni contexto.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
