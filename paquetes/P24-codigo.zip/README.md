# P24 · Deporte: un Elo que se valida con la jornada siguiente

Paquete descargable de **Data School** para el proyecto P24. Incluye el calendario de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python elo.py
python verificar.py
```

`elo.py` construye el rating partido a partido (K=20, ventaja de campo=60), lo usa para pronosticar la
jornada 38 y compara su Brier y su log-loss con la línea base «siempre gana el local». `verificar.py`
sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/futbol-partidos.csv`: **380 partidos × 12 columnas** (38 jornadas, 20 equipos, 10
  partidos por jornada; goles, tiros, xG, posesión y resultado). Sintético y **CC0-1.0**; es el
  `futbol-partidos` del catálogo de Data School.

## Salida esperada

```text
partidos: 380 · equipos: 20 · jornada de validación: 38
top-5 Elo: equipo-02 1620.83 · equipo-03 1609.28 · equipo-06 1596.26 · equipo-09 1572.22 · equipo-05 1545.47
Brier  · Elo: 0.23268 · base: 0.24000
log-loss · Elo: 0.65665 · base: 0.67301
pronósticos de la última jornada: ...
límite: resultados sintéticos de una liga; el Elo no incorpora bajas ni contexto.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Calendario | `leer` comprueba 38 jornadas, 10 partidos y 20 equipos | validación de datos |
| 2 · De Elo a probabilidad | `probabilidad_local` aplica la logística 1/(1+10^(-d/400)) | probabilidad y odds |
| 3 · Recorrer sin fuga | `recorrer` actualiza ratings solo con partidos anteriores y pronostica la 38 | validación temporal |
| 4 · Brier | `brier` mide el error cuadrático de las probabilidades | métricas de probabilidad |
| 5 · Log-loss | `log_loss` castiga la confianza equivocada | métricas de probabilidad |
| 6 · Comparar con la base | `main` publica Elo frente a «siempre gana el local» | evaluación de modelos |

## Fallos típicos

- **`resultado no cuadra con los goles`**: la columna `resultado` está mal o se ha cambiado el orden.
- **`alguna jornada no tiene 10 partidos`**: el calendario está recortado; el Elo no vería a todos.
- **Fuga de información**: usar el rating final para predecir la jornada 38; aquí se corta antes.
- **Brier sin línea base**: un número suelto no dice si el modelo aporta; se compara siempre.

## Límite

Los resultados son sintéticos y de una sola liga. El Elo no incorpora bajas, descanso ni contexto; sirve
para aprender a construir y validar un rating, no para apostar.
