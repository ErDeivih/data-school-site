#!/usr/bin/env python3
"""Puerta del proyecto P55 (Kelly: 5 %, 20 % y 60 % de la banca).

Comprueba el resultado de verdad, sin escribir en disco y sin red: ventaja declarada, fracción óptima de
Kelly, crecimiento teórico frente al medido, ruina con umbral, misma secuencia de caras para las tres
fracciones, reproducibilidad, muestra de datos-ejemplo y código offline. Termina en RESULTADO: VERDE
(código 0) o ROJO (código 1).

Uso:
    python verificar.py

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import math
import sys

sys.dont_write_bytecode = True  # la puerta no escribe nada: ni resultados ni caché de bytecode

from pathlib import Path

import numpy as np

import kelly

fallos: list = []
comprobaciones = 0

# Crecimiento esperado por apuesta del modelo declarado (55 % de caras, pago 1 a 1). Son cuentas del
# modelo, no resultados de la simulación: sirven de referencia para comprobar que la simulación lo sigue.
TEORIA = {0.05: 0.0037526078187898604, 0.2: -0.00013774185471931988, 0.6: -0.15382883325821517}


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def leer_muestra(ruta: Path) -> list:
    with ruta.open(encoding="utf-8", newline="") as f:
        return [int(fila["gana"]) for fila in csv.DictReader(f)]


def main() -> int:
    print("== Puerta del proyecto P55 · Kelly: 5 %, 20 % y 60 % de la banca ==")

    # Paso 1 · Comprueba la ventaja declarada y la fracción óptima de Kelly
    # Por qué: la moneda y el pago se fijan antes de simular; el 10 % de Kelly sale de esas entradas y no
    #          de mirar cuál de las tres fracciones gana.
    # Salida esperada: "OK fraccion de Kelly: 10.00 % de la banca" y "OK crecimientos teoricos".
    # Si falla: RuntimeError de cargar_parametros → falta datos-ejemplo/parametros.json.
    parametros = kelly.cargar_parametros()
    probabilidad = float(parametros["prob_cara"])
    pago = float(parametros["pago"])
    ok(
        (int(parametros["semilla"]), int(parametros["apuestas"]), int(parametros["replicas"])) == (20261110, 10000, 100),
        f"parámetros: {int(parametros['replicas'])} replicas de {int(parametros['apuestas'])} apuestas"
        f" · p(gana)={probabilidad:.2f} · semilla {int(parametros['semilla'])}",
    )
    optima = kelly.fraccion_kelly(probabilidad, pago)
    ok(abs(optima - 0.10) < 1e-12, f"fraccion de Kelly: {optima * 100:.2f} % de la banca")
    teoricos = {float(f): kelly.crecimiento_teorico(float(f), probabilidad, pago) for f in parametros["fracciones"]}
    ok(
        all(abs(teoricos[f] - TEORIA[f]) < 1e-9 for f in TEORIA),
        "crecimiento teorico: " + " · ".join(f"g({f * 100:.0f} %)={g:+.6f}" for f, g in teoricos.items()),
    )
    ok(
        teoricos[0.05] > teoricos[0.2] > teoricos[0.6],
        "crecimiento teorico: el 5 % crece más que el 20 % y el 60 % pierde (no es más apuesta, más crecimiento)",
    )

    # Paso 2 · Ejecuta la simulación principal y comprueba ruina y crecimiento
    # Por qué: el criterio del catálogo pide que el 60 % arruine más y crezca menos; se mide con umbral
    #          declarado y con el logaritmo de la banca, no con la media aritmética.
    # Salida esperada: las líneas de la corrida y los OK de ruina y crecimiento.
    # Si falla: la ruina del 60 % no supera a la del 20 % → las fracciones no comparten la misma moneda.
    resultados = kelly.ejecutar(parametros)
    filas = {fila["fraccion"]: fila for fila in resultados["filas"]}
    ok(
        filas[0.6]["pct_ruina"] > filas[0.2]["pct_ruina"],
        f"ruina: el 60 % arruina {filas[0.6]['pct_ruina'] * 100:.1f} % frente a {filas[0.2]['pct_ruina'] * 100:.1f} % del 20 %",
    )
    ok(
        filas[0.6]["pct_ruina"] >= 0.9,
        f"ruina: la fracción del 60 % arruina al menos 9 de cada 10 réplicas ({filas[0.6]['pct_ruina'] * 100:.1f} %)",
    )
    ok(
        filas[0.05]["crecimiento"] > filas[0.2]["crecimiento"] > filas[0.6]["crecimiento"],
        f"crecimiento: {filas[0.05]['crecimiento']:+.5f} > {filas[0.2]['crecimiento']:+.5f} > {filas[0.6]['crecimiento']:+.5f} por apuesta",
    )
    ok(
        all(abs(filas[f]["crecimiento"] - teoricos[f]) < 0.003 for f in TEORIA),
        "crecimiento: lo medido coincide con el g(f) calculado antes de simular (tolerancia 0,003 por apuesta)",
    )
    ok(
        filas[0.6]["banca_mediana"] < 1.0 and filas[0.2]["banca_mediana"] > 1.0 and filas[0.05]["banca_mediana"] > 1000.0,
        "banca final mediana: 5 % > 1.000, 20 % > 1 y 60 % por debajo de 1",
    )

    # Paso 3 · Comprueba que las tres fracciones ven exactamente la misma secuencia de caras y cruces
    # Por qué: si cada fracción usara su propia moneda, comparar fracciones sería comparar semillas.
    # Salida esperada: el logaritmo de la banca de la réplica 0 se reconstruye a mano para las tres.
    # Si falla: la reconstrucción no coincide → cada fracción consumió una secuencia distinta.
    gana = resultados["simulacion"]["gana"]
    ok(
        gana.shape == (int(parametros["replicas"]), int(parametros["apuestas"])),
        f"secuencia compartida: matriz gana de forma {gana.shape}",
    )
    ok(0.54 < float(gana.mean()) < 0.56, f"secuencia compartida: proporcion de caras {float(gana.mean()):.4f} (declarada 0.55)")
    log_banca = math.log(float(parametros["banca_inicial"]))
    reconstrucciones_ok = True
    for fraccion in TEORIA:
        manual = log_banca + float(np.sum(np.where(gana[0], math.log1p(fraccion * pago), math.log1p(-fraccion))))
        reconstrucciones_ok = reconstrucciones_ok and abs(manual - float(resultados["simulacion"]["trayectorias"][fraccion][0, -1])) < 1e-9
    ok(reconstrucciones_ok, "secuencia compartida: la banca final de la replica 0 se reconstruye a mano en las tres fracciones")

    # Paso 4 · Comprueba la reproducibilidad del experimento
    # Por qué: la semilla 20261110 forma parte del contrato; repetir debe dar las mismas bancas y ruinas.
    # Salida esperada: dos simulaciones seguidas con las mismas métricas.
    # Si falla: los resultados cambian → se está usando el generador global en vez de default_rng.
    segunda = kelly.simular(parametros)
    ok(np.array_equal(resultados["simulacion"]["gana"], segunda["gana"]), "reproducibilidad: la misma semilla repite la secuencia de caras")
    ok(
        all(np.array_equal(resultados["simulacion"]["trayectorias"][f], segunda["trayectorias"][f]) for f in TEORIA),
        "reproducibilidad: las tres trayectorias se repiten exactamente",
    )

    # Paso 5 · Comprueba la muestra de datos-ejemplo contra la secuencia simulada
    # Por qué: la muestra son las primeras 1.000 apuestas de la réplica 0; si no cuadra, el dato de
    #          ejemplo es inventado y la puerta no probaría nada.
    # Salida esperada: 1.000 valores que coinciden con gana[0, :1000].
    # Si falla: el CSV no existe o se regeneró con otra semilla.
    ruta_muestra = kelly.DATOS / "moneda-muestra.csv"
    muestra = leer_muestra(ruta_muestra) if ruta_muestra.exists() else []
    esperadas = [int(v) for v in gana[0, : int(parametros["muestra"])]]
    ok(
        len(muestra) == int(parametros["muestra"]) and muestra == esperadas,
        f"muestra: {len(muestra)} apuestas en datos-ejemplo/moneda-muestra.csv y coinciden con la semilla",
    )

    # Paso 6 · Comprueba que el código es offline y no lleva secretos
    # Por qué: la entrega se comparte y la puerta se ejecuta sin red.
    # Salida esperada: "el código del proyecto no hace peticiones de red" y "no contiene claves".
    # Si falla: aparece un http(s) o un patrón de token en kelly.py → quítalo antes de empaquetar.
    fuente = (kelly.RAIZ / "kelly.py").read_text(encoding="utf-8")
    ok("http://" not in fuente and "https://" not in fuente, "el código del proyecto no hace peticiones de red")
    ok(
        not any(patron in fuente for patron in ("ghp_", "github_pat_", "Authorization:", "api_key")),
        "el código del proyecto no contiene claves ni cabeceras de autorización",
    )

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
