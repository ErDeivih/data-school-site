# P55 · Kelly: qué pasa apostando 5 %, 20 % y 60 % de la banca — código ejecutable

Simula 100 réplicas de 10.000 apuestas de una moneda con **ventaja declarada** (55 % de caras, pago 1 a
1) apostando cada vez el 5 %, el 20 % y el 60 % de la banca actual. Las tres fracciones ven la **misma
secuencia** de caras y cruces; solo cambia la fracción. Mide crecimiento en logaritmo, ruina con umbral
declarado y la peor caída, y lo contrasta con el `g(f)` calculado antes de simular. Es el código que
acompaña a la ficha `../../fichas-ideas/p55-simulador-de-kelly.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **NumPy** `>=1.26` (probado con 2.5.2; licencia BSD-3-Clause).
- **matplotlib** (opcional, licencia PSF/Matplotlib): solo para `python kelly.py --figura`.
- No hace falta red ni ninguna cuenta: la moneda es un modelo con ventaja declarada.

## Instalación

```powershell
cd proyectos/p55-simulador-de-kelly/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` solo exige NumPy; matplotlib queda comentado porque la figura es opcional.

## Orden de ejecución

```powershell
python kelly.py --regenerar-muestra   # reescribe datos-ejemplo/moneda-muestra.csv (semilla 20261110)
python kelly.py                       # simula, imprime la tabla y guarda resultados/
python kelly.py --figura              # además dibuja trayectorias y ruina (matplotlib)
```

`--regenerar-muestra` no hace falta en una ejecución normal: la muestra de 1.000 apuestas ya viaja en
`datos-ejemplo/` y se regenera exacta con la misma semilla.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta es **solo stdout** (no escribe en disco) y no usa red. Comprueba **17 cosas**: la ventaja
declarada, que la fracción óptima de Kelly sea el 10 %, el `g(f)` teórico de las tres fracciones, que el
60 % arruine más y crezca menos que el 20 %, que lo medido coincida con lo teórico (tolerancia 0,003 por
apuesta), que las tres fracciones compartan la misma secuencia de caras, que la semilla 20261110 repita
el experimento, que la muestra de `datos-ejemplo/` se regenere y que el código no haga red ni lleve
claves. Termina en `RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). La salida real es la de
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt), con 17 comprobaciones en verde:

- **5 %:** crecimiento +0,003788 por apuesta, banca final mediana 2,815e+19, ruina 0 %, peor caída 96,1 %.
- **20 %:** crecimiento +0,000006, banca mediana 1,043e+03, ruina 85 %, unos 1.802 pasos hasta el umbral.
- **60 %:** crecimiento −0,153338, banca mediana 0, ruina 100 %, unos 29,8 pasos hasta el umbral.
- **Teoría:** g(5 %) = +0,003753, g(20 %) = −0,000138, g(60 %) = −0,153829; la simulación los sigue.

La ruina se mide con el umbral declarado del 1 % de la banca inicial, no con «llegar a cero»: apostar una
fracción nunca deja la banca exactamente en cero.

## Datos de ejemplo

- `datos-ejemplo/parametros.json`: semilla **20261110**, 10.000 apuestas por réplica, 100 réplicas,
  p(gana) = 0,55, pago 1,0, fracciones [0,05 · 0,20 · 0,60], banca inicial 1.000 y umbral de ruina 0,01.
- `datos-ejemplo/moneda-muestra.csv`: **1.000 filas × 2 columnas** (`apuesta`, `gana` con 0/1). No es un
  CSV del catálogo: son los primeros 1.000 resultados de la primera réplica, generados por el proyecto
  con la semilla fija, y la puerta comprueba que se regeneran exactamente.
- `resultados/`: `resumen.csv` (3 filas), `crecimiento-teorico.csv` (3 filas),
  `trayectorias-muestra.csv` (100 puntos de la primera réplica) y `ejemplo-salida.txt`. Se regeneran al
  ejecutar `kelly.py`; no hacen falta para verificar.

## Fuente real y licencia

- **No hay API ni fuente externa**: el proyecto es local por diseño y la ficha declara `api: []`.
- Datos propios sintéticos y deterministas, generados por el proyecto: **CC0-1.0**.
- NumPy: **BSD-3-Clause**. matplotlib (opcional): **PSF/Matplotlib**.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Ventaja declarada | La probabilidad y el pago se fijan antes de ver el resultado | `Axiomas de probabilidad` |
| 2 · Fracción de Kelly | `f* = (p·(b+1) − 1)/b`: el óptimo sale del modelo | `Criterio de Kelly` |
| 3 · Crecimiento en logaritmo | Por qué más apuesta no es más crecimiento (media geométrica) | `Volatility drag` |
| 4 · Secuencia compartida | Comparar fracciones exige la misma moneda | `Simulación de Monte Carlo` |
| 5 · Ruina con umbral | La ruina se define antes; apostar una fracción no llega a cero | `Riesgo de ruina` |
| 6 · Semilla y muestra | Reproducibilidad de la trayectoria y del dato de ejemplo | `Aleatoriedad y muestreo` |
| 7 · Puerta offline | Recuentos y tolerancias como contrato verificable | `Precisión y error numérico` |

## Estructura

```text
codigo/
├── kelly.py                # ventaja, Kelly, trayectorias, ruina, crecimiento, CSV y figura
├── datos-ejemplo/          # parametros.json y la muestra de 1.000 apuestas (semilla 20261110)
├── verificar.py            # la puerta del proyecto (solo stdout, sin red)
└── resultados/             # ejemplo-salida.txt y los CSV generados
```

## Fallos típicos

- **`ModuleNotFoundError: numpy`**: instala con el mismo Python que ejecuta el script,
  `python -m pip install -r requirements.txt`.
- **Cada fracción usa una moneda distinta**: si se genera una secuencia por fracción, la comparación mide
  la suerte y no la fracción; el proyecto usa una sola matriz `gana` compartida.
- **Media aritmética de la banca**: promediar bancas finales premia trayectorias rarísimas; el criterio
  correcto es el logaritmo (media geométrica), que es lo que compara `g_medido` con `g(f)`.
- **Ruina igual a cero**: apostar una fracción nunca deja la banca en cero; sin umbral declarado el
  recuento de ruina sale 0 en las tres fracciones y no demuestra nada.
- **La muestra no coincide**: se regeneró con otra semilla o con otras réplicas; la muestra son las
  primeras 1.000 apuestas de la primera réplica de la misma simulación.
- **`PermissionError` al guardar**: `resultados/` no es escribible; ejecuta desde `codigo/` o cambia la
  ruta de salida.
