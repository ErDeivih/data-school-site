#!/usr/bin/env python3
"""P55 · Kelly: qué pasa apostando 5 %, 20 % y 60 % de la banca.

Proyecto completo de la ficha P55. Simula 100 réplicas de 10.000 apuestas de una moneda con ventaja
declarada (55 % de caras, pago 1 a 1), apostando cada vez el 5 %, el 20 % y el 60 % de la banca actual.
Las tres fracciones ven exactamente la misma secuencia de caras y cruces; solo cambia la fracción. Mide
crecimiento (en logaritmo), ruina con umbral declarado y la peor caída. No usa red.

    python kelly.py                     # simula, imprime la tabla y guarda resultados/
    python kelly.py --figura            # además dibuja trayectorias y ruina (matplotlib)
    python kelly.py --regenerar-muestra # reescribe datos-ejemplo/moneda-muestra.csv

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"


def cargar_parametros() -> dict:
    # Paso 1 · Lee la ventaja de la moneda y las fracciones desde datos-ejemplo/parametros.json
    # Por qué: la probabilidad, el pago y la semilla se declaran antes de simular; si se eligen después
    #          de ver el resultado, la comparación entre fracciones deja de ser honesta.
    # Salida esperada: las claves del experimento cargadas sin error (justo después se imprime «moneda: …»)
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o restaura datos-ejemplo/parametros.json.
    ruta = DATOS / "parametros.json"
    parametros = json.loads(ruta.read_text(encoding="utf-8"))
    obligatorias = ("semilla", "apuestas", "replicas", "prob_cara", "pago", "fracciones", "banca_inicial", "umbral_ruina")
    faltan = [clave for clave in obligatorias if clave not in parametros]
    if faltan:
        raise RuntimeError(f"faltan claves en {ruta.name}: {', '.join(faltan)}")
    if not 0.0 < float(parametros["prob_cara"]) < 1.0:
        raise RuntimeError("«prob_cara» tiene que estar entre 0 y 1")
    if float(parametros["pago"]) <= 0.0:
        raise RuntimeError("«pago» tiene que ser positivo")
    if not 0.0 < float(parametros["umbral_ruina"]) < 1.0:
        raise RuntimeError("«umbral_ruina» es una fracción de la banca inicial, entre 0 y 1")
    for fraccion in parametros["fracciones"]:
        if not 0.0 < float(fraccion) < 1.0:
            raise RuntimeError("cada fracción tiene que estar entre 0 y 1")
    return parametros


def fraccion_kelly(prob_cara: float, pago: float) -> float:
    """Fracción óptima de la banca según Kelly: (p·(b+1) − 1) / b, con b = pago neto."""
    return (prob_cara * (pago + 1.0) - 1.0) / pago


def crecimiento_teorico(fraccion: float, prob_cara: float, pago: float) -> float:
    """Crecimiento esperado del logaritmo de la banca por apuesta: p·ln(1+f·b) + q·ln(1−f)."""
    return prob_cara * math.log1p(fraccion * pago) + (1.0 - prob_cara) * math.log1p(-fraccion)


def simular(parametros: dict) -> dict:
    # Paso 2 · Genera la secuencia de caras y cruces y las tres trayectorias con la misma semilla
    # Por qué: si cada fracción viera una moneda distinta, la comparación mediría la suerte de cada
    #          semilla y no la fracción; una sola matriz `gana` compartida es lo que hace comparable.
    # Salida esperada: una máscara (100 réplicas × 10.000 apuestas) y el logaritmo de la banca por fracción
    # Si falla: MemoryError → reduce «replicas» o «apuestas» en el JSON (100 × 10.000 son 1 millón de apuestas).
    rng = np.random.default_rng(int(parametros["semilla"]))
    replicas = int(parametros["replicas"])
    apuestas = int(parametros["apuestas"])
    prob_cara = float(parametros["prob_cara"])
    pago = float(parametros["pago"])
    banca = float(parametros["banca_inicial"])

    gana = rng.random((replicas, apuestas)) < prob_cara
    log_banca = math.log(banca)
    trayectorias = {}
    for fraccion in parametros["fracciones"]:
        fraccion = float(fraccion)
        pasos = np.where(gana, math.log1p(fraccion * pago), math.log1p(-fraccion))
        trayectorias[fraccion] = log_banca + np.cumsum(pasos, axis=1)
    return {"gana": gana, "trayectorias": trayectorias}


def _banca(log_banca: float) -> float:
    """Convierte el logaritmo de la banca a banca; evita desbordar a infinito o a negativo."""
    if log_banca < -745.0:
        return 0.0
    return math.exp(log_banca)


def metricas(parametros: dict, simulacion: dict) -> list:
    # Paso 3 · Mide crecimiento, ruina y peor caída por fracción
    # Por qué: la media aritmética de las bancas finales premia trayectorias rarísimas; con apuestas
    #          multiplicativas el criterio correcto es el logaritmo (media geométrica). Y la ruina se
    #          define con un umbral declarado, porque apostar una fracción nunca deja la banca en cero.
    # Salida esperada: una fila por fracción con crecimiento por apuesta, banca mediana, % de ruina y peor caída
    # Si falla: KeyError → las fracciones del JSON no coinciden con las trayectorias simuladas.
    apuestas = int(parametros["apuestas"])
    banca = float(parametros["banca_inicial"])
    fracciones = [float(f) for f in parametros["fracciones"]]
    log_banca = math.log(banca)
    umbral_log = math.log(banca * float(parametros["umbral_ruina"]))
    filas = []
    for fraccion in fracciones:
        logw = simulacion["trayectorias"][fraccion]
        final = logw[:, -1]
        mediana_log = float(np.median(final))
        crecimiento = float(np.mean((final - log_banca) / apuestas))
        arruinada = logw < umbral_log
        cruza = arruinada.any(axis=1)
        pasos_ruina = np.where(cruza, arruinada.argmax(axis=1) + 1, 0)
        caida = logw - np.maximum.accumulate(logw, axis=1)
        caida_min = float(caida.min())
        filas.append(
            {
                "fraccion": fraccion,
                "crecimiento": crecimiento,
                "banca_mediana": _banca(mediana_log),
                "pct_ruina": float(np.mean(cruza)),
                "pasos_ruina_medios": float(pasos_ruina[pasos_ruina > 0].mean()) if cruza.any() else 0.0,
                "peor_caida": 1.0 - math.exp(caida_min) if caida_min > -745.0 else 1.0,
            }
        )
    return filas


def ejecutar(parametros: dict) -> dict:
    """Simula, imprime el resumen de la corrida y devuelve las métricas que la puerta necesita."""
    prob_cara = float(parametros["prob_cara"])
    pago = float(parametros["pago"])
    kelly = fraccion_kelly(prob_cara, pago)
    simulacion = simular(parametros)
    filas = metricas(parametros, simulacion)

    print(
        f"moneda: p(gana)={prob_cara:.2f} · pago {pago:.0f}:1 · banca inicial {float(parametros['banca_inicial']):.0f}"
        f" · {int(parametros['replicas'])} replicas de {int(parametros['apuestas'])} apuestas"
        f" · semilla {int(parametros['semilla'])}"
    )
    print(f"kelly: fraccion optima {kelly * 100:.2f} % de la banca")
    for fila in filas:
        print(
            f"fraccion {fila['fraccion'] * 100:.0f} %: crecimiento/apuesta {fila['crecimiento']:+.6f}"
            f" · banca final mediana {fila['banca_mediana']:.3e}"
            f" · ruina {fila['pct_ruina'] * 100:.1f} %"
            f" · peor caida {fila['peor_caida'] * 100:.1f} %"
        )
    teorias = {float(f): crecimiento_teorico(float(f), prob_cara, pago) for f in parametros["fracciones"]}
    print(
        "crecimiento teorico: "
        + " · ".join(f"g({f * 100:.0f} %)={g:+.6f}" for f, g in teorias.items())
    )
    return {"simulacion": simulacion, "filas": filas, "kelly": kelly, "teorias": teorias}


def guardar(resultados: dict, parametros: dict) -> None:
    # Paso 4 · Guarda las tablas en resultados/ (CSV) y una muestra de trayectorias
    # Por qué: el resumen se guarda por fracción, y las trayectorias se muestrean (100 puntos de la
    #          primera réplica) para que el fichero se lea; las 100 réplicas se regeneran con la semilla.
    # Salida esperada: "resultados: resumen.csv, crecimiento-teorico.csv, trayectorias-muestra.csv"
    # Si falla: PermissionError → resultados/ no es escribible; ejecuta desde codigo/.
    RESULTADOS.mkdir(parents=True, exist_ok=True)
    with (RESULTADOS / "resumen.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["fraccion", "crecimiento_por_apuesta", "banca_final_mediana", "pct_ruina", "pasos_ruina_medios", "peor_caida"])
        for fila in resultados["filas"]:
            escritor.writerow(
                [
                    f"{fila['fraccion']:.2f}",
                    f"{fila['crecimiento']:+.6f}",
                    f"{fila['banca_mediana']:.6e}",
                    f"{fila['pct_ruina']:.4f}",
                    f"{fila['pasos_ruina_medios']:.1f}",
                    f"{fila['peor_caida']:.4f}",
                ]
            )
    with (RESULTADOS / "crecimiento-teorico.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["fraccion", "g_teorico", "g_medido", "diferencia"])
        for fila in resultados["filas"]:
            teorico = resultados["teorias"][fila["fraccion"]]
            escritor.writerow(
                [f"{fila['fraccion']:.2f}", f"{teorico:+.6f}", f"{fila['crecimiento']:+.6f}", f"{fila['crecimiento'] - teorico:+.6f}"]
            )
    fracciones = [float(f) for f in parametros["fracciones"]]
    apuestas = int(parametros["apuestas"])
    puntos = int(parametros.get("puntos_trayectoria", 100))
    indices = np.unique(np.linspace(0, apuestas - 1, min(puntos, apuestas), dtype=int))
    primera = {fraccion: resultados["simulacion"]["trayectorias"][fraccion][0] for fraccion in fracciones}
    with (RESULTADOS / "trayectorias-muestra.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["apuesta"] + [f"banca_{int(f * 100)}" for f in fracciones])
        for indice in indices:
            escritor.writerow([int(indice) + 1] + [f"{_banca(primera[f][indice]):.6g}" for f in fracciones])
    print("resultados: resumen.csv, crecimiento-teorico.csv, trayectorias-muestra.csv")


def escribir_muestra(parametros: dict) -> Path:
    # Paso 5 · Escribe la muestra de datos-ejemplo con la misma secuencia que la simulación
    # Por qué: la muestra son los primeros 1.000 resultados de la primera réplica, no un dato inventado;
    #          así la puerta comprueba que la moneda del JSON se reproduce exactamente.
    # Salida esperada: "muestra: datos-ejemplo/moneda-muestra.csv (1000 apuestas)"
    # Si falla: PermissionError → datos-ejemplo/ tiene que existir y ser escribible.
    ruta = DATOS / "moneda-muestra.csv"
    simulacion = simular(parametros)
    gana = simulacion["gana"][0, : int(parametros["muestra"])]
    with ruta.open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["apuesta", "gana"])
        for indice, valor in enumerate(gana, start=1):
            escritor.writerow([indice, int(valor)])
    print(f"muestra: {ruta.relative_to(RAIZ).as_posix()} ({len(gana)} apuestas)")
    return ruta


def figura(resultados: dict, parametros: dict) -> None:
    # Paso 6 · Dibuja las tres trayectorias (escala logarítmica) y el % de ruina por fracción
    # Por qué: la figura ayuda a ver que más fracción no es más crecimiento, pero la prueba son los números.
    # Salida esperada: resultados/kelly.png
    # Si falla: ModuleNotFoundError de matplotlib → `python -m pip install matplotlib`.
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ModuleNotFoundError as exc:
        raise RuntimeError("para --figura hace falta matplotlib: python -m pip install matplotlib") from exc

    fracciones = [float(f) for f in parametros["fracciones"]]
    apuestas = int(parametros["apuestas"])
    puntos = int(parametros.get("puntos_trayectoria", 100))
    indices = np.unique(np.linspace(0, apuestas - 1, min(puntos, apuestas), dtype=int))
    fig, (izquierda, derecha) = plt.subplots(1, 2, figsize=(11, 4))
    for fraccion in fracciones:
        logw = resultados["simulacion"]["trayectorias"][fraccion][0]
        izquierda.plot(indices + 1, [_banca(float(logw[i])) for i in indices], label=f"{fraccion * 100:.0f} % de la banca")
    izquierda.set_xscale("log")
    izquierda.set_yscale("symlog", linthresh=1e-3)
    izquierda.set_xlabel("apuesta")
    izquierda.set_ylabel("banca")
    izquierda.set_title("Tres fracciones con la misma moneda")
    izquierda.legend()
    derecha.bar([f"{fila['fraccion'] * 100:.0f} %" for fila in resultados["filas"]],
                [fila["pct_ruina"] * 100 for fila in resultados["filas"]], color="#c44e52")
    derecha.set_ylabel("% de réplicas arruinadas")
    derecha.set_title("Ruina (banca < 1 % de la inicial)")
    fig.tight_layout()
    fig.savefig(RESULTADOS / "kelly.png", dpi=120)
    plt.close(fig)
    print("figura: kelly.png")


def main(argv: list) -> int:
    try:
        parametros = cargar_parametros()
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    if "--regenerar-muestra" in argv:
        try:
            escribir_muestra(parametros)
        except OSError as exc:
            print(f"error: {exc}")
            return 1
        return 0
    print("== P55 · Kelly: 5 %, 20 % y 60 % de la banca ==")
    resultados = ejecutar(parametros)
    try:
        guardar(resultados, parametros)
        if "--figura" in argv:
            figura(resultados, parametros)
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
