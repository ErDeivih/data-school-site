# P30 · Salud: quién abandona el programa de seguimiento y cuándo

Paquete descargable de **Data School** para el proyecto P30. Incluye los clientes de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar, sin sklearn.

## Ejecutar

```bash
python churn.py
python verificar.py
```

`churn.py` entrena una regresión logística desde cero, barre umbrales con coste asimétrico (perder un
paciente cuesta 5; una llamada de más, 1), elige el corte de menor coste y mide la calibración por
tramos. `verificar.py` sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/clientes-churn.csv`: **200 clientes × 5 columnas** (antigüedad, uso mensual,
  reclamaciones y baja; 94 bajas). Sintético y **CC0-1.0**; es el `clientes-churn` del catálogo de Data
  School.

## Salida esperada

```text
clientes: 200 · bajas: 94 · train/test: 150/50
pesos: -0.232 · -0.075 · -0.709 · 1.087
mejor umbral por coste: 0.15 · coste 20 · VP 26 · FP 20 · FN 0 · VN 4
calibración por tramos:
  n=10 · prob media 0.162 · tasa real 0.200
  ...
  n=10 · prob media 0.754 · tasa real 0.800
límite: 200 clientes sintéticos; no es un modelo clínico ni sustituye a un profesional.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Grano | `leer` exige ids únicos y baja 0/1 | desbalanceo de clases |
| 2 · Partición | `partir` deja 150/50 con ambas clases | validación |
| 3 · Normalizar | media y desviación solo de train | fuga de datos |
| 4 · Vector | `vector` estandariza con el 1 del intercepto | regresión logística |
| 5 · Entrenar | `entrenar` ajusta por descenso de gradiente | regresión logística |
| 6 · Probabilidad | `probabilidad` aplica la logística | umbrales y coste |
| 7 · Matriz | `matriz` calcula VP/FP/FN/VN y coste | umbrales y coste |
| 8 · Barrido | `barrido` elige el umbral de menor coste | umbrales y coste |
| 9 · Calibración | `calibracion` compara probabilidad y tasa real | calibración |
| 10 · Publicar | `main` deja el umbral y el límite a la vista | comunicación |

## Fallos típicos

- **Usar 0,5 por inercia**: con coste 5:1 el corte óptimo baja y se llama a más gente a propósito.
- **Normalizar con todo el CSV**: el test filtra información al train; se normaliza solo con train.
- **Reportar solo exactitud**: con 94/200 bajas, la exactitud sola no dice si el modelo sirve.
- **Confundir probabilidad con decisión**: la probabilidad se calibra; la decisión aplica un umbral.

## Límite

Son 200 clientes sintéticos. Sirve para aprender umbral por coste y calibración, no es un modelo clínico
ni sustituye a un profesional.
