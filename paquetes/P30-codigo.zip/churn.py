"""P30 · Salud: quién abandona el programa de seguimiento y cuándo.

Entrena una regresión logística desde cero (sin sklearn), barre umbrales con un coste asimétrico
(perder un paciente cuesta más que una llamada de más), elige el corte y mide la calibración por tramos.
Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("id_cliente", "antiguedad_meses", "uso_mensual", "reclamaciones", "baja")
CARACTERISTICAS = ("antiguedad_meses", "uso_mensual", "reclamaciones")
COSTE_FALSO_NEGATIVO = 5.0
COSTE_FALSO_POSITIVO = 1.0
EPOCAS = 3000
TASA = 0.1


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el grano: un cliente por fila y la baja como 0/1.
    # Por qué: si hay ids repetidos o la clase no es binaria, el modelo aprende de datos sucios.
    # Salida esperada: 200 clientes y 94 bajas.
    # Si falla: «columnas inesperadas», «id repetido» o «baja no binaria».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 200:
        raise ValueError(f"se esperaban 200 clientes, hay {len(filas)}")
    ids = [f["id_cliente"] for f in filas]
    if len(ids) != len(set(ids)):
        raise ValueError("hay ids de cliente repetidos")
    if {f["baja"] for f in filas} - {"0", "1"}:
        raise ValueError("la columna baja debe ser 0 o 1")
    return filas


def partir(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    # Paso 2 · Separar train y test de forma determinista: una de cada cuatro filas va a test.
    # Por qué: sin partición no hay forma de saber si el modelo acierta fuera de lo visto.
    # Salida esperada: 150 de train y 50 de test, con ambas clases.
    # Si falla: el test se queda sin bajas o sin no-bajas.
    test = [f for i, f in enumerate(filas) if i % 4 == 0]
    train = [f for i, f in enumerate(filas) if i % 4 != 0]
    if len(test) != 50 or len(train) != 150:
        raise ValueError("la partición no da 150/50")
    if len({f["baja"] for f in test}) != 2 or len({f["baja"] for f in train}) != 2:
        raise ValueError("alguna partición se queda sin una clase")
    return train, test


def normalizar(train: list[dict]) -> dict:
    # Paso 3 · Estandarizar con la media y la desviación de TRAIN, no de todo el CSV.
    # Por qué: usar el test para normalizar es fuga de información.
    # Salida esperada: media y desviación de las tres características del train.
    # Si falla: una característica tiene desviación 0.
    salida = {}
    for c in CARACTERISTICAS:
        valores = [float(f[c]) for f in train]
        media = sum(valores) / len(valores)
        var = sum((v - media) ** 2 for v in valores) / len(valores)
        salida[c] = {"media": media, "desviacion": math.sqrt(var)}
    return salida


def vector(fila: dict, norm: dict) -> list[float]:
    # Paso 4 · Pasar una fila a vector estandarizado, con el 1 del intercepto delante.
    # Por qué: el modelo aprende pesos sobre la misma escala en train y en test.
    # Salida esperada: cuatro números por fila.
    # Si falla: el escalado es 0.
    return [1.0] + [(float(fila[c]) - norm[c]["media"]) / norm[c]["desviacion"] for c in CARACTERISTICAS]


def entrenar(train: list[dict], norm: dict) -> list[float]:
    # Paso 5 · Ajustar la regresión logística por descenso de gradiente.
    # Por qué: entrenar desde cero enseña que el modelo es una función de pesos, no una caja.
    # Salida esperada: pesos estables tras 3.000 épocas.
    # Si falla: la pérdida no baja (tasa demasiado alta o datos sin señal).
    pesos = [0.0] * (len(CARACTERISTICAS) + 1)
    for _ in range(EPOCAS):
        gradientes = [0.0] * len(pesos)
        for fila in train:
            x = vector(fila, norm)
            z = sum(p * v for p, v in zip(pesos, x))
            p = 1.0 / (1.0 + math.exp(-z))
            error = p - float(fila["baja"])
            for j in range(len(pesos)):
                gradientes[j] += error * x[j]
        pesos = [p - TASA * g / len(train) for p, g in zip(pesos, gradientes)]
    return [round(p, 5) for p in pesos]


def probabilidad(fila: dict, norm: dict, pesos: list[float]) -> float:
    # Paso 6 · Calcular la probabilidad de baja con los pesos entrenados.
    # Por qué: el umbral se aplica sobre una probabilidad, no sobre una etiqueta.
    # Salida esperada: un número entre 0 y 1.
    # Si falla: los pesos no tienen la longitud del vector.
    z = sum(p * v for p, v in zip(pesos, vector(fila, norm)))
    return 1.0 / (1.0 + math.exp(-z))


def matriz(test: list[dict], norm: dict, pesos: list[float], umbral: float) -> dict:
    # Paso 7 · Matriz de confusión a un umbral dado, con su coste.
    # Por qué: el umbral no es 0,5 por defecto; se elige por el coste de cada error.
    # Salida esperada: VP, FP, FN, VN y coste = 5·FN + 1·FP.
    # Si falla: las etiquetas no son 0/1.
    vp = fp = fn = vn = 0
    for fila in test:
        p = probabilidad(fila, norm, pesos)
        pred = 1 if p >= umbral else 0
        real = int(fila["baja"])
        if pred == 1 and real == 1:
            vp += 1
        elif pred == 1 and real == 0:
            fp += 1
        elif pred == 0 and real == 1:
            fn += 1
        else:
            vn += 1
    return {"vp": vp, "fp": fp, "fn": fn, "vn": vn,
            "coste": COSTE_FALSO_NEGATIVO * fn + COSTE_FALSO_POSITIVO * fp}


def barrido(test: list[dict], norm: dict, pesos: list[float]) -> list[dict]:
    # Paso 8 · Barrer umbrales y quedarse con el de menor coste.
    # Por qué: bajar el umbral llama a más gente; subirlo deja escapar bajas que cuestan 5 veces más.
    # Salida esperada: el mínimo de coste en un umbral concreto, no en 0,5 por inercia.
    # Si falla: ningún umbral produce una matriz válida.
    salida = []
    for i in range(1, 20):
        umbral = round(i / 20, 2)
        fila = matriz(test, norm, pesos, umbral)
        salida.append({"umbral": umbral, **fila})
    return salida


def calibracion(test: list[dict], norm: dict, pesos: list[float], tramos: int = 5) -> list[dict]:
    # Paso 9 · Calibración por tramos: probabilidad media frente a tasa observada.
    # Por qué: un modelo puede ordenar bien y estar mal calibrado; el tramo lo enseña.
    # Salida esperada: 5 tramos con n, probabilidad media y tasa real.
    # Si falla: hay tramos sin observaciones.
    parejas = sorted(((probabilidad(f, norm, pesos), int(f["baja"])) for f in test), key=lambda x: x[0])
    salida = []
    tam = math.ceil(len(parejas) / tramos)
    for i in range(0, len(parejas), tam):
        grupo = parejas[i:i + tam]
        salida.append({"n": len(grupo),
                       "prob_media": round(sum(p for p, _ in grupo) / len(grupo), 3),
                       "tasa_real": round(sum(y for _, y in grupo) / len(grupo), 3)})
    return salida


def main() -> int:
    # Paso 10 · Publicar el umbral elegido, la matriz y la calibración; declarar el límite.
    # Por qué: el coste y el umbral tienen que quedar a la vista para poder revisarlos.
    # Salida esperada: pesos, umbral de coste mínimo, matriz y 5 tramos.
    # Si falla: revisa --csv o la partición.
    parser = argparse.ArgumentParser(description="Umbral por coste y calibración (P30)")
    parser.add_argument("--csv", default="datos-ejemplo/clientes-churn.csv")
    args = parser.parse_args()
    filas = leer(Path(args.csv))
    train, test = partir(filas)
    norm = normalizar(train)
    pesos = entrenar(train, norm)
    barrido_ = barrido(test, norm, pesos)
    mejor = min(barrido_, key=lambda x: (x["coste"], x["umbral"]))
    print(f"clientes: {len(filas)} · bajas: {sum(int(f['baja']) for f in filas)} · train/test: {len(train)}/{len(test)}")
    print("pesos: " + " · ".join(f"{p:.3f}" for p in pesos))
    print(f"mejor umbral por coste: {mejor['umbral']:.2f} · coste {mejor['coste']:.0f} · VP {mejor['vp']} · FP {mejor['fp']} · FN {mejor['fn']} · VN {mejor['vn']}")
    print("calibración por tramos:")
    for t in calibracion(test, norm, pesos):
        print(f"  n={t['n']:>2} · prob media {t['prob_media']:.3f} · tasa real {t['tasa_real']:.3f}")
    print("límite: 200 clientes sintéticos; no es un modelo clínico ni sustituye a un profesional.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
