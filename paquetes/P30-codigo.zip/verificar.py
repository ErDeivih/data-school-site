﻿#!/usr/bin/env python3
"""Puerta del proyecto P30 (churn: umbral por coste y calibración).

Comprueba grano, partición, pesos, umbral de coste mínimo, matriz, barrido y calibración.
Sin escribir en disco. VERDE (0) o ROJO (1).
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import churn

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "clientes-churn.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = churn.leer(CSV)
    ok(len(filas) == 200, "el CSV tiene 200 clientes")
    ok(sum(int(f["baja"]) for f in filas) == 94, "hay 94 bajas")
    ok(len({f["id_cliente"] for f in filas}) == 200, "los 200 ids son únicos")

    train, test = churn.partir(filas)
    ok(len(train) == 150, "train tiene 150 clientes")
    ok(len(test) == 50, "test tiene 50 clientes")
    ok(len({f["baja"] for f in test}) == 2, "el test conserva las dos clases")

    norm = churn.normalizar(train)
    ok(len(norm) == 3, "se normalizan las 3 características")
    pesos = churn.entrenar(train, norm)
    ok(len(pesos) == 4, "el modelo aprende 4 pesos (intercepto + 3)")
    ok([round(p, 3) for p in pesos] == [-0.232, -0.075, -0.709, 1.087], "los pesos son los esperados")
    ok(pesos[3] > 0, "más reclamaciones sube la probabilidad de baja")
    ok(pesos[1] < 0, "más uso mensual baja la probabilidad de baja")

    barrido = churn.barrido(test, norm, pesos)
    ok(len(barrido) == 19, "el barrido prueba 19 umbrales")
    mejor = min(barrido, key=lambda x: (x["coste"], x["umbral"]))
    ok(mejor["umbral"] == 0.15, "el mejor umbral es 0,15")
    ok(mejor["coste"] == 20, "el coste mínimo es 20")
    ok(mejor["vp"] == 26 and mejor["fp"] == 20 and mejor["fn"] == 0 and mejor["vn"] == 4,
       "la matriz es VP 26 · FP 20 · FN 0 · VN 4")
    ok(mejor["vp"] + mejor["fp"] + mejor["fn"] + mejor["vn"] == 50, "la matriz suma los 50 del test")
    ok(mejor["coste"] == 5 * mejor["fn"] + mejor["fp"], "el coste aplica 5·FN + 1·FP")

    cal = churn.calibracion(test, norm, pesos)
    ok(len(cal) == 5, "la calibración tiene 5 tramos")
    ok(all(t["n"] == 10 for t in cal), "cada tramo tiene 10 observaciones")
    ok(cal[0]["prob_media"] == 0.162 and cal[0]["tasa_real"] == 0.2, "el primer tramo calibra 0,162 frente a 0,200")
    ok(cal[-1]["prob_media"] == 0.754 and cal[-1]["tasa_real"] == 0.8, "el último tramo calibra 0,754 frente a 0,800")

    codigo = (AQUI / "churn.py").read_text(encoding="utf-8")
    ok("import sklearn" not in codigo and "from sklearn" not in codigo, "el modelo se entrena desde cero, sin sklearn")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
