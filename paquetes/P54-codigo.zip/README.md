# P54 · Simulador de dados: 100.000 tiradas contra el valor esperado — código ejecutable

Genera 100.000 tiradas de un dado de seis caras con **semilla fija**, compara la media con el valor
esperado 3,5 y mide cómo la desviación de la media baja al crecer n contra el error estándar teórico
σ/√n. Todo sale de un `parametros.json`, se ejecuta sin red y termina en una puerta que devuelve 0 solo
si los números cuadran. Es el código que acompaña a la ficha
`../../fichas-ideas/p54-simulador-de-dados.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **NumPy** `>=1.26` (probado con 2.5.2; licencia BSD-3-Clause). Genera las tiradas y las medias
  acumuladas.
- **matplotlib** (opcional, licencia PSF/Matplotlib): solo para `python simulador.py --figura`.
- No hace falta red ni ninguna cuenta: el dado es un modelo con probabilidades conocidas.

## Instalación

```powershell
cd proyectos/p54-simulador-de-dados/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` solo exige NumPy; matplotlib queda comentado porque las figuras son opcionales.

## Orden de ejecución

```powershell
python simulador.py --regenerar-muestra   # reescribe datos-ejemplo/tiradas-muestra.csv (semilla 20261109)
python simulador.py                       # simula, imprime la tabla por n y guarda resultados/
python simulador.py --figura              # además dibuja histograma y convergencia (matplotlib)
```

`--regenerar-muestra` no hace falta en una ejecución normal: la muestra de 1.000 tiradas ya viaja en
`datos-ejemplo/` y se puede regenerar byte a byte con la misma semilla.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta es **solo stdout** (no escribe en disco) y se ejecuta sin red. Recalcula todo en memoria y
comprueba **13 cosas**: los parámetros y la semilla 20261109, que la muestra de `datos-ejemplo/` se
regenera exacta, que la media queda a menos de 3 errores estándar de 3,5, que el histograma suma 100.000
tiradas sin caras vacías, que la tabla por n baja en error estándar, que la desviación de la media cae
como 1/√n (cociente de réplicas ≈ 10), que la misma semilla repite y otra cambia, y que el código no
hace red ni lleva claves. Termina en `RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). La
salida real es la de [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt): media 3,49621
frente a 3,5 (0,70 errores estándar), cociente de convergencia 9,05 y 13 comprobaciones en verde.

## Datos de ejemplo

- `datos-ejemplo/parametros.json`: la semilla **20261109**, 6 caras, 100.000 tiradas, los cinco tamaños
  de la tabla (10, 100, 1.000, 10.000 y 100.000) y el tamaño de la muestra (1.000).
- `datos-ejemplo/tiradas-muestra.csv`: **1.000 filas × 2 columnas** (`indice`, `cara`). No es un CSV del
  catálogo: son las primeras 1.000 tiradas de la simulación, generadas por el propio proyecto con la
  semilla fija, y la puerta comprueba que se regeneran exactamente igual.
- `resultados/`: `medias-por-n.csv` (5 filas), `histograma.csv` (6 filas), `convergencia.csv` (200
  puntos muestreados) y `ejemplo-salida.txt`. Se regeneran al ejecutar `simulador.py`; no hacen falta
  para verificar.

## Fuente real y licencia

- **No hay API ni fuente externa**: el proyecto es local por diseño y la ficha declara `api: []`. El
  dado es un modelo uniforme en {1, …, 6}; no se estima la probabilidad de ningún dado físico.
- Datos propios sintéticos y deterministas, generados por el proyecto: **CC0-1.0**.
- NumPy: **BSD-3-Clause**. matplotlib (opcional): **PSF/Matplotlib**.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Parámetros del dado | Un modelo con probabilidades conocidas se declara, no se estima | `Axiomas de probabilidad` |
| 2 · Semilla fija | Reproducibilidad: el generador y la semilla son parte del experimento | `Aleatoriedad y muestreo` |
| 3 · Media frente a 3,5 | La media muestral tiende al valor esperado, no lo garantiza | `Ley de los grandes números` |
| 4 · Error estándar | La diferencia se mide en unidades de σ/√n, no a ojo | `Varianza y desviación típica` |
| 5 · Convergencia con réplicas | La desviación de la media cae como 1/√n | `Simulación de Monte Carlo` |
| 6 · Histograma y recuentos | Que cada cara tenga lo que le toca, con recuentos que suman | `Precisión y error numérico` |
| 7 · Puerta offline | Recuentos, tolerancias y reproducibilidad como contrato | `Simulación de Monte Carlo` |

## Estructura

```text
codigo/
├── simulador.py            # parámetros, tiradas, tabla por n, convergencia, CSV y figuras
├── datos-ejemplo/          # parametros.json y la muestra de 1.000 tiradas (semilla 20261109)
├── verificar.py            # la puerta del proyecto (solo stdout, sin red)
└── resultados/             # ejemplo-salida.txt y los CSV generados
```

## Fallos típicos

- **`ModuleNotFoundError: numpy`**: instala con el mismo Python que ejecuta el script,
  `python -m pip install -r requirements.txt`.
- **La media no cambia entre ejecuciones**: se está usando `np.random.seed` o el generador global en vez
  de `np.random.default_rng(semilla)`; el resultado deja de depender de la semilla declarada.
- **El error estándar no baja en la tabla**: algún `n` está repetido o desordenado en el JSON; la tabla
  se construye con los tamaños declarados, en orden.
- **La muestra no coincide**: se regeneró con otra semilla o cambiando el tamaño de la tirada; la muestra
  son las primeras 1.000 tiradas de la misma simulación.
- **`FileNotFoundError` en `parametros.json`**: el script se lanza desde otra carpeta; usa `codigo/` como
  directorio de trabajo (el módulo resuelve las rutas desde su propio fichero, así que también funciona
  desde fuera, pero `datos-ejemplo/` tiene que existir).
- **`PermissionError` al guardar**: `resultados/` es una carpeta protegida; ejecuta desde `codigo/` o
  cambia la ruta de salida.
