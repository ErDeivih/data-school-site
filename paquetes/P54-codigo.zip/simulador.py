#!/usr/bin/env python3
"""P54 · Simulador de dados: 100.000 tiradas contra el valor esperado.

Proyecto completo de la ficha P54. Genera tiradas de un dado de seis caras con semilla fija, compara la
media con el valor esperado 3,5 y mide cómo la desviación de la media baja al crecer n. No usa red: el
dado es un modelo con probabilidades conocidas.

    python simulador.py                     # simula, imprime la tabla por n y guarda resultados/
    python simulador.py --figura            # además dibuja histograma y convergencia (matplotlib)
    python simulador.py --regenerar-muestra # reescribe datos-ejemplo/tiradas-muestra.csv

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"


def cargar_parametros() -> dict:
    # Paso 1 · Lee los parámetros del dado desde datos-ejemplo/parametros.json
    # Por qué: la semilla y el número de tiradas no se escriben en el código; así el experimento se
    #          cambia sin tocar la lógica y el resultado sigue siendo reproducible.
    # Salida esperada: las cinco claves cargadas sin error (justo después se imprime «dado: …»)
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o restaura datos-ejemplo/parametros.json.
    ruta = DATOS / "parametros.json"
    parametros = json.loads(ruta.read_text(encoding="utf-8"))
    faltan = [clave for clave in ("semilla", "caras", "tiradas", "tamanos", "muestra") if clave not in parametros]
    if faltan:
        raise RuntimeError(f"faltan claves en {ruta.name}: {', '.join(faltan)}")
    if int(parametros["caras"]) < 2:
        raise RuntimeError("un dado necesita al menos dos caras")
    if int(parametros["tiradas"]) < max(int(n) for n in parametros["tamanos"]):
        raise RuntimeError("«tiradas» debe cubrir el mayor tamaño de la tabla")
    return parametros


def valores_teoricos(caras: int) -> dict:
    """Valor esperado, varianza y desviación de un dado uniforme de 1 a `caras` (cuentas del modelo)."""
    esperado = (caras + 1) / 2.0
    varianza = (caras ** 2 - 1) / 12.0
    return {"esperado": esperado, "varianza": varianza, "desviacion": math.sqrt(varianza)}


def error_estandar(n: int, caras: int) -> float:
    """σ/√n: la vara con la que se mide la diferencia entre la media observada y el valor esperado."""
    return valores_teoricos(caras)["desviacion"] / math.sqrt(n)


def simular(parametros: dict) -> np.ndarray:
    # Paso 2 · Genera las tiradas con un generador de semilla fija
    # Por qué: default_rng(semilla) aísla el generador del estado global; la misma semilla devuelve
    #          exactamente las mismas tiradas aunque se ejecute otra vez.
    # Salida esperada: 100000 enteros entre 1 y 6 y una media en torno a 3,5
    # Si falla: TypeError → la semilla del JSON es texto y no un número entero.
    rng = np.random.default_rng(int(parametros["semilla"]))
    return rng.integers(1, int(parametros["caras"]) + 1, size=int(parametros["tiradas"]), dtype=np.int64)


def tabla_por_n(tiradas: np.ndarray, tamanos: list, caras: int) -> list:
    # Paso 3 · Compara la media con el valor esperado y con su error estándar
    # Por qué: una diferencia sin error no dice nada; σ/√n permite juzgar si la media está donde el
    #          modelo dice que debe estar, sin depender de un umbral inventado.
    # Salida esperada: una fila por tamaño, con media, diferencia y error estándar decreciente
    # Si falla: ValueError → algún tamaño de la tabla supera las tiradas generadas.
    teoria = valores_teoricos(caras)
    filas = []
    for n in tamanos:
        n = int(n)
        media = float(np.asarray(tiradas[:n], dtype=np.float64).mean())
        filas.append(
            {
                "n": n,
                "media": media,
                "diferencia": media - teoria["esperado"],
                "error_estandar": error_estandar(n, caras),
            }
        )
    return filas


def convergencia(tiradas: np.ndarray, caras: int, puntos: int = 200) -> dict:
    # Paso 4 · Calcula la media acumulada y su banda de ±2 errores estándar
    # Por qué: la convergencia se lee contra el error teórico; la banda se estrecha como 1/√n y la
    #          media acumulada debe quedarse dentro, no basta con que la línea parezca estabilizarse.
    # Salida esperada: 200 puntos con paso, media acumulada y banda inferior y superior
    # Si falla: ZeroDivisionError → no hay tiradas; revisa «tiradas» en el JSON.
    teoria = valores_teoricos(caras)
    pasos = np.arange(1, len(tiradas) + 1, dtype=np.int64)
    medias = np.cumsum(tiradas, dtype=np.float64) / pasos
    error = teoria["desviacion"] / np.sqrt(pasos)
    indices = np.unique(np.linspace(0, len(tiradas) - 1, min(puntos, len(tiradas)), dtype=int))
    return {
        "pasos": pasos[indices],
        "media": medias[indices],
        "banda_inferior": medias[indices] - 2.0 * error[indices],
        "banda_superior": medias[indices] + 2.0 * error[indices],
    }


def histograma(tiradas: np.ndarray, caras: int) -> list:
    """Recuento por cara: el histograma que debe sumar el número de tiradas."""
    cuentas = np.bincount(tiradas, minlength=caras + 1)[1:]
    return [int(c) for c in cuentas]


def ejecutar(parametros: dict) -> dict:
    """Simula y devuelve todas las piezas que la puerta necesita, imprimiendo el resumen de la corrida."""
    caras = int(parametros["caras"])
    semilla = int(parametros["semilla"])
    tiradas = simular(parametros)
    teoria = valores_teoricos(caras)
    media = float(tiradas.mean())
    tabla = tabla_por_n(tiradas, parametros["tamanos"], caras)
    curva = convergencia(tiradas, caras)
    cuentas = histograma(tiradas, caras)
    se = error_estandar(len(tiradas), caras)
    diferencia = media - teoria["esperado"]

    print(f"dado: {caras} caras · valor esperado {teoria['esperado']:.1f} · {len(tiradas)} tiradas · semilla {semilla}")
    print(f"media observada: {media:.5f} · diferencia {diferencia:+.5f} · error estandar teorico {se:.6f}")
    dentro = "si" if abs(diferencia) < 2.0 * se else "no"
    print(f"dentro de 2 errores estandar: {dentro} (|diferencia| = {abs(diferencia):.6f})")
    print("tabla por n: " + " · ".join(f"n={fila['n']}: {fila['media']:.5f}" for fila in tabla))
    print(f"histograma por cara: {cuentas} (suma {sum(cuentas)})")
    print(f"convergencia: error estandar {error_estandar(1000, caras):.6f} a n=1000 y {se:.6f} a n={len(tiradas)}")
    return {
        "tiradas": tiradas,
        "tabla": tabla,
        "convergencia": curva,
        "histograma": cuentas,
        "media": media,
        "diferencia": diferencia,
        "error_estandar": se,
        "esperado": teoria["esperado"],
    }


def guardar(resultados: dict, parametros: dict) -> None:
    # Paso 5 · Guarda los resultados en resultados/ como CSV reproducibles
    # Por qué: la curva se guarda muestreada (200 puntos), no las 100000 tiradas, para que el fichero
    #          sea pequeño; el dato bruto se regenera con la misma semilla cuando haga falta.
    # Salida esperada: "resultados: medias-por-n.csv, histograma.csv, convergencia.csv"
    # Si falla: PermissionError → la carpeta resultados/ no es escribible; ejecuta desde codigo/.
    RESULTADOS.mkdir(parents=True, exist_ok=True)
    with (RESULTADOS / "medias-por-n.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["n", "media", "diferencia", "error_estandar"])
        for fila in resultados["tabla"]:
            escritor.writerow(
                [fila["n"], f"{fila['media']:.6f}", f"{fila['diferencia']:+.6f}", f"{fila['error_estandar']:.6f}"]
            )
    with (RESULTADOS / "histograma.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["cara", "cuenta"])
        for cara, cuenta in enumerate(resultados["histograma"], start=1):
            escritor.writerow([cara, cuenta])
    curva = resultados["convergencia"]
    with (RESULTADOS / "convergencia.csv").open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["paso", "media_acumulada", "banda_inferior", "banda_superior"])
        for i in range(len(curva["pasos"])):
            escritor.writerow(
                [
                    int(curva["pasos"][i]),
                    f"{curva['media'][i]:.6f}",
                    f"{curva['banda_inferior'][i]:.6f}",
                    f"{curva['banda_superior'][i]:.6f}",
                ]
            )
    print("resultados: medias-por-n.csv, histograma.csv, convergencia.csv")


def escribir_muestra(parametros: dict) -> Path:
    # Paso 6 · Escribe la muestra de datos-ejemplo con la misma semilla del ejercicio
    # Por qué: la muestra no es un dato inventado: son las primeras tiradas de la simulación, así que
    #          la puerta puede comprobar que se regeneran exactamente igual.
    # Salida esperada: "muestra: datos-ejemplo/tiradas-muestra.csv (1000 tiradas)"
    # Si falla: PermissionError → datos-ejemplo/ tiene que existir y ser escribible.
    ruta = DATOS / "tiradas-muestra.csv"
    tiradas = simular(parametros)[: int(parametros["muestra"])]
    with ruta.open("w", encoding="utf-8", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["indice", "cara"])
        for indice, cara in enumerate(tiradas, start=1):
            escritor.writerow([indice, int(cara)])
    print(f"muestra: {ruta.relative_to(RAIZ).as_posix()} ({len(tiradas)} tiradas)")
    return ruta


def figura(resultados: dict, parametros: dict) -> None:
    # Paso 7 · Dibuja el histograma y la convergencia (opcional, necesita matplotlib)
    # Por qué: la figura es una comodidad para leer, no la prueba; el criterio se comprueba con números.
    # Salida esperada: resultados/histograma.png y resultados/convergencia.png
    # Si falla: ModuleNotFoundError de matplotlib → `python -m pip install matplotlib`.
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ModuleNotFoundError as exc:
        raise RuntimeError("para --figura hace falta matplotlib: python -m pip install matplotlib") from exc

    caras = int(parametros["caras"])
    fig, eje = plt.subplots(figsize=(6, 4))
    eje.bar(range(1, caras + 1), resultados["histograma"], color="#4c72b0")
    eje.axhline(len(resultados["tiradas"]) / caras, color="black", linestyle="--", linewidth=1)
    eje.set_xlabel("cara")
    eje.set_ylabel("cuentas")
    eje.set_title(f"Histograma · {len(resultados['tiradas'])} tiradas")
    fig.tight_layout()
    fig.savefig(RESULTADOS / "histograma.png", dpi=120)
    plt.close(fig)

    curva = resultados["convergencia"]
    fig, eje = plt.subplots(figsize=(7, 4))
    eje.plot(curva["pasos"], curva["media"], label="media acumulada", color="#4c72b0")
    eje.fill_between(curva["pasos"], curva["banda_inferior"], curva["banda_superior"], alpha=0.25, label="±2 errores estándar")
    eje.axhline(resultados["esperado"], color="black", linestyle="--", linewidth=1, label="valor esperado")
    eje.set_xscale("log")
    eje.set_xlabel("tiradas (n, escala log)")
    eje.set_ylabel("media")
    eje.set_title("Convergencia de la media a 3,5")
    eje.legend()
    fig.tight_layout()
    fig.savefig(RESULTADOS / "convergencia.png", dpi=120)
    plt.close(fig)
    print("figuras: histograma.png, convergencia.png")


def main(argv: list) -> int:
    try:
        parametros = cargar_parametros()
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    if "--regenerar-muestra" in argv:
        try:
            escribir_muestra(parametros)
        except OSError as exc:
            print(f"error: {exc}")
            return 1
        return 0
    print("== P54 · simulador de dados ==")
    resultados = ejecutar(parametros)
    try:
        guardar(resultados, parametros)
        if "--figura" in argv:
            figura(resultados, parametros)
    except (OSError, RuntimeError) as exc:
        print(f"error: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
