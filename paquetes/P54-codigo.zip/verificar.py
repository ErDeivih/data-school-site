#!/usr/bin/env python3
"""Puerta del proyecto P54 (simulador de dados).

Comprueba el resultado de verdad, sin escribir en disco y sin red: parámetros y semilla, muestra de
datos-ejemplo, media frente a 3,5 con su error estándar, histograma completo, la tabla por n y la caída
de la desviación de la media con réplicas (1/√n). Termina en RESULTADO: VERDE (código 0) o ROJO (1).

Uso:
    python verificar.py

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import csv
import sys

sys.dont_write_bytecode = True  # la puerta no escribe nada: ni resultados ni caché de bytecode

from pathlib import Path

import numpy as np

import simulador

fallos: list = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def leer_caras(ruta: Path) -> list:
    with ruta.open(encoding="utf-8", newline="") as f:
        return [int(fila["cara"]) for fila in csv.DictReader(f)]


def main() -> int:
    print("== Puerta del proyecto P54 · simulador de dados ==")

    # Paso 1 · Comprueba los parámetros declarados y la muestra de datos-ejemplo
    # Por qué: si la semilla no es la del ejercicio, el resto de comprobaciones no demuestra nada.
    # Salida esperada: "OK    parámetros: 6 caras · 100000 tiradas · semilla 20261109"
    # Si falla: RuntimeError de cargar_parametros → falta datos-ejemplo/parametros.json.
    parametros = simulador.cargar_parametros()
    ok(
        (int(parametros["semilla"]), int(parametros["caras"]), int(parametros["tiradas"])) == (20261109, 6, 100000),
        f"parámetros: {parametros['caras']} caras · {parametros['tiradas']} tiradas · semilla {parametros['semilla']}",
    )
    esperadas = int(parametros["muestra"])
    ruta_muestra = simulador.DATOS / "tiradas-muestra.csv"
    muestra = leer_caras(ruta_muestra) if ruta_muestra.exists() else []
    regeneradas = [int(c) for c in simulador.simular(parametros)[:esperadas]]
    ok(
        len(muestra) == esperadas and muestra == regeneradas,
        f"muestra: {len(muestra)} tiradas en datos-ejemplo/tiradas-muestra.csv y coinciden con la semilla",
    )

    # Paso 2 · Ejecuta la simulación principal y comprueba media, histograma y tabla por n
    # Por qué: se vuelve a calcular todo, no se lee un resultado guardado, para no dar por bueno un CSV.
    # Salida esperada: las líneas de la corrida y los OK de media, histograma y tabla.
    # Si falla: la media se sale de 3 errores estándar → revisa la semilla o el número de caras.
    resultados = simulador.ejecutar(parametros)
    se = resultados["error_estandar"]
    diferencia = resultados["diferencia"]
    ok(
        abs(diferencia) <= 3.0 * se,
        f"media frente a 3,5: |{diferencia:+.5f}| = {abs(diferencia) / se:.2f} errores estándar (<= 3)",
    )
    caras = int(parametros["caras"])
    tiradas = int(parametros["tiradas"])
    ok(
        len(resultados["histograma"]) == caras and sum(resultados["histograma"]) == tiradas,
        f"histograma: {len(resultados['histograma'])} caras y suma {sum(resultados['histograma'])} = {tiradas} tiradas",
    )
    minimo, maximo = min(resultados["histograma"]), max(resultados["histograma"])
    ok(
        minimo > 0 and maximo < 2 * tiradas / caras,
        f"histograma: la cara menos frecuente sale {minimo} veces y la más frecuente {maximo} (sin caras vacías ni dobladas)",
    )
    tabla = resultados["tabla"]
    ok(
        [fila["n"] for fila in tabla] == [int(n) for n in parametros["tamanos"]],
        f"tabla por n: {[fila['n'] for fila in tabla]}",
    )
    errores = [fila["error_estandar"] for fila in tabla]
    ok(
        all(errores[i] > errores[i + 1] for i in range(len(errores) - 1)),
        "tabla por n: el error estándar baja en cada fila",
    )
    ok(
        abs(tabla[-1]["diferencia"]) < 0.02,
        f"tabla por n: a n={tabla[-1]['n']} la diferencia es {tabla[-1]['diferencia']:+.5f} (< 0,02)",
    )

    # Paso 3 · Comprueba la convergencia de verdad: la desviación de la media baja como 1/√n
    # Por qué: una sola trayectoria no demuestra la ley de los grandes números; con réplicas se mide la
    #          dispersión de la media a n=1000 y a n=100000 y se compara con el cociente teórico 10.
    # Salida esperada: un cociente entre 8 y 12 (teórico sqrt(100) = 10).
    # Si falla: el cociente se aleja → las tiradas no son independientes o el tamaño no es el del JSON.
    rng = np.random.default_rng(int(parametros["semilla"]) + 1)
    replicas, n_corto, n_largo = 100, 1000, 100000
    medias_cortas, medias_largas = [], []
    for _ in range(replicas):
        tirada = rng.integers(1, caras + 1, size=n_largo, dtype=np.int64)
        medias_cortas.append(float(tirada[:n_corto].mean()))
        medias_largas.append(float(tirada.mean()))
    cociente = float(np.std(medias_cortas, ddof=1) / np.std(medias_largas, ddof=1))
    ok(
        8.0 <= cociente <= 12.0,
        f"convergencia: la desviación de la media cae por {cociente:.2f} al pasar de n=1000 a n=100000 (teórico 10)",
    )

    # Paso 4 · Comprueba la reproducibilidad y que otra semilla cambia el resultado
    # Por qué: la semilla es parte del contrato del ejercicio; repetir sin semilla no sería reproducible.
    # Salida esperada: las primeras 1000 tiradas se repiten exactas y cambian con otra semilla.
    # Si falla: np.array_equal falso → se está usando el generador global en vez de default_rng.
    primera = np.asarray(resultados["tiradas"][:1000])
    segunda = np.asarray(simulador.simular(parametros)[:1000])
    ok(np.array_equal(primera, segunda), "reproducibilidad: la misma semilla repite exactamente las primeras 1000 tiradas")
    otra = np.asarray(simulador.simular({**parametros, "semilla": int(parametros["semilla"]) + 1})[:1000])
    ok(
        not np.array_equal(primera, otra),
        "otra semilla: las primeras 1000 tiradas cambian (el experimento depende de la semilla)",
    )

    # Paso 5 · Comprueba que el código es offline y no lleva secretos
    # Por qué: la entrega se comparte y la puerta se ejecuta sin red; una URL o un token escondido lo rompe.
    # Salida esperada: "el código del proyecto no hace peticiones de red" y "no contiene claves".
    # Si falla: aparece un http(s) o un patrón de token en simulador.py → quítalo antes de empaquetar.
    fuente = (simulador.RAIZ / "simulador.py").read_text(encoding="utf-8")
    ok("http://" not in fuente and "https://" not in fuente, "el código del proyecto no hace peticiones de red")
    ok(
        not any(patron in fuente for patron in ("ghp_", "github_pat_", "Authorization:", "api_key")),
        "el código del proyecto no contiene claves ni cabeceras de autorización",
    )

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
