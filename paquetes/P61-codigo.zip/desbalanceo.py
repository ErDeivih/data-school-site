#!/usr/bin/env python3
"""P61 · Datos desbalanceados: el umbral es una decisión de negocio.

Código ejecutable del proyecto P61 (ruta ciencia). Recorre el trabajo completo sobre el CSV
sintético de transacciones: mide el desbalanceo, parte los datos de forma estratificada, entrena
un modelo, compara la exactitud con precisión, recall y PR-AUC, y elige el umbral por coste con
dos supuestos declarados (coste de un falso negativo y de un falso positivo).

Uso:
    python desbalanceo.py            # pipeline completo; escribe las tablas en resultados/
    python desbalanceo.py limpiar    # borra las tablas generadas y deja el proyecto como descargado

Datos: datos-ejemplo/transacciones-fraude.csv (3000 filas × 9 columnas, CC0-1.0; procedencia y
licencia en el README). Sin red: todo se calcula en local con numpy, pandas y scikit-learn.
"""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo" / "transacciones-fraude.csv"
RESULTADOS = RAIZ / "resultados"

SEMILLA = 20261105
TEST = 0.30
UMBRAL_DEFECTO = 0.50
COSTE_FN = 200.0  # supuesto: un fraude no detectado cuesta 200 EUR (reclamación + gestión)
COSTE_FP = 5.0    # supuesto: una revisión manual de un pago legítimo cuesta 5 EUR
UMBRALES = np.round(np.arange(0.01, 0.951, 0.01), 2)

NUMERICAS = ["importe_eur", "hora", "intentos_24h", "antiguedad_dias"]
CATEGORICAS = ["canal", "pais", "dispositivo"]
COLUMNAS = ["id", "importe_eur", "hora", "canal", "pais", "dispositivo",
            "intentos_24h", "antiguedad_dias", "fraude"]
GENERADOS = ["metricas.csv", "matriz-confusion.csv", "umbrales.csv", "sensibilidad.csv",
             "guion-pasada-uci.md"]


def exigir(condicion: bool, mensaje: str) -> None:
    """Aborta con un mensaje legible; el pipeline devuelve 1 y no deja resultados a medias."""
    if not condicion:
        raise RuntimeError(mensaje)


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def cargar() -> pd.DataFrame:
    # Paso 1 · Carga el CSV y comprueba el contrato de columnas y de identificador
    # Por qué: si el dato de ejemplo cambia (otra muestra, otra versión), las métricas dejan de ser
    #          comparables con la ficha; el contrato se comprueba antes de modelar, no después.
    # Salida esperada: "datos: 3000 filas × 9 columnas · id único · sha256 830cd8b8…"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o recupera el CSV de datos-ejemplo/.
    exigir(DATOS.exists(), f"no existe el dato de ejemplo: {DATOS}")
    df = pd.read_csv(DATOS)
    exigir(list(df.columns) == COLUMNAS, f"columnas inesperadas: {list(df.columns)}")
    exigir(len(df) == 3000, f"se esperaban 3000 filas y hay {len(df)}")
    exigir(df["id"].is_unique, "la columna id tiene duplicados")
    exigir(int(df.isna().sum().sum()) == 0, "el CSV trae valores nulos")
    huella = sha256(DATOS)
    print(f"datos: {len(df)} filas × {df.shape[1]} columnas · id único · sha256 {huella[:8]}…")
    return df


def medir_desbalanceo(df: pd.DataFrame) -> dict:
    # Paso 2 · Mide el desbalanceo y la línea base antes de entrenar nada
    # Por qué: con el 2,3 % de fraude, decir "nunca fraude" acierta el 97,7 %; sin esa referencia
    #          escrita, cualquier exactitud posterior parece buena.
    # Salida esperada: "desbalanceo: 69 fraudes de 3000 (2.30 %) · línea base acierta 97.70 %"
    # Si falla: recuento distinto de 69 → el CSV no es el de la ficha; no sigas con métricas.
    fraudes = int(df["fraude"].sum())
    total = len(df)
    prevalencia = fraudes / total
    exactitud_base = 1.0 - prevalencia
    print(f"desbalanceo: {fraudes} fraudes de {total} ({prevalencia * 100:.2f} %) · "
          f"línea base acierta {exactitud_base * 100:.2f} %")
    return {"fraudes": fraudes, "total": total, "prevalencia": prevalencia,
            "exactitud_base": exactitud_base}


def partir(df: pd.DataFrame) -> dict:
    # Paso 3 · Parte en train/test de forma estratificada y prepara la matriz del modelo
    # Por qué: con 69 positivos, una partición al azar puede dejar el test con cuatro fraudes o con
    #          ninguno; la estratificación fija la proporción y el recuento se publica.
    # Salida esperada: "partición: 2100 train / 900 test · positivos 48 y 21"
    # Si falla: "positivos 0 en test" → revisa stratify: es lo que evita ese caso.
    indices = np.arange(len(df))
    idx_tr, idx_te = train_test_split(indices, test_size=TEST, random_state=SEMILLA,
                                      stratify=df["fraude"])
    escalador = StandardScaler().fit(df.iloc[idx_tr][NUMERICAS])
    numericas = escalador.transform(df[NUMERICAS])
    dummies = pd.get_dummies(df[CATEGORICAS], dtype=float)
    X = np.hstack([numericas, dummies.to_numpy()])
    X_tr, X_te = X[idx_tr], X[idx_te]
    y_tr, y_te = df.iloc[idx_tr]["fraude"].to_numpy(int), df.iloc[idx_te]["fraude"].to_numpy(int)
    print(f"partición: {len(idx_tr)} train / {len(idx_te)} test · "
          f"positivos {int(y_tr.sum())} y {int(y_te.sum())}")
    return {"X_tr": X_tr, "X_te": X_te, "y_tr": y_tr, "y_te": y_te,
            "columnas": NUMERICAS + list(dummies.columns)}


def entrenar(particion: dict) -> np.ndarray:
    # Paso 4 · Entrena la regresión logística y devuelve la probabilidad de fraude en test
    # Por qué: el modelo es una caja blanca y determinista con semilla fija; lo que se evalúa no es
    #          su sofisticación, sino si las métricas y el umbral se leen bien.
    # Salida esperada: "modelo: 13 coeficientes · probabilidad media en test 0.0198"
    # Si falla: ConvergenceWarning → sube max_iter; el modelo no ha convergido y las probas no valen.
    modelo = LogisticRegression(max_iter=2000, random_state=SEMILLA)
    modelo.fit(particion["X_tr"], particion["y_tr"])
    proba = modelo.predict_proba(particion["X_te"])[:, 1]
    print(f"modelo: {modelo.coef_.size} coeficientes · probabilidad media en test {proba.mean():.4f}")
    return proba


def evaluar(particion: dict, proba: np.ndarray) -> dict:
    # Paso 5 · Mide la matriz de confusión y las métricas a umbral 0,5
    # Por qué: la exactitud sola esconde el fallo; precisión, recall y PR-AUC se calculan juntos
    #          para que la tabla deje ver qué se detecta y qué se cuela.
    # Salida esperada: "umbral 0,50: TP 2 · FP 1 · FN 19 · TN 878 · precisión 0.667 · recall 0.095 ·
    #                   F1 0.167 · PR-AUC 0.378 · ROC-AUC 0.937"
    # Si falla: matriz que no suma 900 → la partición está mal; recuenta y_te.
    y = particion["y_te"]
    pred = (proba >= UMBRAL_DEFECTO).astype(int)
    tp = int(((pred == 1) & (y == 1)).sum())
    fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum())
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    pr_auc = float(average_precision_score(y, proba))
    roc_auc = float(roc_auc_score(y, proba))
    print(f"umbral 0,50: TP {tp} · FP {fp} · FN {fn} · TN {tn} · precisión {precision:.3f} · "
          f"recall {recall:.3f} · F1 {f1:.3f} · PR-AUC {pr_auc:.3f} · ROC-AUC {roc_auc:.3f}")
    return {"tp": tp, "fp": fp, "fn": fn, "tn": tn, "precision": precision, "recall": recall,
            "f1": f1, "pr_auc": pr_auc, "roc_auc": roc_auc}


def barrer_umbrales(particion: dict, proba: np.ndarray, coste_fn: float, coste_fp: float,
                    verbose: bool = True) -> pd.DataFrame:
    # Paso 6 · Barre umbrales y calcula el coste esperado de cada corte
    # Por qué: el umbral no es un parámetro técnico, es una decisión de negocio; su valor sale de
    #          minimizar FN·coste_FN + FP·coste_FP, no de dejar 0,5 porque es el defecto.
    # Salida esperada: "coste: umbral 0.03 cuesta 1005.00 EUR · el 0.50 cuesta 3805.00 EUR"
    # Si falla: todos los costes iguales → el umbral no mueve predicciones; mira proba.
    y = particion["y_te"]
    filas = []
    for umbral in UMBRALES:
        pred = (proba >= umbral).astype(int)
        tp = int(((pred == 1) & (y == 1)).sum())
        fp = int(((pred == 1) & (y == 0)).sum())
        fn = int(((pred == 0) & (y == 1)).sum())
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        filas.append({"umbral": float(umbral), "tp": tp, "fp": fp, "fn": fn,
                      "precision": round(precision, 4), "recall": round(recall, 4),
                      "coste_eur": round(fn * coste_fn + fp * coste_fp, 2)})
    tabla = pd.DataFrame(filas)
    mejor = tabla.loc[tabla["coste_eur"].idxmin()]
    peor = tabla.loc[tabla["umbral"].sub(UMBRAL_DEFECTO).abs().idxmin()]
    if verbose:
        print(f"coste: umbral {mejor['umbral']:.2f} cuesta {mejor['coste_eur']:.2f} EUR "
              f"· el 0.50 cuesta {peor['coste_eur']:.2f} EUR")
    return tabla


def sensibilidad(particion: dict, proba: np.ndarray) -> dict:
    # Paso 7 · Repite el barrido duplicando el coste de un falso negativo
    # Por qué: los costes son un supuesto; si el umbral óptimo salta mucho al mover el supuesto, la
    #          decisión depende de una cifra que no está en el CSV y el informe tiene que decirlo.
    # Salida esperada: "sensibilidad: con coste_FN 400 EUR el umbral elegido es 0.02 y cuesta 2100.00 EUR"
    # Si falla: no cambia nada → el modelo está saturado en los extremos; revisa las probabilidades.
    tabla = barrer_umbrales(particion, proba, COSTE_FN * 2, COSTE_FP, verbose=False)
    mejor = tabla.loc[tabla["coste_eur"].idxmin()]
    print(f"sensibilidad: con coste_FN {COSTE_FN * 2:.0f} EUR el umbral elegido es "
          f"{mejor['umbral']:.2f} y cuesta {mejor['coste_eur']:.2f} EUR")
    return {"umbral": float(mejor["umbral"]), "coste_eur": float(mejor["coste_eur"])}


def escribir(base: dict, met: dict, tabla: pd.DataFrame) -> None:
    # Paso 8 · Escribe las tablas del proyecto y el guion de la pasada real
    # Por qué: el entregable es un informe con números reproducibles; cada cifra del README sale de
    #          estos CSV, no de una captura de pantalla.
    # Salida esperada: "resultados: metricas.csv, matriz-confusion.csv, umbrales.csv,
    #                   sensibilidad.csv, guion-pasada-uci.md"
    # Si falla: PermissionError → la carpeta resultados/ no se puede escribir; revisa permisos.
    RESULTADOS.mkdir(exist_ok=True)
    pd.DataFrame([
        {"metrica": "exactitud_linea_base", "valor": round(base["exactitud_base"], 4)},
        {"metrica": "prevalencia", "valor": round(base["prevalencia"], 4)},
        {"metrica": "precision_umbral_0_50", "valor": round(met["precision"], 4)},
        {"metrica": "recall_umbral_0_50", "valor": round(met["recall"], 4)},
        {"metrica": "f1_umbral_0_50", "valor": round(met["f1"], 4)},
        {"metrica": "pr_auc", "valor": round(met["pr_auc"], 4)},
        {"metrica": "roc_auc", "valor": round(met["roc_auc"], 4)},
    ]).to_csv(RESULTADOS / "metricas.csv", index=False)
    pd.DataFrame([{"tp": met["tp"], "fp": met["fp"], "fn": met["fn"], "tn": met["tn"]}]).to_csv(
        RESULTADOS / "matriz-confusion.csv", index=False)
    tabla.to_csv(RESULTADOS / "umbrales.csv", index=False)
    mejor = tabla.loc[tabla["coste_eur"].idxmin()]
    pd.DataFrame([{"coste_fn_eur": COSTE_FN, "coste_fp_eur": COSTE_FP,
                   "umbral_elegido": float(mejor["umbral"]),
                   "coste_elegido_eur": float(mejor["coste_eur"])}]).to_csv(
        RESULTADOS / "sensibilidad.csv", index=False)
    (RESULTADOS / "guion-pasada-uci.md").write_text(
        "# Guion de la pasada real (fuera del repositorio)\n\n"
        "1. Descarga el conjunto de UCI «Default of Credit Card Clients» (id 350, CC BY 4.0).\n"
        "2. Misma limpieza: tipar, separar la etiqueta y comprobar la prevalencia (no es la del CSV local).\n"
        "3. Mismo modelo y misma partición estratificada; el umbral se recalcula con esta prevalencia.\n"
        "4. No se sube el CSV real al repositorio: licencia y tamaño se citan en el README.\n",
        encoding="utf-8")
    print("resultados: metricas.csv, matriz-confusion.csv, umbrales.csv, sensibilidad.csv, "
          "guion-pasada-uci.md")


def limpiar() -> None:
    # Paso 9 · Borra las tablas generadas y deja el proyecto como descargado
    # Por qué: el ZIP no lleva resultados derivados; se reproducen con `python desbalanceo.py`.
    # Salida esperada: "limpiar: resultados/ generados borrados"
    # Si falla: PermissionError → cierra el programa que tenga abierto un CSV de resultados/.
    for nombre in GENERADOS:
        (RESULTADOS / nombre).unlink(missing_ok=True)
    print("limpiar: resultados/ generados borrados")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Métricas en datos desbalanceados (P61)")
    parser.add_argument("accion", nargs="?", default="todo", choices=["todo", "limpiar"])
    args = parser.parse_args(argv)
    if args.accion == "limpiar":
        limpiar()
        return 0
    try:
        df = cargar()
        base = medir_desbalanceo(df)
        particion = partir(df)
        proba = entrenar(particion)
        met = evaluar(particion, proba)
        tabla = barrer_umbrales(particion, proba, COSTE_FN, COSTE_FP)
        sensibilidad(particion, proba)
        escribir(base, met, tabla)
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con resultados a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
