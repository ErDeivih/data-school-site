# P61 · Datos desbalanceados: el umbral es una decisión de negocio — código ejecutable

El proyecto completo sobre el CSV sintético de 3000 pagos con un 2,3 % de fraude: se mide el
desbalanceo, se parte en train/test de forma estratificada, se entrena una regresión logística, se
compara la exactitud con precisión, recall y PR-AUC y se **elige el umbral minimizando el coste
esperado** `FN·200 € + FP·5 €`, con los dos costes declarados como supuesto. Es el código que
acompaña a la ficha
`../../fichas-ideas/p61-metricas-en-datos-desbalanceados.md`.

El resultado que enseña el proyecto: a umbral 0,50 el modelo acierta el 99,7 % de los pagos y **detecta
2 de los 21 fraudes del test** (recall 0,095); a umbral 0,04 detecta 18 de 21 (recall 0,857) con 87
falsos positivos y el coste baja de 3805 € a 1035 €. La exactitud apenas cambia; la decisión, sí.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **numpy**, **pandas** y **scikit-learn** (probados con 2.5.2, 3.0.6 y 1.9.1). Se instalan en un
  comando.
- Windows, Linux o macOS. No hace falta red ni servicios externos: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p61-metricas-en-datos-desbalanceados/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide `numpy`, `pandas` y `scikit-learn`. Licencias: numpy y pandas son BSD-3-Clause;
scikit-learn es BSD-3-Clause.

## Orden de ejecución

El pipeline hace los ocho pasos en orden y escribe sus tablas en `resultados/`:

```powershell
python desbalanceo.py          # pipeline completo: carga, línea base, modelo, umbral y tablas
python desbalanceo.py limpiar  # borra las tablas generadas y deja la carpeta como se descargó
```

La salida esperada de una ejecución (recortada) es esta:

```text
datos: 3000 filas × 9 columnas · id único · sha256 830cd8b8…
desbalanceo: 69 fraudes de 3000 (2.30 %) · línea base acierta 97.70 %
partición: 2100 train / 900 test · positivos 48 y 21
modelo: 13 coeficientes · probabilidad media en test 0.0198
umbral 0,50: TP 2 · FP 1 · FN 19 · TN 878 · precisión 0.667 · recall 0.095 · F1 0.167 · PR-AUC 0.378 · ROC-AUC 0.937
coste: umbral 0.04 cuesta 1035.00 EUR · el 0.50 cuesta 3805.00 EUR
sensibilidad: con coste_FN 400 EUR el umbral elegido es 0.01 y cuesta 1450.00 EUR
resultados: metricas.csv, matriz-confusion.csv, umbrales.csv, sensibilidad.csv, guion-pasada-uci.md
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta no mira que los ficheros existan: recalcula el desbalanceo, la partición, la matriz de
confusión y las métricas; comprueba que la precisión y el recall publicados cuadran con la matriz, que
el umbral elegido no cuesta más que el 0,5, que al duplicar el coste del falso negativo el umbral no
sube y que dos ajustes con la misma semilla dan las mismas probabilidades. No usa red y no escribe
nada. Termina en `RESULTADO: VERDE` (código 0) con **21 comprobaciones**; la salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- [`datos-ejemplo/transacciones-fraude.csv`](datos-ejemplo/transacciones-fraude.csv): **3000 filas ×
  9 columnas** (`id`, `importe_eur`, `hora`, `canal`, `pais`, `dispositivo`, `intentos_24h`,
  `antiguedad_dias`, `fraude`). 69 fraudes (2,3 %); `id` único; sin nulos.
- sha256 del fichero:
  `830cd8b8e2abf8479702530665490dbe2821dc674403471c3b35c25ee838b2a7`. Es copia literal del conjunto
  de práctica del portal del temario (misma compilación que cita la ficha del dataset), sintético,
  semilla fija y licencia **CC0-1.0**: no son transacciones reales ni hay clientes detrás.

Basta con ese CSV: el proyecto se ejecuta sin descargar nada. Para usar datos propios, se copian en
`datos-ejemplo/` con las mismas columnas o se edita la constante `DATOS` de `desbalanceo.py`.

## Fuente real y licencia

- El catálogo no asigna API a este proyecto (`api: []`): la pasada real es una **descarga**, no una
  API, y no se ejecuta aquí.
- El conjunto real de la ficha es **UCI · Default of Credit Card Clients** (id 350), licencia
  **CC BY 4.0**, 30 000 filas × 23 columnas, fichero de 5,3 MB:
  <https://archive.ics.uci.edu/dataset/350/default+of+credit+card+clients>. Es morosidad de tarjeta,
  no fraude: la prevalencia no es la del CSV local y el umbral se recalcula.
- El conjunto de **fraude** de tarjetas de referencia (~144 MB) está en Kaggle, del grupo de ULB
  (<https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud>); su licencia es la que declare esa
  página y **no** es CC BY 4.0. Ninguno de los dos viaja en el repositorio.
- `resultados/guion-pasada-uci.md` deja escrito el guion de esa pasada.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y validar | Contrato de columnas y de `id` antes de modelar | Pandas: fundamentos |
| 2 · Medir el desbalanceo | Qué es una línea base y por qué la exactitud engaña | Desbalanceo de clases |
| 3 · Partición estratificada | Repartir sin romper la proporción de la clase rara | Validación cruzada |
| 4 · Entrenar el modelo | Modelo determinista con semilla y probabilidad calibrada | Métricas de clasificación |
| 5 · Matriz y métricas | Precisión, recall y matriz de confusión que cuadran | Matriz de confusión |
| 6 · PR-AUC frente a ROC | Qué curva ordena mejor con clases desbalanceadas | Precisión, recall y PR |
| 7 · Umbral por coste | Convertir dos costes supuestos en un corte decidido | Umbrales y coste |
| 8 · Verificador offline | Comprobar con tolerancias y reproducir sin red | Precisión y error numérico |

## Estructura

```text
codigo/
├── desbalanceo.py        # pipeline: carga, línea base, modelo, métricas, umbral, tablas
├── verificar.py          # la puerta del proyecto (21 comprobaciones, sin red, sin escribir)
├── requirements.txt      # numpy, pandas, scikit-learn
├── datos-ejemplo/
│   └── transacciones-fraude.csv   # 3000 × 9 · CC0-1.0
└── resultados/
    └── ejemplo-salida.txt         # salida real de `python verificar.py`
```

Las tablas que escribe `python desbalanceo.py` (`metricas.csv`, `matriz-confusion.csv`,
`umbrales.csv`, `sensibilidad.csv`, `guion-pasada-uci.md`) no viajan en el ZIP: se regeneran.

## Fallos típicos

- **`ModuleNotFoundError: sklearn`**: las dependencias no están instaladas o están en otro Python;
  ejecuta `python -m pip install -r requirements.txt` con el mismo intérprete.
- **`FALLO: columnas inesperadas`**: el CSV de `datos-ejemplo/` no es el del catálogo; compara el
  sha256 con el del README y vuelve a copiarlo.
- **`FALLO: se esperaban 3000 filas`**: has sustituido el CSV por una muestra propia; el verifier está
  atado al dato de ejemplo, no a tu fichero.
- **ConvergenceWarning de la regresión**: sube `max_iter` o escala las variables; con este CSV no
  aparece, y si aparece las probabilidades no son fiables.
- **El umbral elegido es 0,01 o 0,95**: con solo 21 positivos, un barrido que toca el borde indica que
  el modelo no separa más; revisa las métricas antes de presentar el corte.
