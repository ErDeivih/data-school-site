#!/usr/bin/env python3
"""Puerta del proyecto P61 (métricas en datos desbalanceados).

Comprueba el resultado de verdad, sin escribir nada y sin red: el CSV de ejemplo es el que dice el
README (sha256), el desbalanceo es el de la ficha (69 de 3000), la partición es estratificada, la
matriz de confusión cuadra con el test, las métricas son coherentes entre sí, el umbral elegido por
coste no es peor que el 0,5 y el modelo es determinista con la semilla fija.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

import desbalanceo as p

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P61 · datos desbalanceados y umbral por coste ==")

    # Paso 1 · Comprueba el dato de ejemplo antes de calcular ninguna métrica
    # Por qué: la mitad de los fallos de un informe vienen de un CSV distinto al que se cita; la
    #          huella del fichero se comprueba, no se supone.
    # Salida esperada: "datos: 3000 filas × 9 columnas · id único · sha256 830cd8b8…"
    # Si falla: FileNotFoundError → falta datos-ejemplo/transacciones-fraude.csv (el ZIP lo trae).
    df = p.cargar()
    ok(len(df) == 3000 and df.shape[1] == 9, f"CSV: {len(df)} filas × {df.shape[1]} columnas")
    ok(p.sha256(p.DATOS) == "830cd8b8e2abf8479702530665490dbe2821dc674403471c3b35c25ee838b2a7",
       "el sha256 del CSV de ejemplo es el de la copia del catálogo")

    # Paso 2 · Mide el desbalanceo y deja escrita la línea base
    # Por qué: sin la línea base, la exactitud del modelo no dice si aporta algo; con 69 positivos, la
    #          referencia trivial acierta el 97,7 %.
    # Salida esperada: "desbalanceo: 69 fraudes de 3000 (2,30 %) · línea base acierta 97,70 %"
    # Si falla: recuento distinto de 69 → el CSV no es el de la ficha.
    base = p.medir_desbalanceo(df)
    ok(base["fraudes"] == 69, f"fraudes: {base['fraudes']} (deben ser 69)")
    ok(abs(base["prevalencia"] - 69 / 3000) < 1e-12, f"prevalencia: {base['prevalencia']:.6f}")
    ok(abs(base["exactitud_base"] - 0.977) < 1e-12, f"línea base: {base['exactitud_base']:.4f}")

    # Paso 3 · Comprueba la partición estratificada
    # Por qué: una partición al azar con 69 positivos puede dejar el test sin fraudes; la
    #          estratificación es lo que hace que recall y PR-AUC signifiquen algo.
    # Salida esperada: "partición: 2100 train / 900 test · positivos 48 y 21"
    # Si falla: positivos 0 en test → falta stratify en train_test_split.
    particion = p.partir(df)
    ok(len(particion["y_tr"]) == 2100 and len(particion["y_te"]) == 900,
       f"partición: {len(particion['y_tr'])} train / {len(particion['y_te'])} test")
    ok(int(particion["y_tr"].sum()) == 48 and int(particion["y_te"].sum()) == 21,
       f"positivos: {int(particion['y_tr'].sum())} train / {int(particion['y_te'].sum())} test")

    # Paso 4 · Entrena y comprueba que las métricas y la matriz cuadran entre sí
    # Por qué: se recalcula la matriz desde las probabilidades y se compara con las métricas
    #          publicadas; si el informe dice recall 0,85 y la matriz dice otra cosa, no vale.
    # Salida esperada: "umbral 0,50: TP 18 · FP 12 · FN 3 · TN 867 · precisión … · recall …"
    # Si falla: la matriz no suma 900 → el test y las probabilidades no son el mismo conjunto.
    proba = p.entrenar(particion)
    met = p.evaluar(particion, proba)
    y = particion["y_te"]
    matriz = met["tp"] + met["fp"] + met["fn"] + met["tn"]
    ok(matriz == 900, f"matriz de confusión: suma {matriz} (debe ser 900)")
    ok(met["tp"] + met["fn"] == int(y.sum()), "los positivos de la matriz son los del test")
    ok(abs(met["precision"] - met["tp"] / (met["tp"] + met["fp"])) < 1e-12,
       f"precisión coherente con la matriz: {met['precision']:.3f}")
    ok(abs(met["recall"] - met["tp"] / (met["tp"] + met["fn"])) < 1e-12,
       f"recall coherente con la matriz: {met['recall']:.3f}")
    ok(0.0 < met["pr_auc"] <= 1.0 and 0.0 < met["roc_auc"] <= 1.0,
       f"PR-AUC {met['pr_auc']:.3f} y ROC-AUC {met['roc_auc']:.3f} en (0, 1]")
    ok(met["pr_auc"] > base["prevalencia"] * 2,
       f"el PR-AUC ({met['pr_auc']:.3f}) supera dos veces la prevalencia ({base['prevalencia']:.3f})")

    # Paso 5 · Comprueba el umbral elegido por coste
    # Por qué: el criterio de la ficha es que el umbral salga de minimizar el coste esperado, no de
    #          dejarlo en 0,5; la comprobación compara los dos costes con la misma tabla.
    # Salida esperada: "coste: umbral 0.04 cuesta 1035.00 EUR · el 0.50 cuesta 3805.00 EUR"
    # Si falla: el umbral elegido cuesta más que 0,50 → el barrido o los costes están mal.
    tabla = p.barrer_umbrales(particion, proba, p.COSTE_FN, p.COSTE_FP)
    ok(tabla["umbral"].between(0.01, 0.95).all(), "el barrido cubre de 0,01 a 0,95")
    ok(len(tabla) == 95, f"el barrido tiene {len(tabla)} cortes")
    mejor = tabla.loc[tabla["coste_eur"].idxmin()]
    coste_050 = float(tabla.loc[tabla["umbral"].sub(0.50).abs().idxmin(), "coste_eur"])
    ok(mejor["coste_eur"] <= coste_050,
       f"umbral {mejor['umbral']:.2f} cuesta {mejor['coste_eur']:.2f} EUR y el 0,50 cuesta {coste_050:.2f} EUR")
    ok(mejor["umbral"] != 0.50, f"el umbral elegido ({mejor['umbral']:.2f}) no es el defecto")

    # Paso 6 · Comprueba la sensibilidad y el determinismo del modelo
    # Por qué: los costes son un supuesto y la semilla fija es lo que permite reproducir la cifra;
    #          sin determinismo, el umbral cambia entre ejecuciones y no se puede auditar.
    # Salida esperada: "sensibilidad: con coste_FN 400 EUR el umbral elegido es 0.01 y cuesta 1450.00 EUR"
    # Si falla: dos ajustes dan probabilidades distintas → revisa random_state y el solver.
    sens = p.sensibilidad(particion, proba)
    ok(sens["umbral"] <= mejor["umbral"],
       f"al duplicar el coste del falso negativo el umbral no sube: {sens['umbral']:.2f} <= {mejor['umbral']:.2f}")
    proba2 = p.entrenar(particion)
    ok(np.array_equal(proba, proba2), "dos ajustes con la misma semilla dan las mismas probabilidades")

    # Paso 7 · Comprueba que la puerta es offline y la entrega no lleva secretos
    # Por qué: verificar.py se ejecuta sin red y la carpeta se comparte; una llamada de red escondida
    #          o un token romperían esa promesa.
    # Salida esperada: "código offline, sin claves"
    # Si falla: aparece http(s) o un patrón de token en los .py → quítalo antes de empaquetar.
    fuentes = [p.RAIZ / "desbalanceo.py"]
    texto = "\n".join(ruta.read_text(encoding="utf-8") for ruta in fuentes)
    ok(not any(x in texto for x in ("import requests", "import urllib", "import socket",
                                    "http://", "https://")),
       "el código no hace peticiones de red")
    ok(not any(x in texto for x in ("ghp_", "github_pat_", "Authorization:")),
       "el código no contiene claves ni cabeceras de autorización")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
