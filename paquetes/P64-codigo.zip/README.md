# P64 · Fútbol: probabilidad de victoria y Monte Carlo del torneo — código ejecutable

El proyecto completo sobre el CSV sintético de 380 partidos: estima la fuerza de ataque y defensa de
los veinte equipos, traduce cada emparejamiento a `P(1)`, `P(X)` y `P(2)` con dos Poisson, calcula la
**probabilidad de campeón** de cada equipo con una DP exacta sobre un cuadro declarado y la contrasta
con **10.000 torneos de Monte Carlo** con semilla fija. Es el código que acompaña a la ficha
`../../fichas-ideas/p64-futbol-probabilidad-y-monte-carlo.md`.

El resultado que enseña el proyecto: las tres probabilidades de cada partido suman 1 con error
4,4·10⁻¹⁶ (380 pares), la tabla analítica de campeón suma 1,000000 y las frecuencias de 10.000
torneos se separan del modelo como mucho **0,0031** (dentro del margen de Monte Carlo). Y una lectura
incómoda que se publica: el modelo apenas mejora la línea base (log loss 1,065 frente a 1,077),
porque la parrilla repite veinte cruces y no da para más.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **numpy** y **pandas** (probados con 2.5.2 y 3.0.6). Se instalan en un comando.
- Windows, Linux o macOS. No hace falta red: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p64-futbol-probabilidad-y-monte-carlo/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide `numpy` y `pandas`. Licencias: numpy BSD-3-Clause; pandas BSD-3-Clause.

## Orden de ejecución

```powershell
python torneo.py          # cargas, parrilla, fuerzas, probabilidades, cuadro, Monte Carlo y tablas
python torneo.py limpiar  # borra las tablas generadas y deja la carpeta como se descargó
```

La salida esperada de una ejecución es esta:

```text
datos: 380 filas × 12 columnas · 38 jornadas × 10 partidos · 20 equipos · sha256 5cbc8977…
parrilla: 20 emparejamientos × 19 repeticiones · 16 equipos por jornada (4 juegan dos veces)
resultado derivado de los goles en 380/380 filas
fuerzas: 20 equipos · goles por equipo y partido 0.9434 · ataque 0.391–1.618 · defensa 0.558–1.618
probabilidades: 380 pares · suma por partido con error máximo 4.4e-16
evaluación (jornadas 31–38, 80 partidos): log loss base 1.077 · modelo 1.065 · Brier base 0.653 · modelo 0.645
cuadro: 16 equipos sembrados · fuera: equipo-12, equipo-19, equipo-20, equipo-18
campeón (analítico): 16 equipos con probabilidad · suma 1.000000
monte carlo: 10000 torneos con semilla 20261105 · total de frecuencias 10000
resultados: fuerzas.csv, probabilidades-campeon.csv, frecuencias.csv, comparacion.csv, metricas.csv, cuadro.md
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula la parrilla, las fuerzas, las probabilidades, la tabla de campeón y el Monte
Carlo; comprueba que el reparto de cada partido suma 1, que la tabla analítica suma 1 con los cuatro
equipos fuera a cero, que el total de frecuencias es 10.000, que la diferencia con el modelo cabe en
3σ y que la misma semilla reproduce la misma salida. No usa red y no escribe nada. Termina en
`RESULTADO: VERDE` (código 0) con **23 comprobaciones**; la salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- [`datos-ejemplo/futbol-partidos.csv`](datos-ejemplo/futbol-partidos.csv): **380 filas × 12 columnas**
  (`jornada`, `local`, `visitante`, `goles_local`, `goles_visitante`, `tiros_local`,
  `tiros_visitante`, `xg_local`, `xg_visitante`, `posesion_local`, `amarillas`, `resultado`).
  38 jornadas × 10 partidos; 20 equipos; 20 emparejamientos distintos repetidos 19 veces.
- sha256 del fichero:
  `5cbc8977b6c9d4f7ae66bfcc7642c93a6655faf7b6e6524a6d40480e2e66a12e`. Es copia literal de
  `datasets/csv/futbol-partidos.csv` del repositorio (manifiesto `datasets/datasets.json`),
  sintético, semilla fija y licencia **CC0-1.0**.

Basta con ese CSV: el proyecto se ejecuta sin descargar nada. Para usar datos propios, se copian en
`datos-ejemplo/` con las mismas columnas o se edita la constante `DATOS` de `torneo.py`.

## Fuente real y licencia

- El catálogo asigna **StatsBomb Open Data** (<https://github.com/statsbomb/open-data>) como contraste
  de datos de fútbol: eventos liberados para investigación y análisis con atribución a StatsBomb y su
  logo. El repositorio **no declara licencia SPDX** (`Other`/`NOASSERTION`), así que no se
  redistribuye el crudo ni se usa comercialmente sin permiso; el código no lo descarga.
- El CSV es sintético: los goles, el xG y el cuadro no son de ninguna competición real. El Monte
  Carlo es una simulación sobre un modelo, no un pronóstico.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y validar | Claves y recuentos de una tabla de partidos | Pandas: fundamentos |
| 2 · Auditar la parrilla | Repetición de emparejamientos y pseudo-réplica | Pandas: agrupaciones y joins |
| 3 · Estimar fuerzas | Ataque y defensa como cocientes contra la media | Estimadores y propiedades |
| 4 · Probabilidades del partido | Dos Poisson y un reparto que suma 1 | Distribuciones discretas |
| 5 · Evaluar con línea base | Log loss y Brier contra frecuencias | Métricas de clasificación |
| 6 · Cuadro y DP exacta | Probabilidad condicional sobre un cuadro declarado | Probabilidad condicional |
| 7 · Monte Carlo | Simular 10.000 torneos y contar campeones | Simulación de Monte Carlo |
| 8 · Semilla y cuadre | Reproducibilidad y margen de Monte Carlo | Aleatoriedad y muestreo |

## Estructura

```text
codigo/
├── torneo.py             # pipeline: fuerzas, probabilidades, cuadro, DP y Monte Carlo
├── verificar.py          # la puerta del proyecto (23 comprobaciones, sin red, sin escribir)
├── requirements.txt      # numpy, pandas
├── datos-ejemplo/
│   └── futbol-partidos.csv   # 380 × 12 · CC0-1.0
└── resultados/
    └── ejemplo-salida.txt
```

Las tablas que escribe `python torneo.py` (`fuerzas.csv`, `probabilidades-campeon.csv`,
`frecuencias.csv`, `comparacion.csv`, `metricas.csv`, `cuadro.md`) no viajan en el ZIP: se regeneran.

## Fallos típicos

- **`ModuleNotFoundError: pandas`**: instala con `python -m pip install -r requirements.txt` con el
  mismo intérprete que lanza el pipeline.
- **Las probabilidades no suman 1**: la PMF de Poisson tiene que truncarse y renormalizarse; con
  `MAX_GOLES = 10` la cola es despreciable y la suma queda en 4·10⁻¹⁶.
- **Conclusiones de una sola simulación**: 10.000 torneos con semilla; una tirada no da frecuencias y
  no se puede comparar con el modelo.
- **Cambiar el cuadro según el resultado**: el cuadro se fija antes de simular (16 por rating, siembra
  clásica) y está escrito en `resultados/cuadro.md`.
- **Confundir simulación con pronóstico**: el modelo no ve lesiones, forma ni azar real; el xG del CSV
  no es una probabilidad de resultado.
