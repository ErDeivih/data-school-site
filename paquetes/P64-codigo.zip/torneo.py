#!/usr/bin/env python3
"""P64 · Fútbol: probabilidad de victoria y Monte Carlo del torneo.

Código ejecutable del proyecto P64 (ruta ciencia). Estima la fuerza de ataque y defensa de los veinte
equipos con los goles del CSV, traduce cada emparejamiento a tres probabilidades que suman 1, calcula
la probabilidad de campeón de cada equipo en un cuadro declarado con una DP exacta sobre el cuadro, y
la contrasta con 10.000 simulaciones de Monte Carlo con semilla fija.

Uso:
    python torneo.py            # pipeline completo; escribe las tablas en resultados/
    python torneo.py limpiar    # borra las tablas generadas y deja el proyecto como descargado

Datos: datos-ejemplo/futbol-partidos.csv (380 filas × 12 columnas, CC0-1.0; procedencia en el README).
Sin red: solo numpy y pandas.
"""
from __future__ import annotations

import argparse
import hashlib
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo" / "futbol-partidos.csv"
RESULTADOS = RAIZ / "resultados"

SEMILLA = 20261105
SIMULACIONES = 10_000
CUADRO = 16          # equipos que entran en el cuadro; los cuatro peores quedan fuera
MAX_GOLES = 10       # truncado del Poisson; la cola se renormaliza
COLUMNAS = ["jornada", "local", "visitante", "goles_local", "goles_visitante", "tiros_local",
            "tiros_visitante", "xg_local", "xg_visitante", "posesion_local", "amarillas", "resultado"]
# Orden de siembra clásico de un cuadro de 16: 1-16, 8-9, 5-12, 4-13, 6-11, 3-14, 7-10, 2-15.
ORDEN_SIEMBRA = [1, 16, 8, 9, 5, 12, 4, 13, 6, 11, 3, 14, 7, 10, 2, 15]
GENERADOS = ["fuerzas.csv", "probabilidades-campeon.csv", "frecuencias.csv", "comparacion.csv",
             "metricas.csv", "cuadro.md"]


def exigir(condicion: bool, mensaje: str) -> None:
    """Aborta con un mensaje legible; el pipeline devuelve 1 y no deja resultados a medias."""
    if not condicion:
        raise RuntimeError(mensaje)


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def cargar() -> pd.DataFrame:
    # Paso 1 · Carga el CSV y comprueba la parrilla y la clave
    # Por qué: las 380 filas no son 380 partidos independientes; el contrato de jornadas, equipos y
    #          clave se comprueba antes de modelar para no confundir repetición con muestra nueva.
    # Salida esperada: "datos: 380 filas × 12 columnas · 38 jornadas × 10 partidos · 20 equipos"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o recupera el CSV de datos-ejemplo/.
    exigir(DATOS.exists(), f"no existe el dato de ejemplo: {DATOS}")
    df = pd.read_csv(DATOS)
    df["resultado"] = df["resultado"].astype(str)
    exigir(list(df.columns) == COLUMNAS, f"columnas inesperadas: {list(df.columns)}")
    exigir(len(df) == 380, f"se esperaban 380 filas y hay {len(df)}")
    exigir(df.duplicated(["jornada", "local", "visitante"]).sum() == 0,
           "la clave (jornada, local, visitante) no es única")
    exigir(int(df.isna().sum().sum()) == 0, "el CSV trae valores nulos")
    exigir(df["jornada"].nunique() == 38, f"jornadas: {df['jornada'].nunique()}")
    exigir(int(df.groupby("jornada").size().nunique()) == 1 and
           int(df.groupby("jornada").size().iloc[0]) == 10, "no hay 10 partidos por jornada")
    equipos = sorted(set(df["local"]) | set(df["visitante"]))
    exigir(len(equipos) == 20, f"equipos: {len(equipos)}")
    print(f"datos: {len(df)} filas × {df.shape[1]} columnas · "
          f"{df['jornada'].nunique()} jornadas × {int(df.groupby('jornada').size().iloc[0])} partidos · "
          f"{len(equipos)} equipos · sha256 {sha256(DATOS)[:8]}…")
    return df


def auditar_parrilla(df: pd.DataFrame) -> dict:
    # Paso 2 · Audita la parrilla: repetición de emparejamientos y resultado derivado
    # Por qué: solo hay 20 emparejamientos repetidos 19 veces y cada jornada repite cuatro equipos;
    #          sin declararlo, una clasificación de liga o una partición al azar serían inventadas.
    # Salida esperada: "parrilla: 20 emparejamientos × 19 repeticiones · 16 equipos por jornada"
    # Si falla: recuentos distintos → el CSV no es el del catálogo; no sigas con el modelo.
    emparejamientos = df.groupby(["local", "visitante"]).size()
    exigir(len(emparejamientos) == 20, f"emparejamientos distintos: {len(emparejamientos)}")
    exigir(int(emparejamientos.nunique()) == 1, "los emparejamientos no se repiten igual")
    equipos_por_jornada = pd.concat([
        df[["jornada", "local"]].rename(columns={"local": "equipo"}),
        df[["jornada", "visitante"]].rename(columns={"visitante": "equipo"}),
    ]).groupby("jornada")["equipo"].nunique()
    derivado = np.where(df["goles_local"] > df["goles_visitante"], "1",
                        np.where(df["goles_local"] == df["goles_visitante"], "X", "2"))
    exigir(int((derivado == df["resultado"]).sum()) == 380, "resultado no coincide con los goles")
    print(f"parrilla: {len(emparejamientos)} emparejamientos × "
          f"{int(emparejamientos.iloc[0])} repeticiones · "
          f"{int(equipos_por_jornada.min())} equipos por jornada (4 juegan dos veces)")
    print(f"resultado derivado de los goles en 380/380 filas")
    return {"emparejamientos": len(emparejamientos), "repeticiones": int(emparejamientos.iloc[0]),
            "equipos_por_jornada": int(equipos_por_jornada.min())}


def estimar_fuerzas(df: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    # Paso 3 · Estima ataque y defensa por equipo con los goles, en campo neutral
    # Por qué: el modelo de partido necesita dos números por equipo, no una tabla de resultados; se
    #          calculan contra la media de la liga para que ataque y defensa sean comparables.
    # Salida esperada: "fuerzas: 20 equipos · goles por equipo y partido 0.9434 · ataque 0.6…–1.5…"
    # Si falla: medias muy lejos de 1 → el cálculo de goles por partido está mal repartido.
    equipos = sorted(set(df["local"]) | set(df["visitante"]))
    partidos = {equipo: 0 for equipo in equipos}
    favor = {equipo: 0 for equipo in equipos}
    contra = {equipo: 0 for equipo in equipos}
    for fila in df.itertuples(index=False):
        partidos[fila.local] += 1
        partidos[fila.visitante] += 1
        favor[fila.local] += fila.goles_local
        contra[fila.local] += fila.goles_visitante
        favor[fila.visitante] += fila.goles_visitante
        contra[fila.visitante] += fila.goles_local
    media = sum(favor.values()) / sum(partidos.values())
    filas = []
    for equipo in equipos:
        ataque = (favor[equipo] / partidos[equipo]) / media
        defensa = (contra[equipo] / partidos[equipo]) / media
        filas.append({"equipo": equipo, "partidos": partidos[equipo], "goles_favor": favor[equipo],
                      "goles_contra": contra[equipo], "ataque": round(ataque, 4),
                      "defensa": round(defensa, 4), "rating": round(ataque / defensa, 4)})
    fuerzas = pd.DataFrame(filas).sort_values("rating", ascending=False).reset_index(drop=True)
    fuerzas.attrs["media_goles"] = media
    if verbose:
        print(f"fuerzas: {len(fuerzas)} equipos · goles por equipo y partido {media:.4f} · "
              f"ataque {fuerzas['ataque'].min():.3f}–{fuerzas['ataque'].max():.3f} · "
              f"defensa {fuerzas['defensa'].min():.3f}–{fuerzas['defensa'].max():.3f}")
    return fuerzas


def poisson(lam: float) -> np.ndarray:
    """PMF de Poisson truncada en MAX_GOLES y renormalizada para que sume 1 exacto."""
    ks = np.arange(MAX_GOLES + 1)
    factoriales = np.array([math.factorial(int(k)) for k in ks])
    pmf = np.exp(-lam) * np.power(lam, ks) / factoriales
    return pmf / pmf.sum()


def probabilidades_partido(fuerzas: pd.DataFrame, verbose: bool = True) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    # Paso 4 · Traduce cada emparejamiento a P(1), P(X) y P(2), que suman 1
    # Por qué: la probabilidad de victoria no se copia de las frecuencias; sale de dos Poisson con las
    #          fuerzas estimadas, y la suma 1 es la comprobación mínima de que el reparto está bien.
    # Salida esperada: "probabilidades: 380 pares · suma por partido con error máximo 0.0e+00"
    # Si falla: suma distinta de 1 → la PMF no está normalizada o falta una rama del reparto.
    media = float(fuerzas.attrs.get("media_goles", 1.0))
    equipos = list(fuerzas["equipo"])
    n = len(equipos)
    p1 = np.zeros((n, n))
    px = np.zeros((n, n))
    p2 = np.zeros((n, n))
    for i, ataque in enumerate(fuerzas["ataque"]):
        for j, defensa in enumerate(fuerzas["defensa"]):
            if i == j:
                continue
            lam_local = ataque * defensa * media
            lam_visitante = fuerzas["ataque"].iloc[j] * fuerzas["defensa"].iloc[i] * media
            matriz = np.outer(poisson(lam_local), poisson(lam_visitante))
            p1[i, j] = float(np.tril(matriz, -1).sum())
            px[i, j] = float(np.trace(matriz))
            p2[i, j] = float(np.triu(matriz, 1).sum())
    fuera_diagonal = ~np.eye(n, dtype=bool)
    error = float(np.abs((p1 + px + p2)[fuera_diagonal] - 1).max())
    if verbose:
        print(f"probabilidades: {n * (n - 1)} pares · suma por partido con error máximo {error:.1e}")
    return p1, px, p2


def evaluar(fuerzas: pd.DataFrame, p1: np.ndarray, px: np.ndarray, p2: np.ndarray,
            df: pd.DataFrame) -> dict:
    # Paso 5 · Compara el modelo con la línea base en un corte por jornada
    # Por qué: sin línea base, un log loss no dice si el modelo aporta; el corte es por jornada porque
    #          solo hay 20 emparejamientos y agrupar por emparejamiento dejaría equipos sin entrenar.
    # Salida esperada: "evaluación (jornadas 31–38): log loss base 1.0… · modelo 1.0…"
    # Si falla: métricas sin sentido → revisa la partición o el orden de las columnas de probabilidad.
    train = df[df["jornada"] <= 30]
    test = df[df["jornada"] >= 31]
    fuerzas_train = estimar_fuerzas(train, verbose=False)
    p1t, pxt, p2t = probabilidades_partido(fuerzas_train, verbose=False)
    indices = {equipo: i for i, equipo in enumerate(fuerzas_train["equipo"])}
    frecuencias = train["resultado"].value_counts(normalize=True)
    base = np.array([frecuencias.get("1", 0.0), frecuencias.get("X", 0.0), frecuencias.get("2", 0.0)])
    logloss = {"base": 0.0, "modelo": 0.0}
    brier = {"base": 0.0, "modelo": 0.0}
    for fila in test.itertuples(index=False):
        i, j = indices[fila.local], indices[fila.visitante]
        probs = np.array([p1t[i, j], pxt[i, j], p2t[i, j]])
        real = np.array([fila.resultado == "1", fila.resultado == "X", fila.resultado == "2"],
                        dtype=float)
        for nombre, reparto in (("base", base), ("modelo", probs)):
            logloss[nombre] += -math.log(max(reparto[real.astype(bool)][0], 1e-15))
            brier[nombre] += float(((reparto - real) ** 2).sum())
    n = len(test)
    for nombre in ("base", "modelo"):
        logloss[nombre] /= n
        brier[nombre] /= n
    print(f"evaluación (jornadas 31–38, {n} partidos): log loss base {logloss['base']:.3f} · "
          f"modelo {logloss['modelo']:.3f} · Brier base {brier['base']:.3f} · "
          f"modelo {brier['modelo']:.3f}")
    return {"logloss_base": logloss["base"], "logloss_modelo": logloss["modelo"],
            "brier_base": brier["base"], "brier_modelo": brier["modelo"], "n_test": n}


def construir_cuadro(fuerzas: pd.DataFrame) -> dict:
    # Paso 6 · Fija el cuadro del torneo antes de simular
    # Por qué: elegir el cuadro después de ver el resultado es trampa; se declara ahora: entran los 16
    #          mejores por rating y los cuatro peores quedan fuera, con siembra clásica.
    # Salida esperada: "cuadro: 16 equipos sembrados · fuera: … (4 equipos)"
    # Si falla: menos de 16 equipos → el cuadro no se puede completar.
    ordenados = fuerzas.sort_values(["rating", "equipo"], ascending=[False, True]).reset_index(drop=True)
    exigir(len(ordenados) >= CUADRO, f"equipos insuficientes para el cuadro: {len(ordenados)}")
    dentro = ordenados.iloc[:CUADRO].reset_index(drop=True)
    fuera = ordenados.iloc[CUADRO:]["equipo"].tolist()
    siembra = [dentro.iloc[pos - 1]["equipo"] for pos in ORDEN_SIEMBRA]
    print(f"cuadro: {CUADRO} equipos sembrados · fuera: {', '.join(fuera)}")
    return {"siembra": siembra, "fuera": fuera, "todos": list(fuerzas["equipo"])}


def matriz_avanza(fuerzas: pd.DataFrame, p1: np.ndarray, px: np.ndarray) -> np.ndarray:
    """Probabilidad de pasar la eliminatoria en campo neutral: victoria + mitad de los empates."""
    return p1 + 0.5 * px


def probabilidad_campeon(cuadro: dict, avanza: np.ndarray, equipos: list[str]) -> pd.Series:
    # Paso 7 · Calcula la probabilidad de campeón con una DP exacta sobre el cuadro
    # Por qué: la tabla analítica es el modelo; se calcula sin simular para poder comparar con las
    #          frecuencias del Monte Carlo y detectar un sorteo mal programado.
    # Salida esperada: "campeón (analítico): 16 equipos con probabilidad · suma 1.000000"
    # Si falla: suma distinta de 1 → el cuadro o la matriz de avance están mal.
    indice = {equipo: i for i, equipo in enumerate(equipos)}
    nodos: list[dict[int, float]] = [{indice[equipo]: 1.0} for equipo in cuadro["siembra"]]
    while len(nodos) > 1:
        siguientes: list[dict[int, float]] = []
        for k in range(0, len(nodos), 2):
            a, b = nodos[k], nodos[k + 1]
            combinado: dict[int, float] = {}
            for equipo_a, masa_a in a.items():
                gana = sum(masa_b * avanza[equipo_a, equipo_b] for equipo_b, masa_b in b.items())
                combinado[equipo_a] = combinado.get(equipo_a, 0.0) + masa_a * gana
            for equipo_b, masa_b in b.items():
                gana = sum(masa_a * avanza[equipo_b, equipo_a] for equipo_a, masa_a in a.items())
                combinado[equipo_b] = combinado.get(equipo_b, 0.0) + masa_b * gana
            siguientes.append(combinado)
        nodos = siguientes
    campeon = pd.Series(0.0, index=equipos)
    for equipo, probabilidad in nodos[0].items():
        campeon.iloc[equipo] = probabilidad
    print(f"campeón (analítico): {(campeon > 0).sum()} equipos con probabilidad · "
          f"suma {campeon.sum():.6f}")
    return campeon


def simular(cuadro: dict, avanza: np.ndarray, equipos: list[str], semilla: int,
            simulaciones: int = SIMULACIONES) -> np.ndarray:
    # Paso 8 · Simula el torneo con semilla fija y cuenta campeones
    # Por qué: el Monte Carlo no es una tirada; son 10.000 torneos con el sorteo del cuadro declarado
    #          y con semilla, para que las frecuencias se puedan reproducir y comparar con el modelo.
    # Salida esperada: "monte carlo: 10000 torneos con semilla 20261105 · total de frecuencias 10000"
    # Si falla: total distinto de simulaciones → alguna rama del cuadro no asigna campeón.
    indice = {equipo: i for i, equipo in enumerate(equipos)}
    generador = np.random.default_rng(semilla)
    actuales = np.array([indice[equipo] for equipo in cuadro["siembra"]], dtype=np.int64)
    actuales = np.tile(actuales, (simulaciones, 1))
    while actuales.shape[1] > 1:
        izquierda = actuales[:, 0::2]
        derecha = actuales[:, 1::2]
        probabilidad = avanza[izquierda, derecha]
        sorteo = generador.random(probabilidad.shape)
        ganador = np.where(sorteo < probabilidad, izquierda, derecha)
        actuales = ganador
    campeones = np.bincount(actuales[:, 0], minlength=len(equipos))
    print(f"monte carlo: {simulaciones} torneos con semilla {semilla} · "
          f"total de frecuencias {int(campeones.sum())}")
    return campeones


def escribir(fuerzas: pd.DataFrame, campeon: pd.Series, campeones: np.ndarray,
             cuadro: dict, metricas_eval: dict) -> None:
    # Paso 9 · Escribe las tablas del proyecto y la descripción del cuadro
    # Por qué: cada cifra del README sale de estos CSV; la comparación modelo–simulación se publica con
    #          su margen de Monte Carlo para que se vea si el sorteo está bien.
    # Salida esperada: "resultados: fuerzas.csv, probabilidades-campeon.csv, frecuencias.csv,
    #                   comparacion.csv, metricas.csv, cuadro.md"
    # Si falla: PermissionError → revisa permisos de resultados/.
    RESULTADOS.mkdir(exist_ok=True)
    equipos = list(fuerzas["equipo"])
    simulado = campeones / campeones.sum()
    sigma = np.sqrt(campeon * (1 - campeon) / campeones.sum())
    comparacion = pd.DataFrame({"equipo": equipos, "modelo": campeon.to_numpy(),
                                "simulado": simulado, "diferencia": simulado - campeon.to_numpy(),
                                "sigma_mc": sigma})
    diferencia_max = float(comparacion["diferencia"].abs().max())
    dentro = set(cuadro["siembra"])
    fuerzas.assign(en_cuadro=fuerzas["equipo"].isin(dentro)).to_csv(RESULTADOS / "fuerzas.csv",
                                                                  index=False)
    pd.DataFrame({"equipo": equipos, "probabilidad_campeon": campeon.to_numpy(),
                  "en_cuadro": [equipo in dentro for equipo in equipos]}).to_csv(
        RESULTADOS / "probabilidades-campeon.csv", index=False)
    pd.DataFrame({"equipo": equipos, "campeon_veces": campeones,
                  "frecuencia": simulado}).to_csv(RESULTADOS / "frecuencias.csv", index=False)
    comparacion.to_csv(RESULTADOS / "comparacion.csv", index=False)
    pd.DataFrame([
        {"metrica": "logloss_base", "valor": round(metricas_eval["logloss_base"], 4)},
        {"metrica": "logloss_modelo", "valor": round(metricas_eval["logloss_modelo"], 4)},
        {"metrica": "brier_base", "valor": round(metricas_eval["brier_base"], 4)},
        {"metrica": "brier_modelo", "valor": round(metricas_eval["brier_modelo"], 4)},
        {"metrica": "partidos_test", "valor": metricas_eval["n_test"]},
        {"metrica": "max_diferencia_modelo_simulado", "valor": round(diferencia_max, 4)},
        {"metrica": "simulaciones", "valor": int(campeones.sum())},
        {"metrica": "semilla", "valor": SEMILLA},
    ]).to_csv(RESULTADOS / "metricas.csv", index=False)
    (RESULTADOS / "cuadro.md").write_text(
        "# Cuadro del torneo (declarado antes de simular)\n\n"
        f"- Equipos dentro: {CUADRO} (los cuatro peores por rating quedan fuera).\n"
        "- Eliminatorias a partido único en campo neutral; si hay empate, 50 % para cada uno.\n"
        "- Siembra clásica 1-16, 8-9, 5-12, 4-13, 6-11, 3-14, 7-10, 2-15.\n"
        f"- Fuera: {', '.join(cuadro['fuera'])}.\n"
        f"- Simulaciones: {int(campeones.sum())} con semilla {SEMILLA}.\n",
        encoding="utf-8")
    print("resultados: fuerzas.csv, probabilidades-campeon.csv, frecuencias.csv, comparacion.csv, "
          "metricas.csv, cuadro.md")


def limpiar() -> None:
    # Paso 10 · Borra las tablas generadas
    # Por qué: el ZIP no lleva derivados; se regeneran con `python torneo.py`.
    # Salida esperada: "limpiar: resultados/ generados borrados"
    # Si falla: PermissionError → cierra el programa que tenga abierto un CSV de resultados/.
    for nombre in GENERADOS:
        (RESULTADOS / nombre).unlink(missing_ok=True)
    print("limpiar: resultados/ generados borrados")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Probabilidad de campeón y Monte Carlo del torneo (P64)")
    parser.add_argument("accion", nargs="?", default="todo", choices=["todo", "limpiar"])
    args = parser.parse_args(argv)
    if args.accion == "limpiar":
        limpiar()
        return 0
    try:
        df = cargar()
        auditar_parrilla(df)
        fuerzas = estimar_fuerzas(df)
        p1, px, p2 = probabilidades_partido(fuerzas)
        evaluacion = evaluar(fuerzas, p1, px, p2, df)
        equipos = list(fuerzas["equipo"])
        avanza = matriz_avanza(fuerzas, p1, px)
        cuadro = construir_cuadro(fuerzas)
        campeon = probabilidad_campeon(cuadro, avanza, equipos)
        campeones = simular(cuadro, avanza, equipos, SEMILLA)
        escribir(fuerzas, campeon, campeones, cuadro, evaluacion)
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con resultados a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
