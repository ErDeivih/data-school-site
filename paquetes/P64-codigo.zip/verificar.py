#!/usr/bin/env python3
"""Puerta del proyecto P64 (probabilidad de campeón y Monte Carlo del torneo).

Comprueba el resultado de verdad, sin escribir nada y sin red: el CSV es el del catálogo (sha256) y su
parrilla repite emparejamientos, cada partido produce un reparto que suma 1, la tabla analítica de
campeón suma 1 con cuatro equipos fuera del cuadro, el Monte Carlo son 10.000 torneos con semilla y
sus frecuencias cuadran con el modelo dentro del margen de Monte Carlo. La misma semilla reproduce la
misma salida.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

import torneo as p

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P64 · probabilidad de campeón y Monte Carlo ==")

    # Paso 1 · Comprueba el dato de ejemplo y la parrilla
    # Por qué: las 380 filas no son 380 partidos independientes; el sha256 y la repetición de
    #          emparejamientos son la primera puerta antes de modelar.
    # Salida esperada: "datos: 380 filas × 12 columnas · 38 jornadas × 10 partidos · 20 equipos"
    # Si falla: FileNotFoundError → falta datos-ejemplo/futbol-partidos.csv (el ZIP lo trae).
    df = p.cargar()
    ok(len(df) == 380 and df.shape[1] == 12, f"CSV: {len(df)} filas × {df.shape[1]} columnas")
    ok(p.sha256(p.DATOS) == "5cbc8977b6c9d4f7ae66bfcc7642c93a6655faf7b6e6524a6d40480e2e66a12e",
       "el sha256 del CSV de ejemplo es el de la copia del catálogo")
    parrilla = p.auditar_parrilla(df)
    ok(parrilla["emparejamientos"] == 20 and parrilla["repeticiones"] == 19,
       f"parrilla: {parrilla['emparejamientos']} emparejamientos × {parrilla['repeticiones']}")
    ok(parrilla["equipos_por_jornada"] == 16,
       f"equipos por jornada: {parrilla['equipos_por_jornada']} (16 distintos, 4 repiten)")
    derivado = np.where(df["goles_local"] > df["goles_visitante"], "1",
                        np.where(df["goles_local"] == df["goles_visitante"], "X", "2"))
    ok(int((derivado == df["resultado"]).sum()) == 380, "resultado derivado de los goles en 380/380")

    # Paso 2 · Comprueba las probabilidades de partido: suman 1 y la línea base está
    # Por qué: la probabilidad de victoria es el primer entregable; un reparto que no suma 1 invalida
    #          el cuadro y el Monte Carlo, y la línea base es lo que dice si el modelo aporta.
    # Salida esperada: "probabilidades: 380 pares · suma por partido con error máximo 4.4e-16"
    # Si falla: suma distinta de 1 → la PMF de Poisson no está normalizada o falta una rama.
    fuerzas = p.estimar_fuerzas(df)
    ok(len(fuerzas) == 20 and fuerzas["equipo"].is_unique, "fuerzas: 20 equipos distintos")
    ok(fuerzas["ataque"].between(0.2, 2.5).all() and fuerzas["defensa"].between(0.2, 2.5).all(),
       f"ataque {fuerzas['ataque'].min():.3f}–{fuerzas['ataque'].max():.3f} · "
       f"defensa {fuerzas['defensa'].min():.3f}–{fuerzas['defensa'].max():.3f}")
    p1, px, p2 = p.probabilidades_partido(fuerzas)
    n = len(fuerzas)
    fuera = ~np.eye(n, dtype=bool)
    error = float(np.abs((p1 + px + p2)[fuera] - 1).max())
    ok(error < 1e-12, f"suma P(1)+P(X)+P(2) = 1 con error {error:.1e}")
    ok(bool((p1[fuera] >= 0).all() and (px[fuera] >= 0).all() and (p2[fuera] >= 0).all()),
       "las tres probabilidades son no negativas")
    frecuencias = df["resultado"].value_counts()
    ok((int(frecuencias.get("1", 0)), int(frecuencias.get("X", 0)), int(frecuencias.get("2", 0)))
       == (174, 114, 92), f"resultado: 1={frecuencias.get('1')} · X={frecuencias.get('X')} · "
                          f"2={frecuencias.get('2')}")

    # Paso 3 · Comprueba la evaluación con línea base en el corte por jornada
    # Por qué: sin línea base no se sabe si el modelo aporta; el corte es por jornada porque solo hay
    #          20 emparejamientos y agrupar por emparejamiento dejaría equipos sin entrenar.
    # Salida esperada: "evaluación (jornadas 31–38, 80 partidos): log loss base 1.077 · modelo 1.065"
    # Si falla: métricas sin sentido → revisa la partición o el orden 1/X/2 de las probabilidades.
    evaluacion = p.evaluar(fuerzas, p1, px, p2, df)
    ok(evaluacion["n_test"] == 80, f"partidos de test: {evaluacion['n_test']}")
    ok(evaluacion["logloss_modelo"] <= evaluacion["logloss_base"],
       f"log loss modelo {evaluacion['logloss_modelo']:.3f} <= base {evaluacion['logloss_base']:.3f}")
    ok(evaluacion["brier_modelo"] <= evaluacion["brier_base"],
       f"Brier modelo {evaluacion['brier_modelo']:.3f} <= base {evaluacion['brier_base']:.3f}")

    # Paso 4 · Comprueba el cuadro declarado y la probabilidad analítica de campeón
    # Por qué: el cuadro se fija antes de simular; la tabla analítica debe sumar 1 y dejar 0 a los
    #          cuatro equipos que no entran.
    # Salida esperada: "campeón (analítico): 16 equipos con probabilidad · suma 1.000000"
    # Si falla: suma distinta de 1 → el cuadro o la matriz de avance están mal.
    equipos = list(fuerzas["equipo"])
    avanza = p.matriz_avanza(fuerzas, p1, px)
    cuadro = p.construir_cuadro(fuerzas)
    ok(len(cuadro["siembra"]) == p.CUADRO and len(cuadro["fuera"]) == 4,
       f"cuadro: {len(cuadro['siembra'])} dentro · {len(cuadro['fuera'])} fuera")
    campeon = p.probabilidad_campeon(cuadro, avanza, equipos)
    ok(abs(float(campeon.sum()) - 1) < 1e-9, f"probabilidad de campeón suma {campeon.sum():.6f}")
    ok(int((campeon > 0).sum()) == p.CUADRO, f"equipos con probabilidad positiva: {int((campeon > 0).sum())}")
    ok(all(float(campeon[equipo]) == 0 for equipo in cuadro["fuera"]), "los cuatro fuera suman 0")

    # Paso 5 · Comprueba el Monte Carlo: semilla, total y cuadre con el modelo
    # Por qué: el Monte Carlo se comprueba contra la tabla analítica con su margen; sin semilla fija no
    #          se puede repetir, y sin cuadre no se sabe si el sorteo es el del cuadro declarado.
    # Salida esperada: "monte carlo: 10000 torneos con semilla 20261105 · total 10000"
    # Si falla: total distinto de 10000 → alguna rama del cuadro no asigna campeón.
    campeones = p.simular(cuadro, avanza, equipos, p.SEMILLA)
    ok(int(campeones.sum()) == p.SIMULACIONES, f"frecuencias: {int(campeones.sum())} torneos")
    simulado = campeones / campeones.sum()
    sigma = np.sqrt(campeon.to_numpy() * (1 - campeon.to_numpy()) / p.SIMULACIONES)
    diferencia = np.abs(simulado - campeon.to_numpy())
    ok(bool((diferencia <= 3 * sigma + 1e-3).all()),
       f"máxima diferencia modelo–simulado: {diferencia.max():.4f} (margen 3 sigma)")
    campeones2 = p.simular(cuadro, avanza, equipos, p.SEMILLA)
    ok(np.array_equal(campeones, campeones2), "la misma semilla da las mismas frecuencias")

    # Paso 6 · Comprueba que el código comprueba y no hace red ni usa secretos
    # Por qué: la puerta se ejecuta sin red y el código se comparte; una descarga escondida rompería
    #          la promesa del README.
    # Salida esperada: "código offline, sin claves"
    # Si falla: aparece una llamada de red o un patrón de token → quítalo antes de empaquetar.
    texto = (p.RAIZ / "torneo.py").read_text(encoding="utf-8")
    ok("CC0-1.0" in texto, "el código cita la licencia CC0-1.0 del CSV")
    ok(not any(x in texto for x in ("import requests", "import urllib", "import socket",
                                    "urlopen(", "requests.get")),
       "el código no hace peticiones de red")
    ok(not any(x in texto for x in ("ghp_", "github_pat_", "Authorization:")),
       "el código no contiene claves ni cabeceras de autorización")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
