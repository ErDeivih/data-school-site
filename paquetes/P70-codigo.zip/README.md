# P70 · Tenis: el saque no lo es todo

Paquete descargable de **Data School** para el proyecto P70. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es cuánto pesa el saque: con 600 puntos, el sacador gana el **58,2 %**,
pero en intercambios cortos gana el **62,7 %** y en largos solo el **52,1 %**. Por superficie, la
ventaja va de **55,6 %** en tierra a **60,8 %** en dura. El saque importa, pero no es el marcador por
sí solo.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python saque.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P70-codigo
python saque.py --csv datos-ejemplo/tenis-puntos.csv
```

## Salida esperada

```text
datos: 600 puntos · 10 partidos · 3 superficies
ventaja global del sacador: 58.2 %
por superficie:
  dura: 60.8 % · 240 puntos
  tierra: 55.6 % · 180 puntos
  hierba: 57.2 % · 180 puntos
por duración del intercambio:
  corto: 62.7 % · 220 puntos
  medio: 58.1 % · 215 puntos
  largo: 52.1 % · 165 puntos
lectura: el saque gana el 58.2 % de los puntos, pero en intercambios largos baja al 52.1 %
(corto: 62.7 %): no es el marcador por sí solo.
límite: 600 puntos sintéticos de 3 superficies; no hay marcador, presión ni identidad de jugador.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/tenis-puntos.csv`: **600 filas × 8 columnas**. 10 partidos, 3 superficies, set,
  juego, sacador, tipo de punto, duración del intercambio y ganador (sacador/resto).
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `tenis-puntos` del catálogo.
- `sha256`: `b046074b41d32abd9bbc14ee7889c3dd7b79a3a0f8d19e5f3c11633dc1b915fe`.

## Qué enseña

| Paso | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida superficie, ganador y duración | un punto sin ganador no se cuenta |
| 2 · Tasa | proporción de puntos del sacador | línea base antes de comparar |
| 3 · Superficie | ventaja por pista | una media global puede ocultar diferencias |
| 4 · Duración | ventaja por tramo de intercambio | el saque pierde fuerza en rallies largos |

## Las trampas que deja a la vista

1. **La media global no cuenta la historia.** 58,2 % global esconde 62,7 % en puntos cortos y 52,1 %
   en largos; sin desglose, el «saque manda» es una frase sin matices.
2. **Los tramos deben cubrir la muestra.** Cada tramo declara sus puntos (220/215/165); sin ese
   control, un tramo con 3 puntos parecería una conclusión.
3. **Ganar puntos no es ganar partidos.** El CSV no trae marcador ni presión; el paquete no afirma
   que el saque decida partidos, solo dónde se apoya la ventaja.

## Fallos típicos

- **`ModuleNotFoundError: saque`**: ejecuta desde la carpeta del paquete.
- **`superficie desconocida`**: el CSV trae una pista fuera de dura/tierra/hierba.
- **`algún tramo de duración se queda sin puntos`**: el corte de duraciones no cubre la muestra.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P70-codigo/
├── saque.py                   # tasas por superficie y duración
├── verificar.py               # 15 comprobaciones
├── requirements.txt
├── datos-ejemplo/tenis-puntos.csv
└── resultados/ejemplo-salida.txt
```

## Límite

600 puntos sintéticos de 3 superficies; no hay marcador, presión, identidad de jugador ni saques
directos. El paquete describe **este CSV** y ordena la lectura, no predice partidos.
