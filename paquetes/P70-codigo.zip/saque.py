"""P70 · Tenis: el saque no lo es todo.

Mide la ventaja del sacador en 600 puntos, la desglosa por superficie y por duración del intercambio,
y muestra dónde se cae esa ventaja: el saque gana puntos, pero no todos los puntos. Sin librerías.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("partido", "superficie", "set", "juego", "sacador", "tipo",
            "duracion_intercambio_s", "gano")
SUPERFICIES = ("dura", "tierra", "hierba")
TRAMOS = ((2.0, 6.0, "corto"), (6.0, 10.0, "medio"), (10.0, 99.0, "largo"))


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: superficie conocida, ganador sacador/resto y duración positiva.
    # Por qué: un punto sin ganador válido no se puede contar; una superficie nueva rompe el desglose.
    # Salida esperada: 600 puntos, 3 superficies y ganador en {sacador, resto}.
    # Si falla: «columnas inesperadas», superficie desconocida o duración no positiva.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 600:
        raise ValueError(f"se esperaban 600 puntos, hay {len(filas)}")
    for fila in filas:
        if fila["superficie"] not in SUPERFICIES:
            raise ValueError(f"superficie desconocida: {fila['superficie']}")
        if fila["gano"] not in ("sacador", "resto"):
            raise ValueError(f"ganador desconocido: {fila['gano']}")
        if float(fila["duracion_intercambio_s"]) <= 0:
            raise ValueError("duración no positiva")
    return filas


def tasa(puntos: list[dict]) -> float:
    # Paso 2 · Proporción de puntos ganados por el sacador.
    # Por qué: es la línea base de la ventaja; sin ella, comparar por superficie es comparar aire.
    # Salida esperada: un número entre 0 y 1.
    if not puntos:
        raise ValueError("no hay puntos")
    return sum(1 for p in puntos if p["gano"] == "sacador") / len(puntos)


def por_superficie(filas: list[dict]) -> dict:
    # Paso 3 · La ventaja del saque por superficie.
    # Por qué: la pista cambia el juego; una media global puede ocultar una superficie sin ventaja.
    # Salida esperada: 3 superficies con su tasa y su número de puntos.
    grupos = defaultdict(list)
    for fila in filas:
        grupos[fila["superficie"]].append(fila)
    return {s: {"tasa": tasa(grupos[s]), "n": len(grupos[s])} for s in SUPERFICIES if grupos[s]}


def por_duracion(filas: list[dict]) -> dict:
    # Paso 4 · La ventaja del saque según dura el intercambio.
    # Por qué: el saque gana puntos cortos; en intercambios largos el resto tiene más oportunidades.
    # Salida esperada: 3 tramos (corto, medio, largo) con su tasa y su número de puntos.
    salida = {}
    for bajo, alto, nombre in TRAMOS:
        puntos = [f for f in filas if bajo <= float(f["duracion_intercambio_s"]) < alto]
        salida[nombre] = {"tasa": tasa(puntos) if puntos else 0.0, "n": len(puntos)}
    if not all(v["n"] for v in salida.values()):
        raise ValueError("algún tramo de duración se queda sin puntos")
    return salida


def main() -> int:
    parser = argparse.ArgumentParser(description="P70 · ventaja del saque por superficie y duración")
    parser.add_argument("--csv", default="datos-ejemplo/tenis-puntos.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    print(f"datos: {len(filas)} puntos · {len({f['partido'] for f in filas})} partidos · {len(SUPERFICIES)} superficies")
    print(f"ventaja global del sacador: {tasa(filas) * 100:.1f} %")
    print("por superficie:")
    for superficie, d in por_superficie(filas).items():
        print(f"  {superficie}: {d['tasa'] * 100:.1f} % · {d['n']} puntos")
    print("por duración del intercambio:")
    for tramo, d in por_duracion(filas).items():
        print(f"  {tramo}: {d['tasa'] * 100:.1f} % · {d['n']} puntos")
    corto = por_duracion(filas)["corto"]["tasa"]
    largo = por_duracion(filas)["largo"]["tasa"]
    print(f"lectura: el saque gana el {tasa(filas) * 100:.1f} % de los puntos, pero en intercambios largos "
          f"baja al {largo * 100:.1f} % (corto: {corto * 100:.1f} %): no es el marcador por sí solo.")
    print("límite: 600 puntos sintéticos de 3 superficies; no hay marcador, presión ni identidad de jugador.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
