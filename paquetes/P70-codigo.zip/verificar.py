#!/usr/bin/env python3
"""Puerta del proyecto P70 (tenis: el saque no lo es todo).

Comprueba datos, ventaja global, superficie, duración del intercambio y ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import saque

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "tenis-puntos.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = saque.leer(CSV)
    ok(len(filas) == 600, "el CSV tiene 600 puntos")
    ok(len({f["partido"] for f in filas}) == 10, "hay 10 partidos")
    ok(len({f["superficie"] for f in filas}) == 3, "hay 3 superficies")

    cerca(saque.tasa(filas), 0.582, 0.002, "ventaja global del sacador")
    superficies = saque.por_superficie(filas)
    cerca(superficies["dura"]["tasa"], 0.608, 0.003, "tasa del sacador en dura")
    cerca(superficies["tierra"]["tasa"], 0.556, 0.003, "tasa del sacador en tierra")
    cerca(superficies["hierba"]["tasa"], 0.572, 0.003, "tasa del sacador en hierba")
    ok(sum(d["n"] for d in superficies.values()) == 600, "las superficies cubren los 600 puntos")

    tramos = saque.por_duracion(filas)
    cerca(tramos["corto"]["tasa"], 0.627, 0.003, "tasa en intercambios cortos")
    cerca(tramos["medio"]["tasa"], 0.581, 0.003, "tasa en intercambios medios")
    cerca(tramos["largo"]["tasa"], 0.521, 0.003, "tasa en intercambios largos")
    ok(tramos["corto"]["tasa"] > tramos["largo"]["tasa"], "el saque pierde ventaja en intercambios largos")
    ok(sum(d["n"] for d in tramos.values()) == 600, "los tramos cubren los 600 puntos")

    codigo = (AQUI / "saque.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
