#!/usr/bin/env python3
"""Puerta del proyecto P68 (cobertura del precio: un día sin viento).

Comprueba el ajuste OLS, el escenario, su intervalo, la sensibilidad y la ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import cobertura

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "precios-luz.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = cobertura.leer(CSV)
    ok(len(filas) == 1440, "el CSV tiene 1440 horas")
    ok(len({f["fecha"] for f in filas}) == 60, "hay 60 días")

    datos = cobertura.ajustar(filas)
    ok(len(datos["beta"]) == 5, "el modelo tiene 5 coeficientes")
    cerca(datos["beta"][1], 0.00140, 0.00002, "coeficiente de demanda")
    cerca(datos["beta"][2], -0.00109, 0.00002, "coeficiente de viento")
    cerca(datos["r2"], 0.892, 0.003, "R² del ajuste")
    ok(datos["beta"][2] < 0, "más viento se asocia a menor precio en estos datos")

    base = cobertura.escenario(datos, filas, 0.50, 0.10)
    cerca(base["delta"], 7.24, 0.05, "delta del escenario viento −50 % y demanda +10 %")
    ok(base["bajo"] < base["delta"] < base["alto"], "el intervalo contiene la estimación")
    cerca(base["bajo"], 6.46, 0.06, "límite inferior del IC95 %")
    cerca(base["alto"], 8.03, 0.06, "límite superior del IC95 %")

    caidas = [0.10, 0.20, 0.30, 0.40, 0.50]
    deltas = [cobertura.escenario(datos, filas, c, 0.0)["delta"] for c in caidas]
    ok(all(b > a for a, b in zip(deltas, deltas[1:])), "el delta crece con la caída de viento")
    cerca(deltas[-1], 4.06, 0.04, "viento −50 % sin subir demanda")

    codigo = (AQUI / "cobertura.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
