"""P68 · Cobertura del precio: un día sin viento.

Ajusta un modelo lineal del precio horario contra demanda, viento y sol, y lo usa para responder una
pregunta de cobertura: si el viento cae a la mitad y la demanda sube un 10 %, ¿cuánto sube el precio
y con qué margen? Incluye tabla de sensibilidad y límite causal. Sin librerías.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("fecha", "hora", "precio_eur_mwh", "demanda_mw", "eolica_mw", "solar_mw", "dia_semana")
NOMBRES = ("intercepto", "demanda", "eolica", "solar", "hora")
CAIDA_VIENTO = 0.50
SUBE_DEMANDA = 0.10


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: precio, demanda, viento y sol numéricos, 1440 horas.
    # Por qué: una columna de texto o un precio negativo cambia el signo del modelo sin avisar.
    # Salida esperada: 1440 filas × 7 columnas.
    # Si falla: «columnas inesperadas», un valor no numérico o horas fuera de 0..23.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 1440:
        raise ValueError(f"se esperaban 1440 filas, hay {len(filas)}")
    for fila in filas:
        if not 0 <= int(fila["hora"]) <= 23:
            raise ValueError("hora fuera de 0..23")
        for columna in ("precio_eur_mwh", "demanda_mw", "eolica_mw", "solar_mw"):
            float(fila[columna])
    return filas


def resolver(a: list[list[float]], b: list[float]) -> list[float]:
    # Paso 2 · Resolver el sistema normal (X'X)β = X'y con eliminación de Gauss.
    # Por qué: es la regresión lineal sin depender de numpy; el pivote evita dividir por cero.
    # Salida esperada: 5 coeficientes.
    # Si falla: matriz singular (predictores colineales).
    n = len(a)
    m = [fila[:] + [b[i]] for i, fila in enumerate(a)]
    for col in range(n):
        pivote = max(range(col, n), key=lambda r: abs(m[r][col]))
        if abs(m[pivote][col]) < 1e-12:
            raise ValueError("matriz singular: predictores colineales")
        m[col], m[pivote] = m[pivote], m[col]
        for r in range(col + 1, n):
            factor = m[r][col] / m[col][col]
            for c in range(col, n + 1):
                m[r][c] -= factor * m[col][c]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        x[i] = (m[i][n] - sum(m[i][j] * x[j] for j in range(i + 1, n))) / m[i][i]
    return x


def ajustar(filas: list[dict]) -> dict:
    # Paso 3 · OLS con X = [1, demanda, viento, sol, hora].
    # Por qué: permite leer el efecto de cada variable manteniendo las demás.
    # Salida esperada: coeficientes, R² y matriz de covarianza para el intervalo.
    # Si falla: el sistema es singular o no hay grados de libertad.
    x = [[1.0, float(f["demanda_mw"]), float(f["eolica_mw"]), float(f["solar_mw"]), float(f["hora"])] for f in filas]
    y = [float(f["precio_eur_mwh"]) for f in filas]
    k = len(NOMBRES)
    xtx = [[sum(x[i][a] * x[i][b] for i in range(len(x))) for b in range(k)] for a in range(k)]
    xty = [sum(x[i][a] * y[i] for i in range(len(x))) for a in range(k)]
    beta = resolver(xtx, xty)
    residuos = [y[i] - sum(beta[j] * x[i][j] for j in range(k)) for i in range(len(y))]
    sc = sum(r * r for r in residuos)
    st = sum((v - sum(y) / len(y)) ** 2 for v in y)
    sigma2 = sc / (len(y) - k)
    inversa = invertir(xtx)
    cov = [[sigma2 * inversa[i][j] for j in range(k)] for i in range(k)]
    return {"beta": beta, "r2": 1 - sc / st, "sigma2": sigma2, "cov": cov}


def invertir(a: list[list[float]]) -> list[list[float]]:
    # Inversa por Gauss-Jordan; solo para 5×5 y con pivoteo.
    n = len(a)
    m = [fila[:] + [1.0 if i == j else 0.0 for j in range(n)] for i, fila in enumerate(a)]
    for col in range(n):
        pivote = max(range(col, n), key=lambda r: abs(m[r][col]))
        if abs(m[pivote][col]) < 1e-12:
            raise ValueError("matriz singular")
        m[col], m[pivote] = m[pivote], m[col]
        div = m[col][col]
        m[col] = [v / div for v in m[col]]
        for r in range(n):
            if r == col:
                continue
            factor = m[r][col]
            m[r] = [m[r][c] - factor * m[col][c] for c in range(2 * n)]
    return [fila[n:] for fila in m]


def escenario(datos: dict, filas: list[dict], caida: float, sube: float) -> dict:
    # Paso 4 · Delta de precio ante una caída de viento y una subida de demanda.
    # Por qué: el coeficiente suelto no responde a la pregunta; el escenario sí, con su intervalo.
    # Salida esperada: delta en €/MWh y su IC95 %.
    media_demanda = sum(float(f["demanda_mw"]) for f in filas) / len(filas)
    media_viento = sum(float(f["eolica_mw"]) for f in filas) / len(filas)
    beta = datos["beta"]
    delta = beta[1] * (sube * media_demanda) + beta[2] * (-caida * media_viento)
    # Gradiente del delta respecto a los coeficientes (demanda y viento).
    gradiente = [0.0, sube * media_demanda, -caida * media_viento, 0.0, 0.0]
    var = sum(gradiente[i] * datos["cov"][i][j] * gradiente[j] for i in range(5) for j in range(5))
    error = math.sqrt(max(0.0, var))
    return {"delta": delta, "ee": error, "bajo": delta - 1.96 * error, "alto": delta + 1.96 * error}


def main() -> int:
    parser = argparse.ArgumentParser(description="P68 · cobertura del precio con escenario de viento")
    parser.add_argument("--csv", default="datos-ejemplo/precios-luz.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    datos = ajustar(filas)
    base = escenario(datos, filas, CAIDA_VIENTO, SUBE_DEMANDA)
    print(f"datos: {len(filas)} horas · precio medio {sum(float(f['precio_eur_mwh']) for f in filas) / len(filas):.2f} €/MWh · R² {datos['r2']:.3f}")
    print(f"coeficientes: demanda {datos['beta'][1]:+.5f} €/MWh/MW · viento {datos['beta'][2]:+.5f} · sol {datos['beta'][3]:+.5f}")
    print(f"escenario: viento −{CAIDA_VIENTO * 100:.0f} % y demanda +{SUBE_DEMANDA * 100:.0f} % → "
          f"{base['delta']:+.2f} €/MWh · IC95 % [{base['bajo']:+.2f}, {base['alto']:+.2f}]")
    print("sensibilidad (solo viento):")
    for caida in (0.10, 0.20, 0.30, 0.40, 0.50):
        d = escenario(datos, filas, caida, 0.0)
        print(f"  −{caida * 100:.0f} %: {d['delta']:+.2f} €/MWh [{d['bajo']:+.2f}, {d['alto']:+.2f}]")
    print("lectura: el modelo da una dirección y un margen; no prueba que el precio suba por el viento, "
          "solo que se mueve con él en estos datos.")
    print("límite: 60 días sintéticos, relación lineal y sin causalidad; no sirve para fijar una cobertura real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
