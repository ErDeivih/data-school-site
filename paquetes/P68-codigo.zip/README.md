# P68 · Cobertura del precio: un día sin viento

Paquete descargable de **Data School** para el proyecto P68. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es de cobertura: si el viento cae a la mitad y la demanda sube un 10 %,
**¿cuánto sube el precio y con qué margen?** El código ajusta un modelo lineal del precio horario
contra demanda, viento y sol, y traduce los coeficientes a un escenario con su intervalo: **+7,24
€/MWh** (IC95 % **[+6,46, +8,03]**), con una tabla de sensibilidad al viento de −10 % a −50 %.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: OLS y su covarianza implementados con la biblioteca estándar.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python cobertura.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P68-codigo
python cobertura.py --csv datos-ejemplo/precios-luz.csv
```

## Salida esperada

```text
datos: 1440 horas · precio medio 43.72 €/MWh · R² 0.892
coeficientes: demanda +0.00140 €/MWh/MW · viento -0.00109 · sol -0.00517
escenario: viento −50 % y demanda +10 % → +7.24 €/MWh · IC95 % [+6.46, +8.03]
sensibilidad (solo viento):
  −10 %: +0.81 €/MWh [+0.66, +0.96]
  −20 %: +1.62 €/MWh [+1.33, +1.92]
  −30 %: +2.44 €/MWh [+1.99, +2.88]
  −40 %: +3.25 €/MWh [+2.65, +3.84]
  −50 %: +4.06 €/MWh [+3.32, +4.80]
lectura: el modelo da una dirección y un margen; no prueba que el precio suba por el viento, solo
que se mueve con él en estos datos.
límite: 60 días sintéticos, relación lineal y sin causalidad; no sirve para fijar una cobertura real.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/precios-luz.csv`: **1440 filas × 7 columnas**. 60 días × 24 horas con precio
  €/MWh, demanda, eólica, solar y día de la semana.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `precios-luz` del catálogo. No son
  precios reales de ningún mercado.
- `sha256`: `e858a6605c840306c01c19f1343ef9bb2a765cf500b50c043c5a39ba8f244773`.

## Qué enseña cada paso

| Paso | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida 1440 horas y valores numéricos | el modelo depende del grano |
| 2 · Resolver | sistema normal (X'X)β = X'y con Gauss | regresión sin librerías |
| 3 · Ajustar | coeficientes, R² y covarianza | leer efectos manteniendo el resto |
| 4 · Escenario | viento −50 % y demanda +10 % con IC95 % | una cifra con margen, no una promesa |
| 5 · Sensibilidad | caídas de viento del 10 al 50 % | cómo cambia la respuesta |

## Las trampas que deja a la vista

1. **Un coeficiente no es una respuesta.** El coeficiente del viento es €/MWh por MW; la pregunta
   pide un escenario (caída porcentual), y el código lo construye con el gradiente.
2. **Sin intervalo, el escenario es una cifra suelta.** El delta lleva IC95 % calculado con la
   covarianza de los coeficientes; el intervalo no cruza 0 en estos datos.
3. **Asociación no es causalidad.** El modelo dice que el precio se mueve con el viento, no que la
   cobertura real cueste eso; el límite lo deja escrito.

## Fallos típicos

- **`ModuleNotFoundError: cobertura`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`** o un valor no numérico: el CSV no es el del catálogo.
- **`matriz singular`**: dos predictores son colineales (por ejemplo, duplicar una columna).
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P68-codigo/
├── cobertura.py               # OLS, escenario, IC95 % y sensibilidad
├── verificar.py               # 15 comprobaciones
├── requirements.txt
├── datos-ejemplo/precios-luz.csv
└── resultados/ejemplo-salida.txt
```

## Límite

60 días sintéticos, relación lineal y sin causalidad; no hay mercados reales, contratos de
cobertura, impuestos ni dinámica de oferta. El paquete enseña el **método** (modelo, escenario,
intervalo y límite), no un precio de cobertura.
