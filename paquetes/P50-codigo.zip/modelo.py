#!/usr/bin/env python3
"""P50 · Modelo financiero de 3 estados con escenarios — código ejecutable.

Construye, para una empresa del CSV, cuenta de resultados, balance y estado de caja desde los mismos
supuestos, comprueba que el balance cuadra (activo = pasivo + patrimonio) en los cinco ejercicios
proyectados y compara un escenario base con uno adverso. Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal de datasets/csv/):
    datos-ejemplo/fundamentales-empresa.csv  (50 filas × 16 columnas)

Uso:
    python modelo.py             # calcula y escribe resultados/
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
EMPRESA = "EMP-A"
TASA_IMPUESTOS = 0.25
ANIOS = 5  # 2026-2030, después del último ejercicio del CSV (2025)
# Supuesto declarado: en el CSV no hay caja. Se parte de caja cero y se dice en el informe.
CAJA_INICIAL = 0.0


# Paso 1 · Carga el CSV y comprueba la forma del panel
# Por qué: las identidades contables solo se pueden comprobar si la clave (empresa, ejercicio) es única
#          y cada empresa tiene los cinco ejercicios; si falta uno, el acumulado de patrimonio miente.
# Salida esperada: "fundamentales: 50 filas · 10 empresas · 5 ejercicios"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_fundamentales() -> pd.DataFrame:
    ruta = DATOS / "fundamentales-empresa.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta)
    df = df.sort_values(["empresa", "ejercicio"]).reset_index(drop=True)
    print(
        f"fundamentales: {len(df)} filas · {df['empresa'].nunique()} empresas · "
        f"{df['ejercicio'].nunique()} ejercicios"
    )
    return df


# Paso 2 · Comprueba las tres identidades internas del CSV
# Por qué: si el beneficio no sale de EBITDA menos depreciación, intereses e impuestos, el modelo
#          proyectado hereda el error; se cuenta la peor diferencia en vez de suponer que cuadra.
# Salida esperada: "identidades: beneficio 0.0 M€ · impuestos 0.0 M€ · patrimonio 0.0 M€"
# Si falla: una diferencia > 0,11 M€ → el CSV fue editado o hay un nulo.
def validar_identidades(df: pd.DataFrame) -> dict:
    calculado = df["ebitda"] - df["depreciacion"] - df["intereses"] - df["impuestos"]
    err_beneficio = float((calculado - df["beneficio_neto"]).abs().max())
    antes_impuestos = df["ebitda"] - df["depreciacion"] - df["intereses"]
    impuesto_esperado = (antes_impuestos.clip(lower=0) * TASA_IMPUESTOS).round(1)
    err_impuestos = float((impuesto_esperado - df["impuestos"]).abs().max())
    d = df.sort_values(["empresa", "ejercicio"]).copy()
    d["patrimonio_previo"] = d.groupby("empresa")["patrimonio_neto"].shift(1)
    con_previo = d.dropna(subset=["patrimonio_previo"]).copy()
    # El patrimonio acumula el beneficio del propio ejercicio (PN_t = PN_{t-1} + beneficio_t); el CSV
    # lo redondea a 0,1 M€, así que la comprobación tolera ese redondeo.
    err_patrimonio = float(
        (con_previo["patrimonio_neto"] - con_previo["patrimonio_previo"] - con_previo["beneficio_neto"]).abs().max()
    )
    resultado = {
        "err_beneficio": err_beneficio,
        "err_impuestos": err_impuestos,
        "err_patrimonio": err_patrimonio,
        "empresas": int(df["empresa"].nunique()),
        "ejercicios_por_empresa": sorted(df.groupby("empresa").size().unique().tolist()),
        "claves_duplicadas": int(df.duplicated(["empresa", "ejercicio"]).sum()),
        "impuestos_negativos": int((df["impuestos"] < 0).sum()),
        "acciones_constantes": bool(df.groupby("empresa")["acciones"].nunique().eq(1).all()),
    }
    print(
        f"identidades: beneficio {err_beneficio:.1f} M€ · impuestos {err_impuestos:.1f} M€ · "
        f"patrimonio {err_patrimonio:.1f} M€"
    )
    return resultado


# Paso 3 · Deriva el activo no corriente que el CSV no exporta
# Por qué: el balance cuadra por construcción con la identidad activo = pasivo + patrimonio, pero el
#          CSV no trae activo total ni activo no corriente; se derivan y se declaran como derivados.
# Salida esperada: "balance: activo no corriente derivado positivo · mínimo 529.2 M€"
# Si falla: algún ANC negativo → los pasivos superan a los activos; no se parchea, se investiga.
def derivar_balance(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["activo_no_corriente"] = (
        d["pasivo_corriente"] + d["deuda_total"] + d["patrimonio_neto"] - d["activo_corriente"]
    )
    d["activo_total"] = d["activo_corriente"] + d["activo_no_corriente"]
    d["pasivo_mas_patrimonio"] = d["pasivo_corriente"] + d["deuda_total"] + d["patrimonio_neto"]
    d["cuadre"] = d["activo_total"] - d["pasivo_mas_patrimonio"]
    minimo = float(d["activo_no_corriente"].min())
    print(f"balance: activo no corriente derivado positivo · mínimo {minimo:.1f} M€")
    return d


# Paso 4 · Fija los supuestos del escenario base desde el histórico
# Por qué: el escenario base no se inventa: crecimiento, margen y coste de la deuda salen de la serie
#          2021-2025 de la empresa; el escenario adverso se define como shock declarado sobre esos.
# Salida esperada: "supuestos EMP-A: crecimiento 5.6% · margen 21.0% · coste deuda 3.5%"
# Si falla: ingresos o deuda a cero → la serie no tiene cinco ejercicios completos.
def supuestos_base(df: pd.DataFrame, empresa: str = EMPRESA) -> dict:
    serie = df[df["empresa"] == empresa].sort_values("ejercicio")
    if len(serie) != 5:
        raise ValueError(f"{empresa} no tiene 5 ejercicios en el CSV")
    primero, ultimo = serie.iloc[0], serie.iloc[-1]
    crecimiento = float((ultimo["ingresos"] / primero["ingresos"]) ** (1 / 4) - 1)
    margen = float((serie["ebitda"] / serie["ingresos"]).mean())
    depreciacion = float((serie["depreciacion"] / serie["ingresos"]).mean())
    coste_deuda = float((serie["intereses"] / serie["deuda_total"]).mean())
    activo_corriente = float((serie["activo_corriente"] / serie["ingresos"]).mean())
    liquidez = float((serie["activo_corriente"] / serie["pasivo_corriente"]).mean())
    supuestos = {
        "crecimiento": crecimiento,
        "margen_ebitda": margen,
        "depreciacion_sobre_ingresos": depreciacion,
        "coste_deuda": coste_deuda,
        "activo_corriente_sobre_ingresos": activo_corriente,
        "liquidez": liquidez,
        "tasa_impuestos": TASA_IMPUESTOS,
        "caja_inicial": CAJA_INICIAL,
        "dividendos": 0.0,
        "amortizacion_deuda": 0.0,
    }
    print(
        f"supuestos {empresa}: crecimiento {crecimiento:.1%} · margen {margen:.1%} · "
        f"coste deuda {coste_deuda:.1%}"
    )
    return supuestos


def supuestos_adversos(base: dict) -> dict:
    """Escenario adverso declarado: sin crecimiento, tres puntos menos de margen y 150 pb más de deuda."""
    adverso = dict(base)
    adverso["crecimiento"] = 0.0
    adverso["margen_ebitda"] = base["margen_ebitda"] - 0.03
    adverso["coste_deuda"] = base["coste_deuda"] + 0.015
    return adverso


# Paso 5 · Construye los tres estados desde los mismos supuestos
# Por qué: resultados, balance y caja tienen que salir del mismo juego de supuestos; si cada estado se
#          calcula por su lado, el cuadre se fuerza y deja de probar nada. El flujo de caja usa la
#          inversión como supuesto declarado (inversión = depreciación en estado estacionario).
# Salida esperada: "estados: 5 ejercicios · cuadre máximo 0.0000 M€ · caja final 411.7 M€"
# Si falla: el cuadre no es cero → revisa el orden de la variación de capital circulante.
def construir_estados(df: pd.DataFrame, empresa: str, supuestos: dict) -> pd.DataFrame:
    serie = df[df["empresa"] == empresa].sort_values("ejercicio")
    ultimo = serie.iloc[-1]
    ingresos = float(ultimo["ingresos"])
    patrimonio = float(ultimo["patrimonio_neto"])
    deuda = float(ultimo["deuda_total"])
    activo_corriente = float(ultimo["activo_corriente"])
    pasivo_corriente = float(ultimo["pasivo_corriente"])
    activo_no_corriente = float(ultimo["pasivo_corriente"] + ultimo["deuda_total"] + ultimo["patrimonio_neto"] - ultimo["activo_corriente"])
    caja = supuestos["caja_inicial"]
    filas = []
    for anio in range(1, ANIOS + 1):
        ingresos_previos = ingresos
        ingresos = ingresos_previos * (1 + supuestos["crecimiento"])
        ebitda = ingresos * supuestos["margen_ebitda"]
        depreciacion = ingresos * supuestos["depreciacion_sobre_ingresos"]
        intereses = deuda * supuestos["coste_deuda"]
        antes_impuestos = ebitda - depreciacion - intereses
        impuestos = max(0.0, antes_impuestos) * supuestos["tasa_impuestos"]
        beneficio = antes_impuestos - impuestos
        inversion = depreciacion  # supuesto declarado: capex de reposición
        ac_previo, pc_previo = activo_corriente, pasivo_corriente
        activo_corriente = ingresos * supuestos["activo_corriente_sobre_ingresos"]
        pasivo_corriente = activo_corriente / supuestos["liquidez"]
        variacion_capital_circulante = (activo_corriente - pasivo_corriente) - (ac_previo - pc_previo)
        caja_previos = caja
        caja = caja_previos + beneficio + depreciacion - inversion - variacion_capital_circulante
        activo_no_corriente = activo_no_corriente + inversion - depreciacion
        patrimonio = patrimonio + beneficio
        activo_total = activo_corriente + caja + activo_no_corriente
        pasivo_mas_patrimonio = pasivo_corriente + deuda + patrimonio
        filas.append(
            {
                "ejercicio": int(ultimo["ejercicio"]) + anio,
                "ingresos": ingresos,
                "ebitda": ebitda,
                "depreciacion": depreciacion,
                "intereses": intereses,
                "impuestos": impuestos,
                "beneficio_neto": beneficio,
                "inversion": inversion,
                "variacion_capital_circulante": variacion_capital_circulante,
                "caja_inicial": caja_previos,
                "caja_final": caja,
                "variacion_caja": caja - caja_previos,
                "activo_corriente": activo_corriente,
                "activo_no_corriente": activo_no_corriente,
                "deuda_total": deuda,
                "patrimonio_neto": patrimonio,
                "activo_total": activo_total,
                "pasivo_mas_patrimonio": pasivo_mas_patrimonio,
                "cuadre": activo_total - pasivo_mas_patrimonio,
            }
        )
    tabla = pd.DataFrame(filas)
    print(
        f"estados: {len(tabla)} ejercicios · cuadre máximo {tabla['cuadre'].abs().max():.4f} M€ · "
        f"caja final {tabla['caja_final'].iloc[-1]:.1f} M€"
    )
    return tabla


# Paso 6 · Compara el escenario base con el adverso
# Por qué: un escenario sin cifras no es un escenario; la tabla lleva las métricas de cada caso y su
#          diferencia, para que se vea cuánto cuesta el shock y no solo que «va peor».
# Salida esperada: "escenarios: base beneficio acumulado 1.436 M€ · adverso 965 M€ · diferencia -471 M€"
# Si falla: base y adverso idénticos → no se aplicó el shock a los supuestos.
def comparar_escenarios(df: pd.DataFrame, empresa: str = EMPRESA) -> tuple[pd.DataFrame, dict, dict]:
    base = supuestos_base(df, empresa)
    adverso = supuestos_adversos(base)
    estados_base = construir_estados(df, empresa, base)
    estados_adversos = construir_estados(df, empresa, adverso)
    metricas = {
        "beneficio_acumulado": "beneficio_neto",
        "caja_final": "caja_final",
        "patrimonio_final": "patrimonio_neto",
        "ingresos_finales": "ingresos",
    }
    filas = []
    for nombre, columna in metricas.items():
        valor_base = float(estados_base[columna].sum() if nombre == "beneficio_acumulado" else estados_base[columna].iloc[-1])
        valor_adverso = float(estados_adversos[columna].sum() if nombre == "beneficio_acumulado" else estados_adversos[columna].iloc[-1])
        filas.append({"metrica": nombre, "base": valor_base, "adverso": valor_adverso, "diferencia": valor_adverso - valor_base})
    tabla = pd.DataFrame(filas)
    print(
        f"escenarios: base beneficio acumulado {tabla.loc[0, 'base']:.0f} M€ · "
        f"adverso {tabla.loc[0, 'adverso']:.0f} M€ · diferencia {tabla.loc[0, 'diferencia']:.0f} M€"
    )
    return tabla, base, adverso


def tabla_markdown(df: pd.DataFrame) -> str:
    """Tabla markdown sin tabulate: cabecera, separador y filas con dos decimales."""
    cabecera = "| " + " | ".join(df.columns) + " |"
    separador = "| " + " | ".join("---" for _ in df.columns) + " |"
    filas = []
    for _, fila in df.iterrows():
        filas.append("| " + " | ".join(f"{v:.2f}" if isinstance(v, (float, np.floating)) else str(v) for v in fila) + " |")
    return "\n".join([cabecera, separador, *filas])


def texto_informe(estados_base: pd.DataFrame, escenarios: pd.DataFrame, supuestos: dict) -> str:
    lineas = [
        "# P50 · Modelo de 3 estados con escenarios",
        "",
        f"Empresa: **{EMPRESA}**. Cinco ejercicios proyectados (2026–2030) desde el último del CSV (2025).",
        "",
        "## Supuestos declarados",
        f"- Crecimiento de ingresos: {supuestos['crecimiento']:.2%} (CAGR 2021–2025 de la empresa).",
        f"- Margen EBITDA: {supuestos['margen_ebitda']:.2%} (media histórica).",
        f"- Coste de la deuda: {supuestos['coste_deuda']:.2%} (intereses / deuda media).",
        "- Inversión (capex): igual a la depreciación, estado estacionario. **Supuesto**: el CSV no trae capex.",
        f"- Caja inicial: {supuestos['caja_inicial']:.0f} M€. **Supuesto**: el CSV no trae caja.",
        "- Dividendos 0 y deuda constante: **supuesto declarado**, el CSV no trae dividendos ni vencimientos.",
        "- El activo no corriente es derivado: pasivo corriente + deuda + patrimonio − activo corriente.",
        "",
        "## Estados proyectados (base)",
        tabla_markdown(estados_base[["ejercicio", "ingresos", "ebitda", "beneficio_neto", "caja_final", "patrimonio_neto", "activo_total", "pasivo_mas_patrimonio", "cuadre"]]),
        "",
        "## Escenarios",
        tabla_markdown(escenarios),
        "",
        "## Límite",
        "El CSV es sintético (semilla fija, CC0-1.0) y no es de ninguna empresa real: el modelo demuestra",
        "que los estados se construyen y cuadran, no que la empresa valga lo que sale. El contraste con",
        "estados reales de la SEC (empresas de EE. UU.) queda fuera de este código offline. No hay",
        "dividendos, caja, capex ni tipos reales en el CSV.",
        "",
    ]
    return "\n".join(lineas)


def main() -> int:
    df = cargar_fundamentales()
    validar_identidades(df)
    derivar_balance(df)
    escenarios, base, adverso = comparar_escenarios(df)
    estados = construir_estados(df, EMPRESA, base)
    RESULTADOS.mkdir(exist_ok=True)
    pd.DataFrame(
        [{"supuesto": k, "valor": v, "fuente": "histórico CSV" if k not in ("caja_inicial",) else "supuesto declarado"} for k, v in base.items()]
    ).to_csv(RESULTADOS / "supuestos.csv", index=False)
    estados.to_csv(RESULTADOS / "estados.csv", index=False)
    escenarios.to_csv(RESULTADOS / "escenarios.csv", index=False)
    (RESULTADOS / "informe.md").write_text(texto_informe(estados, escenarios, base), encoding="utf-8")
    print(f"escrito: {RESULTADOS / 'estados.csv'} · escenarios.csv · supuestos.csv · informe.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
