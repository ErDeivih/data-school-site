#!/usr/bin/env python3
"""Puerta del proyecto P50 · modelo financiero de 3 estados con escenarios.

Recalcula las identidades contables, deriva el balance, construye los tres estados y comprueba que
cuadran y que el flujo de caja sale del beneficio y la depreciación. No usa red y **no escribe
ficheros**: solo calcula y saca conclusiones por stdout.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import modelo

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P50 · modelo financiero de 3 estados ==")

    # Paso 1 · Comprueba la forma del panel antes de modelar
    # Por qué: con una clave repetida o un ejercicio que falta, el acumulado de patrimonio miente.
    # Salida esperada: "datos: 50 filas · 10 empresas · 5 ejercicios"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    df = modelo.cargar_fundamentales()
    ok(
        (len(df), df["empresa"].nunique(), df["ejercicio"].nunique()) == (50, 10, 5),
        f"datos: {len(df)} filas · {df['empresa'].nunique()} empresas · {df['ejercicio'].nunique()} ejercicios",
    )

    # Paso 2 · Comprueba las tres identidades contables del CSV
    # Por qué: el modelo hereda cualquier error del origen; se exige la diferencia máxima tolerando
    #          el redondeo a una décima de millón del fichero.
    # Salida esperada: "identidades: beneficio 0.0 · impuestos 0.1 · patrimonio 0.0 M€"
    # Si falla: una diferencia > 0,11 M€ → el CSV no es el original.
    identidades = modelo.validar_identidades(df)
    ok(identidades["claves_duplicadas"] == 0, "clave (empresa, ejercicio) única")
    ok(identidades["ejercicios_por_empresa"] == [5], f"cinco ejercicios por empresa: {identidades['ejercicios_por_empresa']}")
    ok(identidades["err_beneficio"] <= 0.11, f"beneficio = EBITDA − dep − intereses − impuestos: error {identidades['err_beneficio']:.2f} M€")
    ok(identidades["err_impuestos"] <= 0.11, f"impuestos al 25 % del resultado positivo: error {identidades['err_impuestos']:.2f} M€")
    ok(identidades["err_patrimonio"] <= 0.11, f"patrimonio = anterior + beneficio: error {identidades['err_patrimonio']:.2f} M€")
    ok(identidades["impuestos_negativos"] == 0, "no hay impuestos negativos")
    ok(identidades["acciones_constantes"], "las acciones no cambian dentro de una empresa")

    # Paso 3 · Deriva el balance y comprueba que el activo no corriente no es negativo
    # Por qué: el CSV no trae activo total; la identidad derivada es la única comprobación posible y
    #          debe ser positiva para que el balance tenga sentido.
    # Salida esperada: "balance: ANC mínimo 529.2 M€ · cuadre máximo 0.0"
    # Si falla: un ANC negativo → pasivos por encima de activos; no se parchea.
    balance = modelo.derivar_balance(df)
    ok(bool((balance["activo_no_corriente"] > 0).all()), "activo no corriente derivado positivo en las 50 filas")
    ok(abs(balance["activo_no_corriente"].min() - 529.2) < 0.1, f"ANC mínimo derivado: {balance['activo_no_corriente'].min():.1f} M€")
    ok(float(balance["cuadre"].abs().max()) < 1e-6, "el balance histórico cuadra por la identidad derivada")

    # Paso 4 · Comprueba los supuestos base y que están declarados
    # Por qué: el escenario base sale del histórico; si se inventara, el modelo no sería reproducible.
    # Salida esperada: "supuestos EMP-A: crecimiento 5.6% · margen 21.0% · coste 3.5%"
    # Si falla: crecimiento fuera de [-0,5; 0,5] → la serie de ingresos no está ordenada por ejercicio.
    base = modelo.supuestos_base(df)
    ok(
        abs(base["crecimiento"] - 0.056294) < 1e-5
        and abs(base["margen_ebitda"] - 0.210001) < 1e-5
        and abs(base["coste_deuda"] - 0.034986) < 1e-5,
        f"supuestos EMP-A: crecimiento {base['crecimiento']:.4f} · margen {base['margen_ebitda']:.4f} · coste {base['coste_deuda']:.4f}",
    )
    ok(
        base["tasa_impuestos"] == 0.25 and base["caja_inicial"] == 0.0
        and base["dividendos"] == 0.0 and base["amortizacion_deuda"] == 0.0,
        "los supuestos que no están en el CSV están declarados (caja, dividendos, deuda, impuestos)",
    )

    # Paso 5 · Construye los estados y comprueba el cuadre y la caja
    # Por qué: el balance se comprueba de verdad ejercicio a ejercicio, no se fuerza con un ajuste; y
    #          el flujo de caja se reconstruye desde beneficio, depreciación e inversión.
    # Salida esperada: "estados: 5 ejercicios · cuadre 0.0 · caja final 1425.0 M€"
    # Si falla: cuadre distinto de cero → la variación de capital circulante no está bien encadenada.
    estados = modelo.construir_estados(df, modelo.EMPRESA, base)
    ok(len(estados) == 5, f"estados: {len(estados)} ejercicios proyectados")
    ok(float(estados["cuadre"].abs().max()) < 1e-6, f"activo = pasivo + patrimonio en cada ejercicio (cuadre máx {estados['cuadre'].abs().max():.2e})")
    flujo = estados["beneficio_neto"] + estados["depreciacion"] - estados["inversion"] - estados["variacion_capital_circulante"]
    ok(bool((flujo - estados["variacion_caja"]).abs().lt(1e-6).all()), "el flujo de caja sale de beneficio y depreciación")
    ok(bool((estados["caja_final"] >= 0).all()), "la caja proyectada no es negativa")
    ultimo = estados.iloc[-1]
    ok(
        abs(ultimo["beneficio_neto"] - 326.394760) < 1e-4
        and abs(ultimo["caja_final"] - 1425.047487) < 1e-3
        and abs(ultimo["patrimonio_neto"] - 3565.291507) < 1e-3,
        f"2030 base: beneficio {ultimo['beneficio_neto']:.2f} · caja {ultimo['caja_final']:.2f} · patrimonio {ultimo['patrimonio_neto']:.2f}",
    )

    # Paso 6 · Comprueba los dos escenarios y su diferencia
    # Por qué: un escenario adverso tiene que ser distinto del base y peor en las métricas de negocio.
    # Salida esperada: "escenarios: base 1454 M€ · adverso 891 M€ · diferencia -564 M€"
    # Si falla: base y adverso iguales → no se aplicó el shock.
    escenarios, base_recalculado, adverso = modelo.comparar_escenarios(df)
    tabla = escenarios.set_index("metrica")
    ok(len(escenarios) == 4, f"escenarios: {len(escenarios)} métricas comparadas")
    ok(
        bool((tabla.loc[["beneficio_acumulado", "caja_final", "patrimonio_final"], "diferencia"] < 0).all()),
        "el escenario adverso empeora beneficio, caja y patrimonio",
    )
    ok(abs(tabla.loc["beneficio_acumulado", "base"] - 1454.491507) < 1e-3,
       f"beneficio acumulado base: {tabla.loc['beneficio_acumulado', 'base']:.2f} M€")
    ok(
        abs(float((adverso["crecimiento"] - 0.0)) < 1e-12) and adverso["margen_ebitda"] < base_recalculado["margen_ebitda"]
        and adverso["coste_deuda"] > base_recalculado["coste_deuda"],
        "el adverso aplica los tres shocks declarados: crecimiento 0, margen −3 pp y deuda +150 pb",
    )

    # Paso 7 · Comprueba unidades y que el informe declara fuente y límite
    # Por qué: mezclar millones de euros con euros por acción rompe los múltiplos; el informe debe
    #          decir qué es supuesto y qué no permite concluir.
    # Salida esperada: "unidades e informe: OK"
    # Si falla: un precio fuera del rango 4,52–32,55 € → se está leyendo otra columna.
    informe = modelo.texto_informe(estados, escenarios, base)
    ok(bool(df["precio_accion"].between(4.52, 32.55).all()), "precio por acción dentro del rango del CSV (4,52–32,55 €)")
    ok("Supuesto" in informe and "Límite" in informe and "sintético" in informe,
       "el informe marca los supuestos y declara el límite de los datos")

    # Paso 8 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (modelo.RAIZ / "modelo.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
