# P50 · Modelo financiero de 3 estados con escenarios — código ejecutable

Construye, para `EMP-A`, cuenta de resultados, balance y estado de caja desde los mismos supuestos,
proyecta cinco ejercicios, comprueba que el balance cuadra (activo = pasivo + patrimonio) y compara un
escenario base con uno adverso. Es el código que acompaña a la ficha
`../../fichas-ideas/p50-modelo-financiero-tres-estados.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** (BSD-3-Clause) y **numpy >= 1.26** (BSD-3-Clause).
- Windows, Linux o macOS: nada específico de la máquina; sin red ni servicios externos.

## Instalación

```powershell
cd proyectos/p50-modelo-financiero-tres-estados/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python modelo.py
```

Recorre los pasos, imprime una línea por paso y escribe en `resultados/` los ficheros `supuestos.csv`,
`estados.csv`, `escenarios.csv` e `informe.md`. Los ficheros generados no viajan en el ZIP: solo
`ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: 50 filas y 10 empresas con 5 ejercicios, las tres
identidades contables (beneficio, impuestos y patrimonio) con el error de redondeo tolerado, el activo
no corriente derivado (mínimo 529,2 M€), los supuestos base de `EMP-A`, el cuadre del balance en los
cinco ejercicios, el flujo de caja reconstruido desde beneficio y depreciación, y los dos escenarios con
su diferencia. Termina en `RESULTADO: VERDE` (0) o `RESULTADO: ROJO` (1). No usa red. La salida real
está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/fundamentales-empresa.csv`: **50 filas × 16 columnas**, diez empresas ficticias
  (`EMP-A`…`EMP-J`), dos por sector, y cinco ejercicios (2021–2025). Importes en **millones de euros**;
  `acciones` en millones y `precio_accion` en euros por acción.
- **Sintético, determinista y CC0-1.0**: copia literal de `datasets/csv/`, con
  `sha256:e05cdc41668342dac3235cc7d8bd8f1871e355f8f720632ce681641c7b63f3cb`; tamaño y columnas en
  `datasets-nuevos-2026-11-05.json`.
- El CSV **no trae** activo total, activo no corriente, capex, variación de capital circulante, caja,
  dividendos, deuda neta ni tipos de interés: el modelo los sustituye por supuestos escritos o por
  identidades derivadas, y lo dice.

## Fuente real y licencia

El código es offline. Para contrastar con datos reales:

- **Estados financieros:** `sec-edgar` (<https://data.sec.gov/api/xbrl/>), sin clave; contenido del
  Gobierno de EE. UU. reutilizable citando a la SEC. Se sustituye el CSV por los hechos XBRL de una
  empresa de EE. UU. No hay API gratuita verificable de cuentas de empresas españolas.
- Dependencias: pandas BSD-3-Clause, numpy BSD-3-Clause.

## Supuestos declarados

- **Base desde el histórico:** crecimiento = CAGR de ingresos 2021–2025; margen = EBITDA/ingresos medio;
  coste de la deuda = intereses/deuda medio; depreciación y activo corriente, proporcionales a ingresos.
- **Capex = depreciación** (estado estacionario). El CSV no trae inversión; es un supuesto.
- **Caja inicial = 0** y el activo no corriente se deriva de la identidad del balance. El CSV no trae
  caja ni activo no corriente.
- **Dividendos = 0 y deuda constante**: no hay reparto ni vencimientos en el CSV.
- **Adverso:** crecimiento 0, margen −3 puntos y coste de la deuda +150 pb. Es un shock declarado, no
  una predicción.
- La caja proyectada crece porque no hay dividendos ni amortización de deuda; el informe lo dice.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y validar el panel | Clave natural, ejercicios completos y unidades | `Calidad de datos` |
| 2 · Identidades contables | Cómo se encadenan beneficio, impuestos y patrimonio | `Datos de mercado y acciones corporativas` |
| 3 · Balance derivado | Derivar lo que falta y comprobar el cuadre | `Reconciliación y pruebas` |
| 4 · Supuestos desde el histórico | Separar dato de supuesto por escrito | `Escribir un informe` |
| 5 · Tres estados y caja | Que resultados, balance y caja salgan del mismo juego | `Datos de mercado y acciones corporativas` |
| 6 · Escenarios base y adverso | Dar cifras al escenario en vez de una frase | `Predicción con incertidumbre` |
| 7 · Verificador offline | Reproducibilidad sin red ni ficheros intermedios | `Testing con pytest` |

## Estructura

```text
codigo/
├── modelo.py              # supuestos, tres estados, escenarios e informe
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas y numpy
├── datos-ejemplo/         # fundamentales-empresa.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **`ModuleNotFoundError: pandas`**: instala las dependencias con el mismo Python que ejecuta los
  scripts.
- **`FileNotFoundError`**: ejecuta desde `codigo/` o falta el CSV de `datos-ejemplo/`.
- **`ValueError: no tiene 5 ejercicios`**: `EMPRESA` apunta a una empresa sin los cinco ejercicios; usa
  una de las diez del CSV.
- **El cuadre no es cero**: revisa el orden de la variación de capital circulante; se calcula como
  (activo corriente − pasivo corriente) del ejercicio menos el del anterior.
- **Caja disparada**: sin dividendos ni amortización de deuda la caja acumula todo el beneficio; es un
  supuesto declarado, no un resultado del mundo real.
