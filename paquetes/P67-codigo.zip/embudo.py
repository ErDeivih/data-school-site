"""P67 · El embudo de activación: dónde se cae el usuario.

Convierte 2.000 eventos en un embudo de cuatro etapas (visita, registro, activación, compra), mide
la conversión entre etapas, la compara por canal y señala la caída que más usuarios cuesta. Sin
librerías: solo la estándar.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("usuario_id", "fecha", "evento", "canal", "minutos_sesion", "plan")
ETAPAS = ("visita", "registro", "activacion", "compra")
EVENTOS = ETAPAS + ("abandono",)
CANALES = ("organico", "pago", "referido")


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: eventos conocidos, usuario y canal no vacíos.
    # Por qué: un evento sin usuario no se puede contar en un embudo; uno desconocido rompe las etapas.
    # Salida esperada: 2000 eventos, 4 etapas y 3 canales.
    # Si falla: «columnas inesperadas», un evento fuera de las etapas o un canal desconocido.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 2000:
        raise ValueError(f"se esperaban 2000 eventos, hay {len(filas)}")
    for fila in filas:
        if fila["evento"] not in EVENTOS:
            raise ValueError(f"evento desconocido: {fila['evento']}")
        if not fila["usuario_id"] or fila["canal"] not in CANALES:
            raise ValueError("usuario vacío o canal desconocido")
    return filas


def embudo(filas: list[dict]) -> list[dict]:
    # Paso 2 · Usuarios únicos por etapa, no eventos: un usuario que visita tres veces cuenta una.
    # Por qué: contar eventos infla la conversión y hace que el embudo parezca mejor de lo que es.
    # Salida esperada: 4 etapas con usuarios únicos y su conversión desde la anterior.
    # Si falla: una etapa con 0 usuarios (no se puede calcular la conversión).
    usuarios = {etapa: set() for etapa in ETAPAS}
    for fila in filas:
        if fila["evento"] not in ETAPAS:
            continue
        usuarios[fila["evento"]].add(fila["usuario_id"])
    salida = []
    anterior = None
    for etapa in ETAPAS:
        n = len(usuarios[etapa])
        if n == 0:
            raise ValueError(f"la etapa {etapa} no tiene usuarios")
        salida.append({"etapa": etapa, "usuarios": n,
                       "conversion": (n / anterior) if anterior else 1.0})
        anterior = n
    return salida


def por_canal(filas: list[dict]) -> dict:
    # Paso 3 · Embudo por canal usando el primer canal de cada usuario.
    # Por qué: mezclar canales esconde que un canal trae volumen y otro convierte.
    # Salida esperada: 3 canales × 4 etapas, con usuarios únicos.
    # Si falla: un usuario aparece sin canal.
    primer_canal = {}
    for fila in sorted(filas, key=lambda f: (f["fecha"], f["usuario_id"])):
        primer_canal.setdefault(fila["usuario_id"], fila["canal"])
    usuarios = defaultdict(set)
    for fila in filas:
        if fila["evento"] not in ETAPAS:
            continue
        usuarios[(primer_canal[fila["usuario_id"]], fila["evento"])].add(fila["usuario_id"])
    salida = {}
    for canal in CANALES:
        salida[canal] = [{"etapa": etapa, "usuarios": len(usuarios[(canal, etapa)])} for etapa in ETAPAS]
    return salida


def caida_mayor(etapas: list[dict]) -> dict:
    # Paso 4 · La caída que más usuarios cuesta, en valor absoluto y relativo.
    # Por qué: la etapa con peor porcentaje no siempre es la que más gente pierde.
    # Salida esperada: una etapa con sus dos lecturas.
    # Si falla: el embudo tiene menos de dos etapas.
    if len(etapas) < 2:
        raise ValueError("hace falta más de una etapa")
    pares = []
    for antes, despues in zip(etapas, etapas[1:]):
        perdidos = antes["usuarios"] - despues["usuarios"]
        pares.append({"de": antes["etapa"], "a": despues["etapa"], "perdidos": perdidos,
                      "caida_pct": (perdidos / antes["usuarios"]) * 100})
    return max(pares, key=lambda x: x["perdidos"])


def main() -> int:
    parser = argparse.ArgumentParser(description="P67 · embudo de activación por etapas y canal")
    parser.add_argument("--csv", default="datos-ejemplo/eventos-app.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    etapas = embudo(filas)
    canales = por_canal(filas)
    caida = caida_mayor(etapas)
    print(f"datos: {len(filas)} eventos · {len({f['usuario_id'] for f in filas})} usuarios · {len(CANALES)} canales · {sum(1 for f in filas if f['evento'] == 'abandono')} abandonos")
    print("embudo (usuarios únicos y conversión desde la etapa anterior):")
    for etapa in etapas:
        print(f"  {etapa['etapa']}: {etapa['usuarios']} · {etapa['conversion'] * 100:.1f} %")
    print(f"caída que más cuesta: {caida['de']} → {caida['a']} · {caida['perdidos']} usuarios ({caida['caida_pct']:.1f} %)")
    print("por canal (visita → compra):")
    for canal in CANALES:
        visitas = canales[canal][0]["usuarios"]
        compras = canales[canal][-1]["usuarios"]
        print(f"  {canal}: {visitas} visitas → {compras} compras · {compras / visitas * 100:.1f} %")
    print("lectura: el embudo dice dónde se pierde gente, no por qué; para el porqué hace falta hablar con usuarios.")
    print("límite: eventos sintéticos de una app; no hay sesiones, atribución ni usuarios repetidos entre canales.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
