# P67 · El embudo de activación: dónde se cae el usuario

Paquete descargable de **Data School** para el proyecto P67. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es de producto: **¿dónde se pierde el usuario?** Con 2.000 eventos de una
app, el embudo queda en **500 visitas → 462 registros → 291 activaciones → 74 compras**; la caída que
más cuesta es **activación → compra** (217 usuarios, 74,6 %). Por canal, el orgánico convierte
22,3 % y el pago 4,6 %: el embudo dice dónde se pierde gente, no por qué.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python embudo.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P67-codigo
python embudo.py --csv datos-ejemplo/eventos-app.csv
```

## Salida esperada

```text
datos: 2000 eventos · 500 usuarios · 3 canales · 322 abandonos
embudo (usuarios únicos y conversión desde la etapa anterior):
  visita: 500 · 100.0 %
  registro: 462 · 92.4 %
  activacion: 291 · 63.0 %
  compra: 74 · 25.4 %
caída que más cuesta: activacion → compra · 217 usuarios (74.6 %)
por canal (visita → compra):
  organico: 238 visitas → 53 compras · 22.3 %
  pago: 197 visitas → 9 compras · 4.6 %
  referido: 65 visitas → 12 compras · 18.5 %
lectura: el embudo dice dónde se pierde gente, no por qué; para el porqué hace falta hablar con usuarios.
límite: eventos sintéticos de una app; no hay sesiones, atribución ni usuarios repetidos entre canales.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/eventos-app.csv`: **2000 filas × 6 columnas**. `usuario_id`, fecha, evento
  (`visita`, `registro`, `activacion`, `compra`, `abandono`), canal, minutos y plan; 500 usuarios.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `eventos-app` del catálogo. No
  describe usuarios reales.
- `sha256`: `f926f5f961c5a338c4479bfbab9398de8986f57d77fd8becada41bee4c054460`.

## Qué enseña cada paso

| Paso | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida eventos, canal y usuario | un evento sin usuario no entra en un embudo |
| 2 · Etapas | usuarios únicos por etapa | evento ≠ usuario |
| 3 · Conversión | paso entre etapas | porcentajes que se pueden comparar |
| 4 · Canales | mismo embudo por canal | volumen no es conversión |
| 5 · Caída | usuarios perdidos y porcentaje | la peor etapa no siempre es la que más cuesta |

## Las trampas que deja a la vista

1. **Contar eventos infla el embudo.** Un usuario que visita tres veces es una visita en el embudo,
   no tres; el código usa conjuntos de `usuario_id`.
2. **El canal se decide por el primer evento.** Si se mezclan canales, el pago parece convertir
   mejor de lo que convierte; el código asigna el primer canal de cada usuario.
3. **La caída absoluta manda.** Activación → compra pierde 217 usuarios (74,6 %), más que cualquier
   otra etapa; es la que hay que mirar primero, aunque otra tenga peor porcentaje.

## Fallos típicos

- **`ModuleNotFoundError: embudo`**: ejecuta desde la carpeta del paquete.
- **`evento desconocido`**: el CSV trae un evento fuera de las etapas y de `abandono`.
- **`la etapa … no tiene usuarios`**: falta una etapa en los datos.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P67-codigo/
├── embudo.py                  # etapas, conversión, canales y caída principal
├── verificar.py               # 18 comprobaciones
├── requirements.txt
├── datos-ejemplo/eventos-app.csv
└── resultados/ejemplo-salida.txt
```

## Límite

Eventos sintéticos de una app; no hay sesiones, atribución multicanal, usuarios entre canales ni
causa de la caída. El embudo describe **este CSV** y ordena dónde mirar; no explica el porqué.
