#!/usr/bin/env python3
"""Puerta del proyecto P67 (el embudo de activación).

Comprueba usuarios únicos por etapa, conversión, canal, caída mayor y ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import embudo

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "eventos-app.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.3f} ≈ {esperado:.3f})")


def main() -> int:
    filas = embudo.leer(CSV)
    ok(len(filas) == 2000, "el CSV tiene 2000 eventos")
    ok(len({f["usuario_id"] for f in filas}) == 500, "hay 500 usuarios únicos")
    ok(sum(1 for f in filas if f["evento"] == "abandono") == 322, "hay 322 abandonos declarados")

    etapas = embudo.embudo(filas)
    ok(len(etapas) == 4, "el embudo tiene 4 etapas")
    ok([e["usuarios"] for e in etapas] == [500, 462, 291, 74], "usuarios únicos por etapa")
    cerca(etapas[1]["conversion"], 0.924, 0.002, "conversión visita → registro")
    cerca(etapas[2]["conversion"], 0.630, 0.002, "conversión registro → activación")
    cerca(etapas[3]["conversion"], 0.254, 0.002, "conversión activación → compra")

    caida = embudo.caida_mayor(etapas)
    ok(caida["de"] == "activacion" and caida["a"] == "compra", "la caída mayor es activación → compra")
    ok(caida["perdidos"] == 217, "la caída cuesta 217 usuarios")
    cerca(caida["caida_pct"], 74.57, 0.1, "la caída relativa es 74,6 %")

    canales = embudo.por_canal(filas)
    ok(set(canales) == set(embudo.CANALES), "hay embudo para los 3 canales")
    ok(all(len(v) == 4 for v in canales.values()), "cada canal tiene 4 etapas")
    ok([canales[c][0]["usuarios"] for c in embudo.CANALES] == [238, 197, 65], "visitas por canal")
    ok([canales[c][-1]["usuarios"] for c in embudo.CANALES] == [53, 9, 12], "compras por canal")
    ok(canales["organico"][-1]["usuarios"] > canales["pago"][-1]["usuarios"], "orgánico convierte más que pago en volumen")

    codigo = (AQUI / "embudo.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
