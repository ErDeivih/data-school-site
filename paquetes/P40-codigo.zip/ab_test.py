#!/usr/bin/env python3
"""P40 · A/B test de principio a fin — código ejecutable.

Congela la hipótesis y la métrica, comprueba el reparto, calcula el tamaño muestral a priori, contrasta
dos proporciones con su intervalo y presenta una decisión con sus límites. Todo local y sin red.

Datos de ejemplo (CC0-1.0, copia literal del portal):
    datos-ejemplo/eventos-app.csv  (2000 filas × 6 columnas)

Uso:
    python ab_test.py            # calcula y escribe resultados/
    python verificar.py          # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
CANAL_A = "organico"
CANAL_B = "pago"
ALPHA = 0.05
POTENCIA = 0.80
P_BASE = 0.15          # supuesto a priori: conversión base esperada del 15 %
MDE = 0.05             # efecto mínimo detectable que nos importaría: 5 puntos porcentuales
Z_ALPHA = 1.959963984540054
Z_BETA = 0.8416212335729143
COMPARACIONES_SECUNDARIAS = 3  # organico-pago, organico-referido y pago-referido


# Paso 1 · Carga los eventos y construye una fila por usuario
# Por qué: la métrica es compra por usuario; contar eventos daría 74 compras sobre 2000 eventos y un
#          denominador que no es el de la unidad de asignación.
# Salida esperada: "usuarios: 500 · organico 238 · pago 197 · referido 65"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/.
def cargar_usuarios() -> pd.DataFrame:
    ruta = DATOS / "eventos-app.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; ejecuta desde la carpeta codigo/")
    df = pd.read_csv(ruta, parse_dates=["fecha"])
    usuarios = df.groupby("usuario_id").agg(canal=("canal", "first"), plan=("plan", "first"))
    usuarios["compra"] = usuarios.index.isin(df.loc[df["evento"] == "compra", "usuario_id"].to_numpy())
    usuarios = usuarios.reset_index()
    print(
        f"usuarios: {len(usuarios)} · organico {int((usuarios['canal'] == 'organico').sum())} · "
        f"pago {int((usuarios['canal'] == 'pago').sum())} · referido {int((usuarios['canal'] == 'referido').sum())}"
    )
    return usuarios


# Paso 2 · Congela la hipótesis y la métrica antes de mirar el resultado
# Por qué: si la variante, la métrica o la dirección se eligen después de ver el p-valor, el test deja de
#          ser un test; esta función se ejecuta antes del contraste y su resultado no se toca.
# Salida esperada: "hipótesis congelada: organico > pago en compra por usuario (α 0,05, potencia 0,80)"
# Si falla: falta una variante en el CSV → el canal no existe; revisa los datos.
def hipotesis() -> dict:
    congelada = {
        "variante_a": CANAL_A,
        "variante_b": CANAL_B,
        "metrica": "compra por usuario",
        "direccion_esperada": "organico > pago",
        "alpha": ALPHA,
        "potencia": POTENCIA,
        "dos_colas": True,
        "regla_parada": "una sola lectura, sin parada anticipada",
    }
    print(
        f"hipótesis congelada: {CANAL_A} > {CANAL_B} en {congelada['metrica']} "
        f"(α {ALPHA:.2f}, potencia {POTENCIA:.2f})"
    )
    return congelada


# Paso 3 · Comprueba el reparto de la muestra y cuenta compras por cohorte
# Por qué: antes de testar se mira si el reparto suma 500 y si cada variante tiene compras; en este CSV
#          el canal lo asignó el generador, no un sorteo, y eso se declara.
# Salida esperada: "reparto: organico 238 (53 compras) · pago 197 (9 compras)"
# Si falla: la suma no es 500 → hay usuarios sin canal.
def reparto(usuarios: pd.DataFrame) -> pd.DataFrame:
    filas = []
    for canal in (CANAL_A, CANAL_B):
        grupo = usuarios[usuarios["canal"] == canal]
        compras = int(grupo["compra"].sum())
        filas.append(
            {
                "variante": canal,
                "usuarios": len(grupo),
                "compras": compras,
                "tasa": compras / len(grupo),
            }
        )
    tabla = pd.DataFrame(filas)
    print(
        f"reparto: {CANAL_A} {tabla.iloc[0]['usuarios']} ({tabla.iloc[0]['compras']} compras) · "
        f"{CANAL_B} {tabla.iloc[1]['usuarios']} ({tabla.iloc[1]['compras']} compras)"
    )
    return tabla


# Paso 4 · Calcula el tamaño muestral a priori y el efecto detectable con la muestra real
# Por qué: sin tamaño no se sabe si el test podía detectar algo; se calcula antes con una proporción base
#          y un efecto mínimo declarados, y se compara con las 238 y 197 que hay.
# Salida esperada: "tamaño: 831 por variante necesarias · muestra real 238/197 · MDE real 9.4 pp"
# Si falla: división por cero → MDE nulo; revisa los supuestos.
def tamano_muestral(p_base: float = P_BASE, mde: float = MDE, alpha: float = ALPHA, potencia: float = POTENCIA) -> dict:
    p2 = p_base + mde
    z_alpha = Z_ALPHA
    z_beta = Z_BETA if potencia == 0.80 else 0.8416212335729143
    n = math.ceil(
        (z_alpha * math.sqrt(2 * p_base * (1 - p_base)) + z_beta * math.sqrt(p_base * (1 - p_base) + p2 * (1 - p2))) ** 2
        / mde ** 2
    )
    return {"n_por_variante": n, "p_base": p_base, "mde": mde, "alpha": alpha, "potencia": potencia}


def mde_detectable(n_a: int, n_b: int, p_pooled: float, alpha: float = ALPHA, potencia: float = POTENCIA) -> float:
    """Efecto mínimo detectable aproximado con la muestra disponible (dos colas)."""
    n_efectivo = 2 / (1 / n_a + 1 / n_b)
    z_alpha = Z_ALPHA
    z_beta = Z_BETA if potencia == 0.80 else 0.8416212335729143
    return (z_alpha + z_beta) * math.sqrt(2 * p_pooled * (1 - p_pooled) / n_efectivo)


# Paso 5 · Contrasta dos proporciones con estadístico z, p-valor exacto y efecto
# Por qué: con 9 compras la aproximación normal es frágil, así que se acompaña de un test exacto de
#          Fisher y de un intervalo de Newcombe para la diferencia; el efecto se da con su intervalo.
# Salida esperada: "test: diferencia 17.70 pp · z 5.26 · p 7e-08 · Fisher 1e-07"
# Si falla: p fuera de [0, 1] → el estadístico o el signo están mal.
def contraste_proporciones(k1: int, n1: int, k2: int, n2: int) -> dict:
    p1, p2 = k1 / n1, k2 / n2
    diferencia = p1 - p2
    p_comun = (k1 + k2) / (n1 + n2)
    error = math.sqrt(p_comun * (1 - p_comun) * (1 / n1 + 1 / n2))
    z = diferencia / error
    p_valor = math.erfc(abs(z) / math.sqrt(2))
    return {
        "p1": p1,
        "p2": p2,
        "diferencia": diferencia,
        "z": z,
        "p_valor_z": p_valor,
        "intervalo": newcombe(k1, n1, k2, n2),
        "p_valor_fisher": fisher_exacto(k1, n1 - k1, k2, n2 - k2),
    }


# Paso 6 · Intervalo de Newcombe para la diferencia de proporciones
# Por qué: con proporciones pequeñas el intervalo normal puede cruzar el cero por debajo; el de Newcombe
#          usa los límites de Wilson de cada proporción y no supone normalidad de la diferencia.
# Salida esperada: "intervalo 95 %: 11.5 pp a 23.8 pp"
# Si falla: límites invertidos → revisa el signo de la diferencia.
def wilson(k: int, n: int, z: float = Z_ALPHA) -> tuple[float, float]:
    p = k / n
    denominador = 1 + z ** 2 / n
    centro = (p + z ** 2 / (2 * n)) / denominador
    medio = z * math.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / denominador
    return max(0.0, centro - medio), min(1.0, centro + medio)


def newcombe(k1: int, n1: int, k2: int, n2: int) -> dict:
    p1, p2 = k1 / n1, k2 / n2
    l1, u1 = wilson(k1, n1)
    l2, u2 = wilson(k2, n2)
    diferencia = p1 - p2
    inferior = diferencia - math.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2)
    superior = diferencia + math.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)
    return {"inferior": inferior, "superior": superior}


# Paso 7 · Test exacto de Fisher para la tabla 2×2
# Por qué: con 9 compras, el p-valor asintótico necesita un contraste que no dependa de la normalidad.
# Salida esperada: "Fisher exacto: p 1e-07"
# Si falla: p > 1 → la suma de probabilidades hipergeométricas está mal acumulada.
def fisher_exacto(a: int, b: int, c: int, d: int) -> float:
    """p-valor bilateral exacto de Fisher para [[a, b], [c, d]]."""
    fila1, fila2 = a + b, c + d
    col1 = a + c
    total = fila1 + fila2

    def probabilidad(x: int) -> float:
        return math.comb(fila1, x) * math.comb(fila2, col1 - x) / math.comb(total, col1)

    observada = probabilidad(a)
    extremos = range(max(0, col1 - fila2), min(fila1, col1) + 1)
    return min(1.0, sum(probabilidad(x) for x in extremos if probabilidad(x) <= observada + 1e-12))


# Paso 8 · Decide con la regla escrita y declara la multiplicidad
# Por qué: la decisión sale de la regla congelada; y si además se comparan las tres cohortes, hay tres
#          pares y se corrige con Bonferroni para no vender un falso positivo.
# Salida esperada: "decisión: se rechaza H0 · p ajustado (3 comparaciones) 2e-07"
# Si falla: el p-valor no es el del contraste → la decisión no es reproducible.
def decision(resultado: dict, alpha: float = ALPHA) -> dict:
    rechaza = resultado["p_valor_z"] < alpha and resultado["diferencia"] > 0
    p_ajustado = min(1.0, resultado["p_valor_fisher"] * COMPARACIONES_SECUNDARIAS)
    print(
        f"decisión: {'se rechaza H0' if rechaza else 'no se rechaza H0'} · "
        f"p ajustado ({COMPARACIONES_SECUNDARIAS} comparaciones) {p_ajustado:.1e}"
    )
    return {
        "rechaza_h0": rechaza,
        "alpha": alpha,
        "comparaciones": COMPARACIONES_SECUNDARIAS,
        "p_ajustado_bonferroni": p_ajustado,
        "efecto": resultado["diferencia"],
        "intervalo": resultado["intervalo"],
    }


def texto_informe(
    congelada: dict,
    tabla_reparto: pd.DataFrame,
    tamano: dict,
    mde_real: float,
    resultado: dict,
    decision_final: dict,
) -> str:
    intervalo = resultado["intervalo"]
    lineas = [
        "# P40 · A/B test de principio a fin",
        "",
        "## Hipótesis congelada (antes de mirar el resultado)",
        f"- Variante A: **{congelada['variante_a']}**; variante B: **{congelada['variante_b']}**.",
        f"- Métrica: **{congelada['metrica']}**. Dirección esperada: {congelada['direccion_esperada']}.",
        f"- α = {congelada['alpha']:.2f}, potencia = {congelada['potencia']:.2f}, dos colas, "
        f"{congelada['regla_parada']}.",
        "",
        "## Diseño y muestra",
        f"- Tamaño necesario con proporción base {tamano['p_base']:.2f} y MDE {tamano['mde']:.2f}: "
        f"**{tamano['n_por_variante']} por variante**. La muestra real es "
        f"{int(tabla_reparto.iloc[0]['usuarios'])} y {int(tabla_reparto.iloc[1]['usuarios'])}: "
        "no llega, y el efecto detectable real es de "
        f"{mde_real:.1%}, no del 5 %.",
        "- **No hubo asignación aleatoria:** el canal lo asignó el generador al crear el usuario. Esto es",
        "  una comparación entre cohortes, no un A/B real, y la diferencia no se puede leer como efecto",
        "  causal del canal.",
        "",
        "## Reparto observado",
        "| variante | usuarios | compras | tasa |",
        "| --- | --- | --- | --- |",
        *[
            f"| {fila.variante} | {fila.usuarios} | {fila.compras} | {fila.tasa:.3f} |"
            for fila in tabla_reparto.itertuples()
        ],
        "",
        "## Resultado",
        f"- Diferencia observada: **{resultado['diferencia']:.2%}** (A − B).",
        f"- Intervalo de Newcombe al 95 %: **{intervalo['inferior']:.2%} a {intervalo['superior']:.2%}**.",
        f"- Test z de dos proporciones: z = {resultado['z']:.2f}, p = {resultado['p_valor_z']:.2e}.",
        f"- Test exacto de Fisher: p = {resultado['p_valor_fisher']:.2e} (con 9 compras en B, el exacto"
        "  es la referencia).",
        "",
        "## Decisión",
        f"- Regla congelada: rechazar H0 si p < {decision_final['alpha']:.2f} y la diferencia va en la"
        "  dirección esperada.",
        f"- Resultado: **{'se rechaza H0' if decision_final['rechaza_h0'] else 'no se rechaza H0'}**.",
        f"- Se hacen {decision_final['comparaciones']} comparaciones por pares entre las tres cohortes;"
        f"  con Bonferroni el p ajustado es {decision_final['p_ajustado_bonferroni']:.2e}.",
        "",
        "## Límite",
        "Los datos son sintéticos y el canal no se sorteó: el test practica el método completo, pero no",
        "demuestra que el canal cause la compra. La muestra no alcanza el tamaño calculado y el efecto",
        "detectable real es mayor que el MDE declarado. No hay parada anticipada ni cambio de métrica, y",
        "no se puede extrapolar a usuarios reales.",
        "",
    ]
    return "\n".join(lineas)


def main() -> int:
    usuarios = cargar_usuarios()
    congelada = hipotesis()
    tabla_reparto = reparto(usuarios)
    tamano = tamano_muestral()
    resultado = contraste_proporciones(
        int(tabla_reparto.iloc[0]["compras"]),
        int(tabla_reparto.iloc[0]["usuarios"]),
        int(tabla_reparto.iloc[1]["compras"]),
        int(tabla_reparto.iloc[1]["usuarios"]),
    )
    p_comun = (int(tabla_reparto.iloc[0]["compras"]) + int(tabla_reparto.iloc[1]["compras"])) / 435
    mde_real = mde_detectable(int(tabla_reparto.iloc[0]["usuarios"]), int(tabla_reparto.iloc[1]["usuarios"]), p_comun)
    decision_final = decision(resultado)
    print(
        f"tamaño: {tamano['n_por_variante']} por variante necesarias · muestra real "
        f"{int(tabla_reparto.iloc[0]['usuarios'])}/{int(tabla_reparto.iloc[1]['usuarios'])} · "
        f"MDE real {mde_real:.1%}"
    )
    RESULTADOS.mkdir(exist_ok=True)
    tabla_reparto.to_csv(RESULTADOS / "reparto.csv", index=False)
    (RESULTADOS / "test.json").write_text(
        json.dumps(
            {
                "hipotesis": congelada,
                "tamano_muestral": tamano,
                "mde_detectable": mde_real,
                "resultado": resultado,
                "decision": decision_final,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    (RESULTADOS / "informe.md").write_text(
        texto_informe(congelada, tabla_reparto, tamano, mde_real, resultado, decision_final),
        encoding="utf-8",
    )
    print(f"escrito: {RESULTADOS / 'informe.md'} · test.json · reparto.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
