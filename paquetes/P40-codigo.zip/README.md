# P40 · A/B test de principio a fin — código ejecutable

Congela la hipótesis y la métrica antes de mirar el resultado, comprueba el reparto, calcula el tamaño
muestral a priori, contrasta dos proporciones con su intervalo de Newcombe y un test exacto de Fisher, y
cierra con una decisión y sus límites. Es el código que acompaña a la ficha
`../../fichas-portfolio/p40-ab-test-completo.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** (BSD-3-Clause). El contraste, los intervalos y Fisher usan `math` de la estándar.
- Windows, Linux o macOS: sin red ni servicios externos.

## Instalación

```powershell
cd proyectos/p40-ab-test-completo/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python ab_test.py
```

Recorre los pasos, imprime una línea por paso y escribe en `resultados/` los ficheros `reparto.csv`,
`test.json` e `informe.md`. Los generados no viajan en el ZIP: solo `ejemplo-salida.txt`.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula en memoria, sin escribir nada: 500 usuarios con 74 compras, el reparto 238/197 y
53/9 compras, la hipótesis congelada, el tamaño muestral de 831 por variante, el efecto mínimo detectable
real (9,43 %), la diferencia de 17,70 pp, el intervalo de Newcombe (11,51 %–23,79 %), z = 5,2565,
p = 1,47e-07, el Fisher exacto (6,81e-08) y la decisión con Bonferroni. Termina en `RESULTADO: VERDE`
(0) o `RESULTADO: ROJO` (1). No usa red. La salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/eventos-app.csv`: **2000 filas × 6 columnas**, 500 usuarios × 4 eventos. La métrica se
  construye desde `evento = compra`, no desde `minutos_sesion`.
- **Sintético, determinista y CC0-1.0**: copia literal del CSV servido por el portal en
  `aprender/web/datos/datasets/eventos-app.csv` (no está en `datasets/csv/` del repositorio), con
  `sha256:f926f5f961c5a338c4479bfbab9398de8986f57d77fd8becada41bee4c054460`.
- El CSV **no trae** asignación aleatoria, fecha de intervención, exposición por usuario, importe de
  compra ni campaña: sin asignación no hay causalidad, solo comparación de cohortes.

## Fuente real y licencia

- **No hay API**: la ficha declara `api: []`; el diseño y el test usan solo el CSV local.
- Datos sintéticos CC0-1.0. Dependencia: pandas BSD-3-Clause.

## Supuestos declarados

- **Proporción base 15 % y efecto mínimo detectable 5 pp** para el tamaño a priori; α = 0,05 y potencia
  = 0,80, dos colas, sin parada anticipada. El tamaño necesario (831 por variante) supera la muestra
  real (238 y 197), así que el efecto detectable real es 9,43 %.
- **Coste/multiplicidad:** el contraste principal es uno; además se comparan las tres cohortes por pares
  (3 comparaciones) y se corrige con Bonferroni.
- **No hubo asignación aleatoria:** el canal lo asignó el generador; la diferencia no se lee como efecto
  causal del canal.
- **Intervalo:** Newcombe (Wilson por proporción), porque con 9 compras la aproximación normal es frágil.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Unidad del test | Usuario, no evento, como denominador | `Población y muestra` |
| 2 · Hipótesis congelada | Escribir la regla antes de mirar | `Contraste de hipótesis` |
| 3 · Tamaño muestral | Potencia y efecto mínimo detectable | `Tamaño muestral` |
| 4 · p-valor y errores | Qué significa α y qué no | `Errores tipo I y II y potencia` |
| 5 · Efecto con intervalo | Dar magnitud, no solo significación | `Intervalos de confianza` |
| 6 · Multiplicidad | Corregir cuando comparas tres pares | `Multiplicidad y FDR` |

## Estructura

```text
codigo/
├── ab_test.py             # hipótesis, tamaño, contraste, intervalo, Fisher y decisión
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas
├── datos-ejemplo/         # eventos-app.csv (CC0-1.0)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **Mirar y parar:** cortar al ver un p-valor bajo infla los falsos positivos; la regla va escrita antes.
- **Cambiar la métrica:** pasar de compra por usuario a minutos después de ver el resultado.
- **Tratar el canal como aleatorio:** es una cohorte del generador, no una intervención.
- **Contar eventos:** 74 compras son usuarios distintos; con `visita` repetida el denominador se dispara.
- **Aproximación normal con 9 compras:** el intervalo puede cruzar el cero; usa Newcombe o Fisher.
- **Tamaño a posteriori:** calcular la potencia después de ver el resultado es circular.
- **`ModuleNotFoundError: pandas`**: instala las dependencias con el mismo Python que ejecuta el script.
