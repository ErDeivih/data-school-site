#!/usr/bin/env python3
"""Puerta del proyecto P40 · A/B test de principio a fin.

Recalcula el reparto, el tamaño muestral, el contraste de proporciones, el intervalo de Newcombe, el
test exacto de Fisher y la decisión con la regla congelada. No usa red y **no escribe ficheros**.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import ab_test

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P40 · A/B test completo ==")

    # Paso 1 · Construye la unidad del test (usuario, no evento)
    # Por qué: la métrica es compra por usuario; con eventos el denominador sería 2000 y la tasa otra.
    # Salida esperada: "usuarios: 500 · organico 238 · pago 197 · referido 65"
    # Si falla: FileNotFoundError → falta el CSV en datos-ejemplo/; el ZIP lo trae.
    usuarios = ab_test.cargar_usuarios()
    ok(len(usuarios) == 500 and usuarios["usuario_id"].is_unique, "500 usuarios únicos, una fila por usuario")
    canales = usuarios["canal"].value_counts()
    ok((int(canales["organico"]), int(canales["pago"]), int(canales["referido"])) == (238, 197, 65),
       f"reparto por canal: {canales.to_dict()}")
    ok(int(usuarios["compra"].sum()) == 74, f"compras por usuario: {int(usuarios['compra'].sum())}")

    # Paso 2 · Comprueba la hipótesis congelada
    # Por qué: la regla y la dirección se escriben antes del test; si cambian después, el p-valor no vale.
    # Salida esperada: "hipótesis: organico > pago en compra por usuario"
    # Si falla: falta un campo de la hipótesis → no está congelada.
    congelada = ab_test.hipotesis()
    ok(
        congelada["variante_a"] == "organico" and congelada["variante_b"] == "pago"
        and congelada["metrica"] == "compra por usuario" and congelada["direccion_esperada"] == "organico > pago"
        and congelada["alpha"] == 0.05 and congelada["potencia"] == 0.80,
        "hipótesis congelada: variantes, métrica, dirección, α y potencia",
    )
    ok("sin parada anticipada" in congelada["regla_parada"], "la regla de parada está escrita antes del test")

    # Paso 3 · Recalcula el reparto y las tasas
    # Por qué: el reparto debe sumar 500 y cada tasa sale de sus usuarios, no de los eventos.
    # Salida esperada: "organico 238 → 53 (22,3 %) · pago 197 → 9 (4,6 %)"
    # Si falla: las tasas no cuadran con las compras → se contaron eventos.
    reparto = ab_test.reparto(usuarios)
    ok(int(reparto["usuarios"].sum()) == 435, "las dos variantes del test suman 435 usuarios (238 + 197)")
    ok(
        (int(reparto.iloc[0]["usuarios"]), int(reparto.iloc[0]["compras"])) == (238, 53)
        and abs(float(reparto.iloc[0]["tasa"]) - 53 / 238) < 1e-12,
        f"variante A: {reparto.iloc[0]['usuarios']} usuarios · {reparto.iloc[0]['compras']} compras",
    )
    ok(
        (int(reparto.iloc[1]["usuarios"]), int(reparto.iloc[1]["compras"])) == (197, 9)
        and abs(float(reparto.iloc[1]["tasa"]) - 9 / 197) < 1e-12,
        f"variante B: {reparto.iloc[1]['usuarios']} usuarios · {reparto.iloc[1]['compras']} compras",
    )

    # Paso 4 · Comprueba el tamaño muestral a priori y el efecto detectable real
    # Por qué: el test no puede detectar un 5 % con esta muestra; hay que decirlo con el número.
    # Salida esperada: "tamaño 831 por variante · MDE real 9.4 %"
    # Si falla: n distinto → los supuestos de proporción base o MDE cambiaron.
    tamano = ab_test.tamano_muestral()
    ok(tamano["n_por_variante"] == 831, f"tamaño necesario: {tamano['n_por_variante']} por variante")
    mde_real = ab_test.mde_detectable(238, 197, 62 / 435)
    ok(abs(mde_real - 0.094338) < 1e-5, f"efecto mínimo detectable con la muestra real: {mde_real:.2%}")

    # Paso 5 · Recalcula el contraste, el intervalo y el test exacto
    # Por qué: el efecto, el p-valor y el intervalo son la afirmación central; se reconstruyen desde las
    #          cuatro celdas de la tabla 2×2.
    # Salida esperada: "efecto 17.70 pp · z 5.26 · p 1.5e-07 · intervalo 11.5–23.8 pp"
    # Si falla: z o p no coinciden → el contraste no es el de dos proporciones.
    resultado = ab_test.contraste_proporciones(53, 238, 9, 197)
    ok(abs(resultado["diferencia"] - 0.177004) < 1e-6, f"efecto observado: {resultado['diferencia']:.4%}")
    ok(abs(resultado["z"] - 5.256523) < 1e-5, f"estadístico z: {resultado['z']:.4f}")
    ok(abs(resultado["p_valor_z"] - 1.468047e-07) < 1e-12, f"p-valor z: {resultado['p_valor_z']:.2e}")
    limite_inferior, limite_superior = resultado["intervalo"]["inferior"], resultado["intervalo"]["superior"]
    ok(
        abs(limite_inferior - 0.115086) < 1e-5 and abs(limite_superior - 0.237936) < 1e-5,
        f"intervalo de Newcombe: {limite_inferior:.2%} a {limite_superior:.2%}",
    )
    ok(limite_inferior < resultado["diferencia"] < limite_superior, "el efecto cae dentro de su intervalo")
    ok(abs(resultado["p_valor_fisher"] - 6.813802e-08) < 1e-12, f"p-valor exacto de Fisher: {resultado['p_valor_fisher']:.2e}")
    l1, u1 = ab_test.wilson(53, 238)
    ok(0 <= l1 < 53 / 238 < u1 <= 1, f"Wilson de A: {l1:.3f}–{u1:.3f}")

    # Paso 6 · Comprueba la decisión y la multiplicidad
    # Por qué: se decide con la regla congelada y se corrige si se comparan las tres cohortes por pares.
    # Salida esperada: "decisión: se rechaza H0 · p ajustado 2.0e-07 (3 comparaciones)"
    # Si falla: la decisión no sale del p-valor congelado.
    decision = ab_test.decision(resultado)
    ok(decision["rechaza_h0"] is True and decision["alpha"] == 0.05, "decisión: se rechaza H0 con α = 0,05")
    ok(
        decision["comparaciones"] == 3
        and abs(decision["p_ajustado_bonferroni"] - min(1.0, resultado["p_valor_fisher"] * 3)) < 1e-15,
        f"p ajustado por 3 comparaciones: {decision['p_ajustado_bonferroni']:.2e}",
    )

    # Paso 7 · Comprueba que el informe declara hipótesis, efecto, intervalo y límite
    # Por qué: el entregable es el informe; un test sin hipótesis ni límite no es un A/B de principio a fin.
    # Salida esperada: "el informe declara hipótesis, intervalo, decisión y que no hubo asignación"
    # Si falla: falta la advertencia de cohortes o el intervalo.
    informe = ab_test.texto_informe(congelada, reparto, tamano, mde_real, resultado, decision)
    ok(
        "Hipótesis congelada" in informe and "No hubo asignación aleatoria" in informe,
        "el informe congela la hipótesis y declara que no hubo asignación aleatoria",
    )
    ok(
        "Intervalo de Newcombe" in informe and "Decisión" in informe and "Límite" in informe,
        "el informe trae el intervalo, la decisión y el límite",
    )
    ok(f"{resultado['p_valor_z']:.2e}" in informe, "el informe cita el p-valor del contraste")

    # Paso 8 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (ab_test.RAIZ / "ab_test.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
