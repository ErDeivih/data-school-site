#!/usr/bin/env python3
"""P48 · Análisis de imágenes: dígitos 8×8 con scikit-learn.

Código ejecutable del proyecto P48 (ruta ciencia). Convierte cada imagen en un vector de 64 píxeles,
reduce con PCA ajustado solo con train, clasifica con scikit-learn y presenta la matriz de confusión
10×10 frente al azar y a una línea base trivial. Repite con una partición más exigente y declara el
límite del juguete.

Uso:
    python imagenes.py            # pipeline completo; escribe las tablas en resultados/
    python imagenes.py limpiar    # borra las tablas generadas

Datos: datos-ejemplo/pixeles-digitos.csv (1200 filas × 66 columnas, CC0-1.0; procedencia en el README).
Sin red: solo numpy, pandas y scikit-learn.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo" / "pixeles-digitos.csv"
RESULTADOS = RAIZ / "resultados"

SEMILLA = 20261105
TEST = 0.30
PIXELES = [f"p{i:02d}" for i in range(64)]
ACCIONES = None
GENERADOS = ["varianza.csv", "matriz.csv", "metricas.json", "particiones.csv"]


def exigir(condicion: bool, mensaje: str) -> None:
    """Aborta con un mensaje legible; el pipeline devuelve 1 y no deja resultados a medias."""
    if not condicion:
        raise RuntimeError(mensaje)


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def cargar() -> pd.DataFrame:
    # Paso 1 · Carga el CSV y comprueba rejilla, clases y rangos
    # Por qué: si las clases no están balanceadas o los píxeles se salen de 0–255, el acierto y la
    #          comparación con el azar dejan de significar lo mismo.
    # Salida esperada: "datos: 1200 filas × 66 columnas · 10 clases × 120 · rango 0-255 · sha256 5b952ad4…"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o recupera el CSV de datos-ejemplo/.
    exigir(DATOS.exists(), f"no existe el dato de ejemplo: {DATOS}")
    df = pd.read_csv(DATOS)
    exigir(list(df.columns) == ["id", *PIXELES, "etiqueta"], "columnas inesperadas")
    exigir(len(df) == 1200, f"se esperaban 1200 filas y hay {len(df)}")
    exigir(df["id"].is_unique, "la columna id tiene duplicados")
    exigir(int(df.isna().sum().sum()) == 0, "el CSV trae valores nulos")
    exigir(sorted(df["etiqueta"].unique()) == list(range(10)), "las clases no son 0–9")
    por_clase = df.groupby("etiqueta").size()
    exigir(bool((por_clase == 120).all()), f"clases desbalanceadas: {por_clase.to_dict()}")
    pixeles = df[PIXELES].to_numpy()
    exigir(float(pixeles.min()) >= 0 and float(pixeles.max()) <= 255, "píxeles fuera de 0–255")
    print(f"datos: {len(df)} filas × {df.shape[1]} columnas · {len(por_clase)} clases × "
          f"{int(por_clase.iloc[0])} · rango {int(pixeles.min())}-{int(pixeles.max())} · "
          f"sha256 {sha256(DATOS)[:8]}…")
    return df


def matriz(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    # Paso 2 · Convierte cada imagen en un vector de 64 columnas
    # Por qué: el modelo no ve la rejilla; ve 64 números. La etiqueta va aparte y el índice del fichero
    #          no entra como variable: la etiqueta cicla cada diez filas y delataría la clase.
    # Salida esperada: "matriz: 1200 × 64 píxeles + etiqueta · el índice no entra como variable"
    # Si falla: forma distinta de (1200, 64) → revisa cómo se seleccionan las columnas p00–p63.
    X = df[PIXELES].to_numpy(dtype=float)
    y = df["etiqueta"].to_numpy(dtype=int)
    exigir(X.shape == (1200, 64), f"matriz con forma {X.shape}")
    print(f"matriz: {X.shape[0]} × {X.shape[1]} píxeles + etiqueta · "
          "el índice del fichero no entra como variable")
    return X, y


def partir(X: np.ndarray, y: np.ndarray) -> dict:
    # Paso 3 · Parte de forma estratificada
    # Por qué: las imágenes vienen de diez plantillas con desplazamientos; un split aleatorio reparte
    #          variantes casi idénticas entre train y test y el acierto sale optimista. Se declara.
    # Salida esperada: "partición: 840 train / 360 test · 10 clases en las dos partes"
    # Si falla: clases de menos en test → falta stratify.
    idx_tr, idx_te = train_test_split(np.arange(len(y)), test_size=TEST, random_state=SEMILLA,
                                      stratify=y)
    exigir(len(set(y[idx_tr])) == 10 and len(set(y[idx_te])) == 10, "clases de menos en la partición")
    print(f"partición: {len(idx_tr)} train / {len(idx_te)} test · {len(set(y[idx_tr]))} clases en "
          "las dos partes · casi duplicados declarados")
    return {"X_tr": X[idx_tr], "X_te": X[idx_te], "y_tr": y[idx_tr], "y_te": y[idx_te],
            "idx_tr": idx_tr, "idx_te": idx_te}


def reducir(particion: dict) -> dict:
    # Paso 4 · Ajusta PCA solo con train y elige componentes por varianza explicada
    # Por qué: si el PCA se ajusta con train y test, la reducción ya ha visto el test; el número de
    #          componentes se justifica con la varianza acumulada que se publica.
    # Salida esperada: "PCA: 64 componentes · 90 % de varianza con N · las 10 primeras explican … %"
    # Si falla: varianza que no crece → revisa que los datos sean 0–255 y no texto.
    X_tr = particion["X_tr"]
    escalador = StandardScaler().fit(X_tr)
    X_tr_esc = escalador.transform(X_tr)
    varianza = PCA().fit(X_tr_esc).explained_variance_ratio_
    acumulada = np.cumsum(varianza)
    componentes = int(np.searchsorted(acumulada, 0.90) + 1)
    exigir(componentes <= 64, f"componentes fuera de rango: {componentes}")
    pca = PCA(n_components=componentes, random_state=SEMILLA).fit(X_tr_esc)
    exigir(np.allclose(np.cumsum(pca.explained_variance_ratio_)[-1], acumulada[componentes - 1],
                       atol=1e-9), "la varianza del PCA reducido no coincide con la acumulada")
    print(f"PCA: 64 componentes · 90 % de varianza con {componentes} componentes · "
          f"las 10 primeras explican {acumulada[9] * 100:.1f} %")
    return {"pca": pca, "escalador": escalador, "componentes": componentes,
            "varianza": varianza, "acumulada": acumulada}


def clasificar(particion: dict, reduccion: dict) -> dict:
    # Paso 5 · Entrena el clasificador sobre las componentes, con escalado dentro del pipeline lógico
    # Por qué: el escalado y el PCA se ajustan solo con train; el modelo no ve el test hasta predecir.
    #          Se usa una SVM de núcleo RBF porque con estos desplazamientos un modelo lineal no pasa
    #          del 30 %: la forma de la frontera importa.
    # Salida esperada: "modelo: acierto fuera de muestra 0.914 · azar 0.100"
    # Si falla: acierto 0,10 → el modelo no aprende; revisa la matriz y la escala.
    escalador = reduccion["escalador"]
    pca = reduccion["pca"]
    modelo = SVC(kernel="rbf", C=10, gamma="scale", random_state=SEMILLA)
    modelo.fit(pca.transform(escalador.transform(particion["X_tr"])), particion["y_tr"])
    pred = modelo.predict(pca.transform(escalador.transform(particion["X_te"])))
    acierto = float((pred == particion["y_te"]).mean())
    print(f"modelo: acierto fuera de muestra {acierto:.3f} · azar 0.100")
    return {"pred": pred, "acierto": acierto, "modelo": modelo, "escalador": escalador}


def evaluar(particion: dict, prediccion: dict) -> dict:
    # Paso 6 · Presenta la matriz de confusión 10×10 y la precisión y recall por clase
    # Por qué: con diez clases balanceadas el 10 % es el azar; el acierto global puede esconder dos
    #          clases confundidas, y la matriz es lo que deja verlo.
    # Salida esperada: "matriz de confusión: 10×10 · precisión macro … · recall macro …"
    # Si falla: la matriz no suma 360 → predicciones y test no son el mismo conjunto.
    y_te, pred = particion["y_te"], prediccion["pred"]
    matriz = np.zeros((10, 10), dtype=int)
    for real, dicho in zip(y_te, pred):
        matriz[real, dicho] += 1
    exigir(int(matriz.sum()) == len(y_te), "la matriz no cubre todo el test")
    precision = []
    recall = []
    for clase in range(10):
        tp = int(matriz[clase, clase])
        precision.append(tp / int(matriz[:, clase].sum()) if matriz[:, clase].sum() else 0.0)
        recall.append(tp / int(matriz[clase, :].sum()) if matriz[clase, :].sum() else 0.0)
    linea_base = float((y_te == 0).mean())
    print(f"matriz de confusión: 10×10 · precisión macro {np.mean(precision):.3f} · "
          f"recall macro {np.mean(recall):.3f} · línea base (siempre 0) {linea_base:.3f}")
    return {"matriz": matriz, "precision": precision, "recall": recall,
            "precision_macro": float(np.mean(precision)), "recall_macro": float(np.mean(recall)),
            "linea_base": linea_base}


def particion_exigente(X: np.ndarray, y: np.ndarray, componentes: int) -> dict:
    # Paso 7 · Repite agrupando por vecindad antes de partir, que es la prueba más exigente
    # Por qué: el split aleatorio deja variantes casi idénticas de la misma plantilla a los dos lados
    #          y el acierto sale optimista. Se agrupan las imágenes por vecindad (kNN), se parte por
    #          grupo y el acierto que queda es la estimación honesta de este juguete.
    # Salida esperada: "partición exigente: 180 grupos · acierto por grupo 0.528 frente a 0.914"
    # Si falla: acierto igual al aleatorio → revisa que los grupos no se mezclen entre train y test.
    vecinos = NearestNeighbors(n_neighbors=13).fit(X)
    indices = vecinos.kneighbors(X, return_distance=False)
    visitado = np.zeros(len(X), dtype=bool)
    grupos: list[list[int]] = []
    for i in range(len(X)):
        if visitado[i]:
            continue
        grupo = [i]
        visitado[i] = True
        for j in indices[i]:
            j = int(j)
            if not visitado[j] and len(grupo) < 12:
                grupo.append(j)
                visitado[j] = True
        grupos.append(grupo)
    generador = np.random.default_rng(SEMILLA)
    orden = generador.permutation(len(grupos))
    corte = int(0.70 * len(grupos))
    idx_tr = np.concatenate([grupos[k] for k in orden[:corte]])
    idx_te = np.concatenate([grupos[k] for k in orden[corte:]])
    exigir(len(set(y[idx_te])) == 10, "la partición por grupos deja clases sin test")
    escalador = StandardScaler().fit(X[idx_tr])
    pca = PCA(n_components=componentes, random_state=SEMILLA).fit(escalador.transform(X[idx_tr]))
    modelo = SVC(kernel="rbf", C=10, gamma="scale", random_state=SEMILLA)
    modelo.fit(pca.transform(escalador.transform(X[idx_tr])), y[idx_tr])
    pred = modelo.predict(pca.transform(escalador.transform(X[idx_te])))
    acierto = float((pred == y[idx_te]).mean())
    print(f"partición exigente: {len(grupos)} grupos por vecindad · acierto {acierto:.3f} "
          f"con {len(idx_tr)} train / {len(idx_te)} test")
    return {"acierto": acierto, "grupos": len(grupos), "train": len(idx_tr), "test": len(idx_te)}


def escribir(reduccion: dict, evaluacion: dict, prediccion: dict, exigente: dict) -> None:
    # Paso 8 · Escribe la varianza, la matriz y las métricas
    # Por qué: cada cifra del README sale de estos ficheros; la variable aleatoria no interviene, así
    #          que reejecutar produce los mismos números.
    # Salida esperada: "resultados: varianza.csv, matriz.csv, metricas.json, particiones.csv"
    # Si falla: PermissionError → revisa permisos de resultados/.
    RESULTADOS.mkdir(exist_ok=True)
    pd.DataFrame({"componente": np.arange(1, len(reduccion["varianza"]) + 1),
                  "varianza_explicada": reduccion["varianza"],
                  "varianza_acumulada": reduccion["acumulada"]}).to_csv(
        RESULTADOS / "varianza.csv", index=False)
    pd.DataFrame(evaluacion["matriz"]).to_csv(RESULTADOS / "matriz.csv", index=False,
                                              header=False)
    (RESULTADOS / "metricas.json").write_text(json.dumps({
        "acierto_test": round(prediccion["acierto"], 4),
        "componentes_pca": reduccion["componentes"],
        "precision_macro": round(evaluacion["precision_macro"], 4),
        "recall_macro": round(evaluacion["recall_macro"], 4),
        "linea_base_siempre_0": round(evaluacion["linea_base"], 4),
        "acierto_particion_exigente": round(exigente["acierto"], 4),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame([
        {"particion": "estratificada 70/30", "acierto": round(prediccion["acierto"], 4)},
        {"particion": "bloques contiguos", "acierto": round(exigente["acierto"], 4)},
        {"particion": "azar (10 clases)", "acierto": 0.1},
        {"particion": "línea base siempre 0", "acierto": round(evaluacion["linea_base"], 4)},
    ]).to_csv(RESULTADOS / "particiones.csv", index=False)
    print("resultados: varianza.csv, matriz.csv, metricas.json, particiones.csv")


def limpiar() -> None:
    # Paso 9 · Borra las tablas generadas y deja la carpeta como descargada
    # Por qué: el ZIP no lleva derivados; se regeneran con `python imagenes.py`.
    # Salida esperada: "limpiar: resultados/ generados borrados"
    # Si falla: PermissionError → cierra el programa que tenga abierto un CSV de resultados/.
    for nombre in GENERADOS:
        (RESULTADOS / nombre).unlink(missing_ok=True)
    print("limpiar: resultados/ generados borrados")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Dígitos 8×8 con PCA y scikit-learn (P48)")
    parser.add_argument("accion", nargs="?", default="todo", choices=["todo", "limpiar"])
    args = parser.parse_args(argv)
    if args.accion == "limpiar":
        limpiar()
        return 0
    try:
        df = cargar()
        X, y = matriz(df)
        particion = partir(X, y)
        reduccion = reducir(particion)
        prediccion = clasificar(particion, reduccion)
        evaluacion = evaluar(particion, prediccion)
        exigente = particion_exigente(X, y, reduccion["componentes"])
        escribir(reduccion, evaluacion, prediccion, exigente)
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con resultados a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
