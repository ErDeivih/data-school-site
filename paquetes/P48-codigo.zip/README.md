# P48 · Análisis de imágenes: dígitos 8×8 con scikit-learn — código ejecutable

El proyecto completo sobre el CSV sintético de 1200 imágenes de 8×8: convierte cada imagen en un
**vector de 64 píxeles**, reduce con **PCA ajustado solo con train** (45 componentes explican el 90 %
de la varianza), clasifica con **SVM de núcleo RBF** y presenta la **matriz de confusión 10×10** frente
al azar del 10 % y a la línea base trivial. Cierra con una **partición por vecindad** que revela el
sesgo de los casi duplicados. Es el código que acompaña a la ficha
`../../fichas-portfolio/p48-imagenes-8x8.md`.

El resultado que enseña el proyecto: el acierto fuera de muestra es **0,914** frente al **0,10** del
azar, con precisión macro 0,917 y las diez clases presentes en la matriz; pero al partir **agrupando
por vecindad** (180 grupos) el acierto cae a **0,525**. Esa caída es la prueba de que el 0,914 está
inflado por variantes casi idénticas de la misma plantilla, y el README lo declara en vez de vender
generalización.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **numpy** (2.5.2), **pandas** (3.0.6) y **scikit-learn** (1.9.1). Se instalan en un comando.
- Windows, Linux o macOS. No hace falta red: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p48-imagenes-8x8/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide las tres dependencias. Licencias: numpy, pandas y scikit-learn son BSD-3-Clause.

## Orden de ejecución

```powershell
python imagenes.py          # carga, matriz, PCA, clasificación, matriz de confusión y tablas
python imagenes.py limpiar  # borra las tablas generadas y deja la carpeta como se descargó
```

La salida esperada de una ejecución es esta:

```text
datos: 1200 filas × 66 columnas · 10 clases × 120 · rango 0-255 · sha256 5b952ad4…
matriz: 1200 × 64 píxeles + etiqueta · el índice del fichero no entra como variable
partición: 840 train / 360 test · 10 clases en las dos partes · casi duplicados declarados
PCA: 64 componentes · 90 % de varianza con 45 componentes · las 10 primeras explican 43.0 %
modelo: acierto fuera de muestra 0.914 · azar 0.100
matriz de confusión: 10×10 · precisión macro 0.917 · recall macro 0.914 · línea base (siempre 0) 0.100
partición exigente: 180 grupos por vecindad · acierto 0.525 con 827 train / 373 test
resultados: varianza.csv, matriz.csv, metricas.json, particiones.csv
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula el crudo, la matriz, la partición, la varianza del PCA y la clasificación;
comprueba que el PCA está centrado en el train escalado (no en todo el dataset), que los componentes
elegidos llegan al 90 % y uno menos no, que la matriz 10×10 suma 360, que el acierto supera con holgura
el azar, que la línea base es el 10 % y que la partición por vecindad baja el acierto más de 20 puntos.
No usa red y no escribe nada. Termina en `RESULTADO: VERDE` (código 0) con **26 comprobaciones**; la
salida real está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- [`datos-ejemplo/pixeles-digitos.csv`](datos-ejemplo/pixeles-digitos.csv): **1200 filas × 66 columnas**
  (`id`, `p00`…`p63`, `etiqueta`). 10 clases × 120 imágenes; píxeles 0–255; `id` único.
- sha256 del fichero:
  `5b952ad4297923f67284ebab2e377bfcb7ad6fd1511fdf7ad5adfb32fac7928c`. Es copia literal del conjunto
  de práctica del portal del temario (`web/datos/datasets/pixeles-digitos.csv`), sintético, semilla
  20261112 y licencia **CC0-1.0**: no son dígitos escritos por personas.

Basta con ese CSV: el proyecto se ejecuta sin descargar nada. Para usar datos propios, se copian en
`datos-ejemplo/` con las mismas columnas o se edita la constante `DATOS` de `imagenes.py`.

## Fuente real y licencia

- El catálogo no asigna API (`api: []`): el flujo se demuestra **solo con el CSV local**.
- Los datos son sintéticos: plantillas con desplazamiento y ruido; no sustituyen un problema real de
  imágenes.
- scikit-learn, numpy y pandas: BSD-3-Clause.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y validar | Rejilla, clases balanceadas y rangos | NumPy: fundamentos |
| 2 · Convertir en matriz | Una imagen es un vector de 64 números | Escalares, vectores y matrices |
| 3 · Partir estratificado | Train y test con las diez clases | Train, validación y test |
| 4 · Reducir con PCA | Varianza explicada y componentes justificados | PCA |
| 5 · Clasificar con SVM | Frontera no lineal y semilla fija | SVM |
| 6 · Leer la confusión | Precisión y recall por clase, no solo acierto | Matriz de confusión |
| 7 · Partición por vecindad | Casi duplicados y estimación honesta | La maldición de la dimensionalidad |
| 8 · Verificador offline | Comprobar sin red y sin escribir | Testing con pytest |

## Estructura

```text
codigo/
├── imagenes.py           # pipeline: matriz, partición, PCA, clasificación y evaluación
├── verificar.py          # la puerta del proyecto (26 comprobaciones, sin red, sin escribir)
├── requirements.txt      # numpy, pandas, scikit-learn
├── datos-ejemplo/
│   └── pixeles-digitos.csv   # 1200 × 66 · CC0-1.0
└── resultados/
    └── ejemplo-salida.txt
```

Las tablas que escribe `python imagenes.py` (`varianza.csv`, `matriz.csv`, `metricas.json`,
`particiones.csv`) no viajan en el ZIP: se regeneran.

## Fallos típicos

- **`ModuleNotFoundError: sklearn`**: instala con `python -m pip install -r requirements.txt` con el
  mismo intérprete que lanza el pipeline.
- **PCA con test**: ajustar el PCA o el escalado con todo el dataset es fuga; aquí se ajustan solo con
  train y la puerta lo comprueba contra la media del train.
- **Escala olvidada**: los píxeles van de 0 a 255; el escalado va antes del PCA y dentro del flujo de
  train.
- **Solo acierto global**: con diez clases balanceadas el 10 % es el azar; un 91 % puede esconder dos
  clases confundidas, por eso la matriz es 10×10.
- **Usar el orden de las filas**: la etiqueta cicla cada diez filas; el índice del fichero no entra
  como variable.
- **Vender generalización**: el split aleatorio reparte casi duplicados y da 0,914; la partición por
  vecindad da 0,525 y es la cifra honesta de este juguete.
- **Confundir con el dataset de scikit-learn**: los valores y las plantillas son otros; no se comparan
  cifras de un tutorial.
