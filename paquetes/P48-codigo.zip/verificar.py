#!/usr/bin/env python3
"""Puerta del proyecto P48 (dígitos 8×8 con PCA y scikit-learn).

Comprueba el resultado de verdad, sin escribir nada y sin red: el CSV es el del catálogo (sha256) y
tiene 120 imágenes por clase, la matriz es de 64 píxeles sin la etiqueta, el PCA se ajusta solo con
train y justifica sus componentes, la matriz de confusión 10×10 cuadra con el test, el acierto supera
con holgura el azar del 10 % y la partición por vecindad deja ver el sesgo de los casi duplicados.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np

import imagenes as p

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P48 · dígitos 8×8 con PCA ==")

    # Paso 1 · Comprueba el crudo: 1200 filas, 66 columnas, 120 por clase y rango 0–255
    # Por qué: con clases desbalanceadas o píxeles fuera de rango, el 10 % del azar deja de ser la
    #          referencia y la matriz de confusión no se lee igual.
    # Salida esperada: "datos: 1200 filas × 66 columnas · 10 clases × 120 · rango 0-255"
    # Si falla: FileNotFoundError → falta datos-ejemplo/pixeles-digitos.csv (el ZIP lo trae).
    df = p.cargar()
    ok(len(df) == 1200 and df.shape[1] == 66, f"CSV: {len(df)} filas × {df.shape[1]} columnas")
    ok(p.sha256(p.DATOS) == "5b952ad4297923f67284ebab2e377bfcb7ad6fd1511fdf7ad5adfb32fac7928c",
       "el sha256 del CSV de ejemplo es el de la copia del catálogo")
    ok(bool((df.groupby("etiqueta").size() == 120).all()), "120 imágenes por dígito en las 10 clases")
    ok(bool(df["id"].is_unique), "el id es único (1200 identificadores)")

    # Paso 2 · Comprueba la matriz y que el índice del fichero no entra como variable
    # Por qué: la etiqueta cicla cada diez filas; si el índice se colara como columna, el modelo
    #          aprendería el fichero y no la imagen.
    # Salida esperada: "matriz: 1200 × 64 píxeles + etiqueta"
    # Si falla: forma distinta de (1200, 64) → revisa la selección de p00–p63.
    X, y = p.matriz(df)
    ok(X.shape == (1200, 64) and y.shape == (1200,), f"matriz: {X.shape} y {y.shape}")
    ok(sorted(np.unique(y)) == list(range(10)), "las etiquetas son 0–9")
    ok(list(y[:10]) == list(range(10)), "las filas ciclan la etiqueta (0…9): el orden se declara")
    ok(not any(np.array_equal(X[:, k], np.arange(1200)) for k in range(X.shape[1])),
       "ninguna columna de la matriz es el índice de fila")

    # Paso 3 · Comprueba la partición estratificada
    # Por qué: las variantes casi idénticas de una plantilla se reparten entre train y test; se
    #          declara el sesgo y se usa estratificación para que las diez clases estén en las dos.
    # Salida esperada: "partición: 840 train / 360 test · 10 clases en las dos partes"
    # Si falla: clases de menos en test → falta stratify.
    particion = p.partir(X, y)
    ok(len(particion["y_tr"]) == 840 and len(particion["y_te"]) == 360,
       f"partición: {len(particion['y_tr'])} train / {len(particion['y_te'])} test")
    ok(len(set(particion["y_tr"])) == 10 and len(set(particion["y_te"])) == 10,
       "las diez clases están en train y en test")

    # Paso 4 · Comprueba que el PCA se ajusta solo con train y justifica componentes
    # Por qué: ajustar el PCA con train y test es fuga; la varianza explicada y el número de
    #          componentes se publican para justificar la decisión.
    # Salida esperada: "PCA: 90 % de varianza con 45 componentes · las 10 primeras explican 43.0 %"
    # Si falla: la media del PCA no es la del train escalado → se ajustó con todo el dataset.
    reduccion = p.reducir(particion)
    ok(np.allclose(reduccion["pca"].mean_, 0.0, atol=1e-9),
       "el PCA está centrado en el train escalado (media 0)")
    media_train = X[particion["idx_tr"]].mean(axis=0)
    ok(np.allclose(reduccion["escalador"].mean_, media_train, atol=1e-9),
       "el escalado se ajustó solo con las filas de train")
    acumulada = reduccion["acumulada"]
    ok(len(acumulada) == 64 and np.all(np.diff(acumulada) >= -1e-12), "varianza acumulada monótona")
    ok(acumulada[reduccion["componentes"] - 1] >= 0.90, "los componentes elegidos llegan al 90 %")
    ok(acumulada[reduccion["componentes"] - 2] < 0.90, "un componente menos no llega al 90 %")

    # Paso 5 · Comprueba la clasificación fuera de muestra y la matriz 10×10
    # Por qué: el criterio de la ficha es una matriz completa y un acierto que supere el azar; se
    #          recalcula la matriz desde las predicciones y se compara con el azar y la línea base.
    # Salida esperada: "modelo: acierto 0.914 · matriz 10×10 con precisión macro 0.917"
    # Si falla: la matriz no suma 360 → las predicciones no son del test.
    prediccion = p.clasificar(particion, reduccion)
    evaluacion = p.evaluar(particion, prediccion)
    ok(prediccion["acierto"] > 0.80, f"acierto fuera de muestra: {prediccion['acierto']:.3f}")
    ok(prediccion["acierto"] > 2 * 0.10, "el acierto supera con holgura el azar del 10 %")
    ok(int(evaluacion["matriz"].sum()) == 360, "la matriz 10×10 suma 360")
    ok(bool((evaluacion["matriz"].sum(axis=1) > 0).all()), "las diez clases aparecen en el test")
    ok(abs(evaluacion["precision_macro"] - np.mean(evaluacion["precision"])) < 1e-12,
       f"precisión macro {evaluacion['precision_macro']:.3f} coherente")
    ok(abs(evaluacion["linea_base"] - 0.1) < 0.03,
       f"línea base (siempre 0): {evaluacion['linea_base']:.3f}")
    prediccion2 = p.clasificar(particion, reduccion)
    ok(np.array_equal(prediccion["pred"], prediccion2["pred"]),
       "dos entrenamientos con la misma semilla dan las mismas predicciones")

    # Paso 6 · Comprueba la partición exigente por vecindad
    # Por qué: es la prueba que revela el sesgo de los casi duplicados; si el acierto no bajara, no
    #          habría nada que declarar y el informe lo diría igual.
    # Salida esperada: "partición exigente: 180 grupos · acierto 0.525 frente a 0.914"
    # Si falla: acierto igual al aleatorio → revisa que los grupos no se mezclen entre train y test.
    exigente = p.particion_exigente(X, y, reduccion["componentes"])
    ok(exigente["grupos"] == 180 and exigente["train"] + exigente["test"] == 1200,
       f"grupos de vecindad: {exigente['grupos']} · {exigente['train']} train / {exigente['test']} test")
    ok(exigente["acierto"] < prediccion["acierto"] - 0.20,
       f"por grupos baja el acierto: {exigente['acierto']:.3f} frente a {prediccion['acierto']:.3f}")

    # Paso 7 · Comprueba que el código es offline y no lleva secretos
    # Por qué: la puerta se ejecuta sin red y la carpeta se comparte.
    # Salida esperada: "código offline, sin claves"
    # Si falla: aparece una llamada de red o un token en el código.
    texto = (p.RAIZ / "imagenes.py").read_text(encoding="utf-8")
    ok(not any(x in texto for x in ("import requests", "import urllib", "import socket",
                                    "urlopen(", "requests.get")),
       "el código no hace peticiones de red")
    ok(not any(x in texto for x in ("ghp_", "github_pat_", "Authorization:")),
       "el código no contiene claves ni cabeceras de autorización")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
