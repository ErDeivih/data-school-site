#!/usr/bin/env python3
"""Puerta del proyecto P25 (factores: separar el mercado del estilo).

Comprueba grano, alineación de factores, recuperación de las cargas conocidas, errores típicos,
intervalos, corrección por pruebas múltiples y que el código no usa red ni claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import analizar

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "factores-cartera.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = analizar.leer(CSV)
    ok(len(filas) == 300, "el CSV tiene 300 filas")
    ok(len({f["mes"] for f in filas}) == 60, "hay 60 meses")
    ok({f["activo"] for f in filas} == set(analizar.ACCIONES), "están las 5 acciones")
    ok(all(sum(1 for f in filas if f["activo"] == a) == 60 for a in analizar.ACCIONES),
       "cada acción tiene los 60 meses")

    meses, x, y = analizar.matrices(filas)
    ok(len(meses) == 60 and len(x) == 60 and len(y) == 5, "matrices alineadas: 60 × 3 factores y 5 series")
    ok(all(len(fila) == 3 for fila in x), "cada fila de X tiene 3 factores")
    medias = [sum(fila[i] for fila in x) / len(x) for i in range(3)]
    cerca(medias[0], 0.0102, 0.001, "media mensual del factor mercado")
    cerca(medias[1], -0.0003, 0.001, "media mensual del factor tamaño")
    cerca(medias[2], -0.0009, 0.001, "media mensual del factor valor")

    resultado = analizar.analizar(x, y)
    cargas = {
        "accion-a": (0.970, -0.322, 0.069),
        "accion-b": (1.201, 0.361, -0.172),
        "accion-c": (0.807, 0.203, 0.581),
        "accion-d": (1.069, 0.768, 0.214),
        "accion-e": (0.898, -0.410, -0.287),
    }
    for accion, (bm, bs, bv) in cargas.items():
        cerca(resultado[accion]["beta"][1], bm, 0.05, f"{accion}: carga de mercado")
        cerca(resultado[accion]["beta"][2], bs, 0.05, f"{accion}: carga de tamaño")
        cerca(resultado[accion]["beta"][3], bv, 0.05, f"{accion}: carga de valor")
        ok(resultado[accion]["r2"] > 0.9, f"{accion}: los tres factores explican más del 90 % (R² > 0,9)")
    cerca(resultado["accion-d"]["alpha_anual"], 0.0299, 0.004, "alpha anual de d (el único que roza la significación)")
    ok(resultado["accion-d"]["alpha_anual_bajo"] > 0, "el intervalo del alpha de d no cruza 0 sin corregir")
    ok(resultado["accion-a"]["alpha_anual_bajo"] < 0 < resultado["accion-a"]["alpha_anual_alto"],
       "el alpha de a cruza 0")

    correccion = analizar.pruebas_multiples(resultado)
    ok(correccion["alphas"]["familia"] == 5, "familia de alphas: 5 pruebas")
    ok(correccion["alphas"]["sin_corregir"] == 1, "sin corregir hay 1 alpha con p < 0,05")
    ok(correccion["alphas"]["bonferroni"] == 0, "con Bonferroni no sobrevive el alpha")
    ok(correccion["alphas"]["holm"] == 0, "con Holm tampoco sobrevive el alpha")
    ok(correccion["betas"]["familia"] == 15, "familia de betas: 15 pruebas")
    ok(correccion["betas"]["sin_corregir"] == 14, "sin corregir hay 14 betas significativas")
    ok(correccion["betas"]["bonferroni"] == 13, "con Bonferroni sobreviven 13")
    cerca(correccion["alphas"]["probabilidad_alguna_por_azar"], 0.2262, 0.001, "riesgo familiar de los 5 alphas")
    cerca(correccion["alphas"]["umbral"], 0.01, 0.0001, "umbral de Bonferroni para alphas")

    codigo = (AQUI / "analizar.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
