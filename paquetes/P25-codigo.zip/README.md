# P25 · Factores: separar el mercado del estilo

Paquete descargable de **Data School** para el proyecto P25. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita el repositorio, ni conexión, ni dependencias.

La pregunta del proyecto es cuánto del retorno de una acción es **exposición** a tres factores
(mercado, tamaño y valor) y cuánto es **alpha**. El CSV trae cargas conocidas (por ejemplo, la
acción c tiene 0,6 de valor) para que se pueda comprobar que la regresión las recupera. Después,
el código corrige por haber probado cinco alphas y quince betas: con veinte pruebas, algo sale
«significativo» por azar más de la mitad de las veces.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: `requirements.txt` solo lo dice. Todo con la biblioteca estándar.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python analizar.py
python verificar.py
```

Desde la carpeta del paquete (los datos se buscan en `datos-ejemplo/`):

```bash
cd P25-codigo
python analizar.py --csv datos-ejemplo/factores-cartera.csv
```

## Salida esperada

```text
datos: 300 filas · 60 meses × 5 acciones · factores medios +0.0102 / -0.0003 / -0.0009
acción      alpha/mes  alpha/año  IC95% anual          bmercado  btamaño  bvalor   R²
accion-a    -0.00063   -0.0076   [-0.0420, +0.0268]     0.970    -0.322    0.069   0.934
accion-b    +0.00130   +0.0156   [-0.0146, +0.0458]     1.201     0.361   -0.172   0.967
accion-c    -0.00080   -0.0095   [-0.0422, +0.0231]     0.807     0.203    0.581   0.922
accion-d    +0.00249   +0.0299   [+0.0014, +0.0584]     1.069     0.768    0.214   0.964
accion-e    +0.00059   +0.0070   [-0.0198, +0.0338]     0.898    -0.410   -0.287   0.955
alphas: 5 pruebas · sin corregir 1 · Bonferroni 0 (umbral 0.010) · Holm 0
betas:  15 pruebas · sin corregir 14 · Bonferroni 13 (umbral 0.0033) · Holm 14
con 5 alphas al 5 %, alguno sale «significativo» por azar el 22.6 % de las veces
lectura: el alpha se lee con su intervalo; las betas dicen a qué estilo se parece la cartera.
Un alpha significativo sin corregir no es una prueba, es una hipótesis.
límite: datos sintéticos con cargas conocidas; no describe ningún fondo ni acción real.
```

La salida completa está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/factores-cartera.csv`: **300 filas × 6 columnas** (`mes`, `activo`, `retorno`,
  `mercado`, `tamano`, `valor`). 60 meses × 5 acciones; los tres factores son los mismos para todas
  las acciones de un mes.
- **Sintético, determinista y CC0-1.0**, generado para este paquete con semilla fija `20261110`:
  cada retorno es `alpha + bm·mercado + bs·tamaño + bv·valor + ruido`, con cargas conocidas y ruido
  normal de desviación 0,01. Las cargas «verdaderas» están en el generador del proyecto
  (`_generar-csv-p25.mjs`), y por eso el verificador puede comprobar que la regresión las recupera.
- `sha256` del fichero: `e893318b806b5df5bfde3fc16bf810a8be15741f1495e8cb47cc536218b64bcd`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida grano y que los factores no cambien dentro del mes | grano y consistencia de una tabla larga |
| 2 · Pivotar | matrices X (factores) e Y (retorno) alineadas | alineación por fecha |
| 3 · OLS múltiple | `y = alpha + b1·mercado + b2·tamaño + b3·valor + e` | exposición frente a alpha |
| 4 · p-valor | normal tipificada | significación de cada coeficiente |
| 5 · Intervalo | alpha anual ± 1,96 · error | leer el alpha con incertidumbre |
| 6 · Familia | 5 alphas y 15 betas | cuántas pruebas se están mirando |
| 7 · Corrección | Bonferroni y Holm | data snooping |

## Las tres trampas que el código deja a la vista

1. **Un R² alto no valida el alpha.** Los tres factores explican más del 90 % del retorno (R² 0,92–
   0,97), pero eso solo dice que las betas están bien estimadas. El alpha de la acción d es el único
   que roza la significación (+0,0299 anual, intervalo que no cruza 0), y no sobrevive a Bonferroni.
2. **La familia incluye todo lo que se mira.** No es lo mismo probar 5 alphas que 15 betas: con 20
   contrastes al 5 %, la probabilidad de ver alguno «significativo» por azar es del 64 %.
3. **Un factor es una cartera, no una etiqueta.** Mercado, tamaño y valor se dan como series
   mensuales; el ejercicio no los construye, los usa. Construirlos sin mirar el futuro es otro
   problema (y por eso el paquete no lo finge).

## Fallos típicos

- **`ModuleNotFoundError: analizar`**: ejecuta desde la carpeta del paquete.
- **`FileNotFoundError`**: `--csv` es relativo al directorio actual.
- **`los factores no son iguales para todas las acciones`**: se ha editado el CSV y un factor cambia
  dentro del mismo mes.
- **`X'X no se puede invertir`**: dos factores son idénticos o constantes.
- **Coeficientes lejos de las cargas conocidas**: se ha cargado otro CSV o se han mezclado meses.
- **p-valores distintos en cada ejecución**: no debería; no hay aleatoriedad en el análisis.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P25-codigo/
├── analizar.py                  # pasos 1–7: OLS múltiple, intervalos y correcciones
├── verificar.py                 # la puerta del proyecto: 43 comprobaciones
├── requirements.txt             # sin dependencias
├── datos-ejemplo/
│   └── factores-cartera.csv     # 300 × 6 · sintético con cargas conocidas, CC0-1.0
└── resultados/
    └── ejemplo-salida.txt       # la salida real de una ejecución
```

## Límite

Son 60 meses sintéticos generados con cargas conocidas: el paquete comprueba que el método las
recupera, **no** que existan factores así en el mercado real. No describe ningún fondo, no estima
rentabilidades futuras y no es asesoramiento financiero.
