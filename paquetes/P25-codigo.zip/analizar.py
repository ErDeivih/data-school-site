"""P25 · Factores: separar el mercado del estilo.

Regresa los retornos mensuales de cinco acciones contra tres factores (mercado, tamaño y valor)
y separa lo que es exposición (beta) de lo que es alpha. Después corrige por haber probado cinco
alphas y quince coeficientes a la vez: con muchas pruebas, algo sale «significativo» por azar.

Sin dependencias externas: solo la biblioteca estándar. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("mes", "activo", "retorno", "mercado", "tamano", "valor")
FACTORES = ("mercado", "tamano", "valor")
ACCIONES = ("accion-a", "accion-b", "accion-c", "accion-d", "accion-e")
MESES = 60
NOMBRE_FACTOR = {"mercado": "mercado", "tamano": "tamaño", "valor": "valor"}


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el grano: una fila por mes y acción, con los factores del mes.
    # Por qué: si los factores cambian entre acciones del mismo mes, la regresión compara cosas
    # distintas según el orden de las filas.
    # Salida esperada: 300 filas, 60 meses, 5 acciones y factores idénticos dentro de cada mes.
    # Si falla: «columnas inesperadas», un mes con menos acciones o factores que no cuadran.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 300:
        raise ValueError(f"se esperaban 300 filas, hay {len(filas)}")
    meses = sorted({f["mes"] for f in filas})
    if len(meses) != MESES:
        raise ValueError(f"se esperaban {MESES} meses, hay {len(meses)}")
    por_mes = defaultdict(list)
    for fila in filas:
        for columna in ("retorno", *FACTORES):
            float(fila[columna])
        por_mes[fila["mes"]].append(fila)
    for mes, grupo in por_mes.items():
        if {f["activo"] for f in grupo} != set(ACCIONES):
            raise ValueError(f"{mes}: faltan acciones")
        if len({tuple(f[c] for c in FACTORES) for f in grupo}) != 1:
            raise ValueError(f"{mes}: los factores no son iguales para todas las acciones")
    return filas


def matrices(filas: list[dict]) -> tuple[list[str], list[list[float]], dict[str, list[float]]]:
    # Paso 2 · Pivotar a matrices alineadas por fecha: X = factores, Y = retorno de cada acción.
    # Por qué: mezclar órdenes de filas es el error clásico que hace que el beta salga de otra serie.
    por_mes: dict[str, dict[str, float]] = defaultdict(dict)
    acciones: dict[str, dict[str, float]] = defaultdict(dict)
    for fila in filas:
        por_mes[fila["mes"]][fila["activo"]] = float(fila["retorno"])
        acciones[fila["activo"]][fila["mes"]] = float(fila["retorno"])
    meses = sorted(por_mes)
    x = [[float(next(f for f in filas if f["mes"] == m)[c]) for c in FACTORES] for m in meses]
    y = {a: [acciones[a][m] for m in meses] for a in ACCIONES}
    return meses, x, y


def _resolver(a: list[list[float]], b: list[float]) -> list[float]:
    """Gauss con pivote parcial para sistemas pequeños, sin numpy."""
    n = len(b)
    for col in range(n):
        pivote = max(range(col, n), key=lambda r: abs(a[r][col]))
        a[col], a[pivote] = a[pivote], a[col]
        b[col], b[pivote] = b[pivote], b[col]
        for fila in range(col + 1, n):
            factor = a[fila][col] / a[col][col]
            for c in range(col, n):
                a[fila][c] -= factor * a[col][c]
            b[fila] -= factor * b[col]
    x = [0.0] * n
    for fila in range(n - 1, -1, -1):
        x[fila] = (b[fila] - sum(a[fila][c] * x[c] for c in range(fila + 1, n))) / a[fila][fila]
    return x


def _inversa(a: list[list[float]]) -> list[list[float]]:
    n = len(a)
    aumentada = [list(fila) + [1.0 if i == j else 0.0 for j in range(n)] for i, fila in enumerate(a)]
    for col in range(n):
        pivote = max(range(col, n), key=lambda r: abs(aumentada[r][col]))
        aumentada[col], aumentada[pivote] = aumentada[pivote], aumentada[col]
        divisor = aumentada[col][col]
        aumentada[col] = [v / divisor for v in aumentada[col]]
        for fila in range(n):
            if fila == col:
                continue
            factor = aumentada[fila][col]
            if factor:
                aumentada[fila] = [v - factor * w for v, w in zip(aumentada[fila], aumentada[col])]
    return [fila[n:] for fila in aumentada]


def regresion(y: list[float], x: list[list[float]]) -> dict:
    # Paso 3 · Mínimos cuadrados con intercepto: y = alpha + b1·mercado + b2·tamaño + b3·valor + e.
    # Por qué: el intercepto es el alpha; los coeficientes, la exposición a cada estilo.
    # Salida esperada: 4 coeficientes, errores típicos, t, p-valor y R².
    # Si falla: los factores son colineales y la matriz X'X no se puede invertir.
    n = len(y)
    diseno = [[1.0, *fila] for fila in x]
    k = len(diseno[0])
    xtx = [[sum(fila[i] * fila[j] for fila in diseno) for j in range(k)] for i in range(k)]
    xty = [sum(fila[i] * yi for fila, yi in zip(diseno, y)) for i in range(k)]
    beta = _resolver([fila[:] for fila in xtx], xty[:])
    inversa = _inversa([fila[:] for fila in xtx])
    residuos = [yi - sum(b * xi for b, xi in zip(beta, fila)) for fila, yi in zip(diseno, y)]
    sigma2 = sum(r * r for r in residuos) / (n - k)
    ee = [math.sqrt(max(0.0, sigma2 * inversa[i][i])) for i in range(k)]
    t = [b / e if e else 0.0 for b, e in zip(beta, ee)]
    media = sum(y) / n
    sst = sum((yi - media) ** 2 for yi in y)
    r2 = 1 - sum(r * r for r in residuos) / sst if sst else 0.0
    return {"beta": beta, "ee": ee, "t": t, "r2": r2}


def p_valor_dos_colas(t: float) -> float:
    # Paso 4 · p-valor aproximado con la normal tipificada (n = 60, suficiente para el ejercicio).
    return math.erfc(abs(t) / math.sqrt(2))


def intervalo(valor: float, error: float, z: float = 1.96) -> tuple[float, float]:
    # Paso 5 · Intervalo al 95 %: sin intervalo, una cifra puntual parece más cierta de lo que es.
    return valor - z * error, valor + z * error


def analizar(x: list[list[float]], y: dict[str, list[float]]) -> dict:
    # Paso 6 · Ajustar las cinco acciones y juntar todos los contrastes (5 alphas + 15 betas).
    # Por qué: la familia de pruebas incluye TODOS los coeficientes que se miran, no solo el que salió.
    # Salida esperada: tabla por acción con alpha, betas, intervalo y p-valores.
    # Si falla: una serie es constante o falta algún mes.
    salida = {}
    for nombre, serie in y.items():
        ajuste = regresion(serie, x)
        p = [p_valor_dos_colas(valor) for valor in ajuste["t"]]
        bajo, alto = intervalo(ajuste["beta"][0], ajuste["ee"][0])
        salida[nombre] = {
            **ajuste, "p": p,
            "alpha_anual": ajuste["beta"][0] * 12,
            "alpha_anual_bajo": bajo * 12,
            "alpha_anual_alto": alto * 12,
        }
    return salida


def pruebas_multiples(resultado: dict, alfa: float = 0.05) -> dict:
    # Paso 7 · Corregir por la familia de pruebas: 5 alphas (una por acción) y 15 betas.
    # Por qué: 1 - 0,95^5 = 22,6 % de ver algún alpha «significativo» por azar; con 20 pruebas, 64 %.
    # Salida esperada: significativos sin corregir, Bonferroni y Holm para alphas y betas.
    # Si falla: la familia se declara mal (aquí se declara explícitamente).
    p_alphas = sorted(v["p"][0] for v in resultado.values())
    p_betas = sorted(v["p"][i] for v in resultado.values() for i in range(1, 4))
    def corregir(pvalores: list[float]) -> dict:
        n = len(pvalores)
        umbral = alfa / n
        sin = sum(1 for p in pvalores if p < alfa)
        bonferroni = sum(1 for p in pvalores if p < umbral)
        holm = 0
        for i, p in enumerate(pvalores):
            if p < alfa / (n - i):
                holm += 1
            else:
                break
        return {"familia": n, "sin_corregir": sin, "bonferroni": bonferroni, "holm": holm,
                "umbral": umbral, "probabilidad_alguna_por_azar": 1 - (1 - alfa) ** n}
    return {"alphas": corregir(p_alphas), "betas": corregir(p_betas)}


def main() -> int:
    parser = argparse.ArgumentParser(description="P25 · factores, alpha y pruebas múltiples")
    parser.add_argument("--csv", default="datos-ejemplo/factores-cartera.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    meses, x, y = matrices(filas)
    resultado = analizar(x, y)
    correccion = pruebas_multiples(resultado)
    medias = [sum(fila[i] for fila in x) / len(x) for i in range(3)]

    print(f"datos: {len(filas)} filas · {len(meses)} meses × {len(y)} acciones · "
          f"factores medios {medias[0]:+.4f} / {medias[1]:+.4f} / {medias[2]:+.4f}")
    print("acción      alpha/mes  alpha/año  IC95% anual          bmercado  btamaño  bvalor   R²")
    for nombre, r in resultado.items():
        print(f"{nombre:11} {r['beta'][0]:+.5f}   {r['alpha_anual']:+.4f}   "
              f"[{r['alpha_anual_bajo']:+.4f}, {r['alpha_anual_alto']:+.4f}]   "
              f"{r['beta'][1]:7.3f}   {r['beta'][2]:7.3f}   {r['beta'][3]:6.3f}   {r['r2']:.3f}")
    a, b = correccion["alphas"], correccion["betas"]
    print(f"alphas: {a['familia']} pruebas · sin corregir {a['sin_corregir']} · Bonferroni "
          f"{a['bonferroni']} (umbral {a['umbral']:.3f}) · Holm {a['holm']}")
    print(f"betas:  {b['familia']} pruebas · sin corregir {b['sin_corregir']} · Bonferroni "
          f"{b['bonferroni']} (umbral {b['umbral']:.4f}) · Holm {b['holm']}")
    print(f"con {a['familia']} alphas al 5 %, alguno sale «significativo» por azar el "
          f"{a['probabilidad_alguna_por_azar'] * 100:.1f} % de las veces")
    print("lectura: el alpha se lee con su intervalo; las betas dicen a qué estilo se parece la "
          "cartera. Un alpha significativo sin corregir no es una prueba, es una hipótesis.")
    print("límite: datos sintéticos con cargas conocidas; no describe ningún fondo ni acción real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
