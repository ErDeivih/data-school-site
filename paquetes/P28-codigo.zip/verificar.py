#!/usr/bin/env python3
"""Puerta del proyecto P28 (precios de la luz).

Comprueba grano, perfil horario, laborable/fin, cuota renovable y previsión. Sin escribir en disco.
VERDE (0) o ROJO (1).
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import precios

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "precios-luz.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = precios.leer(CSV)
    ok(len(filas) == 1440, "el CSV tiene 1.440 filas")
    ok(len({f["fecha"] for f in filas}) == 60, "hay 60 días")
    ok(all(sum(1 for f in filas if f["fecha"] == d) == 24 for d in {f["fecha"] for f in filas}), "cada día tiene 24 horas")

    perfil = precios.por_hora(filas)
    ok(len(perfil) == 24, "el perfil cubre las 24 horas")
    ok(perfil[13] == 18.763, "el valle es la hora 13 (18,763 €/MWh)")
    ok(perfil[20] == 77.497, "el pico es la hora 20 (77,497 €/MWh)")
    ok(perfil[0] == 46.527, "la hora 0 promedia 46,527 €/MWh")

    semana = precios.laborable_fin(filas)
    ok(semana["laborable"] == 44.504, "laborable: 44,504 €/MWh")
    ok(semana["fin"] == 41.581, "fin de semana: 41,581 €/MWh")
    ok(semana["laborable"] > semana["fin"], "el laborable es más caro que el fin de semana")

    ok(precios.cuota_renovable(filas) == 0.44925, "la cuota renovable media es 44,925 %")

    m = precios.mae_naive(filas)
    ok(m["naive"] == 4.095, "la MAE de la previsión ingenua es 4,095")
    ok(m["media"] == 13.284, "la MAE de la media es 13,284")
    ok(m["naive"] < m["media"], "la previsión ingenua mejora a la media")

    media = sum(float(f["precio_eur_mwh"]) for f in filas) / len(filas)
    ok(round(media, 3) == 43.724, "el precio medio es 43,724 €/MWh")
    ok(min(float(f["precio_eur_mwh"]) for f in filas) == 7.4, "el mínimo es 7,4 €/MWh")
    ok(max(float(f["precio_eur_mwh"]) for f in filas) == 85.7, "el máximo es 85,7 €/MWh")

    codigo = (AQUI / "precios.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
