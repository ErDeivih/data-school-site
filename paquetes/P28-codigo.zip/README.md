# P28 · Precios de la luz: estacionalidad, picos y previsión

Paquete descargable de **Data School** para el proyecto P28. Incluye las 60 jornadas de ejemplo, el
código comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python precios.py
python verificar.py
```

`precios.py` resume el perfil horario, compara laborables con fin de semana, mide la cuota renovable y
evalúa una previsión ingenua (misma hora del día anterior) contra la media. `verificar.py` sale 0 si todo
cuadra.

## Datos

- `datos-ejemplo/precios-luz.csv`: **1.440 filas × 7 columnas** (60 días × 24 horas; precio, demanda,
  eólica, solar y día de la semana). Sintético y **CC0-1.0**; es el `precios-luz` del catálogo.

## Salida esperada

```text
filas: 1440 · días: 60 · precio medio: 43.724 €/MWh
mínimo: 7.40 · máximo: 85.70
valle: hora 13 (18.763) · pico: hora 20 (77.497)
laborable: 44.504 · fin de semana: 41.581
cuota renovable media: 44.92%
MAE: naive día anterior 4.095 · media 13.284
límite: 60 días sintéticos de un solo mercado; no describe el precio real ni predice el futuro.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Grano | `leer` exige 60 días con sus 24 horas | validación de datos |
| 2 · Perfil horario | `por_hora` calcula la media de cada hora | estacionalidad |
| 3 · Semana | `laborable_fin` compara días 1–5 con 6–7 | estacionalidad |
| 4 · Renovable | `cuota_renovable` mide (eólica+solar)/demanda | mezcla de fuentes |
| 5 · Previsión | `mae_naive` compara día anterior con la media | previsión y línea base |
| 6 · Publicar | `main` deja valle, pico y límite a la vista | comunicación |

## Fallos típicos

- **Día incompleto**: falta una hora; el perfil horario deja de ser comparable.
- **Confundir precio con demanda**: son columnas distintas; el pico de precio no siempre es el de demanda.
- **Previsión sin línea base**: la naive solo vale si mejora a la media; aquí la mejora.
- **Extrapolar 60 días**: no describen el mercado; el límite se declara siempre.

## Límite

Son 60 días sintéticos de un solo mercado. Enseñan estacionalidad y línea base de previsión; no predicen
el precio real.
