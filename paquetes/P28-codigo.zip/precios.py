"""P28 · Precios de la luz: estacionalidad, picos y previsión.

Resume el perfil horario, compara laborables con fines de semana, mide la cuota renovable y evalúa una
previsión ingenua (misma hora del día anterior) contra la media. Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import statistics
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("fecha", "hora", "precio_eur_mwh", "demanda_mw", "eolica_mw", "solar_mw", "dia_semana")
DIAS = 60
HORAS = 24


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y comprobar el grano: 60 días completos de 24 horas.
    # Por qué: para comparar horas y días hace falta una rejilla completa y sin duplicados.
    # Salida esperada: 1.440 filas, 60 fechas y 24 horas por fecha.
    # Si falla: «columna inesperada», «día incompleto» o «demanda no positiva».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != DIAS * HORAS:
        raise ValueError(f"se esperaban {DIAS * HORAS} filas, hay {len(filas)}")
    por_fecha = defaultdict(list)
    for fila in filas:
        if float(fila["demanda_mw"]) <= 0:
            raise ValueError("hay demanda no positiva")
        por_fecha[fila["fecha"]].append(int(fila["hora"]))
    if len(por_fecha) != DIAS or any(sorted(h) != list(range(HORAS)) for h in por_fecha.values()):
        raise ValueError("cada fecha debe tener las 24 horas")
    return filas


def por_hora(filas: list[dict]) -> dict:
    # Paso 2 · Perfil horario: precio medio de cada hora del día.
    # Por qué: el pico y el valle se ven en la hora, no en la media diaria.
    # Salida esperada: valle en la hora 13 (18,763 €/MWh) y pico en la 20 (77,497).
    # Si falla: alguna hora no tiene 60 observaciones.
    grupos = defaultdict(list)
    for fila in filas:
        grupos[int(fila["hora"])].append(float(fila["precio_eur_mwh"]))
    return {hora: round(statistics.mean(valores), 3) for hora, valores in sorted(grupos.items())}


def laborable_fin(filas: list[dict]) -> dict:
    # Paso 3 · Comparar laborables (día 1–5) con fin de semana (6–7).
    # Por qué: la estacionalidad semanal cambia la previsión de un día para otro.
    # Salida esperada: 44,504 €/MWh laborable y 41,581 en fin de semana.
    # Si falla: la columna dia_semana no está entre 1 y 7.
    sem = [float(f["precio_eur_mwh"]) for f in filas if 1 <= int(f["dia_semana"]) <= 5]
    fin = [float(f["precio_eur_mwh"]) for f in filas if int(f["dia_semana"]) in (6, 7)]
    if not sem or not fin:
        raise ValueError("faltan laborables o fines de semana")
    return {"laborable": round(statistics.mean(sem), 3), "fin": round(statistics.mean(fin), 3)}


def cuota_renovable(filas: list[dict]) -> float:
    # Paso 4 · Cuota renovable: (eólica + solar) / demanda, media horaria.
    # Por qué: el precio se explica en parte por cuánta renovable entra en cada hora.
    # Salida esperada: 44,925 %.
    # Si falla: la demanda es 0 en alguna fila.
    cuotas = [(float(f["eolica_mw"]) + float(f["solar_mw"])) / float(f["demanda_mw"]) for f in filas]
    return round(statistics.mean(cuotas), 5)


def mae_naive(filas: list[dict]) -> dict:
    # Paso 5 · Previsión ingenua: misma hora del día anterior; comparar con la media.
    # Por qué: una previsión solo sirve si mejora algo; la media es la línea base.
    # Salida esperada: MAE 4,095 con la naive frente a 13,284 de la media.
    # Si falla: no hay dos días completos.
    por_fecha = defaultdict(dict)
    for fila in filas:
        por_fecha[fila["fecha"]][int(fila["hora"])] = float(fila["precio_eur_mwh"])
    fechas = sorted(por_fecha)
    errores_naive = []
    for i in range(1, len(fechas)):
        for hora in range(HORAS):
            errores_naive.append(abs(por_fecha[fechas[i]][hora] - por_fecha[fechas[i - 1]][hora]))
    media = statistics.mean(float(f["precio_eur_mwh"]) for f in filas)
    errores_media = [abs(float(f["precio_eur_mwh"]) - media) for f in filas[24:]]
    return {"naive": round(statistics.mean(errores_naive), 3), "media": round(statistics.mean(errores_media), 3)}


def main() -> int:
    # Paso 6 · Publicar perfil, semana, renovable y previsión; declarar el límite.
    # Por qué: 60 días sintéticos no describen el mercado; el informe no puede extrapolar.
    # Salida esperada: perfil de 24 horas, laborable/fin, renovable y MAE.
    # Si falla: revisa --csv o si el fichero es el del catálogo.
    parser = argparse.ArgumentParser(description="Estacionalidad y previsión del precio (P28)")
    parser.add_argument("--csv", default="datos-ejemplo/precios-luz.csv")
    args = parser.parse_args()
    filas = leer(Path(args.csv))
    perfil = por_hora(filas)
    precios = [float(f["precio_eur_mwh"]) for f in filas]
    print(f"filas: {len(filas)} · días: {DIAS} · precio medio: {statistics.mean(precios):.3f} €/MWh")
    print(f"mínimo: {min(precios):.2f} · máximo: {max(precios):.2f}")
    valle = min(perfil, key=perfil.get)
    pico = max(perfil, key=perfil.get)
    print(f"valle: hora {valle} ({perfil[valle]:.3f}) · pico: hora {pico} ({perfil[pico]:.3f})")
    semana = laborable_fin(filas)
    print(f"laborable: {semana['laborable']:.3f} · fin de semana: {semana['fin']:.3f}")
    print(f"cuota renovable media: {cuota_renovable(filas):.2%}")
    m = mae_naive(filas)
    print(f"MAE: naive día anterior {m['naive']:.3f} · media {m['media']:.3f}")
    print("límite: 60 días sintéticos de un solo mercado; no describe el precio real ni predice el futuro.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
