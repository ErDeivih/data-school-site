#!/usr/bin/env python3
"""Puerta del proyecto P49 · análisis de una empresa y su sector, con ratios.

Recalcula las cifras clave desde los dos CSV de datos-ejemplo y comprueba el resultado de verdad:
recuentos, relaciones de precio, volatilidad, episodios, medias, comparación sectorial y ratios.
No usa red y **no escribe ningún fichero**: solo calcula y saca conclusiones por stdout.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import analisis

FALLOS: list[str] = []
COMPROBACIONES = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global COMPROBACIONES
    COMPROBACIONES += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        FALLOS.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P49 · empresa y sector con ratios ==")

    # Paso 1 · Comprueba los datos de ejemplo antes de analizarlos
    # Por qué: si el CSV no tiene las filas que promete el README, cualquier métrica posterior es ruido.
    # Salida esperada: "datos: 4000 filas · 8 empresas · 500 sesiones"
    # Si falla: FileNotFoundError → faltan los CSV en datos-ejemplo/; el ZIP los trae.
    df = analisis.cargar_precios()
    resumen = analisis.validar_precios(df)
    ok(
        (resumen["filas"], resumen["empresas"], resumen["sesiones"]) == (4000, 8, 500)
        and resumen["sesiones_por_empresa"] == [500],
        f"datos: {resumen['filas']} filas · {resumen['empresas']} empresas · {resumen['sesiones']} sesiones",
    )

    # Paso 2 · Comprueba que las relaciones de precio no tienen violaciones
    # Por qué: el validador ya cuenta las violaciones; la puerta exige cero para poder fiarse del CSV.
    # Salida esperada: "coherencia: 0 duplicadas · 0 violaciones"
    # Si falla: alguna banda de precio se supera → el CSV fue editado y hay que usar el original.
    ok(resumen["claves_duplicadas"] == 0, f"claves (fecha, empresa) duplicadas: {resumen['claves_duplicadas']}")
    ok(
        sum(resumen["violaciones"].values()) == 0,
        f"coherencia de precio: {resumen['violaciones']}",
    )
    ok(resumen["dias_semana"] == [0, 1, 2, 3, 4], f"calendario laborable: {resumen['dias_semana']}")

    # Paso 3 · Recalcula retornos y volatilidad por su cuenta
    # Por qué: la tabla de retornos es una afirmación; la puerta la reconstruye desde los cierres.
    # Salida esperada: "retornos: 8 empresas · EMP-A vol 0.1253 · retorno 0.1628"
    # Si falla: la tabla no sale de log(cierre) o falta una empresa.
    retornos_diarios, tabla = analisis.calcular_retornos(df)
    ok(len(tabla) == 8 and sorted(tabla["empresa"]) == [f"EMP-{c}" for c in "ABCDEFGH"],
       "retornos: una fila por cada una de las 8 empresas")
    emp_a = tabla.set_index("empresa").loc["EMP-A"]
    ok(
        abs(emp_a["volatilidad_anual"] - 0.125253) < 1e-5 and abs(emp_a["retorno_anualizado"] - 0.162787) < 1e-5,
        f"retornos EMP-A: volatilidad {emp_a['volatilidad_anual']:.4f} · anualizado {emp_a['retorno_anualizado']:.4f}",
    )
    serie_a = retornos_diarios.loc[retornos_diarios["empresa"] == "EMP-A", "retorno"].dropna()
    recalculada = float(serie_a.std()) * np.sqrt(analisis.SESIONES_ANIO)
    ok(abs(recalculada - emp_a["volatilidad_anual"]) < 1e-12,
       f"volatilidad recalculada EMP-A: {recalculada:.6f}")
    ok(bool((tabla["volatilidad_anual"] > 0).all()), "todas las volatilidades son positivas")

    # Paso 4 · Comprueba las medias móviles contra el cierre del propio CSV
    # Por qué: una media móvil mal alineada se detecta comparando la última ventana con la media manual.
    # Salida esperada: "medias: 20 y 60 ventanas · EMP-A ma20 55.8245 · ma60 56.5312"
    # Si falla: NaN al final de ma60 → no hay 60 sesiones por empresa o el rolling está mal agrupado.
    df_medias, tabla_medias = analisis.medias_moviles(df)
    ok({"ma20", "ma60"}.issubset(df_medias.columns), "medias: columnas ma20 y ma60 presentes")
    cierres_a = df.loc[df["empresa"] == "EMP-A", "cierre"].reset_index(drop=True)
    ok(
        abs(float(cierres_a.tail(20).mean()) - float(tabla_medias.set_index("empresa").loc["EMP-A", "ma20"])) < 1e-12,
        f"ma20 de EMP-A coincide con la media de las últimas 20 sesiones: {cierres_a.tail(20).mean():.4f}",
    )
    ultima = tabla_medias.set_index("empresa").loc["EMP-A"]
    ok(
        abs(ultima["ma60"] - 56.531167) < 1e-5 and ultima["tendencia"] == "bajista",
        f"última media de EMP-A: ma20 {ultima['ma20']:.4f} · ma60 {ultima['ma60']:.4f} · {ultima['tendencia']}",
    )

    # Paso 5 · Comprueba que los episodios son comunes y con el signo medido
    # Por qué: si la caída y el rebote no son comunes a las 8 empresas, la comparación sectorial cambia.
    # Salida esperada: "episodios: caida-larga -0.00997 · caida-corta -0.00410 · rebote +0.00896"
    # Si falla: alguna empresa con signo contrario → el CSV no trae los episodios prometidos.
    episodios = analisis.analizar_episodios(retornos_diarios)
    medias = episodios.groupby("episodio")["retorno_medio_diario"].mean()
    ok(len(episodios) == 24, f"episodios: {len(episodios)} filas (8 empresas × 3 episodios)")
    ok(
        abs(medias["caida-larga"] + 0.009970) < 1e-4
        and abs(medias["caida-corta"] + 0.004097) < 1e-4
        and abs(medias["rebote"] - 0.008956) < 1e-4,
        "episodios: medios " + " · ".join(f"{k} {v:+.5f}" for k, v in medias.items()),
    )
    signos = episodios.pivot(index="empresa", columns="episodio", values="retorno_medio_diario")
    ok(
        bool((signos["caida-larga"] < 0).all()) and bool((signos["rebote"] > 0).all()),
        "las 8 empresas caen en la caída larga y suben en el rebote",
    )
    # La caída corta dura 8 sesiones y la deriva propia de EMP-B la compensa: 7 de 8 caen y la media
    # del tramo sigue siendo negativa. Exigir las 8 sería pedirle al dato algo que no dice.
    ok(
        int((signos["caida-corta"] < 0).sum()) >= 7 and float(signos["caida-corta"].mean()) < 0,
        f"caída corta: {int((signos['caida-corta'] < 0).sum())} de 8 empresas caen · media {signos['caida-corta'].mean():+.5f}",
    )

    # Paso 6 · Recalcula la comparación sectorial
    # Por qué: la diferencia con el sector debe salir de los mismos 500 cierres, no de una tabla a mano.
    # Salida esperada: "sector: energia 2 empresas · EMP-A +0.3480 vs media +0.0947"
    # Si falla: la media del sector incluye empresas de otro sector o ventanas distintas.
    comparacion, resumen_sector = analisis.comparar_sector(df)
    ok(resumen_sector["empresas_sector"] == ["EMP-A", "EMP-G"], f"sector energia: {resumen_sector['empresas_sector']}")
    ok(resumen_sector["sectores_una_empresa"] == ["consumo", "industria"],
       f"sectores con una sola empresa: {resumen_sector['sectores_una_empresa']}")
    emp_a_comp = comparacion.set_index("empresa").loc["EMP-A"]
    ok(
        abs(emp_a_comp["retorno_total"] - 0.348035) < 1e-5 and abs(emp_a_comp["media_sector"] - 0.094674) < 1e-5,
        f"comparación EMP-A: {emp_a_comp['retorno_total']:+.4f} vs sector {emp_a_comp['media_sector']:+.4f}",
    )
    ok(bool((comparacion["sesiones"] == 500).all()), "la comparación usa las 500 sesiones de cada empresa")

    # Paso 7 · Recalcula los ratios y comprueba su fuente
    # Por qué: un ratio inventado desde precios no cuadra al recalcularlo con el beneficio por acción.
    # Salida esperada: "ratios: 10 empresas · EMP-A per 11.7267 · deuda/equity 0.4488"
    # Si falla: per distinto del calculado → el ejercicio elegido o las unidades están cambiados.
    ratios = analisis.ratios_fundamentales()
    ok(len(ratios) == 10 and set(ratios["empresa"]) == {f"EMP-{c}" for c in "ABCDEFGHIJ"},
       "ratios: las 10 empresas del CSV de fundamentales")
    emp_a_ratio = ratios.set_index("empresa").loc["EMP-A"]
    per_recalculado = 12.91 / (242.2 / 220)
    ok(
        abs(emp_a_ratio["per"] - per_recalculado) < 1e-9 and abs(emp_a_ratio["deuda_equity"] - 0.448787) < 1e-5,
        f"ratios EMP-A: per {emp_a_ratio['per']:.4f} · deuda/equity {emp_a_ratio['deuda_equity']:.4f}",
    )
    ok(bool((ratios["per"] > 0).all()) and bool((ratios["deuda_equity"] > 0).all()),
       "todos los ratios calculados son positivos")
    ok(bool(((ratios["margen_ebitda"] > 0) & (ratios["margen_ebitda"] < 1)).all()),
       "el margen EBITDA está entre 0 y 1 en todas las empresas")
    informe = analisis.texto_informe(tabla, episodios, comparacion, resumen_sector, ratios)
    ok(
        "fundamentales-empresa" in informe and "Límite" in informe and "sintéticos" in informe,
        "el informe declara la fuente de los ratios y su límite",
    )
    ok("Ningún ratio se deduce de los precios" in informe,
       "el informe separa los ratios de los precios del CSV")

    # Paso 8 · Comprueba que el código es offline
    # Por qué: la puerta se ejecuta sin red y el ZIP se comparte; una URL escondida rompería la promesa.
    # Salida esperada: "offline: sin peticiones de red ni claves"
    # Si falla: aparece un http(s) o un patrón de token en las fuentes.
    fuentes = (analisis.RAIZ / "analisis.py").read_text(encoding="utf-8")
    ok("http://" not in fuentes and "https://" not in fuentes, "offline: sin peticiones de red")
    ok(not any(p in fuentes for p in ("ghp_", "github_pat_", "Authorization:")), "offline: sin claves ni cabeceras")

    print(f"\ncomprobaciones: {COMPROBACIONES}")
    if FALLOS:
        print(f"RESULTADO: ROJO — {len(FALLOS)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
