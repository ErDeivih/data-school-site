#!/usr/bin/env python3
"""P49 · Análisis de una empresa y su sector, con ratios — código ejecutable.

El proyecto contesta tres preguntas con datos locales, sin red:
  1. ¿Cuánto se mueve cada empresa y cuánto de ese movimiento es común al mercado?
  2. ¿Cómo se compara la empresa elegida con las de su sector, en las mismas sesiones?
  3. ¿Qué ratios tiene, y de qué fuente salen?

Los dos CSV son sintéticos, deterministas y CC0-1.0:
  - datos-ejemplo/precios-empresa.csv        (4000 filas × 8 columnas)
  - datos-ejemplo/fundamentales-empresa.csv  (50 filas × 16 columnas)

Uso:
    python analisis.py            # calcula y escribe resultados/
    python verificar.py           # puerta del proyecto: 0 solo si todo cuadra

La salida real de la puerta está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo"
RESULTADOS = RAIZ / "resultados"
EMPRESA = "EMP-A"
VENTANAS = (20, 60)
# Sesiones con un movimiento común a las ocho empresas (medido en el CSV: 180-199, 300-307, 380-394).
EPISODIOS = {
    "caida-larga": (180, 199),
    "caida-corta": (300, 307),
    "rebote": (380, 394),
}
SESIONES_ANIO = 252


# Paso 1 · Carga el CSV de precios y lo deja ordenado por empresa y fecha
# Por qué: sin ordenar por empresa, la primera diferencia de cada serie mezcla dos empresas distintas
#          y el retorno de la primera fila deja de ser comparable.
# Salida esperada: "precios: 4000 filas · 8 empresas · 500 sesiones por empresa"
# Si falla: FileNotFoundError → ejecuta desde codigo/ y comprueba datos-ejemplo/precios-empresa.csv.
def cargar_precios() -> pd.DataFrame:
    ruta = DATOS / "precios-empresa.csv"
    if not ruta.exists():
        raise FileNotFoundError(
            f"falta {ruta}; ejecuta desde la carpeta codigo/ y comprueba datos-ejemplo/"
        )
    df = pd.read_csv(ruta, parse_dates=["fecha"])
    df = df.sort_values(["empresa", "fecha"]).reset_index(drop=True)
    df["sesion"] = df.groupby("empresa").cumcount()
    print(
        f"precios: {len(df)} filas · {df['empresa'].nunique()} empresas · "
        f"{df.groupby('empresa').size().min()} sesiones por empresa"
    )
    return df


# Paso 2 · Valida las cuatro relaciones que el fichero promete
# Por qué: si las relaciones de precio no se cumplen, el CSV no es el que dice el README y cualquier
#          retorno calculado encima es ruido; se cuentan las violaciones en vez de suponerlas.
# Salida esperada: "validación: 0 claves duplicadas · 0 violaciones de precio"
# Si falla: alguna relación supera su banda → revisa que no se haya editado el CSV.
def validar_precios(df: pd.DataFrame) -> dict:
    claves_duplicadas = int(df.duplicated(["fecha", "empresa"]).sum())
    por_empresa = df.groupby("empresa").size()
    d = df.sort_values(["empresa", "fecha"]).copy()
    d["cierre_previo"] = d.groupby("empresa")["cierre"].shift(1)
    v = d.dropna(subset=["cierre_previo"]).copy()
    tope = np.maximum(v["apertura"], v["cierre"])
    suelo = np.minimum(v["apertura"], v["cierre"])
    # Las bandas del generador son 0,2 % y 1,2 %; se suma el error de redondeo a 2 decimales de los
    # dos precios que se comparan (0,01 en total, relativo al precio de referencia).
    redondeo = 0.010
    apertura_ok = (v["apertura"] / v["cierre_previo"] - 1).abs() <= 0.002 + redondeo / v["cierre_previo"]
    maximo_ok = (v["maximo"] >= tope - 1e-9) & (v["maximo"] / tope - 1 <= 0.012 + redondeo / tope)
    minimo_ok = (v["minimo"] <= suelo + 1e-9) & (1 - v["minimo"] / suelo <= 0.012 + redondeo / suelo)
    violaciones = {
        "apertura_vs_cierre_previo": int((~apertura_ok).sum()),
        "maximo_vs_apertura_cierre": int((~maximo_ok).sum()),
        "minimo_vs_apertura_cierre": int((~minimo_ok).sum()),
    }
    resumen = {
        "filas": len(df),
        "empresas": int(df["empresa"].nunique()),
        "sesiones_por_empresa": sorted(por_empresa.unique().tolist()),
        "sesiones": int(len(df) // df["empresa"].nunique()),
        "claves_duplicadas": claves_duplicadas,
        "violaciones": violaciones,
        "dias_semana": sorted(df["fecha"].dt.dayofweek.unique().tolist()),
    }
    total_violaciones = sum(violaciones.values())
    print(f"validación: {claves_duplicadas} claves duplicadas · {total_violaciones} violaciones de precio")
    return resumen


# Paso 3 · Calcula retornos logarítmicos y los anualiza por empresa
# Por qué: los retornos logarítmicos se suman en el tiempo, así que la media diaria y la volatilidad
#          anual salen de la misma serie sin componer a mano; y el signo de una caída no se invierte.
# Salida esperada: "retornos: EMP-A volatilidad anual 0,27 · retorno anualizado -0,01"
# Si falla: un retorno NaN en la primera sesión es normal (no hay cierre previo); no lo rellenes con 0.
def calcular_retornos(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = df.copy()
    d["retorno"] = d.groupby("empresa")["cierre"].transform(lambda s: np.log(s).diff())
    tabla = (
        d.groupby("empresa")
        .agg(
            sesiones=("retorno", "count"),
            retorno_medio_diario=("retorno", "mean"),
            volatilidad_diaria=("retorno", "std"),
        )
        .reset_index()
    )
    tabla["volatilidad_anual"] = tabla["volatilidad_diaria"] * np.sqrt(SESIONES_ANIO)
    tabla["retorno_anualizado"] = np.expm1(tabla["retorno_medio_diario"] * SESIONES_ANIO)
    fila = tabla.set_index("empresa").loc[EMPRESA]
    print(
        f"retornos: {EMPRESA} volatilidad anual {fila['volatilidad_anual']:.2f} · "
        f"retorno anualizado {fila['retorno_anualizado']:.2f}"
    )
    return d, tabla


# Paso 4 · Traza dos medias móviles para separar tendencia de ruido
# Por qué: una sola ventana no distingue tendencia de un tramo; con 20 y 60 sesiones se ve si el
#          precio corto va por encima del largo sin afirmar que eso sea una predicción.
# Salida esperada: "medias: EMP-A cierre 32.55 · ma20 33.10 · ma60 31.80 · tendencia alcista"
# Si falla: NaN en ma60 durante las primeras 59 sesiones es esperado; la tabla final usa la última.
def medias_moviles(df: pd.DataFrame, ventanas: tuple[int, ...] = VENTANAS) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = df.copy()
    for v in ventanas:
        d[f"ma{v}"] = d.groupby("empresa")["cierre"].transform(lambda s, v=v: s.rolling(v).mean())
    ultima = d.groupby("empresa").tail(1)[["empresa", "fecha", "cierre", *[f"ma{v}" for v in ventanas]]].copy()
    ultima["tendencia"] = np.where(ultima["ma20"] > ultima["ma60"], "alcista", "bajista")
    fila = ultima.set_index("empresa").loc[EMPRESA]
    print(
        f"medias: {EMPRESA} cierre {fila['cierre']:.2f} · ma20 {fila['ma20']:.2f} · "
        f"ma60 {fila['ma60']:.2f} · tendencia {fila['tendencia']}"
    )
    return d, ultima.reset_index(drop=True)


# Paso 5 · Mide los episodios de mercado que comparten las ocho empresas
# Por qué: comparar retornos brutos atribuye a la empresa lo que hizo el mercado; con los episodios
#          identificados se puede leer qué parte del movimiento es común antes de comparar.
# Salida esperada: "episodios: caida-larga -0.010 · caida-corta -0.004 · rebote +0.008"
# Si falla: un episodio con retorno medio positivo en una caída → el CSV no es el esperado.
def analizar_episodios(d: pd.DataFrame) -> pd.DataFrame:
    filas = []
    for nombre, (desde, hasta) in EPISODIOS.items():
        tramo = d[(d["sesion"] >= desde) & (d["sesion"] <= hasta)]
        for empresa, serie in tramo.groupby("empresa"):
            filas.append(
                {
                    "episodio": nombre,
                    "empresa": empresa,
                    "sesiones": len(serie),
                    "retorno_medio_diario": float(serie["retorno"].mean()),
                }
            )
    tabla = pd.DataFrame(filas)
    medias = tabla.groupby("episodio")["retorno_medio_diario"].mean()
    print(
        "episodios: "
        + " · ".join(f"{nombre} {valor:+.3f}" for nombre, valor in medias.items())
    )
    return tabla


# Paso 6 · Compara la empresa con las de su sector, en la misma ventana de sesiones
# Por qué: la comparación solo vale si se usan las mismas fechas y el mismo número de sesiones; y si
#          el sector tiene una sola empresa, se declara en vez de rellenar con una de fuera.
# Salida esperada: "sector: energia tiene 2 empresas · EMP-A -8.99 % vs sector -8.99 %"
# Si falla: KeyError de una empresa → el CSV no tiene los mismos identificadores que el mapa.
def comparar_sector(df: pd.DataFrame, empresa: str = EMPRESA) -> tuple[pd.DataFrame, dict]:
    totales = (
        df.groupby("empresa")
        .agg(
            sector=("sector", "first"),
            cierre_inicial=("cierre", "first"),
            cierre_final=("cierre", "last"),
            sesiones=("fecha", "count"),
        )
        .reset_index()
    )
    totales["retorno_total"] = totales["cierre_final"] / totales["cierre_inicial"] - 1
    sector = totales.set_index("empresa").loc[empresa, "sector"]
    pares = sorted(totales.loc[totales["sector"] == sector, "empresa"].tolist())
    media_sector = float(totales.loc[totales["empresa"].isin(pares), "retorno_total"].mean())
    media_mercado = float(totales["retorno_total"].mean())
    filas = []
    for nombre in [empresa, *[p for p in pares if p != empresa]]:
        retorno = float(totales.loc[totales["empresa"] == nombre, "retorno_total"].iloc[0])
        filas.append(
            {
                "empresa": nombre,
                "sector": sector,
                "sesiones": int(totales.loc[totales["empresa"] == nombre, "sesiones"].iloc[0]),
                "retorno_total": retorno,
                "media_sector": media_sector,
                "diferencia_sector": retorno - media_sector,
                "diferencia_mercado": retorno - media_mercado,
            }
        )
    conteo = totales.groupby("sector")["empresa"].nunique()
    resumen = {
        "sector": sector,
        "empresas_sector": pares,
        "sectores_una_empresa": sorted(conteo[conteo == 1].index.tolist()),
    }
    fila = filas[0]
    print(
        f"sector: {sector} tiene {len(pares)} empresas · {empresa} "
        f"{fila['retorno_total']:+.2%} vs sector {media_sector:+.2%}"
    )
    return pd.DataFrame(filas), resumen


# Paso 7 · Lee los ratios de su fuente, no de los precios
# Por qué: un PER o un deuda/equity no se deducen de una serie de precios; salen de estados
#          financieros con ejercicio y licencia. Aquí la fuente es el segundo CSV (CC0-1.0, 2025).
# Salida esperada: "ratios: 10 empresas desde fundamentales-empresa (ejercicio 2025)"
# Si falla: división por cero → patrimonio_neto o acciones a 0; revisa el CSV, no lo parchees.
def ratios_fundamentales() -> pd.DataFrame:
    ruta = DATOS / "fundamentales-empresa.csv"
    if not ruta.exists():
        raise FileNotFoundError(f"falta {ruta}; es la fuente de los ratios")
    fund = pd.read_csv(ruta)
    ultimo = fund[fund["ejercicio"] == fund["ejercicio"].max()].copy()
    ultimo["per"] = ultimo["precio_accion"] / (ultimo["beneficio_neto"] / ultimo["acciones"])
    ultimo["deuda_equity"] = ultimo["deuda_total"] / ultimo["patrimonio_neto"]
    ultimo["margen_ebitda"] = ultimo["ebitda"] / ultimo["ingresos"]
    ultimo["roe"] = ultimo["beneficio_neto"] / ultimo["patrimonio_neto"]
    columnas = ["empresa", "sector", "ejercicio", "precio_accion", "per", "deuda_equity", "margen_ebitda", "roe"]
    tabla = ultimo[columnas].sort_values("empresa").reset_index(drop=True)
    print(
        f"ratios: {len(tabla)} empresas desde fundamentales-empresa "
        f"(ejercicio {int(tabla['ejercicio'].max())})"
    )
    return tabla


def tabla_markdown(df: pd.DataFrame, decimales: int = 2) -> str:
    """Tabla markdown sin depender de tabulate: cabecera, separador y filas formateadas."""
    cabecera = "| " + " | ".join(df.columns) + " |"
    separador = "| " + " | ".join("---" for _ in df.columns) + " |"
    filas = []
    for _, fila in df.iterrows():
        celdas = []
        for valor in fila:
            if isinstance(valor, (float, np.floating)):
                celdas.append(f"{valor:.{decimales}f}")
            else:
                celdas.append(str(valor))
        filas.append("| " + " | ".join(celdas) + " |")
    return "\n".join([cabecera, separador, *filas])


def texto_informe(
    retornos: pd.DataFrame,
    episodios: pd.DataFrame,
    comparacion: pd.DataFrame,
    resumen_sector: dict,
    ratios: pd.DataFrame,
) -> str:
    """Construye el informe de dos páginas como texto; main() lo escribe y verificar.py lo comprueba."""
    medias_episodio = (
        episodios.groupby("episodio")["retorno_medio_diario"].mean().reset_index().sort_values("episodio")
    )
    lineas = [
        "# P49 · Análisis de una empresa y su sector, con ratios",
        "",
        f"Empresa elegida: **{EMPRESA}**, sector **{resumen_sector['sector']}**. "
        f"Ventana: las {int(comparacion['sesiones'].iloc[0])} sesiones completas del CSV.",
        "",
        "## Retornos y volatilidad",
        tabla_markdown(retornos),
        "",
        "## Episodios comunes",
        "Los tres tramos son de mercado, no de la empresa: se leen antes de comparar.",
        tabla_markdown(medias_episodio, decimales=4),
        "",
        "## Comparación sectorial",
        f"Empresas del sector: {', '.join(resumen_sector['empresas_sector'])}. "
        f"Sectores con una sola empresa (no se comparan): {', '.join(resumen_sector['sectores_una_empresa'])}.",
        tabla_markdown(comparacion, decimales=4),
        "",
        "## Ratios",
        "Fuente: `fundamentales-empresa` (CC0-1.0), ejercicio 2025. Ningún ratio se deduce de los "
        "precios del CSV: aquí el precio solo se usa como numerador del PER. El contraste con la SEC "
        "(empresas de EE. UU.) queda fuera de este código offline y se documenta como paso real.",
        tabla_markdown(ratios),
        "",
        "## Límite",
        "Los precios son sintéticos (semilla fija, CC0-1.0) y no son de ninguna empresa real: "
        "sirven para practicar la comparación, no para concluir sobre una inversión. Las fechas son "
        "días laborables sin festivos ni subastas, así que no son un calendario de bolsa. El informe "
        "no promete rentabilidad.",
        "",
    ]
    return "\n".join(lineas)


def main() -> int:
    df = cargar_precios()
    validar_precios(df)
    retornos_diarios, tabla_retornos = calcular_retornos(df)
    _, tabla_medias = medias_moviles(df)
    tabla_episodios = analizar_episodios(retornos_diarios)
    comparacion, resumen_sector = comparar_sector(df)
    ratios = ratios_fundamentales()

    RESULTADOS.mkdir(exist_ok=True)
    tabla_retornos.to_csv(RESULTADOS / "retornos.csv", index=False)
    tabla_medias.to_csv(RESULTADOS / "medias.csv", index=False)
    tabla_episodios.to_csv(RESULTADOS / "episodios.csv", index=False)
    comparacion.to_csv(RESULTADOS / "comparacion.csv", index=False)
    ratios.to_csv(RESULTADOS / "ratios.csv", index=False)
    (RESULTADOS / "informe.md").write_text(
        texto_informe(tabla_retornos, tabla_episodios, comparacion, resumen_sector, ratios),
        encoding="utf-8",
    )
    print(f"escrito: {RESULTADOS / 'retornos.csv'} ... informe.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
