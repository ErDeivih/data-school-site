# P49 · Análisis de una empresa y su sector, con ratios — código ejecutable

El proyecto mide una empresa dentro de su sector con datos locales: valida los precios, calcula
retornos logarítmicos y volatilidad, traza dos medias móviles, separa los episodios de mercado que
comparten las ocho empresas y compara la empresa elegida con las de su sector en las mismas sesiones.
Los ratios salen de un segundo CSV con su ejercicio, no de los precios. Es el código que acompaña a la
ficha `../../fichas-ideas/p49-empresa-y-sector-con-ratios.md`.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas >= 2.2** (licencia BSD-3-Clause) y **numpy >= 1.26** (licencia BSD-3-Clause).
- Windows, Linux o macOS: no hay nada específico de la máquina. No hace falta red ni servicios externos.

## Instalación

```powershell
cd proyectos/p49-empresa-y-sector-con-ratios/codigo
python -m pip install -r requirements.txt
```

## Orden de ejecución

```powershell
python analisis.py
```

El programa recorre los siete pasos, imprime una línea por paso y escribe en `resultados/`:
`retornos.csv`, `medias.csv`, `episodios.csv`, `comparacion.csv`, `ratios.csv` e `informe.md`.
Los ficheros de `resultados/` se generan al ejecutar y solo `ejemplo-salida.txt` viaja en el ZIP.

## Cómo se verifica

```powershell
python verificar.py
```

La puerta recalcula las cifras en memoria, sin escribir nada: 4000 filas y 8 empresas de 500 sesiones,
0 claves duplicadas y 0 violaciones de las tres relaciones de precio, volatilidad y retorno anualizado
de `EMP-A`, `ma20`/`ma60` contra la media manual de los últimos cierres, los tres episodios con su
signo, la comparación con `EMP-G` en energía y los ratios del ejercicio 2025 recalculados desde
beneficio y acciones. Termina en `RESULTADO: VERDE` (código 0) o `RESULTADO: ROJO` (código 1). No usa
red. La salida real está en [`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- `datos-ejemplo/precios-empresa.csv`: **4000 filas × 8 columnas** (`fecha`, `empresa`, `sector`,
  `apertura`, `cierre`, `maximo`, `minimo`, `volumen`). Ocho empresas ficticias (`EMP-A`…`EMP-H`) de
  cinco sectores, 500 sesiones cada una, en días laborables del 2025-01-02 al 2026-12-02.
  `sha256:2b01812744dbdc70bd17d2bff85bb4f061c5560993a8fe0c9519eb8af4895e20`.
- `datos-ejemplo/fundamentales-empresa.csv`: **50 filas × 16 columnas**, diez empresas
  (`EMP-A`…`EMP-J`) y cinco ejercicios (2021–2025). Es la fuente de los ratios, no los precios.
  `sha256:e05cdc41668342dac3235cc7d8bd8f1871e355f8f720632ce681641c7b63f3cb`.
- Los dos son **sintéticos, deterministas y CC0-1.0**, copia literal de `datasets/csv/`
  del repositorio; tamaño, checksum y columnas están en
  `datasets-nuevos-2026-11-05.json`.

## Fuente real y licencia

El código es offline por diseño. Para repetir el ejercicio con datos reales:

- **Precios:** `alpha-vantage` (<https://www.alphavantage.co/query>), clave gratuita, EULA de uso
  personal y no comercial; su FAQ da peticiones ilimitadas a proyectos open source o educativos
  verificados. Se sustituye `datos-ejemplo/precios-empresa.csv` por la serie diaria del ticker.
- **Estados financieros:** `sec-edgar` (<https://data.sec.gov/api/xbrl/>), sin clave; contenido del
  Gobierno de EE. UU. reutilizable citando a la SEC. Es la fuente real para contrastar los ratios.
- Dependencias: pandas BSD-3-Clause, numpy BSD-3-Clause.

## Supuestos declarados

- **252 sesiones al año** para anualizar volatilidad y retorno; no se multiplica el retorno medio por
  252 sin componer: se usa `expm1(media_diaria × 252)`.
- **Benchmark del análisis sectorial:** la media de las ocho empresas del CSV, no un índice de mercado.
  Con ocho empresas sintéticas no hay índice real y se dice.
- **Sector de cada empresa:** la columna `sector` del propio CSV. Solo `energia`, `tecnologia` y `salud`
  tienen dos empresas; `consumo` e `industria` tienen una y no se comparan.
- **Ratios:** se calculan con el último ejercicio del segundo CSV (2025) y con el precio de ese mismo
  ejercicio. El PER usa beneficio por acción, no estimaciones; el resto no usa precios.
- **Contraste real con la SEC:** queda fuera del código offline. El informe lo declara y no mezcla
  cifras reales con las sintéticas.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Cargar y validar precios | Qué es una clave natural y por qué se comprueban las bandas | `Calidad de datos` |
| 2 · Retornos y volatilidad | Retorno logarítmico, anualización y desviación típica | `Retornos logarítmicos` |
| 3 · Medias móviles | `rolling` por grupo y por qué dos ventanas no son una tendencia | `Series temporales en pandas` |
| 4 · Episodios comunes | Separar lo que es mercado de lo que es empresa | `Alpha y beta` |
| 5 · Comparación sectorial | Agrupar, unir y comparar con la misma ventana | `Agrupaciones y joins` |
| 6 · Ratios y fuente | Por qué un ratio no se estima desde el precio | `Datos de mercado y acciones corporativas` |
| 7 · Informe y límite | Escribir lo que se puede y lo que no se puede concluir | `Escribir un informe` |

## Estructura

```text
codigo/
├── analisis.py            # los siete pasos: validación, retornos, medias, episodios, sector, ratios
├── verificar.py           # la puerta del proyecto (no escribe ficheros)
├── requirements.txt       # pandas y numpy con versiones mínimas
├── datos-ejemplo/         # los dos CSV CC0-1.0 (copia literal)
└── resultados/
    └── ejemplo-salida.txt # salida real de la puerta
```

## Fallos típicos

- **`ModuleNotFoundError: pandas`**: no has instalado las dependencias; usa el mismo Python que lanza
  los scripts (`python -m pip install -r requirements.txt`).
- **`FileNotFoundError` en el paso 1**: ejecuta desde la carpeta `codigo/` o falta un CSV de
  `datos-ejemplo/`; el ZIP los trae.
- **`KeyError: 'EMP-A'`**: has cambiado el identificador de la empresa elegida; la constante `EMPRESA`
  al principio de `analisis.py` debe existir en los dos CSV.
- **Volatilidad 0 o NaN**: la primera sesión de cada empresa no tiene retorno (no hay cierre previo);
  no se rellena con 0 porque inventaría un día de calma.
- **UnicodeEncodeError al imprimir**: la consola no admite los símbolos; el script fuerza UTF-8 en
  `stdout` y, si tu terminal no lo soporta, redirige la salida a un fichero.
