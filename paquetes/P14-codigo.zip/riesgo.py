"""P14 · El riesgo de una cartera, medido.

Calcula beta frente al índice, volatilidad anualizada, caída máxima, VaR al 95 % y Sharpe con un tipo
libre de riesgo declarado. Sin dependencias.
"""
from __future__ import annotations

import argparse
import csv
import math
import statistics
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("mes", "activo", "retorno")
ACTIVOS = ("indice", "accion-a", "accion-b", "accion-c", "accion-d", "accion-e")
MESES = 60
TIPO_LIBRE = 0.02


def leer(ruta: Path) -> dict[str, list[float]]:
    # Paso 1 · Leer y comprobar el grano: 60 retornos mensuales por activo.
    # Por qué: la beta se calcula emparejando mes a mes; si falta un mes, la covarianza miente.
    # Salida esperada: 360 filas, 6 activos y 60 meses.
    # Si falla: «columnas inesperadas» o «X tiene N meses».
    with ruta.open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    serie = defaultdict(list)
    for fila in filas:
        serie[fila["activo"]].append(float(fila["retorno"]))
    if set(serie) != set(ACTIVOS):
        raise ValueError(f"activos inesperados: {sorted(serie)}")
    for activo, valores in serie.items():
        if len(valores) != MESES:
            raise ValueError(f"{activo} tiene {len(valores)} meses, no {MESES}")
    return dict(serie)


def beta(activo: list[float], indice: list[float]) -> float:
    # Paso 2 · Beta: covarianza con el índice dividida por la varianza del índice.
    # Por qué: la beta dice cuánto se mueve el activo cuando el mercado se mueve 1.
    # Salida esperada: índice 1; acción-a 0,24593; acción-d −0,26710.
    # Si falla: las series no están alineadas mes a mes.
    mx, ma = statistics.mean(indice), statistics.mean(activo)
    cov = sum((x - mx) * (y - ma) for x, y in zip(indice, activo)) / len(activo)
    var = sum((x - mx) ** 2 for x in indice) / len(indice)
    return cov / var


def volatilidad(retornos: list[float]) -> float:
    # Paso 3 · Volatilidad anualizada: desviación típica mensual × sqrt(12).
    # Por qué: la beta no mide el tamaño del riesgo total; la volatilidad sí.
    # Salida esperada: acción-e 21,284 %.
    # Si falla: hay menos de dos retornos.
    return statistics.stdev(retornos) * math.sqrt(12)


def caida_maxima(retornos: list[float]) -> float:
    # Paso 4 · Caída máxima desde un máximo de la serie encadenada.
    # Por qué: dos activos con la misma volatilidad pueden tener caídas muy distintas.
    # Salida esperada: acción-b −48,180 %.
    # Si falla: la serie está vacía.
    valor, pico, peor = 1.0, 1.0, 0.0
    for r in retornos:
        valor *= 1 + r
        pico = max(pico, valor)
        peor = min(peor, valor / pico - 1)
    return peor


def var_95(retornos: list[float]) -> float:
    # Paso 5 · VaR al 95 %: el percentil 5 de los retornos mensuales.
    # Por qué: da una pérdida mensual que se supera el 5 % de los meses, en las unidades del dato.
    # Salida esperada: acción-c −8,82 %.
    # Si falla: hay pocos retornos para el percentil.
    ordenados = sorted(retornos)
    return ordenados[max(0, int(0.05 * len(ordenados)) - 1)]


def sharpe(retornos: list[float], rf: float = TIPO_LIBRE) -> float:
    # Paso 6 · Sharpe: exceso de retorno anualizado por unidad de volatilidad.
    # Por qué: sin descontar el tipo libre de riesgo, el número no es comparable.
    # Salida esperada: acción-e 0,34260 con rf 2 %.
    # Si falla: la volatilidad es 0.
    anual = (math.prod(1 + r for r in retornos)) ** (12 / len(retornos)) - 1
    vol = volatilidad(retornos)
    return (anual - rf) / vol


def main() -> int:
    # Paso 7 · Publicar la tabla de riesgo con el tipo libre de riesgo a la vista.
    # Por qué: beta, volatilidad, caída y VaR responden preguntas distintas; se dan juntos.
    # Salida esperada: 6 activos con beta, vol, caída, VaR95 y Sharpe.
    # Si falla: revisa --csv o el número de meses.
    parser = argparse.ArgumentParser(description="Riesgo de una cartera (P14)")
    parser.add_argument("--csv", default="datos-ejemplo/cartera-acciones.csv")
    parser.add_argument("--rf", type=float, default=TIPO_LIBRE)
    args = parser.parse_args()
    serie = leer(Path(args.csv))
    indice = serie["indice"]
    print(f"activos: {len(serie)} · meses: {MESES} · tipo libre de riesgo: {args.rf:.2%}")
    print("activo      beta   volatilidad   caída máx.   VaR95    Sharpe")
    for activo in ACTIVOS:
        r = serie[activo]
        print(f"{activo:<10} {beta(r, indice):>6.3f} {volatilidad(r):>13.2%} {caida_maxima(r):>13.2%} {var_95(r):>9.2%} {sharpe(r, args.rf):>8.3f}")
    print("límite: retornos mensuales sintéticos; no es una recomendación ni una serie real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
