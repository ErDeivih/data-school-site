# P14 · El riesgo de una cartera, medido

Paquete descargable de **Data School** para el proyecto P14. Incluye la serie de ejemplo, el código
comentado y un verificador. No necesita el repositorio ni conexión.

## Requisitos

- Python 3.10 o superior.
- **No hay dependencias externas** (`requirements.txt` solo lo dice): biblioteca estándar.

## Ejecutar

```bash
python riesgo.py
python riesgo.py --rf 0.03
python verificar.py
```

`riesgo.py` calcula beta frente al índice, volatilidad anualizada, caída máxima, VaR al 95 % y Sharpe con
un tipo libre de riesgo declarado (`--rf`, 2 % por defecto). `verificar.py` sale 0 si todo cuadra.

## Datos

- `datos-ejemplo/cartera-acciones.csv`: **360 filas × 3 columnas** (60 retornos mensuales del índice y
  cinco acciones, 2021–2025). Sintético y **CC0-1.0**; es el `cartera-acciones` del catálogo.

## Salida esperada

```text
activos: 6 · meses: 60 · tipo libre de riesgo: 2.00%
activo      beta   volatilidad   caída máx.   VaR95    Sharpe
indice      1.000         6.66%       -14.24%    -3.40%   -0.500
accion-a    0.246         9.98%       -41.06%    -4.61%   -1.149
...
límite: retornos mensuales sintéticos; no es una recomendación ni una serie real.
```

## Pasos y lecciones

| Paso del código | Qué hace | Lección |
| --- | --- | --- |
| 1 · Grano | `leer` exige 60 meses por activo | validación de datos |
| 2 · Beta | covarianza con el índice / varianza del índice | beta y riesgo sistemático |
| 3 · Volatilidad | desviación mensual × sqrt(12) | volatilidad |
| 4 · Caída máxima | peor momento desde un máximo | drawdown |
| 5 · VaR95 | percentil 5 de los retornos | valor en riesgo |
| 6 · Sharpe | (anual − rf) / volatilidad | ratio de Sharpe |
| 7 · Publicar | tabla de riesgo con el rf a la vista | comunicación |

## Fallos típicos

- **Beta 1 en todos los activos**: se está comparando el índice consigo mismo.
- **Sharpe sin descontar el rf**: el número se infla y no es comparable.
- **VaR positivo**: se ha tomado el percentil 95 en vez del 5.
- **Caída máxima con la serie de precios**: aquí la serie son retornos; hay que encadenarlos.

## Límite

Los retornos son sintéticos y cubren cinco años. Sirven para aprender las medidas de riesgo, no para
valorar una cartera real.
