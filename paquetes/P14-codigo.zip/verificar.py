﻿#!/usr/bin/env python3
"""Puerta del proyecto P14 (riesgo de cartera).

Comprueba grano, beta, volatilidad, caída máxima, VaR95 y Sharpe. Sin escribir en disco. VERDE/ROJO.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import riesgo

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "cartera-acciones.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    serie = riesgo.leer(CSV)
    ok(len(serie) == 6, "hay 6 activos")
    ok(all(len(v) == 60 for v in serie.values()), "cada activo tiene 60 meses")
    ok(sum(len(v) for v in serie.values()) == 360, "el CSV suma 360 filas")

    idx = serie["indice"]
    ok(round(riesgo.beta(idx, idx), 6) == 1.0, "la beta del índice es 1")
    ok(round(riesgo.beta(serie["accion-a"], idx), 5) == 0.24593, "la beta de acción-a es 0,24593")
    ok(round(riesgo.beta(serie["accion-d"], idx), 5) == -0.2671, "la beta de acción-d es −0,26710")

    ok(round(riesgo.volatilidad(serie["accion-e"]), 5) == 0.21284, "la volatilidad de acción-e es 21,284 %")
    ok(riesgo.volatilidad(serie["accion-e"]) > riesgo.volatilidad(idx), "acción-e es más volátil que el índice")
    ok(round(riesgo.caida_maxima(serie["accion-b"]), 5) == -0.4818, "la caída de acción-b es −48,180 %")
    ok(round(riesgo.caida_maxima(serie["accion-d"]), 5) == -0.19193, "la caída de acción-d es −19,193 %")
    ok(round(riesgo.var_95(serie["accion-c"]), 5) == -0.0882, "el VaR95 de acción-c es −8,820 %")
    ok(riesgo.var_95(serie["accion-c"]) < 0, "el VaR95 se expresa como pérdida negativa")

    s = riesgo.sharpe(serie["accion-e"])
    ok(round(s, 5) == 0.34251, "el Sharpe de acción-e con rf 2 % es 0,34251")
    ok(riesgo.sharpe(serie["accion-e"], 0.0) > s, "sin tipo libre de riesgo el Sharpe es mayor")
    ok(riesgo.sharpe(serie["accion-e"], 0.10) < s, "con rf 10 % el Sharpe es menor")

    codigo = (AQUI / "riesgo.py").read_text(encoding="utf-8")
    ok("requests" not in codigo and "http://" not in codigo and "https://" not in codigo, "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(), "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print("RESULTADO: ROJO — hay comprobaciones sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
