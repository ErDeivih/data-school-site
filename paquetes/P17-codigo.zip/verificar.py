#!/usr/bin/env python3
"""Puerta del proyecto P17 (del API de F1 a un lago, sin romper nada).

Comprueba esquema, ingesta idempotente, bruto, cuarentena, actualización de una fila y ausencia de
red/claves. VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import ingesta

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "f1-clasificacion.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    filas = ingesta.leer_csv(CSV)
    ok(len(filas) == 400, "la API simulada trae 400 filas")
    ok(len(filas[0]) == 12, "cada fila tiene 12 columnas")
    ok(len({(f["carrera"], f["piloto"]) for f in filas}) == 400, "la clave (carrera, piloto) es única")
    ok(all(ingesta.validar(f) is None for f in filas), "las 400 filas pasan el esquema")

    tabla, bruto, primera = ingesta.ingerir(filas)
    ok(len(tabla) == 400, "la tabla tiene 400 claves")
    ok(primera["aceptadas"] == 400 and primera["rechazadas"] == 0, "primera carga: 400 aceptadas, 0 rechazadas")
    ok(primera["nuevas"] == 400 and primera["actualizadas"] == 0, "primera carga: 400 nuevas")
    ok(len(bruto["respuestas"]) == 1, "el bruto guarda 1 respuesta")
    ok(len(primera["bruto"]) == 64, "el bruto se identifica por sha256")

    tabla2, bruto2, segunda = ingesta.ingerir(filas, tabla, bruto)
    ok(len(tabla2) == 400, "la tabla sigue con 400 claves")
    ok(segunda["nuevas"] == 0, "segunda carga: 0 filas nuevas")
    ok(segunda["iguales"] == 400, "segunda carga: 400 filas iguales")
    ok(len(bruto2["respuestas"]) == 1, "repetir la misma respuesta no duplica el bruto")
    ok(tabla2 == tabla, "la tabla no cambia al repetir la carga")

    # Esquema: una fila mala no entra y queda en cuarentena con su motivo.
    mala = dict(filas[0])
    mala["posicion_quali"] = "99"
    ok(ingesta.validar(mala) == "posición fuera de 1..20", "posición 99 se rechaza con su motivo")
    mala2 = dict(filas[0]); mala2["compuesto"] = "lluvia"
    ok(ingesta.validar(mala2) == "compuesto desconocido: lluvia", "compuesto desconocido se rechaza")
    mala3 = dict(filas[0]); mala3["vuelta_quali_s"] = "no-es-un-numero"
    ok(ingesta.validar(mala3) == "un número no es un número", "un texto donde va un número se rechaza")
    vacia = {"carrera": "", "piloto": ""}
    ok(ingesta.validar(vacia) == "falta la clave (carrera, piloto)", "sin clave se rechaza")

    tabla3, _, cuarentena = ingesta.ingerir([filas[0], mala, mala2, mala3], {}, {})
    ok(len(tabla3) == 1, "solo entra la fila válida")
    ok(len(cuarentena["cuarentena"]) == 3, "las 3 filas malas van a cuarentena")
    ok(all("motivo" in r for r in cuarentena["cuarentena"]), "cada rechazo lleva motivo")

    # Cambiar una fila actualiza una y conserva las demás.
    cambiada = [dict(f) for f in filas]
    cambiada[0]["puntos"] = str(int(cambiada[0]["puntos"]) + 1)
    tabla4, _, tercera = ingesta.ingerir(cambiada, tabla2, bruto2)
    ok(tercera["nuevas"] == 0 and tercera["actualizadas"] == 1, "cambiar una fila: 0 nuevas y 1 actualizada")
    ok(tabla4[(filas[0]["carrera"], filas[0]["piloto"])]["puntos"] == cambiada[0]["puntos"],
       "la fila actualizada conserva el valor nuevo")

    codigo = (AQUI / "ingesta.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
