"""P17 · Del API de F1 a un lago, sin romper nada.

Simula la respuesta de una API de clasificaciones (el CSV va dentro del paquete para que el
ejercicio funcione sin red), guarda el bruto tal como llegó, valida el esquema, deja una tabla
idempotente por (carrera, piloto) y manda a cuarentena lo que no cumple. Repetir la carga deja 0
filas nuevas: eso es lo que separa una ingesta de un `INSERT` a lo bruto.

Sin dependencias externas: solo la biblioteca estándar. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys as _sys
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("carrera", "piloto", "equipo", "posicion_quali", "vuelta_quali_s",
            "sector1_s", "sector2_s", "sector3_s", "compuesto", "temperatura_c",
            "posicion_final", "puntos")
COMPUESTOS = {"blando", "medio"}
CLAVE = ("carrera", "piloto")


def leer_csv(ruta: Path) -> list[dict]:
    # Paso 1 · Leer el CSV que simula la respuesta de la API.
    # Por qué: el paquete no puede depender de una API real; el CSV es la respuesta congelada y
    # el resto del pipeline es el mismo que se usaría con HTTP.
    # Salida esperada: 400 filas × 12 columnas (20 carreras × 20 pilotos).
    # Si falla: «columnas inesperadas» o el número de filas no cuadra.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 400:
        raise ValueError(f"se esperaban 400 filas, hay {len(filas)}")
    return filas


def validar(fila: dict) -> str | None:
    # Paso 2 · Esquema de la capa de confianza: tipos, rangos, compuesto y clave.
    # Por qué: lo que entra al lago sin validar contamina todos los informes de después.
    # Salida esperada: None para una fila válida; un motivo concreto para una inválida.
    # Si falla: falta una columna, un número no es número o un rango se sale.
    if not fila.get("carrera") or not fila.get("piloto"):
        return "falta la clave (carrera, piloto)"
    try:
        posicion = int(fila["posicion_quali"])
        final = int(fila["posicion_final"])
        for columna in ("vuelta_quali_s", "sector1_s", "sector2_s", "sector3_s", "temperatura_c"):
            float(fila[columna])
        int(fila["puntos"])
    except (ValueError, TypeError):
        return "un número no es un número"
    if not (1 <= posicion <= 20 and 1 <= final <= 20):
        return "posición fuera de 1..20"
    if fila["compuesto"] not in COMPUESTOS:
        return f"compuesto desconocido: {fila['compuesto']}"
    if float(fila["vuelta_quali_s"]) <= 0:
        return "tiempo de vuelta no positivo"
    return None


def ingerir(filas: list[dict], tabla: dict | None = None, bruto: dict | None = None) -> tuple[dict, dict, dict]:
    # Paso 3 · Ingesta idempotente: la tabla se indexa por clave y el bruto por hash de respuesta.
    # Por qué: reintentar la misma respuesta no debe duplicar filas; cambiar una fila, sí actualizarla.
    # Salida esperada: 400 aceptadas y 0 rechazadas con el CSV válido; 0 nuevas en la segunda pasada.
    # Si falla: la tabla no está indexada por clave o el bruto se guarda duplicado.
    tabla = dict(tabla or {})
    bruto = bruto or {"respuestas": {}}
    aceptadas, rechazadas = [], []
    for fila in filas:
        motivo = validar(fila)
        if motivo:
            rechazadas.append({"fila": fila, "motivo": motivo})
            continue
        aceptadas.append(fila)
    payload = json.dumps(aceptadas, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    huella = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    bruto["respuestas"].setdefault(huella, {"filas": len(aceptadas), "sha256": huella})
    nuevas = actualizadas = iguales = 0
    for fila in aceptadas:
        clave = tuple(fila[c] for c in CLAVE)
        if clave not in tabla:
            tabla[clave] = fila
            nuevas += 1
        elif tabla[clave] != fila:
            tabla[clave] = fila
            actualizadas += 1
        else:
            iguales += 1
    resumen = {"recibidas": len(filas), "aceptadas": len(aceptadas), "rechazadas": len(rechazadas),
               "nuevas": nuevas, "actualizadas": actualizadas, "iguales": iguales,
               "bruto": huella, "cuarentena": rechazadas}
    return tabla, bruto, resumen


def main() -> int:
    parser = argparse.ArgumentParser(description="P17 · ingesta idempotente desde una API simulada")
    parser.add_argument("--csv", default="datos-ejemplo/f1-clasificacion.csv")
    parser.add_argument("--bruto", default="", help="ruta donde escribir el bruto JSON")
    args = parser.parse_args()

    filas = leer_csv(Path(args.csv))
    tabla, bruto, primera = ingerir(filas)
    tabla2, bruto2, segunda = ingerir(filas, tabla, bruto)
    if args.bruto:
        Path(args.bruto).write_text(json.dumps(bruto2, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"datos: {primera['recibidas']} filas de la API simulada · {len(tabla)} claves únicas")
    print(f"primera carga: aceptadas {primera['aceptadas']} · rechazadas {primera['rechazadas']} · "
          f"nuevas {primera['nuevas']} · actualizadas {primera['actualizadas']} · iguales {primera['iguales']}")
    print(f"segunda carga: aceptadas {segunda['aceptadas']} · nuevas {segunda['nuevas']} · "
          f"actualizadas {segunda['actualizadas']} · iguales {segunda['iguales']}")
    print(f"bruto: {len(bruto2['respuestas'])} respuesta(s) guardada(s) · hash {primera['bruto'][:16]}…")
    print("esquema: posición 1..20, compuesto blando|medio, tiempos positivos, clave única")
    print("lectura: la segunda carga deja 0 filas nuevas; el bruto conserva la respuesta y la "
          "cuarentena dice por qué se rechazó cada fila.")
    print("límite: API simulada con un CSV congelado; no hay paginación, red, reintentos HTTP ni CDC real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
