# P17 · Del API de F1 a un lago, sin romper nada

Paquete descargable de **Data School** para el proyecto P17. Incluye el CSV que simula la respuesta
de una API, el código comentado paso a paso, el bruto JSON y un verificador. No necesita conexión ni
dependencias.

La pregunta del proyecto no es «cómo llamo a una API», sino cómo se ingiere **sin romper nada**:
guardar el bruto tal como llegó, validar el esquema, dejar una tabla indexada por clave que no se
duplique al repetir la carga y mandar a cuarentena lo que no cumple. Repetir la misma respuesta deja
**0 filas nuevas** y el bruto **no se duplica**.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice. Todo con la biblioteca estándar.
- Windows, Linux o macOS. No hace falta red: la API está simulada con el CSV congelado.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python ingesta.py
python verificar.py
```

Para guardar el bruto JSON:

```bash
python ingesta.py --bruto resultados/bruto.json
```

Desde la carpeta del paquete:

```bash
cd P17-codigo
python ingesta.py --csv datos-ejemplo/f1-clasificacion.csv --bruto resultados/bruto.json
```

## Salida esperada

```text
datos: 400 filas de la API simulada · 400 claves únicas
primera carga: aceptadas 400 · rechazadas 0 · nuevas 400 · actualizadas 0 · iguales 0
segunda carga: aceptadas 400 · nuevas 0 · actualizadas 0 · iguales 400
bruto: 1 respuesta(s) guardada(s) · hash 4640eb4171bee2d0…
esquema: posición 1..20, compuesto blando|medio, tiempos positivos, clave única
lectura: la segunda carga deja 0 filas nuevas; el bruto conserva la respuesta y la cuarentena dice
por qué se rechazó cada fila.
límite: API simulada con un CSV congelado; no hay paginación, red, reintentos HTTP ni CDC real.
```

El bruto completo está en `resultados/bruto.json`; la salida de consola, en
`resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/f1-clasificacion.csv`: **400 filas × 12 columnas**. 20 carreras (`r01`…`r20`) × 20
  pilotos: equipo, posición y tiempo de clasificación, tres sectores, compuesto, temperatura,
  posición final y puntos. Clave `(carrera, piloto)` única.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `f1-clasificacion` del catálogo
  (semilla fija `20261103`). No son datos reales de ninguna carrera.
- `sha256` del fichero: `2cd5b45e02b14ad12bae786880bf4a175cfc8d2a2ea13d286e28384779054a93`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | la respuesta congelada de la API | el pipeline es el mismo sin depender de la red |
| 2 · Validar | tipos, rangos, compuesto, clave | esquema de la capa de confianza |
| 3 · Ingerir | tabla indexada por `(carrera, piloto)` y bruto por hash | idempotencia y capa cruda |
| 4 · Repetir | segunda carga: 0 nuevas, 400 iguales | reintentar no duplica |
| 5 · Cuarentena | filas malas con su motivo | lo rechazado se explica, no se tira |
| 6 · Actualizar | cambiar una fila: 0 nuevas y 1 actualizada | upsert, no append |

## Las tres trampas que el código deja a la vista

1. **Guardar el bruto no es opcional.** Si solo se guarda la tabla, no se puede reprocesar ni
   auditar qué llegó. El bruto se indexa por `sha256` de la respuesta: reintentar la misma no lo
   duplica, cambiarla sí añade una respuesta nueva.
2. **Idempotente no es «lo intento otra vez».** Es una propiedad que se comprueba: segunda carga,
   **0 nuevas y 400 iguales**. Sin esa comprobación, la palabra sobra.
3. **Una fila mala no puede tumbar el lote.** Va a cuarentena con su motivo (`posición fuera de
   1..20`, `compuesto desconocido`, `un número no es un número`); las buenas entran.

## Fallos típicos

- **`ModuleNotFoundError: ingesta`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`**: el CSV no es el del catálogo o se cambió el separador.
- **La segunda carga da 400 nuevas**: la tabla no está indexada por `(carrera, piloto)`.
- **El bruto crece en cada reintento**: se indexa por contenido, no por intento.
- **Todo va a cuarentena**: el esquema se ha endurecido sin actualizar los datos.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P17-codigo/
├── ingesta.py                 # pasos 1–6: validar, ingerir, repetir, cuarentena y upsert
├── verificar.py               # la puerta del proyecto: 25 comprobaciones
├── requirements.txt           # sin dependencias
├── datos-ejemplo/
│   └── f1-clasificacion.csv   # 400 × 12 · sintético, CC0-1.0
└── resultados/
    ├── bruto.json             # la respuesta cruda guardada
    └── ejemplo-salida.txt     # la salida real de una ejecución
```

## Límite

La API está **simulada** con un CSV congelado: no hay paginación, códigos HTTP, reintentos con
backoff ni CDC real. El paquete enseña el **contrato** (bruto, esquema, clave, idempotencia,
cuarentena y upsert), no la operación de un proveedor concreto. Los datos son sintéticos.
