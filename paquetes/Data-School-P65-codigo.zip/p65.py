"""P65 · Compara dos versiones de un modelo sobre los mismos clientes."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

SEMILLA = 65
COLUMNAS = ("antiguedad_meses", "uso_mensual", "reclamaciones")


def leer_clientes(ruta):
    with ruta.open(encoding="utf-8", newline="") as archivo:
        filas = list(csv.DictReader(archivo))
    ids = [fila["id_cliente"] for fila in filas]
    if not filas or any(not valor for valor in ids) or len(ids) != len(set(ids)):
        raise ValueError("El CSV necesita un identificador único por cliente.")
    x = np.array([[float(fila[campo]) for campo in COLUMNAS] for fila in filas])
    y = np.array([int(fila["baja"]) for fila in filas])
    if set(y) != {0, 1} or not np.isfinite(x).all():
        raise ValueError("Revisa las clases y los valores numéricos del CSV.")
    return np.array(ids), x, y


def predecir(x, y, entrenamiento, prueba, regularizacion):
    # El escalado aprende solo de entrenamiento, igual que la regresión.
    modelo = make_pipeline(
        StandardScaler(), LogisticRegression(C=regularizacion, max_iter=1000)
    )
    modelo.fit(x[entrenamiento], y[entrenamiento])
    return modelo.predict(x[prueba])


def alinear(ids, predicciones):
    # Una diferencia de cobertura debe detener la comparación.
    faltantes = set(ids) - predicciones.keys()
    adicionales = predicciones.keys() - set(ids)
    if faltantes or adicionales:
        raise ValueError(
            f"El candidato no cubre la misma muestra: {len(faltantes)} ausentes, "
            f"{len(adicionales)} adicionales."
        )
    return np.array([predicciones[identificador] for identificador in ids])


def comparar(y, referencia, candidato):
    # La precisión balanceada pondera por igual el acierto de cada clase.
    aciertos_ref = referencia == y
    aciertos_cand = candidato == y
    diferencias = aciertos_cand.astype(int) - aciertos_ref
    clases = [np.flatnonzero(y == clase) for clase in (0, 1)]
    base = np.mean([aciertos_ref[indices].mean() for indices in clases])
    nueva = np.mean([aciertos_cand[indices].mean() for indices in clases])

    # Una pareja es el resultado de ambos modelos para el mismo cliente.
    # Remuestreamos por clase para conservar ambas clases en cada réplica.
    azar = np.random.default_rng(SEMILLA)
    replicas = [
        diferencias[azar.choice(indices, size=(5000, len(indices)), replace=True)]
        .mean(axis=1)
        for indices in clases
    ]
    inferior, superior = np.quantile(np.mean(replicas, axis=0), [0.025, 0.975])
    return float(base), float(nueva), float(inferior), float(superior)


def ejecutar(opciones):
    ids, x, y = leer_clientes(opciones.csv)
    # La misma partición queda congelada antes de entrenar las dos versiones.
    entrenamiento, prueba = train_test_split(
        np.arange(len(ids)), test_size=0.30, random_state=SEMILLA, stratify=y
    )
    referencia = predecir(x, y, entrenamiento, prueba, regularizacion=1.0)
    if opciones.caso == "candidato":
        nueva = predecir(x, y, entrenamiento, prueba, regularizacion=0.15)
    elif opciones.caso == "invertido":
        nueva = 1 - referencia
    else:
        nueva = referencia.copy()

    predicciones = dict(zip(ids[prueba], nueva, strict=True))
    if opciones.caso == "sin-id":
        del predicciones[ids[prueba][0]]
    candidato = alinear(ids[prueba], predicciones)
    base, actual, inferior, superior = comparar(y[prueba], referencia, candidato)

    # La tolerancia se fija antes de observar la comparación.
    limite = -opciones.tolerancia
    if superior < limite:
        decision, codigo = "rechazar", 2
    elif inferior >= limite:
        decision, codigo = "aprobar", 0
    else:
        decision, codigo = "revisar", 1
    return {
        "caso": opciones.caso,
        "semilla": SEMILLA,
        "clientes_evaluados": len(prueba),
        "ids_prueba": sorted(ids[prueba].tolist()),
        "precision_balanceada_referencia": base,
        "precision_balanceada_candidato": actual,
        "diferencia": actual - base,
        "intervalo_95": [inferior, superior],
        "tolerancia": opciones.tolerancia,
        "decision": decision,
    }, codigo


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, default=Path(__file__).with_name("clientes-churn.csv"))
    parser.add_argument("--caso", choices=("candidato", "identico", "invertido", "sin-id"),
                        default="candidato")
    parser.add_argument("--tolerancia", type=float, default=0.02)
    parser.add_argument("--salida", type=Path)
    opciones = parser.parse_args()
    if not 0 <= opciones.tolerancia <= 1:
        parser.error("La tolerancia debe estar entre 0 y 1.")

    try:
        informe, codigo = ejecutar(opciones)
    except (OSError, KeyError, ValueError) as error:
        informe, codigo = {"decision": "entrada_invalida", "motivo": str(error)}, 3
    salida = json.dumps(informe, ensure_ascii=False, indent=2)
    if opciones.salida:
        opciones.salida.write_text(salida + "\n", encoding="utf-8")
    print(salida)
    return codigo


if __name__ == "__main__":
    raise SystemExit(main())