# P65 · Detectar regresiones antes de publicar un modelo

Piloto de código comentado para la ficha P65 de Data School. Incluye el CSV sintético
original del portal, clientes-churn, CC0-1.0. El código usa los datos para enseñar
el proceso. Los resultados carecen de validez para clientes reales.

## Ejecutar

Con Python y un entorno virtual activado:

    python -m pip install -r requirements.txt
    python p65.py --caso candidato --salida comparacion.json

El programa escribe el informe y devuelve 0 al aprobar, 1 al pedir revisión,
2 al rechazar y 3 si falta un dato necesario. La tolerancia de ejemplo es 0,02
en la escala 0–1 de precisión balanceada. Se puede fijar antes de comparar
mediante --tolerancia.

| Fase | Dónde está en el código | Lección en Data School |
| --- | --- | --- |
| 1. Congelar la evaluación | ejecutar separa por clase con semilla fija. predecir entrena la transformación y el modelo solo con entrenamiento. | Separación de entrenamiento, validación y prueba (train-val-test). Pipelines de ML (pipelines-de-ml). |
| 2. Comparar versiones | alinear exige los mismos clientes. comparar calcula la precisión balanceada y remuestrea las parejas dentro de cada clase. | Métricas de clasificación (metricas-de-clasificacion). Bootstrap (bootstrap). |
| 3. Decidir y probar | ejecutar compara el intervalo con la tolerancia. main entrega el JSON y devuelve el código de salida. | Vuelve a la rúbrica de P65 y explica qué significa cruzar el umbral. |

## Reproducir los controles

    python p65.py --caso identico
    python p65.py --caso invertido
    python p65.py --caso sin-id

En la ejecución de comprobación, el caso idéntico aprobó con diferencia 0.
El invertido se rechazó y el caso con un identificador ausente devolvió una
entrada inválida. Las dos regularizaciones del caso candidato coincidieron
en las predicciones de los 60 clientes de prueba de este CSV. Usa una validación
separada si quieres elegir otras regularizaciones antes de la prueba final.

Huella SHA-256 del CSV incluido
5290b89e3ecf746e378b01af2e73bb9e39a4297541e5ccbedae19bfc97a9839c