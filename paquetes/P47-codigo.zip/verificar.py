﻿#!/usr/bin/env python3
"""Puerta del proyecto P47 (DAG con reintentos y auditoría).

Comprueba el resultado de verdad, sin escribir nada y sin red: el CSV es el del catálogo (sha256) y
cuadra con la tarea `validar`, el grafo tiene tres tareas sin ciclos y orden topológico, el fallo
transitorio reintenta con espera creciente y el permanente no se reintenta, cada tarea deja auditoría
con tarea, hora, resultado y filas, el embudo por cohorte cuadra y la segunda ejecución es idempotente.

Uso:
    python verificar.py      # 0 si todo cuadra; 1 si algo falla

La salida real de una ejecución está en resultados/ejemplo-salida.txt.
"""
from __future__ import annotations

# La consola de Windows puede estar en cp1252: si la salida lleva flechas o signos Unicode, la puerta
# fallaría al imprimir y no por un error del proyecto. Se fuerza UTF-8 en stdout/stderr.
import sys as _sys
for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

import sys

import dag
import reintentos
import tareas

fallos: list[str] = []
comprobaciones = 0


def ok(condicion: bool, mensaje: str) -> bool:
    global comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos.append(mensaje)
    return condicion


def main() -> int:
    print("== Puerta del proyecto P47 · DAG con reintentos y auditoría ==")

    # Paso 1 · Comprueba el CSV de ejemplo y la tarea de validación
    # Por qué: `validar` es la primera tarea del DAG; si el dato no cuadra, el flujo se detiene con un
    #          error permanente y no se publica nada.
    # Salida esperada: "validar: 2000 filas · 500 usuarios · 4 eventos por usuario · clave única"
    # Si falla: FileNotFoundError → falta datos-ejemplo/eventos-app.csv (el ZIP lo trae).
    df = dag.cargar()
    ok(len(df) == 2000 and df.shape[1] == 6, f"CSV: {len(df)} filas × {df.shape[1]} columnas")
    ok(dag.sha256(dag.DATOS) == "f926f5f961c5a338c4479bfbab9398de8986f57d77fd8becada41bee4c054460",
       "el sha256 del CSV de ejemplo es el de la copia del catálogo")
    validacion = tareas.validar(df)
    ok(validacion == {"filas": 2000, "usuarios": 500},
       f"validar: {validacion['filas']} filas y {validacion['usuarios']} usuarios")
    ok(int(df["evento"].value_counts().get("visita", 0)) == 851
       and int(df["evento"].value_counts().get("compra", 0)) == 74,
       f"eventos: visita {int(df['evento'].value_counts().get('visita', 0))} · "
       f"compra {int(df['evento'].value_counts().get('compra', 0))}")
    try:
        tareas.validar(df.iloc[:-1])
        ok(False, "validar acepta un CSV recortado")
    except reintentos.ErrorPermanente:
        ok(True, "validar rechaza un CSV recortado con error permanente")

    # Paso 2 · Comprueba el grafo: tres tareas, dependencias y orden topológico
    # Por qué: el criterio de la ficha pide dependencias explícitas y ausencia de ciclos; el orden no
    #          se improvisa, se deriva del grafo.
    # Salida esperada: "orden: validar → agregar → publicar"
    # Si falla: "ciclo" → revisa las dependencias declaradas.
    orden = dag.orden_topologico(dag.DAG)
    ok(orden == ["validar", "agregar", "publicar"], f"orden topológico: {orden}")
    try:
        dag.orden_topologico({"a": ["b"], "b": ["a"]})
        ok(False, "un DAG con ciclo no se detecta")
    except ValueError:
        ok(True, "un DAG con ciclo se rechaza")

    # Paso 3 · Comprueba el backoff y el registro del reintento
    # Por qué: el criterio pide espera creciente y registro con intento y error; sin probar el fallo
    #          no se demuestra que el reintento existe.
    # Salida esperada: "espera_backoff 0.1, 0.2, 0.4" y "3 intentos con esperas [0.1, 0.2]"
    # Si falla: esperas no crecientes → revisa base y factor del backoff.
    ok([round(reintentos.espera_backoff(n), 4) for n in (1, 2, 3)] == [0.1, 0.2, 0.4],
       "el backoff dobla la espera en cada intento")
    contador = {"fallos": 2}

    def tarea_transitoria() -> dict:
        if contador["fallos"] > 0:
            contador["fallos"] -= 1
            raise reintentos.ErrorTransitorio("503 simulado")
        return {"filas": 12}

    ejecucion = reintentos.ejecutar_con_reintentos(tarea_transitoria)
    ok(ejecucion["ok"] and len(ejecucion["intentos"]) == 3,
       f"reintento: {len(ejecucion['intentos'])} intentos hasta el éxito")
    ok(ejecucion["esperas"] == [0.1, 0.2], f"esperas aplicadas: {ejecucion['esperas']}")
    ok([intento["resultado"] for intento in ejecucion["intentos"]] ==
       ["FALLO TRANSITORIO", "FALLO TRANSITORIO", "OK"], "el registro de intentos queda completo")

    def tarea_permanente() -> dict:
        raise reintentos.ErrorPermanente("esquema roto")

    try:
        reintentos.ejecutar_con_reintentos(tarea_permanente)
        ok(False, "un error permanente se reintenta")
    except reintentos.ErrorPermanente:
        ok(True, "un error permanente se relanza sin reintentar")

    # Paso 4 · Comprueba el embudo por cohorte con usuarios únicos
    # Por qué: contar eventos en vez de usuarios infla el embudo; el agregado se mide con usuarios
    #          únicos y cuadra con la ficha.
    # Salida esperada: "agregar: orgánico 238 → 220 → 156 → 53 · pago 197 → 179 → 90 → 9"
    # Si falla: pasos o cohortes de menos → revisa los valores de canal y evento.
    agregado = tareas.agregar(df)
    ok(len(agregado) == 12, f"embudo: {len(agregado)} filas (3 cohortes × 4 pasos)")
    por_cohorte = {cohorte: list(grupo["usuarios"]) for cohorte, grupo in agregado.groupby("cohorte")}
    ok(por_cohorte.get("organico") == [238, 220, 156, 53], f"orgánico: {por_cohorte.get('organico')}")
    ok(por_cohorte.get("pago") == [197, 179, 90, 9], f"pago: {por_cohorte.get('pago')}")
    ok(por_cohorte.get("referido") == [65, 63, 45, 12], f"referido: {por_cohorte.get('referido')}")
    ultimo = agregado[agregado["paso"] == "compra"].set_index("cohorte")["tasa_sobre_visita"]
    ok(abs(float(ultimo["organico"]) - 53 / 238) < 1e-4,
       f"conversión orgánica: {float(ultimo['organico']):.4f}")

    # Paso 5 · Comprueba la ejecución completa, la auditoría y la idempotencia
    # Por qué: la auditoría tiene que permitir reconstruir la ejecución (tarea, hora, resultado, filas)
    #          y la segunda pasada tiene que dejar las mismas claves y el mismo contenido.
    # Salida esperada: "auditoría de 3 tareas · publicar con 3 intentos · repetición idéntica"
    # Si falla: menos de 3 entradas o contenido distinto → el DAG no ejecuta el orden o publica mal.
    reloj = lambda: "2026-11-07T00:00:00"
    primera = dag.ejecutar(df, fallos_transitorios=2, reloj=reloj)
    auditoria = primera["auditoria"]
    ok([entrada["tarea"] for entrada in auditoria] == ["validar", "agregar", "publicar"],
       f"auditoría en orden: {[entrada['tarea'] for entrada in auditoria]}")
    ok(all(entrada["hora"] == "2026-11-07T00:00:00" for entrada in auditoria),
       "la auditoría sella la hora de cada tarea")
    ok(all(entrada["resultado"] == "OK" and entrada["filas"] is not None for entrada in auditoria),
       "cada entrada trae resultado y número de filas")
    publicar = [entrada for entrada in auditoria if entrada["tarea"] == "publicar"][0]
    ok(publicar["intentos"] == 3 and publicar["esperas"] == [0.1, 0.2],
       f"publicar: {publicar['intentos']} intentos y esperas {publicar['esperas']}")
    segunda = dag.ejecutar(df, estado=dict(primera["estado"]), reloj=reloj)
    repeticion = dag.comparar_estados(primera["estado"], segunda["estado"])
    ok(len(primera["estado"]) == 12 and repeticion["mismas_claves"] and repeticion["mismo_contenido"],
       f"repetición idempotente: {len(primera['estado'])} claves y contenido idéntico")
    tercera = dag.ejecutar(df, estado={}, reloj=reloj)
    ok(tercera["auditoria"] == dag.ejecutar(df, estado={}, reloj=reloj)["auditoria"],
       "dos ejecuciones con el mismo reloj dejan la misma auditoría")

    # Paso 6 · Comprueba que el código es offline y no lleva secretos
    # Por qué: la puerta se ejecuta sin red y la carpeta se comparte; una descarga escondida rompería
    #          la promesa del README.
    # Salida esperada: "código offline, sin claves"
    # Si falla: aparece una llamada de red o un token en los módulos.
    texto = "\n".join((dag.RAIZ / nombre).read_text(encoding="utf-8")
                      for nombre in ("dag.py", "tareas.py", "reintentos.py"))
    ok(not any(x in texto for x in ("import requests", "import urllib", "import socket",
                                    "urlopen(", "requests.get")),
       "el código no hace peticiones de red")
    ok(not any(x in texto for x in ("ghp_", "github_pat_", "Authorization:")),
       "el código no contiene claves ni cabeceras de autorización")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {len(fallos)} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    sys.exit(main())
