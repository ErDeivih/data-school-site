#!/usr/bin/env python3
"""Reintentos con backoff exponencial y registro de esperas (P47).

La espera se calcula y se registra, pero no se duerme: así la prueba del backoff es rápida y
reproducible. Si se quiere esperar de verdad, se pasa `dormir=time.sleep`.
"""
from __future__ import annotations

from typing import Callable


class ErrorTransitorio(Exception):
    """Fallo que puede resolverse reintentando (timeout, 503, bloqueo temporal)."""


class ErrorPermanente(Exception):
    """Fallo que no se arregla reintentando (esquema roto, dato inválido)."""


def espera_backoff(intento: int, base: float = 0.1, factor: float = 2.0) -> float:
    # Paso 1 · Calcula la espera del intento: base, base·2, base·4…
    # Por qué: reintentar sin espera satura la fuente y no deja que se recupere; el backoff se declara
    #          y se registra para poder auditar la política aplicada.
    # Salida esperada: "espera_backoff(1..3) = [0.1, 0.2, 0.4]"
    # Si falla: espera negativa o cero → revisa base y factor; el primer intento espera `base`.
    if intento < 1:
        raise ValueError("el intento empieza en 1")
    return base * (factor ** (intento - 1))


def ejecutar_con_reintentos(tarea: Callable[[], dict], max_intentos: int = 3,
                            base: float = 0.1, factor: float = 2.0,
                            reloj: Callable[[], str] | None = None,
                            dormir: Callable[[float], None] | None = None) -> dict:
    # Paso 2 · Ejecuta una tarea y la reintenta si el error es transitorio
    # Por qué: se distingue error transitorio de permanente; un esquema roto no se arregla esperando y
    #          se corta al primer intento. Cada intento queda en el registro con su espera.
    # Salida esperada: "tarea 'publicar': 3 intentos · esperas 0.1, 0.2 · resultado OK"
    # Si falla: el error permanente se relanza sin reintentar; el transitorio se agota en max_intentos.
    intentos: list[dict] = []
    esperas: list[float] = []
    for numero in range(1, max_intentos + 1):
        try:
            resultado = tarea()
            intentos.append({"intento": numero, "resultado": "OK",
                             "hora": reloj() if reloj else None})
            print(f"tarea: {numero} intento(s) · esperas {', '.join(str(e) for e in esperas) or 'ninguna'}"
                  f" · resultado OK")
            return {"ok": True, "resultado": resultado, "intentos": intentos, "esperas": esperas}
        except ErrorPermanente:
            intentos.append({"intento": numero, "resultado": "FALLO PERMANENTE",
                             "hora": reloj() if reloj else None})
            print(f"tarea: error permanente en el intento {numero}; no se reintenta")
            raise
        except ErrorTransitorio as exc:
            intentos.append({"intento": numero, "resultado": "FALLO TRANSITORIO",
                             "error": str(exc), "hora": reloj() if reloj else None})
            if numero == max_intentos:
                print(f"tarea: agotados los {max_intentos} intentos con error transitorio")
                return {"ok": False, "resultado": None, "intentos": intentos, "esperas": esperas}
            espera = espera_backoff(numero, base=base, factor=factor)
            esperas.append(espera)
            if dormir is not None:
                dormir(espera)
            print(f"tarea: fallo transitorio en el intento {numero} ({exc}); "
                  f"espera {espera:.2f} s antes del intento {numero + 1}")
    return {"ok": False, "resultado": None, "intentos": intentos, "esperas": esperas}
