#!/usr/bin/env python3
"""Tareas del DAG de P47: validar, agregar y publicar.

Cada tarea recibe datos en memoria y devuelve un resultado; no escribe ficheros: la escritura es del
pipeline. `publicar` es idempotente por clave `(cohorte, paso)` y puede fallar de forma transitoria
para demostrar el reintento.
"""
from __future__ import annotations

import pandas as pd

from reintentos import ErrorPermanente, ErrorTransitorio

PASOS = ["visita", "registro", "activacion", "compra"]
COLUMNAS = ["usuario_id", "fecha", "evento", "canal", "minutos_sesion", "plan"]


def validar(df: pd.DataFrame) -> dict:
    # Paso 3 · Valida el crudo y detiene el flujo si no cuadra
    # Por qué: un fallo de datos no se arregla reintentando; se lanza ErrorPermanente y el DAG no
    #          sigue, en vez de publicar un agregado sobre datos incompletos.
    # Salida esperada: "validar: 2000 filas · 500 usuarios · 4 eventos por usuario · clave única"
    # Si falla: ErrorPermanente con el motivo → el CSV no es el del catálogo o está recortado.
    if list(df.columns) != COLUMNAS:
        raise ErrorPermanente(f"columnas inesperadas: {list(df.columns)}")
    if len(df) != 2000:
        raise ErrorPermanente(f"se esperaban 2000 filas y hay {len(df)}")
    usuarios = df["usuario_id"].nunique()
    if usuarios != 500:
        raise ErrorPermanente(f"se esperaban 500 usuarios y hay {usuarios}")
    por_usuario = df.groupby("usuario_id").size()
    if not bool((por_usuario == 4).all()):
        raise ErrorPermanente("hay usuarios con un número de eventos distinto de 4")
    if df.duplicated(["usuario_id", "fecha"]).sum() != 0:
        raise ErrorPermanente("la clave (usuario_id, fecha) se repite")
    print(f"validar: {len(df)} filas · {usuarios} usuarios · "
          f"{int(por_usuario.iloc[0])} eventos por usuario · clave única")
    return {"filas": len(df), "usuarios": usuarios}


def agregar(df: pd.DataFrame) -> pd.DataFrame:
    # Paso 4 · Agrega el embudo por cohorte con usuarios únicos
    # Por qué: `visita` aparece 851 veces pero son 238 usuarios orgánicos; contar eventos en vez de
    #          usuarios infla el embudo y cambia la tasa de conversión.
    # Salida esperada: "agregar: 3 cohortes × 4 pasos · orgánico 238 → 220 → 156 → 53 (22.3 %)"
    # Si falla: cohortes o pasos de menos → revisa los valores de `canal` y `evento`.
    filas = []
    for cohorte in sorted(df["canal"].unique()):
        usuarios = set(df.loc[df["canal"] == cohorte, "usuario_id"])
        if not usuarios:
            raise ErrorPermanente(f"cohorte sin usuarios: {cohorte}")
        visitantes = len(usuarios)
        for paso in PASOS:
            alcanzan = len(usuarios & set(df.loc[df["evento"] == paso, "usuario_id"]))
            filas.append({"cohorte": cohorte, "paso": paso, "usuarios": alcanzan,
                          "tasa_sobre_visita": round(alcanzan / visitantes, 4)})
    agregado = pd.DataFrame(filas)
    resumen = " · ".join(
        f"{cohorte} " + " → ".join(str(int(x)) for x in grupo["usuarios"])
        for cohorte, grupo in agregado.groupby("cohorte"))
    print(f"agregar: {agregado['cohorte'].nunique()} cohortes × {len(PASOS)} pasos · {resumen}")
    return agregado


def publicar(agregado: pd.DataFrame, estado: dict, fallos_restantes: list[int] | None = None) -> dict:
    # Paso 5 · Publica el agregado por clave, de forma idempotente
    # Por qué: la segunda ejecución no puede duplicar filas; se escribe en un diccionario indexado por
    #          (cohorte, paso), así que repetir sobrescribe la misma clave y el recuento no cambia.
    # Salida esperada: "publicar: 12 filas por clave · estado con 12 claves"
    # Si falla: claves duplicadas → revisa la tupla que hace de clave.
    if fallos_restantes and fallos_restantes[0] > 0:
        fallos_restantes[0] -= 1
        raise ErrorTransitorio("el destino devolvió 503 (fallo simulado declarado)")
    for fila in agregado.itertuples(index=False):
        estado[(fila.cohorte, fila.paso)] = {"usuarios": int(fila.usuarios),
                                             "tasa_sobre_visita": float(fila.tasa_sobre_visita)}
    print(f"publicar: {len(agregado)} filas por clave · estado con {len(estado)} claves")
    return {"filas": len(agregado), "claves": len(estado)}
