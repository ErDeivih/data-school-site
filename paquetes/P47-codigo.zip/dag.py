#!/usr/bin/env python3
"""P47 · Orquestación de flujos: un DAG con reintentos y auditoría.

Código ejecutable del proyecto P47 (ruta datos). Define un grafo de tres tareas (validar, agregar,
publicar), lo ejecuta en orden topológico, reintenta con backoff exponencial un fallo transitorio
declarado y deja auditoría de cada tarea. La segunda ejecución publica por clave y no duplica filas.

Uso:
    python dag.py            # pipeline completo; escribe la auditoría y el embudo en resultados/
    python dag.py limpiar    # borra los resultados generados

Datos: datos-ejemplo/eventos-app.csv (2000 filas × 6 columnas, CC0-1.0; procedencia en el README).
Sin red: solo pandas y la biblioteca estándar.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

import reintentos
import tareas

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "datos-ejemplo" / "eventos-app.csv"
RESULTADOS = RAIZ / "resultados"

DAG = {"validar": [], "agregar": ["validar"], "publicar": ["agregar"]}
GENERADOS = ["dag-auditoria.json", "embudo.csv", "repeticion.json"]


def exigir(condicion: bool, mensaje: str) -> None:
    """Aborta con un mensaje legible; el pipeline devuelve 1 y no deja resultados a medias."""
    if not condicion:
        raise RuntimeError(mensaje)


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def cargar() -> pd.DataFrame:
    # Paso 6 · Carga el CSV y deja la validación de contenido a la tarea `validar`
    # Por qué: cargar y validar son responsabilidades distintas; si el fichero no existe el fallo es
    #          de entorno, y si no cuadra el fallo es de datos (permanente, no se reintenta).
    # Salida esperada: "datos: 2000 filas × 6 columnas · sha256 f926f5f9…"
    # Si falla: FileNotFoundError → ejecuta desde codigo/ o recupera el CSV de datos-ejemplo/.
    exigir(DATOS.exists(), f"no existe el dato de ejemplo: {DATOS}")
    df = pd.read_csv(DATOS)
    print(f"datos: {len(df)} filas × {df.shape[1]} columnas · sha256 {sha256(DATOS)[:8]}…")
    return df


def orden_topologico(dag: dict[str, list[str]] | None = None) -> list[str]:
    # Paso 7 · Calcula el orden de ejecución del grafo y detecta ciclos
    # Por qué: encadenar scripts con `&&` no declara dependencias; el orden se deriva del grafo y un
    #          ciclo se rechaza antes de ejecutar nada.
    # Salida esperada: "orden: validar → agregar → publicar"
    # Si falla: "ciclo" → revisa las dependencias declaradas; el DAG no puede ejecutarse.
    dag = dag or DAG
    pendientes = {tarea: set(dependencias) for tarea, dependencias in dag.items()}
    orden: list[str] = []
    while pendientes:
        listas = [tarea for tarea, dependencias in pendientes.items() if not dependencias]
        if not listas:
            raise ValueError(f"el DAG tiene un ciclo: {sorted(pendientes)}")
        for tarea in sorted(listas):
            orden.append(tarea)
            del pendientes[tarea]
        for dependencias in pendientes.values():
            dependencias.difference_update(listas)
    print("orden: " + " → ".join(orden))
    return orden


def ejecutar(df: pd.DataFrame, estado: dict | None = None, fallos_transitorios: int = 0,
             reloj=None, dormir=None) -> dict:
    # Paso 8 · Ejecuta el DAG en orden y deja auditoría de cada tarea y de cada reintento
    # Por qué: la auditoría no es un log de texto; guarda tarea, hora, resultado, filas e intentos
    #          para poder reconstruir qué pasó. El fallo transitorio es un escenario declarado.
    # Salida esperada: "publicar: fallo transitorio en el intento 1 … espera 0.10 s" y auditoría de 3 tareas
    # Si falla: un ErrorPermanente se relanza y el DAG se detiene antes de publicar nada.
    if estado is None:
        estado = {}
    reloj = reloj or (lambda: datetime.now().isoformat(timespec="seconds"))
    orden = orden_topologico()
    auditoria: list[dict] = []
    contexto: dict = {"estado": estado,
                      "fallos": [fallos_transitorios] if fallos_transitorios else None,
                      "agregado": None}

    def tarea(nombre: str):
        if nombre == "validar":
            return tareas.validar(df)
        if nombre == "agregar":
            contexto["agregado"] = tareas.agregar(df)
            return {"filas": len(contexto["agregado"])}
        return tareas.publicar(contexto["agregado"], estado, contexto["fallos"])

    for nombre in orden:
        hora = reloj()
        ejecucion = reintentos.ejecutar_con_reintentos(
            lambda nombre=nombre: tarea(nombre), reloj=reloj, dormir=dormir)
        resultado = ejecucion["resultado"] or {}
        auditoria.append({"tarea": nombre, "hora": hora,
                          "resultado": "OK" if ejecucion["ok"] else "FALLO",
                          "filas": resultado.get("filas"),
                          "intentos": len(ejecucion["intentos"]),
                          "esperas": ejecucion["esperas"]})
        if not ejecucion["ok"]:
            raise RuntimeError(f"la tarea {nombre} agotó los reintentos")
    return {"auditoria": auditoria, "estado": estado}


def escribir(auditoria: list[dict], estado: dict, repeticion: dict) -> None:
    # Paso 9 · Escribe la auditoría, el embudo publicado y la prueba de repetición
    # Por qué: el entregable es el registro y el agregado; sin ellos no se puede reconstruir la
    #          ejecución ni comprobar que repetir no duplica.
    # Salida esperada: "resultados: dag-auditoria.json, embudo.csv, repeticion.json"
    # Si falla: PermissionError → revisa permisos de resultados/.
    RESULTADOS.mkdir(exist_ok=True)
    (RESULTADOS / "dag-auditoria.json").write_text(
        json.dumps(auditoria, ensure_ascii=False, indent=2), encoding="utf-8")
    with (RESULTADOS / "embudo.csv").open("w", encoding="utf-8", newline="") as fichero:
        escritor = csv.writer(fichero)
        escritor.writerow(["cohorte", "paso", "usuarios", "tasa_sobre_visita"])
        for (cohorte, paso), datos in sorted(estado.items()):
            escritor.writerow([cohorte, paso, datos["usuarios"], datos["tasa_sobre_visita"]])
    (RESULTADOS / "repeticion.json").write_text(
        json.dumps(repeticion, ensure_ascii=False, indent=2), encoding="utf-8")
    print("resultados: dag-auditoria.json, embudo.csv, repeticion.json")


def comparar_estados(antes: dict, despues: dict) -> dict:
    # Paso 10 · Compara dos publicaciones por clave y por contenido
    # Por qué: comprobar solo el número de filas es idempotencia aparente; dos ejecuciones pueden
    #          dejar las mismas filas con contenido distinto. Se comparan las claves y los valores.
    # Salida esperada: "repetición: 12 claves antes y después · contenido idéntico"
    # Si falla: claves o valores distintos → la publicación no es idempotente.
    return {"claves_antes": len(antes), "claves_despues": len(despues),
            "mismas_claves": set(antes) == set(despues),
            "mismo_contenido": antes == despues,
            "filas_antes": sum(1 for _ in antes), "filas_despues": sum(1 for _ in despues)}


def limpiar() -> None:
    # Paso 11 · Borra los resultados generados y deja la carpeta como descargada
    # Por qué: el ZIP no lleva derivados; se regeneran con `python dag.py`.
    # Salida esperada: "limpiar: resultados/ generados borrados"
    # Si falla: PermissionError → cierra el programa que tenga abierto un resultado.
    for nombre in GENERADOS:
        (RESULTADOS / nombre).unlink(missing_ok=True)
    print("limpiar: resultados/ generados borrados")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="DAG con reintentos y auditoría (P47)")
    parser.add_argument("accion", nargs="?", default="todo", choices=["todo", "limpiar"])
    args = parser.parse_args(argv)
    if args.accion == "limpiar":
        limpiar()
        return 0
    try:
        df = cargar()
        primera = ejecutar(df, fallos_transitorios=2)
        segunda = ejecutar(df, estado=dict(primera["estado"]))
        repeticion = comparar_estados(primera["estado"], segunda["estado"])
        exigir(repeticion["mismo_contenido"], "la segunda ejecución cambió el contenido publicado")
        print(f"repetición: {repeticion['claves_antes']} claves antes y "
              f"{repeticion['claves_despues']} después · contenido idéntico")
        escribir(primera["auditoria"] + segunda["auditoria"], segunda["estado"], repeticion)
    except Exception as exc:  # se informa y se devuelve 1; no se sigue con resultados a medias
        print(f"FALLO: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
