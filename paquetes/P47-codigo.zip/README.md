# P47 · Orquestación de flujos: un DAG con reintentos y auditoría — código ejecutable

El proyecto completo sobre el CSV sintético de 2000 eventos de app: define un **DAG de tres tareas**
(`validar`, `agregar`, `publicar`) con dependencias explícitas y sin ciclos, lo ejecuta en orden
topológico, **reintenta con backoff exponencial** un fallo transitorio declarado, deja **auditoría** de
cada tarea (hora, resultado, filas, intentos y esperas) y publica por clave para que la segunda
ejecución **no duplique** filas. Es el código que acompaña a la ficha
`../../fichas-portfolio/p47-dag-con-reintentos.md`.

El resultado que enseña el proyecto: el fallo transitorio de `publicar` se reintenta con esperas
**0,1 s y 0,2 s** y a la tercera va; el embudo por cohorte sale **orgánico 238 → 220 → 156 → 53**,
**pago 197 → 179 → 90 → 9** y **referido 65 → 63 → 45 → 12**; y la segunda pasada deja **las mismas 12
claves con el mismo contenido**, no solo el mismo número de filas.

## Requisitos

- **Python 3.10 o superior** (probado con Python 3.12.10).
- **pandas** (probado con 3.0.6). Se instala en un comando.
- Windows, Linux o macOS. No hace falta red: el CSV viaja en `datos-ejemplo/`.

## Instalación

```powershell
cd proyectos/p47-dag-con-reintentos/codigo
python -m pip install -r requirements.txt
```

`requirements.txt` pide `pandas`, licencia BSD-3-Clause.

## Orden de ejecución

```powershell
python dag.py          # carga, ejecuta el DAG con un fallo simulado, repite y escribe la auditoría
python dag.py limpiar  # borra los resultados generados y deja la carpeta como se descargó
```

La salida esperada de una ejecución es esta:

```text
datos: 2000 filas × 6 columnas · sha256 f926f5f9…
orden: validar → agregar → publicar
validar: 2000 filas · 500 usuarios · 4 eventos por usuario · clave única
tarea: 1 intento(s) · esperas ninguna · resultado OK
agregar: 3 cohortes × 4 pasos · organico 238 → 220 → 156 → 53 · pago 197 → 179 → 90 → 9 · referido 65 → 63 → 45 → 12
tarea: fallo transitorio en el intento 1 (el destino devolvió 503 (fallo simulado declarado)); espera 0.10 s antes del intento 2
tarea: fallo transitorio en el intento 2 (el destino devolvió 503 (fallo simulado declarado)); espera 0.20 s antes del intento 3
publicar: 12 filas por clave · estado con 12 claves
tarea: 3 intento(s) · esperas 0.1, 0.2 · resultado OK
repetición: 12 claves antes y 12 después · contenido idéntico
resultados: dag-auditoria.json, embudo.csv, repeticion.json
```

## Cómo se verifica

```powershell
python verificar.py
```

La puerta comprueba el crudo, que `validar` rechaza un CSV recortado con error permanente, el orden
topológico y la detección de ciclos, el backoff creciente y su registro, que un error permanente no se
reintenta, el embudo por cohorte con usuarios únicos, la auditoría de las tres tareas y la idempotencia
de la segunda ejecución (claves y contenido). No usa red y no escribe nada. Termina en
`RESULTADO: VERDE` (código 0) con **25 comprobaciones**; la salida real está en
[`resultados/ejemplo-salida.txt`](resultados/ejemplo-salida.txt).

## Datos de ejemplo

- [`datos-ejemplo/eventos-app.csv`](datos-ejemplo/eventos-app.csv): **2000 filas × 6 columnas**
  (`usuario_id`, `fecha`, `evento`, `canal`, `minutos_sesion`, `plan`). 500 usuarios × 4 eventos; clave
  `(usuario_id, fecha)` única; 32 días entre 2026-01-02 y 2026-02-02.
- sha256 del fichero:
  `f926f5f961c5a338c4479bfbab9398de8986f57d77fd8becada41bee4c054460`. Es copia literal del conjunto
  de práctica del portal del temario (`web/datos/datasets/eventos-app.csv`), sintético, semilla
  20261111 y licencia **CC0-1.0**: no hay usuarios reales ni producto detrás.

Basta con ese CSV: el proyecto se ejecuta sin descargar nada. Para usar datos propios, se copian en
`datos-ejemplo/` con las mismas columnas o se edita la constante `DATOS` de `dag.py`.

## Fuente real y licencia

- El catálogo no asigna API (`api: []`): el DAG se demuestra **solo con el CSV local**.
- El CSV es sintético; el agregado no describe ninguna app real.
- pandas: licencia BSD-3-Clause.

## Mapa paso → lección

| Paso del código | Qué se aprende | Lección del temario |
| --- | --- | --- |
| 1 · Calcular el backoff | Espera creciente y por qué no reintentar en caliente | Idempotencia y reintentos |
| 2 · Ejecutar con reintentos | Distinguir error transitorio de permanente | Idempotencia y reintentos |
| 3 · Validar el crudo | Un contrato de datos que detiene el flujo | Contratos de datos |
| 4 · Agregar el embudo | Usuarios únicos, no eventos contados | Pandas: agrupaciones y joins |
| 5 · Publicar por clave | Idempotencia de verdad: misma clave, mismo valor | Idempotencia y reintentos |
| 6 · Cargar el CSV | Entrada local y reproducibilidad del ejemplo | ETL frente a ELT |
| 7 · Orden topológico | Dependencias declaradas y detección de ciclos | Orquestación y DAG |
| 8 · Auditar la ejecución | Qué tarea, cuándo, con qué resultado y filas | Observabilidad de datos |
| 9 · Repetir sin duplicar | Comparar claves y contenido, no solo el recuento | Reconciliación y pruebas |
| 10 · Verificador offline | Comprobar sin red y sin escribir | Testing con pytest |

## Estructura

```text
codigo/
├── dag.py                # grafo, orden topológico, ejecución y pipeline
├── tareas.py             # validar, agregar y publicar (idempotente)
├── reintentos.py         # backoff exponencial y registro de intentos
├── verificar.py          # la puerta del proyecto (25 comprobaciones, sin red, sin escribir)
├── requirements.txt      # pandas
├── datos-ejemplo/
│   └── eventos-app.csv   # 2000 × 6 · CC0-1.0
└── resultados/
    └── ejemplo-salida.txt
```

Los ficheros que escribe `python dag.py` (`dag-auditoria.json`, `embudo.csv`, `repeticion.json`) no
viajan en el ZIP: se regeneran.

## Fallos típicos

- **`ModuleNotFoundError: pandas`**: instala con `python -m pip install -r requirements.txt` con el
  mismo intérprete que lanza el DAG.
- **Encadenar scripts con `&&`**: no declara dependencias, no reintenta y no deja auditoría; el orden
  se deriva del grafo.
- **Reintentar errores de datos**: un esquema roto no se arregla esperando; `validar` lanza
  `ErrorPermanente` y el flujo se detiene sin publicar.
- **Reintentar sin espera**: el backoff crece (0,1 s, 0,2 s…) y queda registrado; la prueba no duerme
  de verdad para que sea rápida y reproducible.
- **Idempotencia aparente**: comparar solo el número de filas no basta; se comparan claves y contenido.
- **Contar eventos como usuarios**: `visita` aparece 851 veces; el embudo se mide con usuarios únicos.
- **Auditoría sin decisión**: un log que solo dice «tarea ejecutada» no permite reconstruir el flujo;
  faltan hora, resultado, filas e intentos.
