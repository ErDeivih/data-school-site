# P29 · Streaming: eventos tardíos, ventanas y marcas de agua

Paquete descargable de **Data School** para el proyecto P29. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita el repositorio, ni conexión, ni dependencias.

La pregunta del proyecto es qué pasa cuando el orden de **llegada** no es el orden del **evento**:
cómo se cierran ventanas sin publicar antes de tiempo (marca de agua), qué se hace con lo que llega
tarde y cómo se demuestra que reenviar el mismo fichero no duplica nada. Con este CSV, el flujo
acepta **240 de 240 eventos**, descarta **12 reentregas**, detecta **9 tardíos** y cierra **40
ventanas**; el lote y el flujo cuadran al último decimal.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **No hay dependencias externas**: `requirements.txt` solo lo dice. Todo va con la biblioteca
  estándar de Python.
- Windows, Linux o macOS. No hace falta red.

## Instalación

```bash
python -m pip install -r requirements.txt
```

No instala nada: el fichero existe para que el comando funcione igual que en el resto de paquetes.

## Ejecutar

```bash
python flujo.py
python verificar.py
```

`flujo.py` lee las entregas, comprueba el contrato del evento, las procesa por orden de llegada con
una marca de agua de 2 horas, cierra ventanas de 6 horas, separa los tardíos y reconcilia el
resultado con el lote. `verificar.py` comprueba todo eso y sale 0 si cuadra.

Desde la carpeta del paquete (los datos se buscan en `datos-ejemplo/`):

```bash
cd P29-codigo
python flujo.py --csv datos-ejemplo/eventos-sensor.csv
```

## Salida esperada

```text
datos: 252 filas de flujo · 240 eventos únicos
duplicados descartados: 12 · tardíos: 9
ventanas cerradas: 40 · eventos aceptados: 240
  ventana  0– 6 h · n= 5 · temp media 71.66 °C · presión máx 4.14 bar
  ...
  ventana 150–156 h · n= 6 · temp media 88.58 °C · presión máx 5.31 bar
  ...
reconciliación: 240 de 240 eventos del lote · media 71.4370 vs 71.4370 °C
idempotencia: reprocesar el mismo fichero deja 240 aceptados y 240 eventos únicos (no cambia)
lectura: el flujo no pierde nada, pero 9 eventos llegan tarde y se cuentan aparte; la ventana que ya
se publicó no se reabre, y el lote es quien reconcilia.
límite: datos sintéticos de una planta, una sola clave y 6 horas por ventana; no es un motor real.
```

La salida completa (40 ventanas) está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/eventos-sensor.csv`: **252 entregas** = 240 eventos únicos + 12 reentregas.
  Columnas: `evento_id`, `sensor`, `hora_evento`, `hora_llegada`, `temperatura`, `presion`, `estado`.
  Las lecturas vienen del dataset `sensores-planta` del catálogo (240 horas; episodio de avería entre
  las horas 150 y 168); el paquete añade el tiempo de evento, el de llegada con retrasos
  deterministas y las reentregas.
- **Sintético, determinista y CC0-1.0**: generado a partir del catálogo con reglas fijas. No es
  telemetría real de ninguna planta.
- `sha256` del fichero: `c0e0669ba8ea06fe5ad1c3a2859c8e55d384d195fd2ab6a381886215d552c97d`.
- Nada se descarga en tiempo de ejecución: no hay red, no hay API, no hay claves.

## Qué enseña cada paso

| Paso del código | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida columnas, tiempos y clave `evento_id` | contrato del evento y grano |
| 2 · Ordenar por llegada | procesa por `hora_llegada`, no por `hora_evento` | el orden del flujo no es el del dato |
| 3 · Deduplicar | descarta las reentregas por clave | idempotencia en la entrada |
| 4 · Marca de agua | máximo evento visto − latencia | cuándo una ventana ya no puede cambiar |
| 5 · Ventanas | 6 horas fijas, se publican al cerrarse | agregación por tiempo de evento |
| 6 · Tardíos | cuenta y aparta lo que llega después del cierre | datos tardíos no se tiran en silencio |
| 7 · Reconciliar | ventanas + tardíos contra el lote | exactamente una vez, comprobado |

## Las tres trampas que el código deja a la vista

1. **Ordenar por hora de evento es hacer trampa.** Si se ordena por `hora_evento`, los tardíos
   desaparecen del problema y la marca de agua no se pone a prueba. El código ordena por llegada.
2. **La marca de agua no es un reloj de pared.** Es el máximo tiempo de evento visto menos la
   latencia tolerada; con latencia 2 h, un evento de la hora 100 que llega cuando ya se vio la 105
   está 3 h por detrás de la marca y se cuenta como tardío.
3. **Reprocesar no puede duplicar.** La clave `evento_id` y el conjunto de vistos hacen que reenviar
   el mismo fichero deje 240 aceptados, no 480; el verificador lo comprueba. Además, la ventana ya
   publicada **no se reabre**: el tardío se cuenta aparte y se reconcilia al final.

## Fallos típicos

- **`ModuleNotFoundError: flujo`**: ejecuta desde la carpeta del paquete, no desde su padre.
- **`FileNotFoundError`**: el comando se ha lanzado desde otra carpeta; `--csv` es relativo al
  directorio actual.
- **`columnas inesperadas`**: el CSV no es el del catálogo o se ha abierto con otro separador.
- **`se esperaban 252 filas`**: falta alguna entrega o se ha editado el CSV a mano.
- **Ventanas de más de 6 eventos**: la marca de agua se está calculando después de aceptar el evento.
- **`reconciliación` no cuadra**: se han tirado tardíos sin contarlos o se ha reabierto una ventana.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P29-codigo/
├── flujo.py                   # pasos 1–7: evento, marca de agua, ventanas y reconciliación
├── verificar.py               # la puerta del proyecto: 27 comprobaciones, sin red, sin escribir
├── requirements.txt           # sin dependencias
├── datos-ejemplo/
│   └── eventos-sensor.csv     # 252 entregas (240 eventos + 12 reentregas) · sintético, CC0-1.0
└── resultados/
    └── ejemplo-salida.txt     # la salida real de una ejecución
```

## Límite

Es una planta sintética de una sola clave, ventanas fijas de 6 horas y una latencia de 2 horas; el
motor es un recorrido en memoria, no un sistema distribuido. Enseña el **contrato** (evento, marca de
agua, tardío, idempotencia, reconciliación), no operación real de Kafka/Flink ni garantías de un
proveedor. No hay datos personales ni telemetría real.
