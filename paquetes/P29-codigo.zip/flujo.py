"""P29 · Streaming: eventos tardíos, ventanas y marcas de agua.

Convierte las lecturas de una planta en un flujo de eventos con tiempo de evento y tiempo de
llegada, cierra ventanas con una marca de agua, cuenta los eventos tardíos y demuestra que
reproducir el mismo fichero dos veces no duplica nada (idempotencia) ni cambia el resultado
(reconciliación con el lote).

Sin dependencias externas: solo la biblioteca estándar. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("evento_id", "sensor", "hora_evento", "hora_llegada", "temperatura", "presion", "estado")
VENTANA = 6          # horas por ventana (ventana fija, no deslizante)
LATENCIA = 2          # horas de retraso que la marca de agua tolera antes de cerrar


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer el flujo y comprobar el contrato del evento: clave, tiempos y columnas.
    # Por qué: sin clave única y sin tiempo de evento no hay idempotencia ni ventanas honestas.
    # Salida esperada: 252 filas, 240 eventos únicos y 12 reentregas del mismo evento.
    # Si falla: «columnas inesperadas», un id repetido con datos distintos o una hora no entera.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 252:
        raise ValueError(f"se esperaban 252 filas (240 eventos + 12 reentregas), hay {len(filas)}")
    vistos = {}
    for fila in filas:
        for columna in ("hora_evento", "hora_llegada"):
            int(fila[columna])
        for columna in ("temperatura", "presion"):
            float(fila[columna])
        anterior = vistos.get(fila["evento_id"])
        if anterior is not None and anterior != (fila["hora_evento"], fila["temperatura"], fila["presion"]):
            raise ValueError(f"{fila['evento_id']}: la reentrega trae datos distintos")
        vistos[fila["evento_id"]] = (fila["hora_evento"], fila["temperatura"], fila["presion"])
    if len(vistos) != 240:
        raise ValueError(f"se esperaban 240 eventos únicos, hay {len(vistos)}")
    return filas


def estado_vacio() -> dict:
    return {"vistos": set(), "ventanas": {}, "cerradas": [], "tardios": [], "duplicados": 0,
            "max_evento": None}


def _cerrar(estado: dict, marca: int) -> None:
    # Paso 4 · Cerrar las ventanas cuyo final ya queda por detrás de la marca de agua.
    # Por qué: una ventana no se puede publicar mientras pueda llegar un evento dentro de ella;
    # la marca de agua (máximo tiempo de evento visto − latencia) es la promesa de que ya no llega.
    for inicio in sorted(estado["ventanas"]):
        ventana = estado["ventanas"][inicio]
        if inicio + VENTANA <= marca:
            estado["cerradas"].append(ventana)
            del estado["ventanas"][inicio]


def procesar(filas: list[dict], estado: dict | None = None) -> dict:
    # Pasos 2–5 · Recorrer por orden de LLEGADA, marcar tardíos y cerrar ventanas con la marca de agua.
    # Por qué: el orden de llegada no es el orden del evento; si se ordena por hora_evento se hace
    # trampa y los tardíos desaparecen del problema.
    # Salida esperada: 240 eventos aceptados, 12 duplicados, 30 tardíos y 16 ventanas cerradas.
    # Si falla: la marca de agua se calcula después de aceptar el evento (lo tardío se cuela) o
    # se olvida cerrar las últimas ventanas al terminar el flujo (quedan eventos sin publicar).
    estado = estado or estado_vacio()
    for fila in sorted(filas, key=lambda f: (int(f["hora_llegada"]), f["evento_id"])):
        if fila["evento_id"] in estado["vistos"]:
            estado["duplicados"] += 1
            continue
        evento = int(fila["hora_evento"])
        llegada = int(fila["hora_llegada"])
        marca = None if estado["max_evento"] is None else estado["max_evento"] - LATENCIA
        estado["vistos"].add(fila["evento_id"])
        estado["max_evento"] = evento if estado["max_evento"] is None else max(estado["max_evento"], evento)
        if marca is not None and evento < marca:
            estado["tardios"].append({"evento_id": fila["evento_id"], "hora_evento": evento,
                                      "hora_llegada": llegada, "temperatura": float(fila["temperatura"]),
                                      "presion": float(fila["presion"])})
        else:
            inicio = (evento // VENTANA) * VENTANA
            ventana = estado["ventanas"].setdefault(inicio, {
                "inicio": inicio, "fin": inicio + VENTANA, "n": 0, "suma_temp": 0.0,
                "max_presion": float("-inf"), "tardios_reconciliados": 0,
            })
            ventana["n"] += 1
            ventana["suma_temp"] += float(fila["temperatura"])
            ventana["max_presion"] = max(ventana["max_presion"], float(fila["presion"]))
        _cerrar(estado, estado["max_evento"] - LATENCIA)
    # Al terminar el flujo se cierra lo que quede: un flujo que se para también publica sus ventanas.
    _cerrar(estado, 10 ** 9)
    return estado


def lote(filas: list[dict]) -> dict:
    # Paso 6 · El resultado del lote, para comparar: todos los eventos únicos, sin marca de agua.
    # Por qué: el flujo no puede perder ni inventar; la reconciliación demuestra que cuadra con el lote.
    unicos = {}
    for fila in filas:
        unicos.setdefault(fila["evento_id"], fila)
    ventanas = defaultdict(lambda: {"n": 0, "suma_temp": 0.0})
    for fila in unicos.values():
        inicio = (int(fila["hora_evento"]) // VENTANA) * VENTANA
        ventanas[inicio]["n"] += 1
        ventanas[inicio]["suma_temp"] += float(fila["temperatura"])
    return {"eventos": len(unicos), "ventanas": dict(ventanas),
            "media_temp": sum(float(f["temperatura"]) for f in unicos.values()) / len(unicos)}


def reconciliar(estado: dict, referencia: dict) -> dict:
    # Paso 7 · Cuadrar flujo y lote: los eventos aceptados son ventanas + tardíos; nada perdido.
    # Por qué: un flujo con marca de agua puede tirar tardíos en silencio; aquí se cuentan y se suman.
    en_ventanas = sum(v["n"] for v in estado["cerradas"])
    en_curso = sum(v["n"] for v in estado["ventanas"].values())
    total = en_ventanas + en_curso + len(estado["tardios"])
    media = 0.0
    peso = 0
    for ventana in estado["cerradas"] + list(estado["ventanas"].values()):
        media += ventana["suma_temp"]
        peso += ventana["n"]
    for evento in estado["tardios"]:
        media += evento["temperatura"]
        peso += 1
    return {"aceptados": total, "duplicados": estado["duplicados"], "tardios": len(estado["tardios"]),
            "en_ventanas": en_ventanas + en_curso, "ventanas_cerradas": len(estado["cerradas"]),
            "cuadra": total == referencia["eventos"], "media_temp": media / peso if peso else 0.0,
            "media_lote": referencia["media_temp"]}


def main() -> int:
    parser = argparse.ArgumentParser(description="P29 · streaming con ventanas y marca de agua")
    parser.add_argument("--csv", default="datos-ejemplo/eventos-sensor.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    estado = procesar(filas)
    referencia = lote(filas)
    cuadre = reconciliar(estado, referencia)

    print(f"datos: {len(filas)} filas de flujo · {len(estado['vistos'])} eventos únicos")
    print(f"duplicados descartados: {cuadre['duplicados']} · tardíos: {cuadre['tardios']}")
    print(f"ventanas cerradas: {cuadre['ventanas_cerradas']} · eventos aceptados: {cuadre['aceptados']}")
    for ventana in estado["cerradas"]:
        print(f"  ventana {ventana['inicio']:>2}–{ventana['fin']:>2} h · n={ventana['n']:>2} · "
              f"temp media {ventana['suma_temp'] / ventana['n']:.2f} °C · "
              f"presión máx {ventana['max_presion']:.2f} bar")
    print(f"reconciliación: {cuadre['aceptados']} de {referencia['eventos']} eventos del lote · "
          f"media {cuadre['media_temp']:.4f} vs {cuadre['media_lote']:.4f} °C")
    estado2 = procesar(filas, estado)
    cuadre2 = reconciliar(estado2, referencia)
    print(f"idempotencia: reprocesar el mismo fichero deja {cuadre2['aceptados']} aceptados y "
          f"{len(estado2['vistos'])} eventos únicos (no cambia)")
    print(f"lectura: el flujo no pierde nada, pero {cuadre['tardios']} eventos llegan tarde y se cuentan "
          "aparte; la ventana que ya se publicó no se reabre, y el lote es quien reconcilia.")
    print("límite: datos sintéticos de una planta, una sola clave y 6 horas por ventana; no es un motor real.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
