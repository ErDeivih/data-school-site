#!/usr/bin/env python3
"""Puerta del proyecto P29 (streaming: tardíos, ventanas y marcas de agua).

Comprueba el resultado: contrato del evento, reentregas, detección de tardíos con marca de agua,
cierre de ventanas, reconciliación exacta con el lote e idempotencia al reprocesar el mismo
fichero. No usa red y no escribe en disco.

VERDE (código 0) solo si todo pasa; ROJO (código 1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import flujo

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "eventos-sensor.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def main() -> int:
    # Paso 1 · Contrato del flujo: columnas, eventos únicos y reentregas.
    filas = flujo.leer(CSV)
    ok(len(filas) == 252, "el CSV tiene 252 entregas")
    ok(len(filas[0]) == 7, "el evento tiene 7 columnas")
    ids = [f["evento_id"] for f in filas]
    ok(len(set(ids)) == 240, "hay 240 eventos únicos")
    ok(len(ids) - len(set(ids)) == 12, "hay 12 reentregas del mismo evento")
    ok(all(int(f["hora_llegada"]) >= int(f["hora_evento"]) for f in filas),
       "ninguna entrega llega antes de su hora de evento")

    # Pasos 2–5 · Procesar por orden de llegada con marca de agua y ventanas de 6 horas.
    estado = flujo.procesar(filas)
    ok(len(estado["vistos"]) == 240, "el flujo acepta 240 eventos")
    ok(estado["duplicados"] == 12, "descarta las 12 reentregas")
    ok(len(estado["tardios"]) == 9, "cuenta 9 eventos tardíos")
    ok(len(estado["cerradas"]) == 40, "cierra las 40 ventanas de 6 horas")
    ok(all(v["inicio"] + flujo.VENTANA == v["fin"] for v in estado["cerradas"]),
       "cada ventana es de 6 horas")
    ok(all(1 <= v["n"] <= 6 for v in estado["cerradas"]), "ninguna ventana tiene más de 6 eventos")
    ok([v["inicio"] for v in estado["cerradas"]] == sorted(v["inicio"] for v in estado["cerradas"]),
       "las ventanas se publican en orden")
    ok(any(v["inicio"] == 150 for v in estado["cerradas"]), "la ventana de la avería (150–156 h) se cierra")
    averia = next(v for v in estado["cerradas"] if v["inicio"] == 150)
    ok(averia["suma_temp"] / averia["n"] > 80, "la ventana de la avería supera 80 °C de media")
    ok(all(t["hora_llegada"] - t["hora_evento"] > flujo.LATENCIA for t in estado["tardios"]),
       "todo tardío llegó más tarde que la latencia tolerada")

    # Pasos 6–7 · Reconciliación con el lote: no se pierde ni se inventa nada.
    referencia = flujo.lote(filas)
    ok(referencia["eventos"] == 240, "el lote tiene 240 eventos únicos")
    cuadre = flujo.reconciliar(estado, referencia)
    ok(cuadre["cuadra"], "ventanas + tardíos = 240 eventos del lote")
    ok(cuadre["aceptados"] == 240, "el flujo acepta exactamente 240")
    ok(cuadre["en_ventanas"] == 231, "231 eventos entran en ventanas y 9 quedan como tardíos")
    ok(abs(cuadre["media_temp"] - cuadre["media_lote"]) <= 1e-9, "la media de temperatura cuadra con el lote")

    # Idempotencia: reprocesar el mismo fichero no añade eventos ni cambia el resultado.
    estado2 = flujo.procesar(filas, estado)
    cuadre2 = flujo.reconciliar(estado2, referencia)
    ok(cuadre2["aceptados"] == 240, "reprocesar deja 240 aceptados (no duplica)")
    ok(len(estado2["vistos"]) == 240, "reprocesar deja 240 eventos únicos")
    ok(len(estado2["cerradas"]) == 40, "reprocesar no reabre ni duplica ventanas")
    ok(len(estado2["tardios"]) == 9, "reprocesar no inventa tardíos nuevos")

    # Determinismo: dos ejecuciones limpias dan el mismo resultado.
    ok(flujo.procesar(filas)["vistos"] == estado["vistos"], "el procesamiento es determinista")

    # El código no usa red ni claves.
    codigo = (AQUI / "flujo.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
