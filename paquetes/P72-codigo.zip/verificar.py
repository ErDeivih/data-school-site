#!/usr/bin/env python3
"""Puerta del proyecto P72 (tiendas: ingresos, ticket y dependencia).

Comprueba datos, cifras por tienda, dependencia, día top y ausencia de red/claves.
VERDE (0) solo si todo pasa; ROJO (1) si algo falla.
"""
from __future__ import annotations

import sys as _sys
from pathlib import Path

import tiendas

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

AQUI = Path(__file__).resolve().parent
CSV = AQUI / "datos-ejemplo" / "ventas-mensuales.csv"
fallos = 0
comprobaciones = 0


def ok(condicion, mensaje):
    global fallos, comprobaciones
    comprobaciones += 1
    print(("OK    " if condicion else "FALLO ") + mensaje)
    if not condicion:
        fallos += 1


def cerca(valor, esperado, tolerancia, mensaje):
    ok(abs(valor - esperado) <= tolerancia, f"{mensaje} ({valor:.4f} ≈ {esperado:.4f})")


def main() -> int:
    filas = tiendas.leer(CSV)
    ok(len(filas) == 180, "el CSV tiene 180 días-tienda")
    ok(len({f["tienda"] for f in filas}) == 3, "hay 3 tiendas")
    ok(len({f["fecha"] for f in filas}) == 180, "hay 180 fechas (una fila por fecha)")

    t = tiendas.por_tienda(filas)
    ok(set(t) == {"centro", "sur", "norte"}, "las tiendas son centro, sur y norte")
    cerca(t["centro"]["ingresos"], 65279.56, 0.02, "ingresos de centro")
    cerca(t["centro"]["unidades"], 4892, 0.1, "unidades de centro")
    cerca(t["centro"]["ticket"], 13.34, 0.01, "ticket de centro")
    cerca(t["centro"]["cuota"], 0.339, 0.002, "cuota de centro")
    ok(t["sur"]["ticket"] > t["centro"]["ticket"], "sur tiene mejor ticket que centro")

    dep = tiendas.dependencia(t)
    ok(dep["primera"] == "centro", "la primera tienda es centro")
    cerca(dep["ratio_12"], 1.02, 0.01, "ratio primera/segunda")
    cerca(dep["hhi"], 0.333, 0.003, "HHI de las tres cuotas")
    ok(dep["hhi"] < 0.4, "no hay dependencia extrema de una sola tienda")

    top = tiendas.dia_top(filas)
    ok(top["fecha"] == "2026-05-23" and top["tienda"] == "norte", "día top: 2026-05-23 en norte")
    cerca(top["ingresos"], 1738.51, 0.02, "ingresos del día top")
    ok(top["unidades"] == 119, "unidades del día top")

    codigo = (AQUI / "tiendas.py").read_text(encoding="utf-8")
    ok("http://" not in codigo and "https://" not in codigo and "requests" not in codigo,
       "el código no hace peticiones de red")
    ok("api_key" not in codigo.lower() and "authorization" not in codigo.lower(),
       "el código no contiene claves")

    print(f"\ncomprobaciones: {comprobaciones}")
    if fallos:
        print(f"RESULTADO: ROJO — {fallos} comprobación(es) sin cumplir")
        return 1
    print("RESULTADO: VERDE — todas las comprobaciones pasan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
