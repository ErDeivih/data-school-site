"""P72 · Tiendas: ingresos, ticket y dependencia.

Convierte 180 días-tienda de tres tiendas en una lectura de negocio: cuánto ingresa cada una, cuál
tiene mejor ticket, cuánto depende la empresa de la primera y qué día concentra la caja. Sin librerías.

Sin dependencias externas. Sin red.
"""
from __future__ import annotations

import argparse
import csv
import sys as _sys
from collections import defaultdict
from pathlib import Path

for _flujo in (_sys.stdout, _sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

COLUMNAS = ("fecha", "tienda", "unidades", "ingresos")


def leer(ruta: Path) -> list[dict]:
    # Paso 1 · Leer y validar: 180 filas, unidades e ingresos positivos.
    # Por qué: una fila con ingresos 0 o negativos cambia la media de ticket sin avisar.
    # Salida esperada: 180 filas, una por fecha, con 60 por tienda.
    # Si falla: «columnas inesperadas», unidades negativas o ingresos no numéricos.
    with Path(ruta).open(encoding="utf-8", newline="") as archivo:
        lector = csv.DictReader(archivo)
        if tuple(lector.fieldnames or ()) != COLUMNAS:
            raise ValueError(f"columnas inesperadas: {lector.fieldnames}")
        filas = list(lector)
    if len(filas) != 180:
        raise ValueError(f"se esperaban 180 filas, hay {len(filas)}")
    for fila in filas:
        if int(fila["unidades"]) <= 0 or float(fila["ingresos"]) <= 0:
            raise ValueError("unidades o ingresos no positivos")
    return filas


def por_tienda(filas: list[dict]) -> dict:
    # Paso 2 · Ingresos, unidades, ticket medio y cuota por tienda.
    # Por qué: sumar ingresos sin mirar unidades confunde precio con volumen.
    # Salida esperada: 3 tiendas con sus cuatro cifras.
    # Si falla: una tienda sin filas.
    acumulado = defaultdict(lambda: {"dias": 0, "unidades": 0, "ingresos": 0.0})
    for fila in filas:
        t = acumulado[fila["tienda"]]
        t["dias"] += 1
        t["unidades"] += int(fila["unidades"])
        t["ingresos"] += float(fila["ingresos"])
    if len(acumulado) != 3:
        raise ValueError("se esperaban 3 tiendas")
    total = sum(t["ingresos"] for t in acumulado.values())
    for t in acumulado.values():
        t["ticket"] = t["ingresos"] / t["unidades"]
        t["cuota"] = t["ingresos"] / total
    return dict(acumulado)


def dependencia(tiendas: dict) -> dict:
    # Paso 3 · Cuota de la primera tienda: una sola tienda no debe sostener toda la caja.
    # Por qué: el total puede crecer y la dependencia empeorar al mismo tiempo.
    # Salida esperada: cuota de la primera, ratio primera/segunda y HHI.
    orden = sorted(tiendas.items(), key=lambda kv: kv[1]["ingresos"], reverse=True)
    primera = orden[0]
    segunda = orden[1]
    hhi = sum(t["cuota"] ** 2 for t in tiendas.values())
    return {"primera": primera[0], "cuota_primera": primera[1]["cuota"],
            "ratio_12": primera[1]["ingresos"] / segunda[1]["ingresos"],
            "hhi": hhi, "orden": [nombre for nombre, _ in orden]}


def dia_top(filas: list[dict]) -> dict:
    # Paso 4 · El día con más ingresos, con su tienda y su ticket.
    # Por qué: un pico de un día puede ser una promoción, no una tendencia.
    # Salida esperada: una fila con fecha, tienda e ingresos.
    mejor = max(filas, key=lambda f: float(f["ingresos"]))
    return {"fecha": mejor["fecha"], "tienda": mejor["tienda"],
            "ingresos": float(mejor["ingresos"]), "unidades": int(mejor["unidades"])}


def main() -> int:
    parser = argparse.ArgumentParser(description="P72 · ingresos, ticket y dependencia por tienda")
    parser.add_argument("--csv", default="datos-ejemplo/ventas-mensuales.csv")
    args = parser.parse_args()

    filas = leer(Path(args.csv))
    tiendas = por_tienda(filas)
    dep = dependencia(tiendas)
    top = dia_top(filas)
    print(f"datos: {len(filas)} días-tienda · {len({f['fecha'] for f in filas})} fechas · {len(tiendas)} tiendas")
    print("por tienda:")
    for nombre in dep["orden"]:
        t = tiendas[nombre]
        print(f"  {nombre}: {t['ingresos']:.2f} € · {t['unidades']} uds · ticket {t['ticket']:.2f} € · cuota {t['cuota'] * 100:.1f} %")
    print(f"dependencia: {dep['primera']} aporta el {dep['cuota_primera'] * 100:.1f} % · "
          f"ratio primera/segunda {dep['ratio_12']:.2f} · HHI {dep['hhi']:.3f}")
    print(f"día top: {top['fecha']} · {top['tienda']} · {top['ingresos']:.2f} € · {top['unidades']} unidades")
    print("lectura: el ticket separa precio de volumen; la cuota dice si el total depende de una sola tienda.")
    print("límite: 3 tiendas sintéticas y 60 filas por tienda; no hay costes, margen, devoluciones ni campañas.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
