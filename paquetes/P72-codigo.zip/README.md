# P72 · Tiendas: ingresos, ticket y dependencia

Paquete descargable de **Data School** para el proyecto P72. Incluye el CSV de ejemplo, el código
comentado paso a paso y un verificador. No necesita conexión ni dependencias.

La pregunta del proyecto es de negocio: **¿de qué tienda depende la caja y cuál gana por ticket, no
solo por volumen?** El código separa ingresos, unidades y ticket medio, calcula la cuota de cada
tienda y su concentración (HHI 0,333): la caja está bastante repartida, con centro al 33,9 %, y el
mejor ticket es el de sur (13,51 €) aunque no sea la primera por ingresos.

## Requisitos

- Python **3.10 o superior** (probado con Python 3.12.10).
- **Sin dependencias externas**: `requirements.txt` solo lo dice.
- Windows, Linux o macOS. No hace falta red.

## Ejecutar

```bash
python -m pip install -r requirements.txt
python tiendas.py
python verificar.py
```

Desde la carpeta del paquete:

```bash
cd P72-codigo
python tiendas.py --csv datos-ejemplo/ventas-mensuales.csv
```

## Salida esperada

```text
datos: 180 días-tienda · 180 fechas · 3 tiendas
por tienda:
  centro: 65279.56 € · 4892 uds · ticket 13.34 € · cuota 33.9 %
  sur: 64208.64 € · 4752 uds · ticket 13.51 € · cuota 33.4 %
  norte: 62803.88 € · 4651 uds · ticket 13.50 € · cuota 32.7 %
dependencia: centro aporta el 33.9 % · ratio primera/segunda 1.02 · HHI 0.333
día top: 2026-05-23 · norte · 1738.51 € · 119 unidades
lectura: el ticket separa precio de volumen; la cuota dice si el total depende de una sola tienda.
límite: 3 tiendas sintéticas y 60 filas por tienda; no hay costes, margen, devoluciones ni campañas.
```

La salida real está en `resultados/ejemplo-salida.txt`.

## Datos

- `datos-ejemplo/ventas-mensuales.csv`: **180 filas × 4 columnas** (`fecha`, `tienda`, `unidades`,
  `ingresos`); 60 filas por tienda y una fecha por fila.
- **Sintético, determinista y CC0-1.0**: copia literal del dataset `ventas-mensuales` del catálogo.
- `sha256`: `afa71a0b0ae0189e863247ff5a25f4ebe1836742ac7686f929d6a42565ecf7f6`.

## Qué enseña

| Paso | Qué hace | Qué se aprende |
| ---: | --- | --- |
| 1 · Leer | valida 180 filas y valores positivos | una fila a cero rompe el ticket |
| 2 · Por tienda | ingresos, unidades, ticket y cuota | no confundir volumen con precio |
| 3 · Dependencia | cuota de la primera, ratio y HHI | medir concentración, no intuirla |
| 4 · Día top | el pico con su tienda y ticket | un pico no es una tendencia |

## Las trampas que deja a la vista

1. **Más ingresos no es mejor ticket.** Centro lidera por ingresos (65.279,56 €) pero sur tiene mejor
   ticket (13,51 € frente a 13,34 €); sin separar unidades, la conclusión cambia.
2. **La dependencia se mide.** El HHI (0,333) y el ratio primera/segunda (1,02) dicen que la caja está
   repartida; mirar solo el total lo ocultaría.
3. **Un día top no es una tendencia.** El pico del 23 de mayo en norte (1.738,51 €) necesita contexto
   de campaña o calendario que el CSV no trae.

## Fallos típicos

- **`ModuleNotFoundError: tiendas`**: ejecuta desde la carpeta del paquete.
- **`columnas inesperadas`**: el CSV no es el del catálogo.
- **`se esperaban 3 tiendas`**: falta una tienda o cambió el nombre.
- **`UnicodeEncodeError` en una consola antigua**: el código fuerza UTF-8 al arrancar.

## Estructura

```text
P72-codigo/
├── tiendas.py                 # por tienda, dependencia y día top
├── verificar.py               # 18 comprobaciones
├── requirements.txt
├── datos-ejemplo/ventas-mensuales.csv
└── resultados/ejemplo-salida.txt
```

## Límite

Tres tiendas sintéticas y 60 filas por tienda; no hay costes, margen, devoluciones ni campañas. El
paquete enseña a **leer una caja por tienda**, no a fijar precios.
